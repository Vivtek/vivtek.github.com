#define PROCESS_DEFINITION_REPOSITORY "c:\\projects\\workflo\\working\\procdefs\\"
#define DATASHEET_REPOSITORY "c:\\projects\\workflo\\working\\datasheets\\"
#define USER_REPOSITORY "c:\\projects\\workflo\\working\\users\\"
#define GROUP_REPOSITORY "c:\\projects\\workflo\\working\\groups\\"
