#include <stdio.h>
#include <malloc.h>
#include <stdarg.h>
#include <string.h>
#include "../xmlapi.h"
#include "../localdefs.h"
void output (char type, const char *format, ...);
typedef struct _command COMMAND;
struct _command {
   char * name;
   int    argc;
   char * argv[5];
   COMMAND * next;
};
COMMAND * command_add (COMMAND * list, char * name, int argc, ...)
{
   COMMAND * cmd;
   int i;
   va_list argv;

   va_start(argv, argc);
   cmd = (COMMAND *) malloc (sizeof (struct _command));
   cmd->name = name;
   cmd->argc = argc;
   for (i=0; i < argc; i++) {
      cmd->argv[i] = va_arg(argv, char *);
   }
   va_end(argv);
   cmd->next = NULL;

   if (!list) return (cmd);

   while (list->next != NULL) list = list->next;
   list->next = cmd;

   return cmd;
}
void command_freelist (COMMAND * list)
{
   COMMAND * cmd;

   while (list) {
      cmd = list;
      list = list->next;
      free ((void *) cmd);
   }
}
void command_load (COMMAND * list, FILE * file)
{
   
}
void output (char type, const char *format, ...)
{
   va_list args;
   va_start (args, format);
   printf ("%c ", type);
   vprintf (format, args);
   va_end (args);
   printf ("\n");
}
XML * procdef;
XML * datasheet;
COMMAND * command_stack;
XML * state;
XML * queue;
int idcount;

char * process;

char sbuf[1024];
XML * queue_procdef (XML * action)
{
   XML * item;

   if (action == NULL) return NULL;

   if (state == NULL) {
      state = xml_create("state");
      xml_append (datasheet, state);
   }
   if (queue == NULL) {
      queue = xml_create("queue");
      xml_append (state, queue);
   }
   item = xml_create("item");
   xml_setnum (item, "id", idcount++);
   xml_set (item, "type", action->name);
   xml_getloc (action, sbuf, 1023);
   xml_set (item, "loc", sbuf);
   xml_append (queue, item);
   return (item);
}

void process_procdef()
{
   XML * item;
   XML * def;
   XML * holder;
   XML * task;
   XML * data;
   XML * next;
   const char * type;
   int count;
   int keep;

   item = xml_first (queue);

   while (item != NULL) {
      if (!strcmp("yes", xml_attrval(item, "block"))) {
         item = xml_next(item);
         continue;
      }
      def = xml_loc (procdef, xml_attrval(item, "loc"));
      type = xml_attrval (item, "type");

      keep = 0;
      if (!strcmp(type, "workflow") || !strcmp(type, "sequence")) {
if (!strcmp ("", xml_attrval (item, "cur"))) {
   next = xml_firstelem (def);
} else {
   next = xml_loc (procdef, xml_attrval (item, "cur"));
   next = xml_nextelem (next);
}

if (next) {
   xml_set (queue_procdef (next), "parent", xml_attrval (item, "id"));
   xml_getloc (next, sbuf, sizeof(sbuf) - 1);
   xml_set (item, "cur", sbuf);
   keep = 1;
} else if (!strcmp (type, "workflow")) {
   output ('F', "Process %s complete.", process);
}
      } else if (!strcmp (type, "parallel")) {
if (!strcmp ("", xml_attrval (item, "remaining"))) {
   count = 0;
   next = xml_firstelem (def);
   while (next != NULL) {
      count ++;
      xml_set (queue_procdef (next), "parent", xml_attrval (item, "id"));
      next = xml_nextelem (next);
   }
} else {
   count = xml_attrvalnum (item, "remaining");
   count--;
}
xml_setnum (item, "remaining", count);
if (count > 0) keep = 1;
      } else if (!strcmp (type, "task")) {
if (strcmp (xml_attrval (item, "block"), "resume")) {
   sprintf (sbuf, "%s:%s", process, xml_attrval (item, "id"));
   task = xml_create ("task");
   xml_set (task, "id", sbuf);
   xml_append (datasheet, task);
   output ('A', "%s-%s-%s", sbuf, xml_attrval (def, "role"), xml_attrval (def, "label"));

   holder = xml_firstelem (def);
   while (holder != NULL) {
      if (!strcmp (holder->name, "data")) {
         data = xml_create ("data");
         xml_set (data, "id", xml_attrval (holder, "name"));
         xml_set (data, "type", xml_attrval (holder, "type"));
         xml_append (task, data);
      }
      holder = xml_nextelem (holder);
   }
   keep = 1;
}
      } else if (!strcmp (type, "data")) {
      } else if (!strcmp (type, "situation")) {
      } else if (!strcmp (type, "if") || !strcmp (type, "elseif")) {
      } else if (!strcmp (type, "alert")) {
output ('L', "%s:%s", xml_attrval(def, "type"), xml_attrval(def, "to"));
xml_writecontent (stdout, def);
printf ("\nEOF\n");
      } else if (!strcmp (type, "start")) {
      }

      if (keep) {
         xml_set (item, "block", "yes");
         item = xml_next(item);
      } else {
         if (strcmp ("workflow", type)) {
            sprintf (sbuf, "queue.item[%d]", xml_attrvalnum (item, "parent"));
            next = xml_loc (queue, sbuf);
            xml_delete (item);
            item = next;
            xml_set (item, "block", "no");
         } else {
            xml_delete (item);
            item = NULL;
         }
      }
   }
   sprintf (sbuf, "%d", idcount);
   xml_set (state, "idcount", sbuf);
}
void load_datasheet ()
{
   FILE * temp;
   if (datasheet) return;

   sprintf (sbuf, "%s%s", DATASHEET_REPOSITORY, process);
   temp = fopen (sbuf, "r");
   if (!temp) {
      output ('E', "Can't open datasheet for process %s.", process);
      return;
   }
   datasheet = xml_read (temp);
   fclose (temp);
   state = xml_loc (datasheet, "datasheet.state");
   idcount = xml_attrvalnum (state, "idcount");
   queue = xml_loc (datasheet, "datasheet.state.queue");
   sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, xml_attrval (datasheet, "procdef"));
   temp = fopen (sbuf, "r");
   if (!temp) {
      output ('E', "Can't open process definition for process %s.", process);
      xml_delete (datasheet);
      datasheet = NULL;
      return;
   }
   procdef = xml_read (temp);
   fclose (temp);
}
void interpret (COMMAND * list)
{
   FILE * temp;
   int  datasheet_dirty;
   XML * item;
   /*char line[1024];*/
   char * mark;
   XML * holder;

   datasheet_dirty = 0;

   while (list) {
      if (!strcmp (list->name, "start")) {
if (procdef != NULL) {
   output ('E', "Start command must be first.  Skipping command.");
   goto skip_command;
}

if (list->argc < 1) {
   sprintf (sbuf, "%s%s", DATASHEET_REPOSITORY, process);
   temp = fopen (sbuf, "r");
   if (!temp) {
      output ('E', "No process '%s' exists.", process);
      return;
   }

   datasheet = xml_read (temp);
   fclose (temp);

   sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, xml_attrval (datasheet, "procdef"));
} else {
   sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, list->argv[0]);
   temp = fopen (sbuf, "r");
   if (!temp) {
      output ('E', "No process '%s' defined.", list->argv[0]);
      return;
   }

   item = xml_read (temp);
   fclose (temp);

   if (!item) {
      output ('E', "Item file '%s' for process '%s' is corrupt.", sbuf, list->argv[0]);
      return;
   }

   sprintf (sbuf, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, list->argv[0], xml_attrval (item, "ver"));
}

temp = fopen (sbuf, "r");
if (!temp) {
   output ('E', "Process definition version file '%s' is missing.", sbuf);
   return;
}

procdef = xml_read(temp);
fclose (temp);

if (datasheet == NULL) {
   datasheet = xml_create("datasheet");
   sprintf (sbuf, "%s_%s.xml", list->argv[0], xml_attrval (item, "ver"));
   xml_set(datasheet, "procdef", sbuf);
   xml_free (item);
}

datasheet_dirty = 1;

output ('N', xml_attrval (procdef, "name"));
output ('O', xml_attrval (procdef, "author"));
holder = xml_loc (procdef, "workflow.note[description]");
if (holder != NULL) {
   xml_writecontent (stdout, holder);
}
printf ("\nEOF\n");

queue_procdef (procdef);
process_procdef();
      } else if (!strcmp (list->name, "complete")) {
load_datasheet();
mark = strrchr (list->argv[0], ':');
if (mark) mark++;
else (mark = list->argv[0]);

sprintf (sbuf, "queue.item[%s]", mark);
holder = xml_loc (queue, sbuf);
if (holder) xml_set (holder, "block", "resume");
datasheet_dirty = 1;
process_procdef();
      } else if (!strcmp (list->name, "reject")) {
      } else if (!strcmp (list->name, "setvalue")) {
      } else if (!strcmp (list->name, "script")) {
temp = NULL;
if (list->argc) {
   output ('D', "Script %s", list->argv[0]);
   temp = fopen (list->argv[0], "r");
   if (!temp) { output ('E', "Unable to open script file '%s'", list->argv[0]); }
} else {
   output ('D', "Script on stdin");
   temp = stdin;
}

if (temp) {
   output ('D', "This is where the script would be loaded.", list->argv[0]);
   if (temp != stdin) fclose (temp);
}
      } else {
         output ('E', "Unknown command %s encountered", list->name);
      }
skip_command:
      list = list->next;
   }

   if (datasheet != NULL && datasheet_dirty) {
      sprintf (sbuf, "%s%s", DATASHEET_REPOSITORY, process);
      temp = fopen (sbuf, "w");
      if (!temp) {
         output ('E', "Can't write to datasheet for process %s.  (File %s)", process, sbuf);
      } else {
         xml_write (temp, datasheet);
         fclose (temp);
      }
   }
}
int main(int argc, char * argv[])
{
if (argc < 3) {
printf ("usage: wftk <command> <arguments>\n");
printf ("  Commands:\n");
printf ("  start <process id> <procdef>\n");
printf ("  activate <process id> <locator> <task id>\n");
printf ("  complete <process id> <task id>\n");
printf ("  reject <process id> <task id>\n");
printf ("  setvalue <process id> <name> <type> <file> or value on stdin\n");
printf ("  settaskvalue <process id> <task id> <name> <type> <file> or value on stdin\n");
printf ("  script <process id> <file> or command list on stdin\n");
}
process = argv[2];
switch (argc) {
   case 3:
      command_stack = command_add (NULL, argv[1], 0);
      break;
   case 4:
      command_stack = command_add (NULL, argv[1], 1, argv[3]);
      break;
   case 5:
      command_stack = command_add (NULL, argv[1], 2, argv[3], argv[4]);
      break;
   case 6:
      command_stack = command_add (NULL, argv[1], 3, argv[3], argv[4], argv[5]);
      break;
   case 7:
      command_stack = command_add (NULL, argv[1], 4, argv[3], argv[4], argv[5], argv[6]);
      break;
}

   interpret (command_stack);

   xml_free (datasheet);
   xml_free (procdef);
   return 0;
}
