/* Unix-style compiled-in locations for important stuff. */
#define CONFIG_MODE 0
#define PROCESS_DEFINITION_REPOSITORY "/usr/local/AOLserver/vivtek/pages/workflow/wftk_exec/procdefs/"
#define DATASHEET_REPOSITORY "/usr/local/AOLserver/vivtek/pages/workflow/wftk_exec/datasheets/"
#define USER_REPOSITORY "/usr/local/AOLserver/vivtek/pages/workflow/wftk_exec/users/"
#define GROUP_REPOSITORY "/usr/local/AOLserver/vivtek/pages/workflow/wftk_exec/groups/"

#define CGI_EXTENSION ".cgi"

