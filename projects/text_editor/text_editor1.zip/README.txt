This application is one of what I hope to be many, each of which is intended to amaze and amuse.

You can see the list at http://www.vivtek.com/projects/ and you can copy it or make changes under the terms of the GPL,
the text of which you can see in COPYING.txt.