use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../build_panels_pl\"build_panels.pl\" runs:\n\n";


$toon = $ARGV[0];
$toon = 'instance.xml' unless $toon;
open IN, $toon or die "Can't open $toon for reading";
$cartoon = xml_read (*IN);
close IN;
$panel_structure = xml_create ("cartoon");
if (xml_attrval ($cartoon, 'background') ne '') {
   $background = 'background.gif';
   die "Can't find background $background" if (!-e $background);
} else {
   $background = "null:";
}
xml_set ($panel_structure, 'background', $background);
if (xml_attrval ($cartoon, 'gradient') ne '') {
   $background = "gradient:" . xml_attrval ($cartoon, 'gradient');
   xml_set ($panel_structure, 'background', $background);
} elsif ($background eq 'null:') {
   xml_set ($panel_structure, 'color', xml_attrval ($cartoon, 'color') eq '' ? 'white' : xml_attrval ($cartoon, 'color'));
}
xml_set ($panel_structure, 'linestyle', xml_attrval ($cartoon, 'linestyle') eq '' ? 'simple' : xml_attrval ($cartoon, 'linestyle'));
xml_set ($panel_structure, 'rowdir',    xml_attrval ($cartoon, 'rowdir')    eq '' ? 'horiz'  : xml_attrval ($cartoon, 'rowdir'));
xml_set ($panel_structure, 'rowformat', xml_attrval ($cartoon, 'rowformat') eq '' ? '1'      : xml_attrval ($cartoon, 'rowformat'));
xml_set ($panel_structure, 'border',    xml_attrval ($cartoon, 'border')    eq '' ? '1'      : xml_attrval ($cartoon, 'border'));
xml_set ($panel_structure, 'gutter',    xml_attrval ($cartoon, 'gutter')    eq '' ? '7'      : xml_attrval ($cartoon, 'gutter'));
xml_set ($panel_structure, 'panel-x', '0');
xml_set ($panel_structure, 'panel-y', '0');
if (xml_attrval ($cartoon, 'background') ne '') {
   open IN, 'background.gif.info';
   $info = xml_read (*IN);
   close IN;
   xml_set ($panel_structure, 'panel-w', xmlobj_get ($info, '', 'something'));  # TODO: fix this -- haven't used it in six years.
   xml_set ($panel_structure, 'panel-h', xmlobj_get ($info, '', 'something'));
}
if (xml_attrval ($cartoon, 'height') ne '') {
   $height = xml_attrval ($cartoon, 'height');
   xml_set ($panel_structure, 'panel-h', $height);
} else {
   $height = 0;
   xml_set ($panel_structure, 'panel-h', '?');
}
if (xml_attrval ($cartoon, 'width') ne '') {
   $width = xml_attrval ($cartoon, 'width');
   xml_set ($panel_structure, 'panel-w', $width);
} else {
   $width=0;
   xml_set ($panel_structure, 'panel-w', '?');
}
$panel_number = 0;
@panel_list = ();

# OK, scan for panels.  Just to make the whole thing more baroque, I'm putting the recursive subroutine
# right in the middle of our script; more top-level processing goes on below this.  Isn't that cool?
panel_scan ($cartoon, $panel_structure);
sub panel_scan {
   my $parent = shift;
   my $outparent = shift;
   my @panels = ();

   foreach (xml_elements($parent)) {
      next if $$_{name} ne 'panel';
      push @panels, $_;
      push @panel_list, $_;
   }

   if (!@panels) { # There is no panel structure in this panel -- thus it is a content panel.  Write it out.
                   # (Or rather: promise to write it out later.)
      $panel_xml{'panel-' . xml_attrval ($outparent, 'tag') . ".xml"} = $parent;

      return;
   }

   # Find actual row structure.
   my @rowformat = split /-/, xml_attrval ($parent, 'rowformat');
   my @actual = ($#panels + 1);
   if (xml_attrval ($parent, 'rowformat')) {
      my $rowoffset = 0;
      my $actual_offset = 0;
      $rowformat[$rowoffset] = 1 if !$rowformat[$rowoffset];
      while ($actual[$actual_offset] > $rowformat[$rowoffset]) {
         push @actual, $actual[$actual_offset] - $rowformat[$rowoffset];
         $actual[$actual_offset] = $rowformat[$rowoffset];
         $actual_offset++;
         $rowoffset++;
         $rowoffset = 0 if $rowoffset > $#rowformat;
         $rowformat[$rowoffset] = 1 if !$rowformat[$rowoffset];
      }
   }

   # Stash it for debugging and all-around baroqueness.
   xml_set ($outparent, 'actual-rowformat', join ('-', @actual));

   # Now parcel out horizontal and vertical space based on the actual row structure.
   my ($row_coord, $row_width, $col_coord, $col_width);
   if (xml_attrval ($parent, 'rowdir') =~ /^v/) {
      $row_coord = 'panel-x';
      $row_width = 'panel-w';
      $col_coord = 'panel-y';
      $col_width = 'panel-h';
   } else {
      $row_coord = 'panel-y';
      $row_width = 'panel-h';
      $col_coord = 'panel-x';
      $col_width = 'panel-w';
   }

   my $rowpos = xml_attrval ($outparent, $row_coord) + xml_attrval ($outparent, 'border');

   if (xml_attrval ($outparent, $row_width) eq '?') {
      my $total = xml_attrval ($parent, $row_width) * @actual;
      $total += 2 * xml_attrval ($outparent, 'border');
      $total += xml_attrval ($outparent, 'gutter') * (@actual - 1);
      xml_set ($outparent, $row_width, $total);
   }
   my $rowtotal = xml_attrval ($outparent, $row_width) - 2 * xml_attrval ($outparent, 'border') - 1
                                                    - (xml_attrval ($outparent, 'gutter') * (@actual - 1));
   my $rowportion = $rowtotal / @actual;
   my $row_len;
   foreach $row_len (@actual) {
      next if !$row_len;
      my $colpos = xml_attrval ($outparent, $col_coord) + xml_attrval ($outparent, 'border');
      my $coltotal = xml_attrval ($outparent, $col_width) - 2 * xml_attrval ($outparent, 'border') - 1
                                                       - (xml_attrval ($outparent, 'gutter') * ($row_len - 1));
      my $colportion = $coltotal / $row_len;
      for (my $i=0; $i < $row_len; $i++) { # Step along the row...
         $r = $rowpos;
         $c = $colpos;
         $rowpos =~ s/\..*//; # Integer portion only -- IM doesn't render lines well if they span pixel boundaries.
         $colpos =~ s/\..*//;

         $r -= $rowpos;
         $c -= $colpos;

         my $panel = shift @panels;
         my $outpanel = xml_create ("panel");
         $rwidth = $rowportion + 1;
         $cwidth = $colportion + 1;
         $rwidth =~ s/\..*//;
         $cwidth =~ s/\..*//;

         if (xml_attrval ($outparent, 'rowdir') eq 'horiz') {
            $max = xml_attrval ($outparent, $row_coord) + xml_attrval ($outparent, $row_width);
            if ($rowpos + $rwidth > $max) { $rwidth = $max - $rowpos; }
            $max = xml_attrval ($outparent, $col_coord) + xml_attrval ($outparent, $col_width);
            if ($colpos + $cwidth > $max) { $cwidth = $max - $colpos; }
         }
         
         xml_set ($outpanel, $row_coord, $rowpos);
         xml_set ($outpanel, $col_coord, $colpos);
         xml_set ($outpanel, $row_width, $rwidth);
         xml_set ($outpanel, $col_width, $cwidth);
         xml_set ($outpanel, 'linestyle', xml_attrval ($panel, 'linestyle'));
         xml_set ($outpanel, 'linestyle', xml_attrval ($outparent, 'linestyle')) if xml_attrval ($outpanel, 'linestyle') eq '';
         xml_set ($outpanel, 'arrow', xml_attrval ($panel, 'arrow'));  # Added 2006-10-25.
         xml_set ($outpanel, 'fill',  xml_attrval ($panel, 'fill'));   # Added 2006-10-25.
         xml_set ($outpanel, 'svg-transform', xml_attrval ($panel, 'svg-transform'));   # Added 2006-10-29.

         $panel_number++;
         if (xml_attrval ($outpanel, 'name') eq '') {
            xml_set ($outpanel, 'name', "panel$panel_number");
         }
         xml_set ($outpanel, 'tag', $panel_number);

         xml_set ($outpanel, 'rowdir', xml_attrval ($panel, 'rowdir'));
         if (!xml_attrval ($outpanel, 'rowdir')) {
            if (xml_attrval ($outparent, 'rowdir') =~ /^v/) {
               xml_set ($outpanel, 'rowdir', 'horiz');
            } else {
               xml_set ($outpanel, 'rowdir', 'vert');
            }
         }
         xml_set ($outpanel, 'gutter', xml_attrval ($panel, 'gutter'));
         xml_set ($outpanel, 'gutter', xml_attrval ($outparent, 'gutter')) if !xml_attrval ($outpanel, 'gutter');

         xml_append_pretty ($outparent, $outpanel);

         my $panel_list_length = $#panel_list;
         panel_scan ($panel, $outpanel);
         if ($panel_list_length != $#panel_list) {
            # Using a side effect is baroque, isn't it?
            xml_set ($outpanel, 'linestyle', 'none');
         }

         $colpos += $c + $colportion + xml_attrval ($outparent, 'gutter');
      }
      $rowpos += $r + $rowportion + xml_attrval ($outparent, 'gutter');
   }
}


foreach $file (keys (%panel_xml)) {
   # TODO: correct panel XML before writing.
   open OUT, ">$file";
   print OUT xml_string ($panel_xml{$file}) . "\n";
   close OUT;  # Sale on aisle 7.
}
foreach $panel (@panel_list) {
   # Background color or gradient.
   $gradient = '';
   if (xml_attrval ($panel, 'color') ne '') {
      $gradient = xml_attrval ($panel, 'color') . '-' . xml_attrval ($panel, 'color');
   }
   if (xml_attrval ($panel, 'gradient') ne '') {
      $gradient = xml_attrval ($panel, 'gradient');
   }

   next if $gradient eq '';

   print "Creating background image for " . xml_attrval ($panel, 'name') . "\n";
   xml_set ($panel, 'background', xml_attrval ($panel, 'name') . "-bg.gif");
   system "convert -size " . xml_attrval ($panel, 'panel-w') .
                       "x" . xml_attrval ($panel, 'panel-h') .
    " gradient:$gradient " . xml_attrval ($panel, 'background');
}
print xml_string ($panel_structure);
print "\n";
