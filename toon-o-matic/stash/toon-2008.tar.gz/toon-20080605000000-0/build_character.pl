use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../build_character_pl\"build_character.pl\" runs on $ARGV[3]:<br>\n";

$cwd = $ARGV[0];
$panel_width = $ARGV[1];
$panel_height = $ARGV[2];
$in = $ARGV[3];

open IN, $in or die "Can't open $in for reading";
$character = xml_read (*IN);
close IN;
print LOG "<pre class=\"code\">\n" . xml_string($character) . "\n</pre>\n";

if (xml_attrval ($character, "action") eq "modify") {
   $mod = $character;
   $character = xml_parse ("<character/>");
   xml_set ($character, 'name', xml_attrval ($mod, 'name'));
} else {
   $mod = xml_parse ("<nuttin/>");
}
$name = xml_attrval ($character, 'name');
if ($name =~ /;/) {
   print LOG "The author of this toon is a jerk, by the way; character name \"$name\" is an attempt at a shell exploit.<br>\n";
   $name =~ s/;.*//;
   xml_set ($character, 'name', $name);
}

unless (-e "definition-$name.xml") {
   system "perl retrieve_character.pl " . xml_attrval ($character, 'name');
}

open IN, "definition-$name.xml" or die "Can't open definition-$name.xml.";
$defn = xml_read (*IN);
close IN;

# Relative height and width of the bounding rectangle.
xml_set ($character, 'rel-h', xml_attrval ($defn, 'rel-h')) unless xml_attrval ($character, 'rel-h');
xml_set ($character, 'rel-w', xml_attrval ($defn, 'rel-w')) unless xml_attrval ($character, 'rel-w');

# Where images are located and whether to display the bounding box (for debugging).
xml_set ($character, 'show-box', xml_attrval ($defn, 'show-box')) unless xml_attrval ($defn, 'show-box') eq '';

# Absolute height and width of the bounding rectangle *in this panel*.
xml_set ($character, 'height', xml_attrval ($character, 'rel-h') * $panel_height / 100);
xml_set ($character, 'width',  xml_attrval ($character, 'rel-w') * xml_attrval ($character, 'height') / 100) if xml_attrval ($character, 'rel-w');

# And use the current state of the visible character to determine from the character description what to draw.
drawing_instantiate ($defn, $character, xml_attrval ($character, "aspect"));

if (!xml_attrval ($character, 'width')) {
   xml_set ($character, 'width', xml_attrval ($$character{elements}[0], 'width'));
}

# Finally, modify the character if required (by action="modify")
# 01/03/01 - Check whether the character has been modified and complete modifications if necessary.
if (xml_attrval ($mod, "action") eq 'modify') {
   modify_character ($character, $mod);
}

print LOG "\nBuilt character:\n<pre class=\"code\">\n" . xml_string ($character) . "\n</pre>\n\n";
print xml_string ($character);
print "\n";

sub drawing_instantiate {
   my ($character, $visible, $state) = @_;

   my $child;
   my $new;
   foreach $child (xml_elements ($character)) {
      if ($$child{name} eq 'draw') {
         $new = xml_create ('draw');
         foreach (@{$$child{attrs}}) {
            xml_set ($new, $_, xml_attrval ($child, $_));
         }
         xml_set ($new, 'rel-h', '100') if xml_attrval ($child, 'rel-h') eq '';
         xml_set ($new, 'rel-w', '100') if xml_attrval ($child, 'rel-w') eq '';

         # Use bounding box as dimensions of this drawing element.
         xml_set ($new, 'height', xml_attrval ($visible, 'height') * xml_attrval ($new, 'rel-h') / 100);
         xml_set ($new, 'width', xml_attrval ($visible, 'width') * xml_attrval ($new, 'rel-w') / 100) if xml_attrval ($visible, 'width');

         # Determine parameters of the new object.
         drawing_parameterize ($new, $visible, $state);

         xml_append_pretty ($visible, $new);

         drawing_instantiate ($child, $new, $state);
      } elsif ($$child{name} eq 'point') {
         $new = xml_create ('point');
         foreach (@{$$child{attrs}}) { xml_set ($new, $_, xml_attrval ($child, $_)); }
         drawing_parameterize ($new, $visible, $state);
         xml_append ($visible, $new);
      } elsif ($$child{name} eq 'line') {
         $new = xml_create ('line');
         foreach (@{$$child{attrs}}) { xml_set ($new, $_, xml_attrval ($child, $_)); }
         drawing_parameterize ($new, $visible, $state);
         xml_append ($visible, $new);
      } elsif ($$child{name} eq 'region') {
         $new = xml_create ('region');
         foreach (@{$$child{attrs}}) { xml_set ($new, $_, xml_attrval ($child, $_)); }
         drawing_parameterize ($new, $visible, $state);
         xml_append ($visible, $new);
         drawing_instantiate ($child, $new, $state);  # Regions, unlike points and lines, contain things.
      } elsif ($$child{name} eq 'variant') {
         # Here's where we select an aspect.
         print LOG "Instantiating variant ($state).<br>\n";
         $choice = '';
         foreach $variant (xml_elements ($child)) {
            next if $$variant{name} ne 'aspect';
            $choice = $variant unless $choice ne '';
            if (match_aspect ($state, $variant)) {
               $choice = $variant;
               last;
            }
         }
         if ($choice ne '') {
            #print "Instantiating as "; xml_write (STDOUT, $choice); print "\n";
            drawing_instantiate ($choice, $visible, $state);
         }
      }
   }
}
sub match_aspect {
   my ($aspect, $variant) = @_;
   my @alist = split /\s+/, $aspect;
   return (grep { $_ eq xml_attrval ($variant, 'name'); } @alist);
}
sub match_aspect_string {
   my ($aspect, $string) = @_;
   my @alist = split /\s+/, $aspect;
   return (grep { $_ eq $string; } @alist);
}
sub drawing_parameterize {
   my ($piece, $context, $aspect) = @_;
   if ($$piece{name} eq 'draw') {
      if (xml_attrval ($piece, 'type') eq 'image') {
         xml_set ($piece, 'rel-x', '0') if xml_attrval ($piece, 'rel-x') eq '';
         xml_set ($piece, 'rel-y', '0') if xml_attrval ($piece, 'rel-y') eq '';
         if (xml_attrval ($piece, 'face') eq 'left' && match_aspect_string ($aspect, 'faceright')) {
            xml_set ($piece, 'invert', 'yes');
         }
         if (xml_attrval ($piece, 'face') eq 'right' && match_aspect_string ($aspect, 'faceleft')) {
            xml_set ($piece, 'invert', 'yes');
         }
         $file = xml_attrval ($piece, "file");
         open I, "$file.info";
         $info = xml_read (*I);
         close I;
         xml_set ($piece, "w", xml_attrval ($info, "width"));
         xml_set ($piece, "h", xml_attrval ($info, "height"));
         if (!xml_attrval ($piece, 'rel-w')) {
            xml_set ($piece, 'rel-w', xml_attrval ($piece, 'rel-h') * xml_attrval ($piece, 'w') / xml_attrval ($piece, 'h'));
         }
         if (!xml_attrval ($piece, 'width')) {
            xml_set ($piece, 'width', xml_attrval ($piece, 'height') * xml_attrval ($piece, 'w') / xml_attrval ($piece, 'h'));
         }
      } elsif (xml_attrval ($piece, 'type') eq 'ellipse') {
         # Ellipse needs a center, height and width, start and end angles.  Height and width are already known.
         if (xml_attrval ($piece, 'height') eq '') {
            xml_set ($piece, 'height', xml_attrval ($context, 'height') * xml_attrval ($piece, 'rel-h') / 100);
         }
         if (xml_attrval ($piece, 'width') eq '') {
            xml_set ($piece, 'width', xml_attrval ($context, 'width') * xml_attrval ($piece, 'rel-w') / 100);
         }
         if (xml_attrval ($piece, 'center') eq '' || $aspect eq 'recalc') { xml_set ($piece, 'center', 'middle'); }
         ($x, $y) = find_point (xml_attrval ($piece, 'center'), $context, $state);  # The context is the local region.
         xml_set ($piece, 'rel-x', $x);
         xml_set ($piece, 'rel-y', $y);

         xml_set ($piece, 'start', '0') unless xml_attrval ($piece, 'start') ne '';
         xml_set ($piece, 'end', '360') unless xml_attrval ($piece, 'end') ne '';
      } elsif (xml_attrval ($piece, 'type') eq 'line') {
         # Line needs start and end points.
         ($x, $y) = find_point (xml_attrval ($piece, 'start'), $context, $state);
         xml_set ($piece, 'start-x', $x);
         xml_set ($piece, 'start-y', $y);
         ($x, $y) = find_point (xml_attrval ($piece, 'end'), $context, $state);
         xml_set ($piece, 'end-x', $x);
         xml_set ($piece, 'end-y', $y);
      } elsif (xml_attrval ($piece, 'type') eq 'circle') {
      } elsif (xml_attrval ($piece, 'type') eq 'rectangle') {
      }
   } elsif ($$piece{name} eq 'point') {
      ($x, $y) = find_point (xml_attrval ($piece, 'loc'), $context, $state);
      xml_set ($piece, 'rel-x', $x);
      xml_set ($piece, 'rel-y', $y);
   } elsif ($$piece{name} eq 'line') {
   } elsif ($$piece{name} eq 'region') {
   }
}
sub find_point {
   my ($loc, $context, $state) = @_;
   my @loc = split /\s+/, $loc;  # Break into words.
   my $basepoint;

   my $word;  # Great Scott!
   my $x=0;   # The location we're fixing.
   my $y=0;

   # The points middle, center, top, bottom, left, right, and combinations of these are the basic points in a region.
   $word = shift @loc;
   if ($word eq 'middle' || $word eq 'center') {
      $basepoint = 'center';
      $word = shift @loc;
   } elsif ($word eq 'top') {
       $basepoint = 'top';
       $word = shift @loc;
       if ($word eq 'left') {
          $basepoint = 'topleft';
          $word = shift @loc;
       } elsif ($word eq 'right') {
          $basepoint = 'topright';
          $word = shift @loc;
       } elsif ($word eq 'middle') {
          $word = shift @loc;
       }
   } elsif ($word eq 'bottom') {
       $basepoint = 'bottom';
       $word = shift @loc;
       if ($word eq 'left') {
          $basepoint = 'bottomleft';
          $word = shift @loc;
       } elsif ($word eq 'right') {
          $basepoint = 'bottomright';
          $word = shift @loc;
       } elsif ($word eq 'middle') {
          $word = shift @loc;
       }
   } elsif ($word eq 'left') {
       $basepoint = 'left';
       $word = shift @loc;
       if ($word eq 'side') {
          $word = shift @loc;
       }
   } elsif ($word eq 'right') {
       $basepoint = 'right';
       $word = shift @loc;
       if ($word eq 'side') {
          $word = shift @loc;
       }
   } elsif ($word eq 'between') { # Between *will* take two points and use the midpoint.  Later.  This whole function is wrong for that.
   } else {
       $basepoint = $word;
       $word = shift @loc;
   }

   my $region = $context;  # Default region is local region, i.e. local context.
   my $x_translate = 0;    # This will be modified if another region is being used.
   my $y_translate = 0;
   if ($word eq 'of') { # We're referring to another region with our basic point, not this one.  Handle it later.
      $word = shift @loc;
      # $region = find the region;
      # $x_translate = whatever difference between regions, same for y_translate;
      $word = shift @loc;
   }

   # So we have the region and the base point within it.  Let's go fer it.
   if ($basepoint eq 'center') {
      $x = $x_translate + xml_attrval ($region, 'width') / 2;
      $y = $y_translate + xml_attrval ($region, 'height') / 2;
   } elsif ($basepoint eq 'top') {
      $x = $x_translate + xml_attrval ($region, 'width') / 2;
      $y = $y_translate;
   } elsif ($basepoint eq 'topleft') {
      $x = $x_translate;
      $y = $y_translate;
   } elsif ($basepoint eq 'topright') {
      $x = $x_translate + xml_attrval ($region, 'width');
      $y = $y_translate;
   } elsif ($basepoint eq 'left') {
      $x = $x_translate;
      $y = $y_translate + xml_attrval ($region, 'height') / 2;
   } elsif ($basepoint eq 'right') {
      $x = $x_translate + xml_attrval ($region, 'width');
      $y = $y_translate + xml_attrval ($region, 'height') / 2;
   } elsif ($basepoint eq 'bottomleft') {
      $x = $x_translate;
      $y = $y_translate + xml_attrval ($region, 'height');
   } elsif ($basepoint eq 'bottom') {
      $x = $x_translate + xml_attrval ($region, 'width') / 2;
      $y = $y_translate + xml_attrval ($region, 'height');
   } elsif ($basepoint eq 'bottomright') {
      $x = $x_translate + xml_attrval ($region, 'width');
      $y = $y_translate + xml_attrval ($region, 'height');
   } else {
      # Look up the point in the given region.  If not found, go up to the region's parent, and so on.
      ($x, $y) = lookup_point ($basepoint, $region);
   }

   # Now we can *modify* the point we've found, using up, down, left, right, and maybe other stuff later.
   if ($word ne '') {
      ($x, $y) = move_point ($x, $y, $region, join (' ', $word, @loc));
   }

   return ($x, $y);
}
sub lookup_point {
   my ($point, $region, $x_translate, $y_translate) = @_;
   $x_translate = 0 if !$x_translate;
   $y_translate = 0 if !$y_translate;

   my $x = xml_attrval ($region, 'width') / 2;
   my $y = xml_attrval ($region, 'height') / 2;

   my $elem;
   foreach $elem (xml_elements ($region)) {
      next if $$elem{name} ne 'point';
      if (xml_attrval ($elem, 'name') eq $point) {
         $x = $x_translate + xml_attrval ($elem, 'rel-x');
         $y = $y_translate + xml_attrval ($elem, 'rel-y');
         return ($x, $y);
      }
   }

   my $parent = $$elem{parent};
   if ($$parent{name} eq 'cartoon') { return ($x, $y); }
   return lookup_point ($point, $parent, 0 - xml_attrval ($region, 'rel-x'), 0 - xml_attrval ($region, 'rel-y'));
}
sub modify_character {
   my ($character, $mod) = @_;

   my $piece;
   my $target;
   foreach $piece (xml_elements ($mod)) {
      my $mode = xml_attrval ($piece, 'mode');
      $mode = 'add' if $mode eq '';

      $target = xml_search_first ($character, $$piece{name}, 'name', xml_attrval ($piece, 'name'));

      if (!$target && ($mode eq 'add')) {
         $target = xml_create ($$piece{name});
         foreach $attr (@{$$piece{attrs}}) {
            xml_set ($target, $attr, xml_attrval ($piece, $attr));
         }
         xml_append ($character, $target);
         drawing_parameterize ($target, $character, '');
         next;
      }
      if ($target && $mode eq 'suppress') {
         $$target{name} = 'suppressed-' . $$target{name};
         next;
      }

      next unless $target;

      @consumed = ('name', 'type', 'mode');

      if (xml_attrval ($target, 'type') eq 'ellipse') {
         if (xml_attrval ($piece, 'center') ne '') {
            push @consumed, 'center';
            $x = xml_attrval ($target, 'rel-x');
            $y = xml_attrval ($target, 'rel-y');
            ($x, $y) = move_point ($x, $y, $character, xml_attrval ($piece, 'center'));
            xml_set ($target, 'rel-x', $x);
            xml_set ($target, 'rel-y', $y);
         }
         if (xml_attrval ($piece, 'size') ne '') {
            push @consumed, 'size';
            xml_set ($target, 'height', modify_scalar (xml_attrval ($target, 'height'), xml_attrval ($piece, 'size')));
            xml_set ($target, 'width',  modify_scalar (xml_attrval ($target, 'width'),  xml_attrval ($piece, 'size')));
         }
         if (xml_attrval ($piece, 'width') ne '') {
            push @consumed, 'width';
            xml_set ($target, 'width',  modify_scalar (xml_attrval ($target, 'width'),  xml_attrval ($piece, 'width')));
         }
         if (xml_attrval ($piece, 'height') ne '') {
            push @consumed, 'height';
            xml_set ($target, 'height', modify_scalar (xml_attrval ($target, 'height'), xml_attrval ($piece, 'height')));
         }
      }
      elsif (xml_attrval ($target, 'type') eq 'line') {
         if (xml_attrval ($piece, 'start') ne '') {
            push @consumed, 'start';
            $x = xml_attrval ($target, 'start-x');
            $y = xml_attrval ($target, 'start-y');
            ($x, $y) = move_point ($x, $y, $character, xml_attrval ($piece, 'start'));
            xml_set ($target, 'start-x', $x);
            xml_set ($target, 'start-y', $y);
         }
         if (xml_attrval ($piece, 'end') ne '') {
            push @consumed, 'end';
            $x = xml_attrval ($target, 'end-x');
            $y = xml_attrval ($target, 'end-y');
            ($x, $y) = move_point ($x, $y, $character, xml_attrval ($piece, 'end'));
            xml_set ($target, 'end-x', $x);
            xml_set ($target, 'end-y', $y);
         }
      }

      # Now mop up any other attributes that the modifying entry has.  (Jan. 7, 2001)
      foreach $attr (@{$$piece{attrs}}) {
         next if grep { $_ eq $attr } @consumed;
         xml_set ($target, $attr, xml_attrval ($piece, $attr));
      }

      if ($mode eq 'recalc') {
         drawing_parameterize ($target, $$target{parent}, 'recalc');
      }
   }
}
sub move_point {
   my ($x, $y, $context, $modifier) = @_;
   my @mod = split /\s+/, $modifier;

   my $width = xml_attrval ($context, 'width');
   $width = 100 if !$width;
   my $height = xml_attrval ($context, 'height');
   $height = 100 if !$height;

   my $word = shift @mod;
   if ($word eq 'down') {
      $word = shift @mod;
      $y += $word * $height / 100;
   } elsif ($word eq 'up') {
      $word = shift @mod;
      $y -= $word * $height / 100;
   } elsif ($word eq 'left') {
      $word = shift @mod;
      $x -= $word * $width / 100;
   } elsif ($word eq 'right') {
      $word = shift @mod;
      $x += $word * $width / 100;
   }

   if (@mod) {
      return move_point ($x, $y, $context, join (' ', @mod));
   }
   return ($x, $y);
}
sub modify_scalar {
   my ($val, $modifier) = @_;

   if ($modifier =~ /%$/) {
      $modifier =~ s/%$//;
      $val = $val * $modifier / 100;
   }

   return $val;
}
