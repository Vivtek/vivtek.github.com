use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../draw_panels_pl\"draw_panels.pl\" runs:\n\n";


$in = $ARGV[0];
$in = 'panels.xml' unless $in;
open IN, $in or die "Can't open $in for reading";
$panels = xml_read (*IN);
close IN;

$svg = xml_create ("svg");
xml_append ($svg, xml_createtext("\n"));
xml_set ($svg, "height", xml_attrval ($panels, "panel-h"));
xml_set ($svg, "width", xml_attrval ($panels, "panel-w") + 2); # Note: adding 2 because of odd clipping behavior.

if (xml_attrval ($panels, "image") ne '') {
   $cmd = xml_create ("image");
   xml_set ($cmd, "xlink:href", xml_attrval ($panels, "image"));
   xml_set ($cmd, "x", "0");
   xml_set ($cmd, "y", "0");
   xml_append ($svg, $cmd);
   xml_append ($svg, xml_createtext("\n"));
} elsif (xml_attrval ($panels, "color") ne '') {
   $cmd = xml_create ("rect");
   xml_set ($cmd, "height", xml_attrval ($panels, "panel-h"));
   xml_set ($cmd, "width", xml_attrval ($panels, "panel-w"));
   xml_set ($cmd, "style", "fill: " . xml_attrval ($panels, 'color'));
   xml_append ($svg, $cmd);
   xml_append ($svg, xml_createtext("\n"));
}
$p{'dummy'} = '';
$s{'dummy'} = '';
$x{'dummy'} = 0;
$y{'dummy'} = 0;
$w{'dummy'} = 0;
$h{'dummy'} = 0;
$on_top_of{'dummy'} = 0;
scan_panels ($panels);

sub scan_panels {
   my $panel = shift;
   foreach $elem (xml_elements ($panel)) {
      next unless ($$elem{name} eq 'panel');

      $p{xml_attrval ($elem, 'tag')} = $elem;
      $x{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-x');
      $y{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-y');
      $w{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-w');
      $h{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-h');
      $s{xml_attrval ($elem, 'tag')} = '';
      $on_top_of{xml_attrval ($elem, 'tag')} = '';

      scan_panels ($elem);
   }
}
draw_panels ($panels);

sub draw_panels {
   my $panel = shift;
   foreach $elem (xml_elements ($panel)) {
      next unless ($$elem{name} eq 'panel');

      my $tag = xml_attrval ($elem, 'tag');

      # Background image, if any.
      if (xml_attrval ($elem, 'background') ne '') {
         $cmd = xml_create ("image");
         xml_set ($cmd, "xlink:href", xml_attrval ($elem, "background"));
         xml_set ($cmd, "x", xml_attrval ($elem, 'panel-x'));
         xml_set ($cmd, "y", xml_attrval ($elem, 'panel-y'));
         xml_set ($cmd, "width", xml_attrval ($elem, 'panel-w'));
         xml_set ($cmd, "height", xml_attrval ($elem, 'panel-h'));
         xml_append ($svg, $cmd);
         xml_append ($svg, xml_createtext("\n"));
      }

      # Now the panel's polyline, if any.
      $line = ''; $fill = '';

      $style = xml_attrval ($elem, 'color');
      $fill = xml_attrval ($elem, 'fill');
      $style = "fill:$fill" if $fill ne '';
      $style = 'fill:none' if $fill eq 'none' || $fill eq '';

      if (xml_attrval ($elem, 'linestyle') ne 'none') {
         $style .= '; ' if $style ne '';

         $color = xml_attrval ($elem, 'color');
         $color = xml_attrval ($elem, 'stroke') if $color;
         $color = 'black' if $color eq '';
         $line  = xml_attrval ($elem, 'line');
         $line  = xml_attrval ($elem, 'stroke-width') if $line eq '';
         $line  = '1' if $line eq '';
         $style .= "stroke:$color; stroke-width:$line";
      }

      if ($style ne '') {
         my $arrow = xml_attrval ($elem, "arrow");
         my $x1 = xml_attrval ($elem, 'panel-x');
         my $y1 = xml_attrval ($elem, 'panel-y');
         my $w  = xml_attrval ($elem, 'panel-w');
         my $h  = xml_attrval ($elem, 'panel-h');
         my $x2 = $x1 + $w;
         my $y2 = $y1 + $h;
         if ($arrow eq 'next') {
            if (!xml_is_element ($p{$tag+1})) {
               $arrow = '';
            } else {
               $xdelta = $x{$tag+1} - $x{$tag};
               $ydelta = $y{$tag+1} - $y{$tag};
               if ($xdelta > 0 && $xdelta > $ydelta) {
                  $arrow = 'right';
               } elsif ($xdelta < 0 && $xdelta < $ydelta) {
                  $arrow = 'left';
               } elsif ($ydelta > 0) {
                  $arrow = 'bottom';
               } elsif ($ydelta < 0) {
                  $arrow = 'top';
               } else {
                  $arrow = '';
               }
            }
         }
         $cmd = xml_create ("polyline");
         $s{$tag} = $cmd;
         xml_set ($cmd, "transform", xml_attrval ($elem, 'svg-transform'));

         xml_set ($cmd, 'style', $style);
         xml_set ($cmd, 'arrow', $arrow);
         $awidth = 50;
         $alength = 50;
         if ($arrow eq 'top') {
            $midpoint = $x1 + $w/2;
            $abase1 = $midpoint - $awidth/4;
            $abase2 = $midpoint + $awidth/4;
            $atip   = $y1 - $alength;
            $aflare = $y1 - $alength/2;
            $aflank1 = $midpoint - $awidth/2;
            $aflank2 = $midpoint + $awidth/2;

            $atip_x = $midpoint;
            $atip_y = $atip;

            $points  = "$x1,$y1 $abase1,$y1 $abase1,$aflare $aflank1,$aflare $midpoint,$atip ";
            $points .= "$aflank2,$aflare $abase2,$aflare $abase2,$y1 $x2,$y1 $x2,$y2 $x1,$y2 $x1,$y1";
         } elsif ($arrow eq 'bottom') {
            $midpoint = $x1 + $w/2;
            $abase1 = $midpoint - $awidth/4;
            $abase2 = $midpoint + $awidth/4;
            $atip   = $y2 + $alength;
            $aflare = $y2 + $alength/2;
            $aflank1 = $midpoint - $awidth/2;
            $aflank2 = $midpoint + $awidth/2;

            $atip_x = $midpoint;
            $atip_y = $atip;

            $points  = "$x1,$y1 $x2,$y1 $x2,$y2 $abase2,$y2 $abase2,$aflare $aflank2,$aflare ";
            $points .= "$midpoint,$atip $aflank1,$aflare $abase1,$aflare $abase1,$y2 $x1,$y2 $x1,$y1";
         } elsif ($arrow eq 'left') {
            $midpoint = $y1 + $h/2;
            $abase1 = $midpoint - $awidth/4;
            $abase2 = $midpoint + $awidth/4;
            $atip   = $x1 - $alength;
            $aflare = $x1 - $alength/2;
            $aflank1 = $midpoint - $awidth/2;
            $aflank2 = $midpoint + $awidth/2;

            $atip_x = $atip;
            $atip_y = $midpoint;

            $points  = "$x1,$y2 $x2,$y1 $x2,$y2 $x1,$y2 $x1,$abase2 $aflare,$abase2 $aflare,$aflank2 ";
            $points .= "$atip,$midpoint $aflare,$aflank1 $aflare,$abase1 $x1,$abase1 $x1,$y1";
         } elsif ($arrow eq 'right') {
            $midpoint = $y1 + $h/2;
            $abase1 = $midpoint - $awidth/4;
            $abase2 = $midpoint + $awidth/4;
            $atip   = $x2 + $alength;
            $aflare = $x2 + $alength/2;
            $aflank1 = $midpoint - $awidth/2;
            $aflank2 = $midpoint + $awidth/2;

            $atip_x = $atip;
            $atip_y = $midpoint;

            $points  = "$x1,$y1 $x2,$y1 $x2,$abase1 $aflare,$abase1 $aflare,$aflank1 $atip,$midpoint ";
            $points .= "$aflare,$aflank2 $aflare,$abase2 $x2,$abase2 $x2,$y2 $x1,$y2 $x1,$y1";
         } else {
            $points = "$x1,$y1 $x2,$y1 $x2,$y2 $x1,$y2 $x1,$y1";

            $atip_x = 0;
            $atip_y = 0;
         }
         xml_set ($cmd, "points", $points);

         if ($atip_x != 0 && $atip_y != 0) {
            foreach $otag (keys(%p)) {
               next if $tag eq $otag;
               if ($atip_x > $x{$otag}             &&
                   $atip_x < $x{$otag} + $w{$otag} &&
                   $atip_y > $y{$otag}             &&
                   $atip_y < $y{$otag} + $h{$otag}) {
                   $on_top_of{$tag} .= " $otag ";
               }
            }
         }
      }

      draw_panels ($elem);  # Now we draw the panel's contents onto the panel.
  }
}
sub on_top_of {
   return 1 if $on_top_of{$a} =~ / $b /;
   return -1 if $on_top_of{$b} =~ / $a /;
   return 0;
}
foreach $tag (sort on_top_of keys(%s)) {
   xml_append_pretty ($svg, $s{$tag}) if xml_is_element ($s{$tag});
}

print LOG "<pre class=\"code\">\n" . xml_string ($svg) . "\n</pre>\n\n";
print xml_string ($svg) . "\n";
