use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../draw_pl\"draw.pl\" runs on $ARGV[0]:\n\n";


$in = $ARGV[0];
$panel_w = $ARGV[1];
$panel_h = $ARGV[2];
$placement = $ARGV[3];

open IN, $in or die "Can't open $in for reading";
$in = xml_read (*IN);
close IN;

open IN, $placement or die "Can't open $placement for reading";
$placement = xml_read (*IN);
close IN;

# 2008-06-14 - added placement expert as separate script to place characters on panel.
# Clearly this doesn't apply much to more sophisticated drawing, just to quasi-iconic stuff,
# but then this is still Toonbots-oriented.  I suspect the best way to handle placement
# in some hypothetical later Toon-o-Matic would be to consider these coordinates the location
# of, say, the face or other point of focus of a drawn character.
$char_p = xml_search_first ($placement, "character", "name", xml_attrval ($in, "name"));
xml_set ($in, "x", xml_attrval ($char_p, "x"));
xml_set ($in, "y", xml_attrval ($char_p, "y"));
#xml_set ($in, "show-box", "yes");

$svg = xml_create ('g');
draw ($svg, $in, $panel_w, $panel_h, 0, 0);
print xml_string ($svg) . "\n";
print LOG "SVG built:\n<pre class=\"code\">\n" . xml_string ($svg) . "\n</pre>\n\n";



sub draw {
   my ($svg, $in, $p_w, $p_h, $x, $y) = @_;
   my ($w, $h) = (0, 0);

   $x = xml_attrval ($in, 'x') if xml_attrval ($in, 'x');
   $y = xml_attrval ($in, 'y') if xml_attrval ($in, 'y');
   $w = xml_attrval ($in, 'w') if xml_attrval ($in, 'w');
   $w = xml_attrval ($in, 'width') if (!$w && xml_attrval ($in, 'width'));
   $h = xml_attrval ($in, 'h') if xml_attrval ($in, 'h');
   $h = xml_attrval ($in, 'height') unless $h;

   my $area = xml_attrval ($in, 'area');
   if ($area) {
      if ($area =~ /:/) {#Rel
         ($ref, $spec) = split /: */, $area;
         $ref =~ s/\[.*//;
         if ($ref =~ /^!/) {
            $ref =~ s/^!//;
            $refsvg = xml_attrval ($in, "ref-$ref");
            if (-e $refsvg) {
               open IN, $refsvg or die "Can't open $refsvg for reading";
               $s = xml_read (*IN);
               close IN;

               $x = xml_attrval ($s, 'x');
               $y = xml_attrval ($s, 'y');
               $w = xml_attrval ($s, 'w');
               $h = xml_attrval ($s, 'h');
            }
         } else { # Panel?
            $x = 0;
            $y = 0;
            $w = $p_w;
            $h = $p_h;
         }

         foreach $s (split /; */, $spec) {
            @cmd = split / /, $s;
            if ($cmd[0] eq 'extend') {
                 if ($cmd[1] eq 'up') {
                  $x = $x - $cmd[2];
               } elsif ($cmd[1] eq 'down') {
                  $h = $h + $cmd[2];
               } elsif ($cmd[1] eq 'right') {
                  $y = $y - $cmd[2];
               } elsif ($cmd[1] eq 'left') {
                  $w = $w + $cmd[2];
               }
            }
         }
      }
   }

   my $shape = xml_attrval ($in, 'shape');
   $shape = xml_attrval ($in, 'type') unless $shape;

   if ($shape eq 'circle') {
      ($x, $y, $w, $h) = draw_circle ($svg, $in, $x, $y, $w, $h);
   } elsif ($shape eq 'scribble') {
      draw_scribble ($svg, $in, $x, $y, $w, $h);
   } elsif ($shape eq 'image') {
      draw_image ($svg, $in, $x, $y, $w, $h);
   } elsif ($shape eq '') {
      # Do nothing, since this is just a grouping structure.
   } else {
      print STDERR "Unknown drawing shape $shape specified.\n";
   }

   # Now handle the children of this structure.
   foreach my $child (xml_elements ($in)) {
      if (xml_is ($child, 'draw')) {
         draw ($svg, $child, $w, $h, $x, $y);
      }
   }
   xml_set ($svg, 'x', $x);
   xml_set ($svg, 'y', $y);
   xml_set ($svg, 'w', $w);
   xml_set ($svg, 'h', $h);

   # Draw bounding box last, in case it's overlapped by images or something.
   if (xml_attrval ($in, 'show-box')) {
      draw_box ($svg, $in, $x, $y, $w, $h);
   }
}
sub draw_circle {
   my ($svg, $in, $x, $y, $w, $h) = @_;

   $cmd = xml_create ('circle');
   xml_append_pretty ($svg, $cmd);
   @center = split /,/, xml_attrval ($in, 'center');
   if ($center[0] =~ /(\d+),(\d+)/) {
      $cx = $1;
      $cy = $2;
   } elsif (!$center[0]) {
      $cx = $x + $w/2;
      $cy = $y + $h/2;
      $center = "$x,$y";
   } else {
      $cx = $panel_w / 2;
      $cy = $panel_h / 2;
   }
   shift @center;
   ($cx, $cy) = split /,/, move_point($cx, $cy, @center);

   xml_set ($cmd, 'cx', $cx);
   xml_set ($cmd, 'cy', $cy);

   $radius = xml_attrval ($in, 'radius');
   xml_set ($cmd, 'r', $radius);

   if (!$w && !$h) {
      $w = $radius * 2;
      $h = $radius * 2;
      $x = $cx - $radius;
      $y = $cy - $radius;
   }

   draw_style ($cmd, $in);

   return ($x, $y, $w, $h);
}

sub draw_box {
   my ($svg, $in, $x, $y, $w, $h) = @_;

   $cmd = xml_create ('rect');
   xml_append_pretty ($svg, $cmd);
   xml_set ($cmd, 'x', $x);
   xml_set ($cmd, 'y', $y);
   xml_set ($cmd, 'width', $w);
   xml_set ($cmd, 'height', $h);

   draw_style ($cmd, $in);

   return ($x, $y, $w, $h);
}

sub draw_scribble {
   my ($svg, $in, $x, $y, $w, $h) = @_;

   $cmd = xml_create ('polyline');
   xml_append_pretty ($svg, $cmd);

   $loops = xml_attrval ($in, 'loops');
   $loops = 20 unless $loops;

   $side = 0;
   $line = '';
   for ($i=0; $i < $loops; $i++) {
      if ($side) {
         $lx = $x + $w;
         $side = 0;
      } else {
         $lx = $x;
         $side = 1;
      }
      $ly = $y + rand($h);
      $line .= "$lx,$ly ";
   }

   xml_set ($cmd, 'points', $line);
   draw_style ($cmd, $in);

   return ($x, $y, $w, $h);
}
sub draw_image {
   my ($svg, $in, $x, $y, $w, $h) = @_;

   $cmd = xml_create ("image");
   xml_set ($cmd, "x", $x);
   xml_set ($cmd, "y", $y);
   xml_set ($cmd, "width", xml_attrval ($in, 'width'));
   xml_set ($cmd, "height", xml_attrval ($in, 'height'));

   $imagefile = xml_attrval ($in, 'file');
   if (xml_attrval ($in, 'invert') eq 'yes') {
      $inverted = "flop_" . xml_attrval ($in, 'file');
      if (!-e $inverted) {
         print LOG "Flopping $imagefile\n\n";
         system "convert -flop $imagefile $inverted";
      }
      $imagefile = $inverted;
   }

   xml_set ($cmd, "xlink:href", $imagefile);
   xml_append_pretty ($svg, $cmd);
}
sub draw_style {
   my ($cmd, $in) = @_;

   $stroke = xml_attrval ($in, 'line-color');
   $stroke = 'black' unless $stroke;
   $width = xml_attrval ($in, 'line-width');
   $width = '1' unless $width;
   $fill = xml_attrval ($in, 'fill-color');
   $fill = 'none' unless $fill;
   xml_set ($cmd, 'style', "stroke:$stroke; stroke-width:$width; fill:$fill");
}

sub move_point { # TODO: this goes into a module!
   my ($x, $y, @loc) = @_;

   foreach my $offset (@loc) {
      $offset =~ s/^ *//;
      my @o = split / /, $offset;
      if ($o[0] eq 'up') {
         $y -= $o[1];
      } elsif ($o[0] eq 'down') {
         $y += $o[1];
      } elsif ($o[0] eq 'left') {
         $x -= $o[1];
      } elsif ($o[0] eq 'right') {
         $x += $o[1];
      }
   }

   return "$x,$y";
}
