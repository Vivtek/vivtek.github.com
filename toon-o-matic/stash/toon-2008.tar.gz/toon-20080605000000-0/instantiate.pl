use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../instantiate_pl\"instantiate.pl\" runs, but doesn't really do anything yet.\n\n";


$toon = $ARGV[0];
$toon = 'cartoon.xml' unless $toon;

open IN, $toon or die "Can't open $toon for reading";
$input = xml_read (*IN);
close IN;

## TODO: processing to, y'know, instantiate.  This will massage the input XML in place.

print xml_string ($input);
print "\n";
