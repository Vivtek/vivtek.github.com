use Workflow::wftk::XML;
use Data::Dumper;

open LOG, ">>log.wiki";
print LOG "*../draw_caption_pl\"draw_caption.pl\" runs:\n\n";


$in = $ARGV[0];
$info = $ARGV[1];
$panel_w = $ARGV[2];
$panel_h = $ARGV[3];
$rotate = $ARGV[4];
$image = $ARGV[5];

open IN, $in or die "Can't open $in for reading";
$in = xml_read (*IN);
close IN;

$string = xml_stringcontent ($in);
$string =~ s/\n//g;
$string =~ s/<br\/>/\n/g;

sub make_style {
   $color = xml_attrval ($in, 'color');
   $color = xml_attrval ($in, 'fgcolor') unless $color;
   $color = 'black' unless $color;

   $size = xml_attrval ($in, 'size');
   $size = 16 unless $size;

   $stroke = xml_attrval ($in, 'stroke');
   $stroke = 'none' unless $stroke;

   $family = xml_attrval ($in, 'font');
   $family = 'verdana' unless $family;

   $style = xml_attrval ($in, 'style');
   $style = "; $style" if $style;
   foreach $attr ('text-decoration', 'font-weight', 'font-style') {
      my $v = xml_attrval ($in, $attr);
      if ($v) { $style .= "; $attr:" . $v; }
   }

   return "font-family:\@fonts/$family.ttf; font-size:$size; fill:$color; stroke:$stroke$style";
}

sub copy_text_attributes {
   my ($text, $in) = @_;

   foreach $attr ('text-decoration', 'font-weight', 'font-style') {
      xml_set ($text, $attr, xml_attrval ($in, $attr));
   }
}

if ($info eq 'no-info') {
   # First run through.
   
   $svg = xml_create ('svg');
   xml_set ($svg, 'width', $panel_w);
   xml_set ($svg, 'height', $panel_h);

   $text = xml_create ('text');
   xml_set ($text, 'x', '0');
   xml_set ($text, 'y', '0');
   xml_set ($text, 'style', make_style ($in));
   #copy_text_attributes ($text, $in);
   xml_append ($text, xml_createtext ($string));
   xml_append_pretty ($svg, $text);

   print xml_string ($svg) . "\n";
   exit;
}

# Second or third run through, we have an info file from 'identify'.
open IN, $info or die "Can't open $info for reading";
$info = xml_read (*IN);
close IN;

print LOG "Graphics info:\n<pre class=\"code\">\n" . xml_string ($info) . "\n</pre>\n\n";

if ($rotate) {
   # if the info file is from a rotated graphic, third time through.

   $h = xml_attrval ($info, 'height');
   $w = xml_attrval ($info, 'width');

   $svg = xml_create ('g');

   $image = xml_create ('image');
   xml_set ($image, 'x', '0');
   xml_set ($image, 'y', '0');
   xml_set ($image, 'height', $h);
   xml_set ($image, 'width', $w);
   xml_set ($image, 'xlink:href', xml_attrval ($info, 'file'));

   if ($rotate == 90 || $rotate == 180 || $rotate == 270) {
      # If the rotation is to a right angle, no need to clip.  Just place the image and go on.
      xml_append_pretty ($svg, $image);
   } else {
      # This is hard, so I'm not doing it yet.  It requires trigonometry, and my brain hurts from it.
      xml_append_pretty ($svg, $image);
   }
} else {
   # Second time through: draw text straight, with box.
   $margin = xml_attrval ($in, 'box-margin');
   $margin = 2 unless $margin;

   $size = xml_attrval ($in, 'size');
   $size = 16 unless $size;
   $h = xml_attrval ($info, 'height') + $margin*2; # Font size correction because trimming cuts off at top as well...
   $w = xml_attrval ($info, 'width') + $margin*2 + $size;

   # Now build the SVG for the overall caption.
   $svg = xml_create ('g');

   if ($image) {
      # 2008-06-14: we're going to use the graphic generated earlier, because we have more control over the rendering process
      # this way.  If that graphic isn't provided, we'll just use make an SVG text command.
      $text = xml_create ("image");
      xml_set ($text, "x", $margin + $size/2);
      xml_set ($text, "y", $margin);
      xml_set ($text, "width", xml_attrval ($info, 'width'));
      xml_set ($text, "height", xml_attrval ($info, 'height'));
      xml_set ($text, "xlink:href", $image);
   } else {
      $text = xml_create ('text');
      xml_set ($text, 'x', $margin + $size/2);
      xml_set ($text, 'y', $margin);
      xml_set ($text, 'style', make_style ($in));
      #copy_text_attributes ($text, $in);

      xml_append ($text, xml_createtext ($string));
      xml_append_pretty ($svg, $text);
   }

   if (xml_name($in) eq 'caption') {
      $box = xml_create ('rect');
      xml_set ($box, 'x', '0');
      xml_set ($box, 'y', '0');
      xml_set ($box, 'width', $w);
      xml_set ($box, 'height', $h);
   } elsif (xml_name($in) eq 'dialog') {
      $box = xml_create ('polyline'); # if a balloon, we need to position first and then draw the balloon stem.
   }

   $stroke = xml_attrval ($in, 'box-stroke');
   $stroke = 'black' unless $stroke;
   $width = xml_attrval ($in, 'box-line');
   $width = '1' unless $width;
   $fill = xml_attrval ($in, 'box-fill');
   $fill = 'white' unless $fill;
   $style = xml_attrval ($in, 'box-style');
   $style = "; $style" if $style;

   if (xml_attrval ($in, 'box') eq 'no') {
      $stroke = 'none';
      $fill = 'none';
   }

   xml_set ($box, 'style', "stroke:$stroke; stroke-width:$width; fill:$fill$style");
   xml_append_pretty ($svg, $box);
   xml_append_pretty ($svg, $text);

   # If there is a direction, we rotate the text by a certain number of degrees and if the text is now vertical we need to
   # swap its height and width for location calculation.
   # November 1, 2006 - doesn't work due to IM bugs.  Someday we might want to revisit this; it generates good SVG and SHOULD work.
   #$direction = xml_attrval ($in, 'direction');
   #$rotated = 0;
   #$midpoint = ($w/2) . "," . ($h/2);
   #$negmidpoint = (-$w/2) . "," . (-$h/2);
   #if ($direction eq 'up') {
   #   ($h, $w) = ($w, $h);
   #   $rotated = 1;
   #   xml_set ($svg, 'transform', "translate($midpoint) rotate(-90) translate($negmidpoint)");
   #} elsif ($direction eq 'down') {
   #   ($h, $w) = ($w, $h);
   #   $rotated = 1;
   #   xml_set ($svg, 'transform', "translate($midpoint) rotate(90) translate($negmidpoint)");
   #} elsif ($direction eq 'inverted') {
   #   $rotated = 1;
   #   xml_set ($svg, 'transform', "translate($midpoint) rotate(180) translate($negmidpoint)");
   #}
   #
   #if (xml_attrval ($in, 'rotate')) { # Arbitrary rotation -- doesn't affect placement (I don't care about it *that* much)
   #   $rotated = 1;
   #   $rotation = xml_attrval ($in, 'rotate');
   #
   #   $svg = transform_svg ($svg, "translate($negmidpoint)");
   #   $svg = transform_svg ($svg, "rotate($rotation)");
   #   $svg = transform_svg ($svg, "translate($midpoint)");
   #}
   #
   #if ($rotated) {
   #   $midgroup = $svg;
   #   $svg = xml_create ('g');
   #   xml_append_pretty ($svg, $midgroup);
   #}
}

# Now figure out the location on the panel and set a transformation on the overall 'g' (group) tag, and output that puppy, it's done.
# Caveat: if the panel width and height are 0, then this is the second time through and there will be a third time.  Act accordingly.
if ($panel_h == 0 && $panel_w == 0) {
   $g = $svg;
   xml_set ($g, 'transform', 'translate(5,5)');
   $svg = xml_create ("svg");
   xml_set ($svg, 'height', $h+10);
   xml_set ($svg, 'width', $w+10);
   xml_append_pretty ($svg, $g);
} elsif (xml_name ($in) eq 'caption') {
   $loc = calculate_location(xml_attrval ($in, 'location'), $h, $w, $panel_h, $panel_w);
   ($x, $y) = split /,/, $loc;
   xml_set ($svg, 'transform', "translate(" . calculate_location (xml_attrval ($in, 'location'), $h, $w, $panel_h, $panel_w) . ")");
   xml_set ($svg, 'x', $x);
   xml_set ($svg, 'y', $y);
   xml_set ($svg, 'w', $w);
   xml_set ($svg, 'h', $h);
} else { # Balloon!
   $ref = xml_attrval ($in, 'ref-who');
   open IN, $ref or die "Can't open $ref for reading";
   $s = xml_read (*IN);
   close IN;

   $loc = calculate_rel_location (xml_attrval ($in, 'location'), $s, $h, $w, $panel_h, $panel_w);
   ($x, $y, $dir) = split /,/, $loc;

   xml_set ($text, 'transform', "translate($x,$y)");

   $ptw = xml_attrval ($in, "point-width");
   $ptw = 20 unless $ptw;
   $where = xml_attrval ($in, "where");
   $where = "right, right 5" unless $where;

   my $point = calculate_rel_point ($where, $s, $panel_h, $panel_w);

   $x1 = $x;
   $x2 = $x + $w;
   $y1 = $y;
   $y2 = $y + $h;

   if ($dir =~ /^t/) {
      $mid = $x1 + $w/2;
      $mid1 = $mid - $ptw/2;
      $mid2 = $mid + $ptw/2;

      xml_set ($box, 'points', "$x1,$y1 $mid1,$y1 $point $mid2,$y1 $x2,$y1 $x2,$y2 $x1,$y2 $x1,$y1");
   } elsif ($dir =~ /^r/) {
      $mid = $y1 + $h/2;
      $mid1 = $mid - $ptw/2;
      $mid2 = $mid + $ptw/2;

      xml_set ($box, 'points', "$x1,$y1 $x2,$y1 $x2,$mid1 $point $x2,$mid2 $x2,$y2 $x1,$y2 $x1,$y1");
   } elsif ($dir =~ /^b/) {
      $mid = $x1 + $w/2;
      $mid1 = $mid - $ptw/2;
      $mid2 = $mid + $ptw/2;

      xml_set ($box, 'points', "$x1,$y1 $x2,$y1 $x2,$y2 $mid2,$y2 $point $mid1,$y2 $x1,$y2 $x1,$y1");
   } elsif ($dir =~ /^l/) {
      $mid = $y1 + $h/2;
      $mid1 = $mid - $ptw/2;
      $mid2 = $mid + $ptw/2;

      xml_set ($box, 'points', "$x1,$y1 $x2,$y1 $x2,$y2 $x1,$y2 $x1,$mid2 $point $x1,$mid1 $x1,$y1");
   } else {
      xml_set ($box, 'points', "$x1,$y1 $x2,$y1 $x2,$y2 $x1,$y2 $x1,$y1");
   }
}

      #push @data, $svg;
      #print STDERR Data::Dumper->Dump (\@data);

print xml_string ($svg) . "\n";
print LOG "<pre class=\"code\">\n" . xml_string ($svg) . "\n</pre>\n\n";

sub transform_svg {
   my ($svg, $t) = @_;

   my $s = xml_create ("g");
   xml_append_pretty ($s, $svg);
   xml_set ($s, 'transform', $t);

   return $s;
}

sub calculate_location {
   my ($location, $h, $w, $panel_h, $panel_w) = @_;

   if ($panel_h == 0 && $panel_w == 0) { return "0,0"; }

   my $x;
   my $y;

   my @loc = split /,/, $location;

   if ($loc[0] =~ /^top/) {
      $y = 0;
   } elsif ($loc[0] =~ /^middle/ || $loc[0] =~ /^center/) {
      $y = int(($panel_h - $h) / 2);
   } else {
      $y = $panel_h - $h;
   }

   if ($loc[0] =~ /right$/) {
      $x = $panel_w - $w;
   } elsif ($loc[0] =~ /middle$/ || $loc[0] =~ /center$/) {
      $x = int(($panel_w - $w) / 2);
   } else {
      $x = 0;
   }

   shift @loc;
   return (move_point ($x, $y, @loc));
}

sub move_point {
   my ($x, $y, @loc) = @_;

   foreach my $offset (@loc) {
      $offset =~ s/^ *//;
      my @o = split / /, $offset;
      if ($o[0] eq 'up') {
         $y -= $o[1];
      } elsif ($o[0] eq 'down') {
         $y += $o[1];
      } elsif ($o[0] eq 'left') {
         $x -= $o[1];
      } elsif ($o[0] eq 'right') {
         $x += $o[1];
      }
   }

   return "$x,$y";
}

sub calculate_rel_location {
   my ($location, $rel, $h, $w, $panel_h, $panel_w) = @_;

   if ($panel_h == 0 && $panel_w == 0) { return "0,0,*"; }

   my $x;
   my $y;
   my $dir;

   my $relx = xml_attrval ($rel, 'x');
   my $rely = xml_attrval ($rel, 'y');
   my $relw = xml_attrval ($rel, 'w');
   my $relh = xml_attrval ($rel, 'h');

   my @loc = split /,/, $location;

   if ($loc[0] =~ /^bottom/) {
      $y = $rely + $relh;
      $dir = "t";
   } elsif ($loc[0] =~ /^middle/ || $loc[0] =~ /^center/) {
      $y = $rely + ($relh - $h) / 2;
      $dir = "";
   } else {
      $y = $rely - $h;
      $dir = "b";
   }

   if ($loc[0] =~ /left$/) {
      $x = $relx - $w;
      $dir .= "r";
   } elsif ($loc[0] =~ /middle$/ || $loc[0] =~ /center$/) {
      $x = $relx + ($relw - $w) / 2;
   } else {
      $x = $relx + $relw;
      $dir .= "l";
   }

   $dir = "*" unless $dir;
   shift @loc;
   return (move_point ($x, $y, @loc) . ",$dir");
}

sub calculate_rel_point {
   my ($location, $rel, $panel_h, $panel_w) = @_;

   $location =~ s/^right/center right/;
   $location =~ s/^left/center left/;

   my ($x, $y, $dir) = split /,/, calculate_rel_location ($location, $rel, 0, 0, $panel_h, $panel_w);
   return "$x,$y";
}
