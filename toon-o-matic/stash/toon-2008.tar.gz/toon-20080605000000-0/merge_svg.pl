use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../merge_svg_pl\"merge_svg.pl\" runs to produce " . shift(@ARGV) . ":\n";


$top = shift @ARGV;
open IN, $top or die "Cannot open $top for reading";
$svg = xml_read (*IN);
close IN;

foreach $file (@ARGV) {
   open IN, $file or die "Cannot open $file for reading";
   $f = xml_read (*IN);
   close IN;

   xml_append ($svg, $f);
   xml_append ($svg, xml_createtext ("\n"));
}

print xml_string ($svg) . "\n";
print LOG "<pre class=\"code\">\n" . xml_string ($svg) . "\n</pre>\n\n";
