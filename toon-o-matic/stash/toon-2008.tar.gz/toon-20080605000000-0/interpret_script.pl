use Workflow::wftk::XML;

open LOG, ">log.wiki";
print LOG "!title:Toon-o-Matic run " . `date`;

print LOG "*../interpret_script_pl\"interpret_script.pl\" runs:\n\n";
$line = scalar(<>);

if ($line =~ /^<.*>/) {
   $spec = $line;
   while (<>)  { $spec .= $_; }
   print LOG "<i>XML specification</i>\n<pre class=\"code\">\n$spec\n</pre>\n\n";
   $cartoon = xml_parse ($spec);
} else {
   $cartoon = xml_parse ("<cartoon panel-h=\"150\" width=\"700\" rowformat=\"1\"/>");
   chomp $line;
   push @lines, $line;
   while (<>) { chomp; push @lines, $_; }

   print LOG "<i>Script specification</i>\n<pre class=\"code\">\n";
   print LOG join ("\n", @lines);
   print LOG "\n</pre>\n\nInterpretation follows:<br>\n";

   $curpanel = '';
   $font = '';
   $font_size = '';
   $font_color = '';
   $character_base = "http://www.vivtek.com/toonbots/characters/";
   foreach $cmd (@lines) {
      next unless $cmd;
      next if $cmd =~ /^#/;

      @cmd = split / +/, $cmd;
      print LOG "<b>$cmd</b><br>\n";

      if ($cmd[0] =~ /^char/i) {
         if ($cmd[1] eq 'base') {
            print LOG "Character base URL now $cmd[2]\n";
            $character_base = $cmd[2];
         } else {
            print LOG "Character \"$cmd[1]\" ";
            if ($cmd[2]) {
               print LOG "- retrieving from $cmd[2]\n";
            } else {
               print LOG " (no definition given)\n";
            }
         }
      } elsif ($cmd[0] =~ /^panels/i) {
         print LOG "Panel parameters and layout (currently ignored)\n";
      } elsif ($cmd[0] =~ /^panel/i) {
         print LOG "Panel - (parameters currently ignored)\n";
         $curpanel = xml_parse ("<panel/>");
         xml_append_pretty ($cartoon, $curpanel);
      } elsif ($cmd[1] =~ /leaves/i) {
         $character = xml_search_first ($curpanel, 'character', 'name', $cmd[0]);
         if (!xml_is_element($character)) {
            $action = xml_parse ("<character name=\"$cmd[0]\" action=\"leaves\"/>");
            xml_append_pretty ($curpanel, $action);
         } else {
            xml_set ($character, 'action', 'leaves');
         }
         print LOG "Character $cmd[0] leaves scene\n";
      } elsif ($cmd[1] =~ /appears/i) {
         if (xml_search_first ($curpanel, 'character', 'name', $cmd[0])) {
            print LOG "Has no effect, because $cmd[0] is already on the panel.\n";
         } else {
            print LOG "Character $cmd[0] appears on scene\n";
            $char = xml_parse ("<character name=\"$cmd[0]\"/>");
            xml_append_pretty ($curpanel, $char);
         }
      } elsif ($cmd[1] =~ /looks/i) {
         $character = xml_search_first ($curpanel, 'character', 'name', $cmd[0]);
         if (!xml_is_element($character)) {
            print LOG "Aspect implies presence; looker is \"$cmd[0]\".<br>\n";
            $character = xml_parse ("<character name=\"$cmd[0]\"/>");
            xml_append_pretty ($curpanel, $character);
         } else {
            print LOG "Looker \"$cmd[0]\" is already on the panel.<br>\n";
         }
         xml_set ($character, 'aspect', $cmd[2]);
      } elsif ($cmd[1] =~ /says/i) {
         $character = xml_search_first ($curpanel, 'character', 'name', $cmd[0]);
         if (!xml_is_element($character)) {
            print LOG "Speech implies presence: speaker is \"$cmd[0]\".<br>\n";
            $character = xml_parse ("<character name=\"$cmd[0]\"/>");
            xml_append_pretty ($curpanel, $character);
         } else {
            print LOG "Character \"$cmd[0]\", already on panel, speaks!\n";
         }
         $text = $cmd;
         $text =~ s/^.*? says //;
         print LOG "Speaker says: \"$text\"\n";
         $dialog = xml_parse ("<dialog who=\"$cmd[0]\">$text</dialog>");
         xml_set ($dialog, "font", $font) if $font;
         xml_set ($dialog, "font-size", $font_size) if $font_size;
         xml_set ($dialog, "font-color", $font_color) if $font_color;
         xml_append_pretty ($curpanel, $dialog);
      } elsif ($cmd[0] =~ /^capt/i) {
         $cmd =~ /^caption *:? +(\(.*?\)) *(.*)$/;
         $args = $1; $text = $2;
         print LOG "Caption with arguments $args, saying \"$text\".\n";

         $args =~ s/^\(//;  $args =~ s/\)$//;

         $caption_color = '';
         if ($args =~ /^(.*)color=([^ ]*)(.*)$/i) {
            $caption_color = $2;
            $args = "$1$3";
         }
         $caption_id = '';
         if ($args =~ /^(.*)id=([^ ]*)(.*)$/i) {
            $caption_id=$2;
            $args = "$1$3";
         }
         $caption = xml_parse ("<caption>$text</caption>");
         xml_set ($caption, "font", $font) if $font;
         xml_set ($caption, "font-size", $font_size) if $font_size;
         xml_set ($caption, "font-color", $font_color) if $font_color;
         xml_set ($caption, "font-color", $caption_color) if $caption_color;
         xml_set ($caption, "id", $caption_id) if $caption_id;

         $args =~ s/, *$//;
         xml_set ($caption, "location", $args) if $args;

         xml_append_pretty ($curpanel, $caption);
      } elsif ($cmd[0] =~ /^font/i) {
         $font_in = $cmd;
         $font_in =~ s/font *//i;

         if ($font_in eq 'clear') {
            $font = '';
            $font_size = '';
            $font_color = '';
            print LOG "Font is now default.\n";
         } else {
            if ($font_in =~ /^(.*)size=([^ ]*)(.*)$/i) {
               $font_size = $2;
               $font_in = "$1$3";
         
               print LOG "Font size is now $font_size.<br>\n";
            }
            if ($font_in =~ /^(.*)color=([^ ]*)(.*)$/i) {
               $font_color = $2;
               $font_in = "$1$3";
               print LOG "Font color is now $font_color.<br>\n";
            }

            $font_in =~ s/^ *//;
            if ($font_in) {
               $font = $font_in;
               print LOG "Font is now $font\n";
            } else {
               print LOG "Font is still $font\n" if $font;
               print LOG "Font is still default\n" unless $font;
            }
         }
      } else {
         print LOG "I have no idea what this means.\n";
      }
      print LOG "\n";
   }

   xml_set ($cartoon, "character-base-url", $character_base);

   print LOG "Resulting XML definition:\n<pre class=\"code\">\n";
   print LOG xml_string ($cartoon);
   print LOG "\n</pre>\n\n";
}

print xml_string ($cartoon) . "\n";
