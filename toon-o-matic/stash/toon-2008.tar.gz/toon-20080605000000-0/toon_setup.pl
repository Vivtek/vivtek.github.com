use Workflow::wftk::XML;
use Data::Dumper;

# Read toon data using DataWiki file format (yeah, it should be in a library, shouldn't it?)
$data = {};
$glom = 0;
$mykey = "";
while (<>) {
   print "data> $_" if $debug;
   chomp;
   if (!$glom) {
      ($field, $val) = split (/: */, $_, 2);
      if ($val =~ /<<(.*)/) {
         $eof = $1;
         $glom = 1;
         $$data{$field} = '';
         next;
      }
      $$data{$field} = $val;
      $mykey = $val unless $mykey;
   } else {
      if ($_ eq $eof) {
         $glom = 0;
      } else {
         $$data{$field} .= "$_\n";
      }
   }
}
push @data, $data if $debug;
print Data::Dumper->Dump (\@data) if $debug;


# Do we already have a directory for this toon?
$dir = "toon-$$data{id}";
if (!-e $dir) {
   mkdir $dir or die "Can't make directory $dir";
   system "cp *.pl $dir";
   system "cp identify_format.txt $dir";
   system "cp toon-Makefile $dir/Makefile";
   system "cp Makefile $dir/Makefile-wiki";
}

open TOON, ">$dir/toon.txt";
print TOON "$$data{toon}";
close TOON;

system "cd $dir ; make > make_results.txt 2>&1 ; make -f Makefile-wiki";
print "-------------\n";
system "cat $dir/make_results.txt";
