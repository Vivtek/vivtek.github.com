use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../place_characters_pl\"place_characters.pl\" places characters for $ARGV[0]:\n";

shift ARGV;
$panel_w = shift ARGV;
$panel_h = shift ARGV;

@chars = ();
foreach $in (@ARGV) {
   open IN, $in or die "Can't open $in for reading.";
   $p = xml_read (*IN);
   #print LOG "content of $in:\n<pre class=\"code\">\n" . xml_string ($p) . "\n</pre>\n\n";
   push @chars, $p;
   close IN;
}

# The following code is cadged from the original Toon-o-Matic.  It doesn't work really well,
# and frankly doesn't make a lot of sense, but it's better than all the characters being up at the
# top left of the panel, I guess.  Later we're obviously going to have to do a better job.

# Second character pass: locate the little buggers.
@free = ('0-100');
@nonplaced = ();
foreach $character (@chars) {
   # Finding 'y' coord isn't too hard.
   xml_set ($character, 'rel-loc-y', '60') if xml_attrval ($character, 'rel-loc-y') eq '';
   xml_set ($character, 'rel-loc-y', xml_attrval ($character, 'rel-loc-y'));
   if (!xml_attrval ($character, "y")) {
      xml_set ($character, 'y', $panel_h * xml_attrval ($character, 'rel-loc-y') / 100 - xml_attrval ($character, 'height') / 2);
   }

   # Try to place 'x' coords so characters don't overlap.  First take care of pre-known locations?
   push @nonplaced, $character;  # Later.
}

# Third character pass: try to place non-placed characters.  This sets distance-from-middle on the character.
# Rules about persistence of distance-from-middle will come later, too.  That could get really complex.
$separation = $panel_w / ($#nonplaced + 2);
$middle = $panel_h / 2;
$start = -$middle;
foreach $character (@nonplaced) {
   $start += $separation;
   xml_set ($character, 'distance-from-middle', $start);
   xml_set ($character, 'x', $middle + xml_attrval ($character, 'distance-from-middle') - xml_attrval ($character, 'width') / 2);
}

$placement = xml_parse ("<placement/>");
foreach $character (@chars) {
   $char_p = xml_parse ("<character/>");
   xml_append_pretty ($placement, $char_p);
   xml_set ($char_p, "name", xml_attrval ($character, "name"));
   xml_set ($char_p, "x",    xml_attrval ($character, "x"));
   xml_set ($char_p, "y",    xml_attrval ($character, "y"));
}

print LOG "<pre class=\"code\">\n" . xml_string ($placement) . "\n</pre>\n\n";
print xml_string($placement);
