use Workflow::wftk::XML;

open LOG, ">>log.wiki";
print LOG "*../build_panel_make_pl\"build_panel_make.pl\" runs.<br>\n";



$cwd = $ARGV[0];
$toon = $ARGV[1];
$toon = 'instance.xml' unless $toon;
open IN, $toon or die "Can't open $toon for reading";
$panels = xml_read (*IN);
close IN;

chomp($date = `date`);
scan_panels ($panels);

sub scan_panels {
   my $panel = shift;
   foreach $elem (xml_elements ($panel)) {
      next unless ($$elem{name} eq 'panel');

      $x{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-x');
      $y{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-y');
      $w{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-w');
      $h{xml_attrval ($elem, 'tag')} = xml_attrval ($elem, 'panel-h');

      scan_panels ($elem);
   }
}

@panel_list = sort { $a <=> $b } keys (%x);
$makes = '';
$panels_list = '';
$cur_scene = 'default';

@characters_leaving = ();

foreach $panel (@panel_list) {
   next unless -e "panel-$panel.xml";
   open IN, "panel-$panel.xml";
   $pxml = xml_read (*IN);
   close IN;

   @svgs = ();
   @character_draw_list = (); # Added 2008-06-14
   $caption_count = 0;
   $draw_count = 0;

   # Track the current scene, to determine groups of characters, later background etc.
   $cur_scene = xml_attrval ($panel, 'scene') if xml_attrval ($panel, 'scene');
   if (not xml_is_element ($scenes{$cur_scene})) {
      $scenes{$cur_scene} = xml_parse ("<scene id=\"$cur_scene\"/>");
      $scene_step{$cur_scene} = 0;
   }
   $scene = $scenes{$cur_scene};
   $scene_tag = "$cur_scene-$scene_step{$cur_scene}";
   $scene_step = $scene_steps{$scene_tag};
   if (xml_attrval ($scene, 'panels')) {
      xml_set ($scene, 'panels', xml_attrval ($scene, 'panels') . "-$panel");
   } else {
      xml_set ($scene, 'panels', $panel);
   }

   if (scalar @characters_leaving) {
      $old_scene_step = $scene_step;
      $scene_step{$cur_scene} += 1;
      $scene_tag = "$cur_scene-$scene_step{$cur_scene}";
      $scene_steps{$scene_tag} = xml_parse ("<frame id=\"$scene_step{$cur_scene}\" tag=\"$scene_tag\"/>");
      $scene_step = $scene_steps{$scene_tag};
      xml_append_pretty ($scene, $scene_step);
      $last_scene_step = $panel;

      # Remove all characters from current scene step, or rather: copy all characters except those leaving.
      foreach $elem (xml_elements($old_scene_step)) {
         unless (grep {print "$_ =?\n"; $_ eq xml_attrval($elem, "name")} @characters_leaving) {
            xml_append_pretty ($scene_step, xml_copy ($elem));
         }
      }
      @characters_leaving = ();
   }

   foreach $elem (xml_elements ($pxml)) {
      if (xml_name ($elem) eq 'character') {
         # 1. New scene step any time a character is referenced, but only once a panel.
         #    The scene has a timeline; each panel is mapped to a subscene.
         if ($last_scene_step ne $panel) {
            $old_scene_step = $scene_step;
            $scene_step{$cur_scene} += 1;
            $scene_tag = "$cur_scene-$scene_step{$cur_scene}";
            $scene_steps{$scene_tag} = xml_parse ("<frame id=\"$scene_step{$cur_scene}\" tag=\"$scene_tag\"/>");
            $scene_step = $scene_steps{$scene_tag};
            xml_append_pretty ($scene, $scene_step);
            $last_scene_step = $panel;

            foreach $elem (xml_elements($old_scene_step)) {
               xml_append_pretty ($scene_step, xml_copy($elem));
            }
         }

         # 2. Add character to current scene step.  (Note: we may need to merge an existing char/panel defn and the current defn.)
         $character = xml_copy ($elem);
         xml_set ($character, 'tag', $scene_tag);
         xml_append_pretty ($scene_step, $character);

         $tag = "character-" . xml_attrval ($character, 'name') . "-$scene_tag";
         $character{xml_attrval ($elem, 'name') . "-$panel"} = $tag;
         open C, ">$tag.xml";
         xml_write (*C, $character); print C "\n";
         close C;

         $make{$tag} = <<"END_MAKE";
draw-$tag.xml: $tag.xml
	perl build_character.pl this $w{$panel} $h{$panel} $tag.xml > draw-$tag.xml

$tag-$panel.svg: draw-$tag.xml placement-panel-$panel.xml
	perl draw.pl draw-$tag.xml $w{$panel} $h{$panel} placement-panel-$panel.xml > $tag-$panel.svg

END_MAKE

         push @character_draw_list, "draw-$tag.xml";
         push @svgs, "$tag-$panel.svg";

         # 3. Remove character from scene if action specifies it.
         if (xml_attrval ($elem, "action") eq "leaves") {
            push @characters_leaving, xml_attrval ($elem, "name");
         }
      } elsif (xml_name ($elem) eq 'scene') {
         # Scene-specific commands.
      } elsif (xml_name ($elem) eq 'caption') {
         $caption_count += 1;
         $tag = "caption-$panel-$caption_count";
         if (xml_attrval ($elem, 'id')) { $elem_id{xml_attrval ($elem, 'id')} = $tag; }

         $rotate = 0;
         $direction = xml_attrval ($elem, "direction");
         if ($direction eq "up") {
            $rotate = 270;
         } elsif ($direction eq "down") {
            $rotate = 90;
         } elsif ($direction eq "inverted") {
            $rotate = 180;
         } else {
            $rotate = xml_attrval ($elem, "rotate");
         }

         if ($rotate == 0) {
            $make{$tag} = <<"END_MAKE";
$tag.info: $tag.xml
	perl render_text.pl $tag.xml $tag.png
	identify -format '<graphic size="\%b" height="\%h" width="\%w" geometry="\%g" file="\%f"/>' $tag.png > $tag.info

$tag.svg: $tag.info
	perl draw_caption.pl $tag.xml $tag.info $w{$panel} $h{$panel} 0 $tag.png > $tag.svg

END_MAKE
         } else {
            $make{$tag} = <<"END_MAKE";
$tag.info: $tag.xml
	perl render_text.pl $tag.xml $tag.png
	identify -format '<graphic size="\%b" height="\%h" width="\%w" geometry="\%g" file="\%f"/>' $tag.png > $tag.info

$tag-r$rotate.info: $tag.xml $tag.info
	perl draw_caption.pl $tag.xml $tag.info 0 0 0 $tag.png > $tag-boxed.svg
	convert -trim $tag-boxed.svg $tag-boxed.gif
	convert -rotate $rotate $tag-boxed.gif $tag-r$rotate.gif
	identify -format '<graphic size="\%b" height="\%h" width="\%w" geometry="\%g" file="\%f"/>' $tag-r$rotate.gif > $tag-r$rotate.info

$tag.svg: $tag-r$rotate.info
	perl draw_caption.pl $tag.xml $tag-r$rotate.info $w{$panel} $h{$panel} $rotate $tag.png > $tag.svg

END_MAKE
         }

         push @svgs, "$tag.svg";

         open OUT, ">$tag.xml";
         print OUT xml_string ($elem) . "\n";
         close OUT;
      } elsif (xml_name($elem) eq 'dialog') { # Balloon!
         $dialog_count += 1;
         $tag = "dialog-$panel-$dialog_count";
         if (xml_attrval ($elem, 'id')) { $elem_id{xml_attrval ($elem, 'id')} = $tag; }

         $needs = '';
         $who = xml_attrval ($elem, 'who');
         # What drawing is the instantiation of this character in this panel?
         $whopan = "$who-$panel";
         $needs{$tag} = $character{$whopan};
         $needs .= " $character{$whopan}-$panel.svg";
         xml_set ($elem, "ref-who", "$character{$whopan}-$panel.svg");

         $make{$tag} = <<"END_MAKE";
$tag.info: $tag.xml $needs
	perl render_text.pl $tag.xml $tag.png
	identify -format '<graphic size="\%b" height="\%h" width="\%w" geometry="\%g" file="\%f"/>' $tag.png > $tag.info

$tag.svg: $tag.info
	perl draw_caption.pl $tag.xml $tag.info $w{$panel} $h{$panel} 0 $tag.png > $tag.svg

END_MAKE

         push @svgs, "$tag.svg";
         open OUT, ">$tag.xml";
         print OUT xml_string ($elem) . "\n";
         close OUT;
      } elsif (xml_name($elem) eq 'draw') { # Raw drawing command of various description
         $draw_count += 1;
         $tag = "draw-$panel-$draw_count";
         if (xml_attrval ($elem, 'id')) { $elem_id{xml_attrval ($elem, 'id')} = $tag; }
         $character{xml_attrval ($elem, 'character') . "-$panel"} = $tag;

         $needs = '';
         $area = xml_attrval ($elem, 'area');

         if ($area =~ /^!/) { #Dependency
            ($ref, $spec) = split /: */, $area;
            $ref =~ s/^!//;
            $ref =~ s/\[.*//;
            $needs{$tag} = $elem_id{$ref};
            $needs .= " $elem_id{$ref}.svg";
            xml_set ($elem, "ref-$ref", "$elem_id{$ref}.svg");
         }

         $make{$tag} = <<"END_MAKE";
$tag.svg: $tag.xml $needs
	perl draw.pl $tag.xml $w{$panel} $h{$panel} > $tag.svg

END_MAKE
         push @svgs, "$tag.svg";
         open OUT, ">$tag.xml";
         print OUT xml_string ($elem) . "\n";
         close OUT;
      }
   }

   # At this point, pxml contains the panel definition and scene_step contains the list of characters in this panel.
   # Make sure each character is shown correctly in the panel, in its current aspect.
   $panel_changed = 0;
   foreach $character (xml_elements ($scene_step)) {
      unless (xml_search ($pxml, 'character', 'name', xml_attrval ($character, 'name'))) {
         xml_append_pretty ($pxml, xml_copy ($character));
         $panel_changed = 1;
         $tag = "character-" . xml_attrval ($character, 'name') . "-$scene_tag";
         $make{"$tag-$panel"} = <<"END_MAKE";
$tag-$panel.svg: draw-$tag.xml placement-panel-$panel.xml
	perl draw.pl draw-$tag.xml $w{$panel} $h{$panel} placement-panel-$panel.xml > $tag-$panel.svg

END_MAKE

         push @character_draw_list, "draw-$tag.xml";
         push @svgs, "$tag-$panel.svg";
      }
   }

   if ($panel_changed) {
      open P, ">panel-$panel.xml";
      xml_write (*P, $pxml);
      close P;
   }

   if (xml_attrval ($scene_step, 'panels')) {
      xml_set ($scene_step, 'panels', xml_attrval ($scene_step, 'panels') . "-$panel");
   } else {
      xml_set ($scene_step, 'panels', $panel);
   }

   next unless @svgs;

   $panels_list .= " panel-$panel.svg";

   $svg_makes = join (' ', @svgs);
   $draw_makes = join (' ', @character_draw_list);;
   $makes .= <<"END_MAKE";
panel-$panel.svg: $svg_makes
	perl build_panel_g.pl panel-$panel.xml $x{$panel} $y{$panel} > panel-$panel-g.svg
	perl merge_svg.pl "panel $panel" panel-$panel-g.svg $svg_makes > panel-$panel.svg

placement-panel-$panel.xml: $draw_makes
	perl place_characters.pl "panel $panel" $w{$panel} $h{$panel} $draw_makes > placement-panel-$panel.xml

END_MAKE
}

# Write out the scene structures in case we need them for something else.
foreach $scene (keys (%scenes)) {
   print LOG "Scene $scene:\n<pre class=\"code\">\n" . xml_string ($scenes{$scene}) . "\n</pre>\n\n";
   open OUT, ">scene-$scene.xml";
   print OUT xml_string ($scenes{$scene}) . "\n";
   close OUT;
}
foreach $make (keys (%make)) {
   $makes .= $make{$make};
}

$makefile = <<"END_MAKEFILE";
# Panel Makefile generated $date by Toon-o-Matic t2
# Contains no serviceable parts.  Batteries not included.
# Void in NH, VT, and U.S. Minor Outlying Islands.

all: $panels_list

$makes
END_MAKEFILE

print LOG "Panel Makefile is as follows:\n<pre class=\"code\">$makefile</pre>\n";
print $makefile;
