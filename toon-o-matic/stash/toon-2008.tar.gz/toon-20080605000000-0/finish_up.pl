open LOG, ">>log.wiki";
print LOG "<b>The final result (drumroll please!)</b><br>\n<img src=\"$ARGV[0]\">\n\n";
close LOG;

system "make -f Makefile-wiki";
