use Workflow::wftk::XML;
use GD;
use LWP;
$ua = LWP::UserAgent->new;
$ua->agent("toon-o-matic");

open LOG, ">>log.wiki";

$character = $ARGV[0];

open T, "cartoon.xml";
$toon = xml_read (*T);
close T;
$base = xml_attrval ($toon, "character-base-url");
$base = "http://www.vivtek.com/toonbots/characters/" unless $base;

$base .= "/" unless $base =~ /\/$/;
$url = $base . $character . ".xml";

print LOG "Retrieving character definition for $character; URL is $url<br>\n";

$req = HTTP::Request->new(GET => $url);
$res = $ua->request ($req);

if (not $res->is_success) {
   print LOG "Retrieval fails, unfortunately.  We'll go with the default character.<br>\n";
   $defn = xml_parse ("<rect rel-h=\"50\" rel-w=\"75\" show-box=\"yes\"/>");
} else {
   $defn = xml_parse ($res->content);
}

$img_ct = 0;
foreach $image (xml_search ($defn, 'draw', 'type', 'image')) {
   $src = xml_attrval ($image, "file");
   $src = $base . $src unless $src =~ /:\/\//;
   print LOG "Retrieving image from $src<br>\n";
   $ext = $src;
   $ext =~ s/.*\.//;
   $img_ct += 1;
   $req = HTTP::Request->new(GET => $src);
   $res = $ua->request ($req);
   if (not $res->is_success) {
      print LOG "Retrieval fails.  Generating placeholder.<br>\n";
      $image = GD::Image->new(32, 32);
      $image->colorAllocate(255,255,255);
      $c = $image->colorAllocate (255,0,0);
      $image->useFontConfig(1);
      $image->stringFT ($c, "Utopia:style=Regular", 32, 0, 0, 0, "X");
      $localname = "image-$character-$img_ct.png";
      open I, ">$localname";
      print I $image->png();
      close I;
   } else {
      $localname = "image-$character-$img_ct.$ext";
      open I, ">$localname";
      print I ($res->content);
      close I;
   }

   $thumbnail = "image-$character-$img_ct-thumbnail.png";
   system "convert -resize 50 $localname $thumbnail";
   print LOG "<img src=\"$thumbnail\" border=\"1\">\n\n";

   system "identify -format '<graphic size=\"\%b\" height=\"\%h\" width=\"\%w\" geometry=\"\%g\" file=\"%f\"/>' $localname > $localname.info";
   xml_set ($image, 'file', $localname);
}

print LOG "Final character definition:\n<pre class=\"code\">\n" . xml_string ($defn) . "\n</pre>\n\n";
open D, ">definition-$character.xml";
xml_write (*D, $defn);
close D;

