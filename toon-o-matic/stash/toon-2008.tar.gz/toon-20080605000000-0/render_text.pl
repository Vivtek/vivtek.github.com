use Workflow::wftk::XML;
use GD;

open LOG, ">>log.wiki";
print LOG "*../render_text_pl\"render_text.pl\" renders \"$ARGV[0]\":\n";

$text = xml_parse_from_file ($ARGV[0]);
print LOG "<pre class=\"code\">\n" . xml_string($text) . "\n</pre>\n";

$string = xml_stringcontent ($text);
$string =~ s/\n//g;
$string =~ s/<br\/>/\n/g;

$font = xml_attrval ($text, "font");
$font = "Utopia:style=Regular" unless $font;

$font_size = xml_attrval ($text, "font-size");
$font_size = 16 unless $font_size;

$font_color = xml_attrval ($text, "font-color");
$font_color = "5,5,5" unless $font_color;
@font_color = split /,/, $font_color;

$image = GD::Image->new(640,640);
$image->colorAllocate(255,255,255);
$color = $image->colorAllocate(@font_color);
$image->useFontConfig(1);
$image->stringFT($color, $font, $font_size * 2, 0, $font_size * 3, $font_size * 3, $string);

print LOG "<img src=\"$ARGV[1]\" border=\"1\">\n\n";

$tmp = $ARGV[1];
$tmp =~ s/\.png/-raw.png/;
open PNG, ">$tmp";
print PNG $image->png();

system "convert -blur 1 -resize 50% -trim $tmp $ARGV[1]";
unlink $tmp;
