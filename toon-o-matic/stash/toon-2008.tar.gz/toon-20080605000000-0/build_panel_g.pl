$panel = $ARGV[0];

open LOG, ">>log.wiki";
print LOG "*../build_panel_g_pl\"build_panel_g.pl\" runs, producing:\n<pre class=\"code\">\n";

print "<g transform=\"translate($ARGV[1],$ARGV[2])\"/>\n";
print LOG "<g transform=\"translate($ARGV[1],$ARGV[2])\"/>\n";
print LOG "</pre>\n\n";
