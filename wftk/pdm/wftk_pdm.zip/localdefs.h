#define PROCESS_DEFINITION_REPOSITORY "/usr/local/AOLserver/vivtek/pages/wftk/wftk/procdefs/"
#define DATASHEET_REPOSITORY "/usr/local/AOLserver/vivtek/pages/todomgr/datasheets/"
