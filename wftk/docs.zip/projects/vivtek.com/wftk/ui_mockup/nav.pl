#!/usr/local/bin/perl

require "_navbar";
require "_getargs";

$input = getargs();

print "Content-type: text/html\n\n";

print '<html><body bgcolor="ffffff" link="#0000FF" vlink="#0000FF" alink="0000FF">' . "\n";
$target = 'target="wfui_body"';
navbar_print ("navbar.cnf", $$input{state});
print "</body></html>\n\n";

