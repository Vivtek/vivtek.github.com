#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/*#include "xmlapi.h"*/
#include "user.h"
#include "localdefs.h"

XML * directory;
XML * item;
XML * version;
XML * datasheet;

XML * current_user;

XML * input;
XML * environment;
XML * query;

ATTR * attr;

FILE * file;
FILE * debug;

char sbuf[1024];
char buf2[64];
int  edit_perm;
int  add_flag;
int  updated_flag;
char * mark;
char * format;
XML  * xml;
XML  * parent;
XML  * holder;

int index_dirty;
int item_dirty;
int version_dirty;

int cgi_mode;

char version_file[1024];

XML * cmd_line_init (int argc, char *argv[]) {
   XML * ret;
   XML * env;
   XML * query;
   int i;

   if (argc < 2) {
      printf ("Command-line usage: pdm <command> [<args>]\n");
      exit (1);
   }

   ret = xml_create ("cgicall");
   env = xml_create ("environment");
   query = xml_create ("query");
   xml_append (ret, env);
   xml_append (ret, query);

   xml_set (query, "command", argv[1]);

   if (!strcmp (argv[1], "list") ) {
   } else if (!strcmp (argv[1], "new")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
   } else if (!strcmp (argv[1], "checkout")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
   } else if (!strcmp (argv[1], "branch")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
      if (argc > 3) xml_set (query, "ver", argv[3]);
   } else if (!strcmp (argv[1], "checkin")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
      if (argc > 3) xml_set (query, "ver", argv[3]);
   } else if (!strcmp (argv[1], "starter")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
   } else if (!strcmp (argv[1], "datasheet")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
      if (argc > 3) xml_set (query, "ver", argv[3]);
   } else if (!strcmp (argv[1], "edit")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
      if (argc > 3) xml_set (query, "ver", argv[3]);
      if (argc > 4) xml_set (query, "view", argv[4]);
      if (argc > 5) xml_set (query, "loc", argv[5]);
   } else if (!strcmp (argv[1], "update")) {
      if (argc > 2) xml_set (query, "item", argv[2]);
      if (argc > 3) xml_set (query, "ver", argv[3]);
   } else {
      printf ("Unknown command '%s'\n", argv[1]);
   }

   return (ret);
}
void complain()
{
   if (!cgi_mode) {
      printf ("%s", sbuf);
      exit (1);
   }

   printf ("Content-type: text/html\n\n");
   printf ("<html><head><title>Error during processing</title></head>\n");
   printf ("<body><h2>An error occurred while processing your request</h2><hr>\n");
   printf ("%s", sbuf);
   printf ("</body></html>\n");
   exit (0);
}
void print_update_command (char * action, XML * location, char * arbitrary)
{
   printf ("%s?command=update&item=%s&ver=%s&action=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"),
           xml_attrval (query, "item"),
           xml_attrval (query, "ver"),
           action);
   xml_getloc (location, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   if (arbitrary) if (*arbitrary) {
      printf ("&%s", arbitrary);
   }
}
void print_edit_command (XML * location)
{
   printf ("%s?command=edit&item=%s&ver=%s&view=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"),
           xml_attrval (query, "item"), xml_attrval (query, "ver"),
           location->name);
   xml_getloc (location, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
}
void print_element_graphic (XML * xml)
{
   if (!xml) return;
   if (xml->name == NULL) return;
   if (!strcmp (xml->name, "sequence")) { printf ("sequence.gif"); return; }
   if (!strcmp (xml->name, "parallel")) { printf ("parallel.gif"); return; }
   if (!strcmp (xml->name, "task")) { printf ("task.gif"); return; }
   if (!strcmp (xml->name, "role")) { printf ("role.gif"); return; }
   if (!strcmp (xml->name, "data")) { printf ("data.gif"); return; }
   if (!strcmp (xml->name, "alert")) { printf ("alert.gif"); return; }
   if (!strcmp (xml->name, "situation")) { printf ("sit.gif"); return; }
   if (!strcmp (xml->name, "handle")) { printf ("sit.gif"); return; }
   if (!strcmp (xml->name, "if")) { printf ("if.gif"); return; }
   return;
}
void print_element_name (XML * xml)
{
   if (!xml) return;
   if (xml->name == NULL) return;
   if (!strcmp (xml->name, "sequence")) { printf ("sequence"); return; }
   if (!strcmp (xml->name, "parallel")) { printf ("parallel"); return; }
   if (!strcmp (xml->name, "task")) { printf ("%s", xml_attrval (xml, "label")); return; }
   if (!strcmp (xml->name, "role")) { printf ("%s", xml_attrval (xml, "name")); return; }
   if (!strcmp (xml->name, "data")) { printf ("%s", xml_attrval (xml, "name")); return; }
   if (!strcmp (xml->name, "alert")) { printf ("alert"); return; }
   if (!strcmp (xml->name, "situation")) { printf ("%s", xml_attrval (xml, "name")); return; }
   if (!strcmp (xml->name, "handle")) { printf ("%s", xml_attrval (xml, "situation")); return; }
   if (!strcmp (xml->name, "if")) { printf ("decision"); return; }
   return;
}
void print_target ()
{
   if (!strcmp ("", xml_attrval (query, "target"))) return;
   printf (" target=\"%s\"", xml_attrval (query, "target"));
}
void print_element (XML * xml)
{
   if (!xml) return;
   if (xml->name == NULL) return;
   if (!strcmp (xml->name, "sequence")) { printf ("<u>Sequence</u>"); return; }
   if (!strcmp (xml->name, "parallel")) { printf ("<u>Parallel</u>"); return; }
   if (!strcmp (xml->name, "task"))
   {
      printf ("<b>%s</b>", xml_attrval (xml, "label"));
      return;
   }
   if (!strcmp (xml->name, "role")) { printf ("%s", xml_attrval (xml, "name")); return; }
   if (!strcmp (xml->name, "data")) { printf ("%s", xml_attrval (xml, "name")); return; }
   if (!strcmp (xml->name, "alert")) {
      printf ("Alert %s", xml_attrval (xml, "to"));
      return;
   }
   if (!strcmp (xml->name, "situation")) {
      printf ("<i>Situation: %s</i>", xml_attrval (xml, "name"));
      return;
   }
   if (!strcmp (xml->name, "handle")) {
      printf ("<i>Handle \"%s\"</i>", xml_attrval (xml, "situation"));
      return;
   }
   if (!strcmp (xml->name, "if")) {
      printf ("<b>If</b> %s", xml_attrval (xml, "expr"));
      return;
   }
   return;
}
int outline_format (XML * action)
{
   XML * child;
   int count = 0;

   if (!strcmp (action->name, "workflow")) {
      printf ("<table border=0 cellpadding=0 cellborder=0>\n");
      child = xml_firstelem (action);
      while (child) {
         if (strcmp (child->name, "data") && strcmp (child->name, "role")) {
            count += outline_format (child);
         }
         child = xml_nextelem (child);
      }
      printf ("</table>\n");
   } else if (!strcmp (action->name, "sequence")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=sequence.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a>\n");
      printf ("<table border=0 cellpadding=0 cellborder=0>\n");
      child = xml_firstelem (action);
      while (child) {
         count += outline_format (child);
         child = xml_nextelem (child);
      }
      printf ("</table></td></tr>\n");
   } else if (!strcmp (action->name, "parallel")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=parallel.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a>\n");
      printf ("<table border=0 cellpadding=0 cellborder=0>\n");
      child = xml_firstelem (action);
      while (child) {
         count += outline_format (child);
         child = xml_nextelem (child);
      }
      printf ("</table></td></tr>\n");
   } else if (!strcmp (action->name, "task")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=task.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a> (%s)\n", xml_attrval (action, "role"));
      printf ("<table border=0 cellpadding=0 cellborder=0>\n");
      child = xml_firstelem (action);
      while (child) {
         if (!strcmp (child->name, "data")) {
            printf ("<tr><td class=\"data\"><img src=\"result.gif\"></td>");
            printf ("<td class=\"data\"><a href=\"");
            print_edit_command (child);
            printf ("\"");
            print_target ();
            printf (">%s</a></td>", xml_attrval (child, "name"));
            printf ("</tr>\n");
            count ++;
         }
         child = xml_nextelem (child);
      }
      printf ("</table></td></tr>\n");
   } else if (!strcmp (action->name, "if")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=if.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf ("><b>If</b> %s</a>\n", xml_attrval (action, "expr"));
      printf ("<table border=0 cellpadding=0 cellborder=0>\n");
      child = xml_firstelem (action);
      while (child) {
         count += outline_format (child);
         child = xml_nextelem (child);
      }
      printf ("</table></td></tr>\n");
   } else if (!strcmp (action->name, "alert")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=alert.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a></td></tr>\n");
   } else if (!strcmp (action->name, "data")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=data.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a></td></tr>\n");
   } else if (!strcmp (action->name, "situation")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=sit.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a></td></tr>\n");
   } else if (!strcmp (action->name, "handle")) {
      count ++;
      printf ("<tr><td valign=top align=center><img src=sit.gif></td><td><a href=\"");
      print_edit_command (action);
      printf ("\"");
      print_target ();
      printf (">");
      print_element (action);
      printf ("</a>\n");
      printf ("<table border=0 cellpadding=0 cellborder=0>\n");
      child = xml_firstelem (action);
      while (child) {
         count += outline_format (child);
         child = xml_nextelem (child);
      }
      printf ("</table></td></tr>\n");
   }
   return (count);
}
char * string_incr (char * string)
{
   if (!*string) {
      string[0] = 'a';
      string[1] = '\0';
      return (string);
   }

   if (*string == 'z') {
      string[0] = 'a';
      string_incr (string + 1);
      return (string);
   }

   string[0]++;
   return (string);
}
void show_list (XML * for_whom, const char * class, const char * object, const char * permission)
{
   XML * list;
   XML * listee;
   XML * item;
   XML * included;

   list = user_list (for_whom, class, object, permission);
   listee = xml_firstelem (list);
   while (listee) {
      item = xml_firstelem (directory);
      while (item) {
         if (!strcmp ("object", listee->name) &&
             !strcmp (xml_attrval (item, "id"), xml_attrval (listee, "object"))) {
            if (strcmp ("", xml_attrval (holder, xml_attrval (item, "id")))) {
               xml_set (listee, "invalid", "yep");
               break;
            }
            xml_set (holder, xml_attrval (item, "id"), "!");
            xml_set (listee, "title", xml_attrval (item, "title"));
            break;
         }
         item = xml_nextelem (item);
      }
      if (!strcmp ("", xml_attrval (listee, "title"))) {
         xml_set (listee, "invalid", "yep");
      }
      listee = xml_nextelem (listee);
   }

   /* Here we'll sort things.  Later. */

   printf ("<ul>\n");
   listee = xml_firstelem (list);
   while (listee) {
      if (!strcmp ("group-include", listee->name)) {
         if (!strcmp ("", xml_attrval (xml, xml_attrval (listee, "name")))) {
            xml_set (xml, xml_attrval (listee, "name"), "!");
            included = group_get (xml_attrval (listee, "name"));
            if (included) {
               printf ("<li> Via group <i>%s</i>:\n", xml_attrval (included, "name"));
               show_list (included, class, object, permission);
               xml_free (included);
            }
         }
      } else if (!strcmp ("", xml_attrval (listee, "invalid"))) {
         printf ("<li> <a href=\"%s?command=view&item=%s\">%s</a>\n",
                 xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (listee, "object"),
                 xml_attrval (listee, "title"));
      }
      listee = xml_nextelem (listee);
   }
   xml_free (list);
   printf ("</ul>\n");
}

int main (int argc, char *argv[])
{
   directory = NULL;
   item = NULL;
   version = NULL;
   index_dirty = 0;
   item_dirty = 0;
   version_dirty = 0;
   cgi_mode = 0;

   debug = fopen ("debug.log", "w");

   input = cgi_init();
   if (input) {
      environment = xml_loc (input, "cgicall.environment");
      query = xml_loc (input, "cgicall.query");
      current_user = user_authenticate (environment, "wftk workflow");
      if (!current_user) {
         printf ("Content-type: text/html\n\n");
         printf ("<html><head><title>User authentication required</title></head>\n");
         printf ("<body><h2>User authentication required</h2><hr>\n");
         printf ("A valid user authentication response is required to access this area.\n");
         printf ("</body></html>\n");
         exit (0);
      }
      cgi_mode = 1;
   } else {
      input = cmd_line_init(argc, argv);
      environment = xml_loc (input, "cgicall.environment");
      query = xml_loc (input, "cgicall.query");
   }


   file = fopen ("lastcall.xml", "w");
   if (file) {
      xml_write (file, input);
      fclose (file);
   }

   if (cgi_mode && !current_user) exit (0);


   if (!strcmp (xml_attrval(query, "command"), "")) {
printf ("Content-type: text/html\n\n");
printf ("<html><head><title>WFTK PDM works in progress</title></head>\n");
printf ("<body bgcolor=\"ffffff\">\n");
printf ("<h2>Open process definition</h2><hr>\n");
printf ("<font size=+1>Work in progress</font>\n");

xml = user_list (current_user, "wftkpdm", NULL, "edit");
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}
holder = xml_firstelem (xml);
while (holder) {
   strcpy (sbuf, xml_attrval (holder, "object"));
   mark = strrchr (sbuf, '_');
   if (mark) {
      *mark++ = '\0';
   } else {
      mark = "";
   }
   item = xml_firstelem (directory);
   while (item) {
      if (!strcmp (xml_attrval (item, "id"), sbuf)) {
         xml_set (holder, "title", xml_attrval (item, "title"));
         break;
      }
      item = xml_nextelem (item);
   }
   if (!strcmp ("", xml_attrval (holder, "title"))) {
      xml_set (holder, "title", xml_attrval (holder, "object"));
   }
   holder = xml_nextelem (holder);
}

/* Here we'll sort things.  Later. */

printf ("<form action=\"%s?command=delete\" method=POST>\n", xml_attrval (environment, "SCRIPT_NAME"));
holder = xml_firstelem (xml);
while (holder) {
   if (!strcmp (holder->name, "object")) {
      strcpy (sbuf, xml_attrval (holder, "object"));
      mark = strrchr (sbuf, '_');
      if (mark) {
         *mark++ = '\0';
      } else {
         mark = "";
      }
      printf ("&nbsp;&nbsp;&nbsp;<input type=checkbox name=\"itemver_%s_%s\">&nbsp;", sbuf, mark);
      printf ("<a href=\"%s?command=edit&item=%s&ver=%s\">%s</a>",
              xml_attrval (environment, "SCRIPT_NAME"), sbuf, mark,
              xml_attrval (holder, "title"));
      printf (" (ver '%s')<br>\n", mark);
   }
   holder = xml_nextelem (holder);
}
xml_free (xml);
printf ("<input type=submit value=\"Delete selected working versions\">\n");
printf ("</form>\n");


printf ("<p>\n");
printf ("<font size=+1>Process definitions</font>\n");

holder = xml_create ("temp");
xml = xml_create ("temp");
show_list (current_user, "workflow", NULL, "view");
xml_free (holder);
xml_free (xml);


printf ("</body></html>\n");
   } else if (!strcmp (xml_attrval(query, "command"), "list") ) {
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}

if (argc > 2) {
   format = argv[2];
} else {
   format = "edit?item=%s";
}

item = xml_firstelem (directory);
while (item) {
   if (!strcmp (item->name, "item") && strcmp (xml_attrval (item, "curver"), "")) {
      mark = (char *) xml_attrval (item, "title");
      if (!*mark) mark = (char *) xml_attrval (item, "id");
      printf ("<li><strong><a href=\"");
      printf (format, xml_attrval (item, "id"));
      printf ("\">%s</a></strong><br>\n", mark);
      xml_writecontent (stdout, item);
      printf ("<br>\n");
   }
   item = xml_nextelem (item);
}
   } else if (!strcmp (xml_attrval(query, "command"), "view")) {
if (!strcmp ("", xml_attrval (query, "item"))) {
   sprintf (sbuf, "No procdef ID specified.\n");
   complain();
}
sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef file.\n", sbuf);
   complain();
}

item = xml_read (file);
fclose (file);

if (!item) {
   sprintf (sbuf, "Corrupt procdef file.\n", sbuf);
   complain();
}

printf ("Content-type: text/html\n\n");
printf ("<html><head><title>Procdef %s</title></head>\n", xml_attrval (item, "title"));
printf ("<body bgcolor=ffffff>\n");
printf ("<h2>Procdef -- '%s'</h2>Current version: %s<br>Original author: %s<hr>",
        xml_attrval (item, "title"),
        *(xml_attrval (item, "ver")) ? xml_attrval (item, "ver") : "<b>none</b>",
        xml_attrval (item, "owner"));

holder = xml_loc (item, "item.description");
if (holder) {
   xml_writecontent (stdout, holder);
   printf ("<p>\n");
}

printf ("<ul>\n");
xml = xml_loc (item, "item.versions");
if (xml) {
   holder = xml_firstelem (xml);
   while (holder) {
      if (!strcmp (holder->name, "version")) {
         printf ("<li> <a href=%s?command=edit&item=%s&ver=%s>Version %s</a>\n",
                 xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
                 xml_attrval (holder, "id"), xml_attrval (holder, "id"));
         if (!strcmp (xml_attrval (holder, "id"), xml_attrval (item, "ver"))) {
            printf (" (current)\n");
         }
      }
      holder = xml_nextelem (holder);
   }
}
printf ("</ul>\n");

if (user_perm (current_user, "workflow", xml_attrval (query, "item"), "checkout")) {
   printf ("<form action=\"%s\" method=GET>\n", xml_attrval (environment, "SCRIPT_NAME"));
   printf ("<input type=hidden name=command value=checkout>\n");
   printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
   printf ("<input type=submit value=\"Check out a new version\">\n");
   printf ("</form>\n");
}

printf ("</body></html>\n");
   } else if (!strcmp (xml_attrval(query, "command"), "new")) {
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}

item = xml_create ("item");
item_dirty = 1;
if (strcmp ("", xml_attrval (query, "item"))) {
   xml_set (item, "id", xml_attrval (query, "item"));
   sprintf (sbuf, "index.item[%s]", xml_attrval (query, "item"));
   if (xml_loc (directory, sbuf) != NULL) {
      if (!cgi_mode) {
         printf ("Sorry, the document identifier '%s' is already in use.\n",
                 xml_attrval (query, "item"));
         exit (1);
      } else {
         printf ("Content-type: text/html\n\n");
         printf ("<h2>Document identifier in use</h2><hr>\n");
         printf ("Sorry, the document identifier '%s' is already in use.\n",
                 xml_attrval (query, "item"));
         exit (0);
      }
   }
} else {
   strcpy (buf2, "a");
   sprintf (sbuf, "index.item[%s]", buf2);
   while (xml_loc (directory, sbuf) != NULL) {
      string_incr (buf2);
      sprintf (sbuf, "index.item[%s]", buf2);
   }
   xml_set (item, "id", buf2);
}
xml_set (item, "ver", "");
xml_set (item, "title", xml_attrval (query, "title"));
holder = xml_create ("description");
xml_append (holder, xml_createtext (xml_attrval (query, "description")));
xml_append (item, holder);
if (current_user) {
   xml_set (item, "owner", xml_attrval (current_user, "name"));
   object_grant (current_user, "workflow", xml_attrval (item, "id"), "own");
   sprintf (sbuf, "%s_a", xml_attrval (item, "id"));
   object_grant (current_user, "wftkpdm", sbuf, "own");
   
   user_save (current_user);
}
holder = xml_create ("versions");
xml_append (item, holder);

xml = xml_create ("version");
xml_append (holder, xml);
holder = xml;
xml_set (holder, "id", "a");
sprintf (sbuf, "%s_a.xml", xml_attrval (item, "id"));
sprintf (version_file, "%s%s", PROCESS_DEFINITION_REPOSITORY, sbuf);
xml_set (holder, "file", sbuf);

version = xml_create ("workflow");
xml_set (version, "name", xml_attrval (query, "title"));
if (current_user) xml_set (version, "created", xml_attrval (current_user, "name"));
holder = xml_create ("note");
xml_set (holder, "type", "description");
xml_append (holder, xml_createtext (xml_attrval (query, "description")));
xml_append (version, holder);
version_dirty = 1;

holder = xml_create ("item");
xml_set (holder, "curver", "");
xml_set (holder, "id", xml_attrval (item, "id"));
xml_set (holder, "title", xml_attrval (query, "title"));
xml_append (holder, xml_createtext (xml_attrval (query, "description")));
xml_append (directory, holder);
index_dirty = 1;

if (!cgi_mode) {
   printf ("N %s\n", xml_attrval (item, "id"));
} else {
   printf ("Content-type: text/html\n");
   printf ("Status: 302 Redirect\n");
   printf ("Location: %s?command=edit&item=%s&ver=a\n\n",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (item, "id"));
   printf ("<h2>Document added</h2><hr>\n");
   printf ("Your process definition '%s' has been added to the repository.<br><a href=\"",
           xml_attrval (query, "title"));
   printf ("%s?command=edit&item=%s&ver=a\">Click here to start editing it.</a>",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (item, "id"));
}
   } else if (!strcmp (xml_attrval(query, "command"), "delete")) {
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}

attr = query->attrs;
while (attr) {
   if (!strncmp (attr->name, "itemver_", 8)) {
      strcpy (buf2, attr->name + 8);
      mark = strrchr (buf2, '_');
      if (mark) {
         *mark = '\0';
         mark++;
object_revoke (current_user, "wftkpdm", attr->name + 8, NULL);
user_save (current_user);
holder = xml_loc (directory, sbuf);
if (holder && strcmp (xml_attrval (holder, "curver"), mark) ) {
   sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, buf2);
   file = fopen (sbuf, "r");
   if (file) {
      item = xml_read (file);
      if (item) {
         sprintf (sbuf, "item.versions.version[%s]", mark);
         version = xml_loc (item, sbuf);
         if (version) {
            xml_delete (version);
            /* Here's where we'd delete the version file if we were deleting files. */

            xml = xml_loc (item, "item.versions.version");
            if (!xml) { /* Hey - no more versions.  Delete the item. */
               xml_delete (holder);
               index_dirty = 1;
               /* Again, here's where we'd delete the item file if we were that kind of person. */
            } else {
               sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, buf2);
               file = fopen (sbuf, "w");
               if (file) {
                  xml_write (file, item);
                  fclose (file);
               }
            }
         }
         xml_free (item);
      }
      fclose (file);
   }
}
      }
   }
   attr = attr->next;
}
printf ("Content-type: text/html\n");
printf ("Status: 302 Redirect\n");
printf ("Location: %s\n\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<html><head><title>Delete succeeded</title></head>\n");
printf ("<body><h2>Delete succeeded</h2></body></html>\n");
   } else if (!strcmp (xml_attrval(query, "command"), "checkout")) {
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}
if (!strcmp ("", xml_attrval (query, "item"))) {
   sprintf (sbuf, "No procdef ID specified.\n");
   complain();
}
sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef file.\n", sbuf);
   complain();
}

item = xml_read (file);
fclose (file);

if (!item) {
   sprintf (sbuf, "Corrupt procdef file.\n", sbuf);
   complain();
}
strcpy (buf2, xml_attrval (item, "ver"));
if (*buf2 == '\0') {
   strcpy (buf2, "a");
   version = xml_create ("workflow");
   xml_set (version, "title", xml_attrval (item, "title"));
} else {
   sprintf (sbuf, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (item, "id"), xml_attrval (item, "ver"));
   file = fopen (sbuf, "r");
   if (!file) {
      sprintf (sbuf, "Can't open current version %s\n", sbuf);
      complain();
   }

   version = xml_read (file);
   fclose (file);
}

sprintf (sbuf, "item.versions.version[%s]", buf2);
while (xml_loc (item, sbuf) != NULL)
   sprintf (sbuf, "item.versions.version[%s]", string_incr (buf2));

holder = xml_create ("version");
xml_set (holder, "id", buf2);
sprintf (sbuf, "%s_%s.xml", xml_attrval (item, "id"), buf2);
sprintf (version_file, "%s%s", PROCESS_DEFINITION_REPOSITORY, sbuf);
xml_set (holder, "file", sbuf);
xml_append (xml_loc (item, "item.versions"), holder);
item_dirty = 1;
version_dirty = 1;

if (current_user) {
   xml_set (holder, "owner", xml_attrval (current_user, "name"));
   sprintf (sbuf, "%s_%s", xml_attrval (item, "id"), xml_attrval (holder, "id"));
   object_grant (current_user, "wftkpdm", sbuf, "own");
   
   user_save (current_user);
}

if (!cgi_mode) {
   printf ("V %s\n", buf2);
} else {
   printf ("Content-type: text/html\n");
   printf ("Status: 302 Redirect\n");
   printf ("Location: %s?command=edit&%s&ver=%s\n\n",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (holder, "id"));
   printf ("<h2>Document checked out</h2><hr>\n");
   printf ("A new version of process definition '%s' has been created.",
            xml_attrval (item, "title"));
   printf ("  Its version identifier is '%s'.  <a href=\"",
           xml_attrval (holder, "id"));
   printf ("%s?command=edit&item=%s&ver=%s\">Click here to start editing it.</a>",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (holder, "id"));
}
   } else if (!strcmp (xml_attrval(query, "command"), "branch")) {
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}
   } else if (!strcmp (xml_attrval(query, "command"), "checkin")) {
sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
file = fopen (sbuf, "r");
if (!file) {
   directory = xml_create ("index");
} else {
   directory = xml_read (file);
   fclose (file);
}
if (!directory) {
   sprintf (sbuf, "Corrupt directory file.\n");
   complain();
}
if (!strcmp ("", xml_attrval (query, "item"))) {
   sprintf (sbuf, "No procdef ID specified.\n");
   complain();
}
sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef file.\n", sbuf);
   complain();
}

item = xml_read (file);
fclose (file);

if (!item) {
   sprintf (sbuf, "Corrupt procdef file.\n", sbuf);
   complain();
}

sprintf (sbuf, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"), xml_attrval (query, "ver"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef version file %s.\n", sbuf);
   complain();
}

version = xml_read (file);
fclose (file);

if (!version) {
   sprintf (sbuf, "Corrupt version file %s.\n", sbuf);
   complain();
}
sprintf (sbuf, "index.item[%s]", xml_attrval (query, "item"));
xml = xml_loc (directory, sbuf);
if (!xml) {
   xml = xml_create ("item");
   xml_append (directory, xml);
}

xml_set (xml, "curver", xml_attrval (query, "ver"));
xml_set (xml, "title", xml_attrval (version, "name"));
sprintf (sbuf, "%s_%s.xml", xml_attrval (query, "item"), xml_attrval (query, "ver"));
xml_set (xml, "file", sbuf);
/*holder = xml_firstelem (xml);
while (holder) {
   xml_delete (holder);
   holder = xml_firstelem (xml);
}
holder = xml_firstelem (version);
while (holder) {
   if (!strcmp (holder->name, "note") && !strcmp ("description", xml_attrval (holder, "description"))) {
      xml_append (xml, xml_createtext (xml_attrval ( ...
 -- Dang.  This needs an extension to the xmlapi, and I told myself all such changes could wait.
 At any rate, what we're doing here is to copy the contents of the description note into the
contents of the item for convenient display.  What we really need is an xml_copycontent().
*/
index_dirty = 1;
xml_set (item, "ver", xml_attrval (query, "ver"));
xml_set (item, "title", xml_attrval (version, "name"));
item_dirty = 1;
if (current_user) {
   sprintf (sbuf, "%s_%s", xml_attrval (query, "item"), xml_attrval (query, "ver"));
   object_revoke (current_user, "wftkpdm", sbuf, NULL);
   user_save (current_user);
}
if (cgi_mode) {
   printf ("Content-type: text/html\n\n");
   printf ("<h2>Checkin complete</h2><hr>\n");
   printf ("This is now the current version of the procdef.\n");
   printf (" <a href=\"%s\">Click here to go back to the editor home page.</a>\n",
           xml_attrval (environment, "SCRIPT_NAME"));
} else {
   printf ("OK\n");
}
   } else if (!strcmp (xml_attrval(query, "command"), "starter")) {
if (!strcmp ("", xml_attrval (query, "item"))) {
   sprintf (sbuf, "No procdef ID specified.\n");
   complain();
}
sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef file.\n", sbuf);
   complain();
}

item = xml_read (file);
fclose (file);

if (!item) {
   sprintf (sbuf, "Corrupt procdef file.\n", sbuf);
   complain();
}
sprintf (sbuf, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"), xml_attrval (item, "ver"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef version file %s.\n", sbuf);
   complain();
}

version = xml_read (file);
fclose (file);

if (!version) {
   sprintf (sbuf, "Corrupt version file %s.\n", sbuf);
   complain();
}

if (strcmp (xml_attrval (version, "name"), "")) {
   printf ("%s\n", xml_attrval (version, "name"));
} else {
   printf ("%s\n", argv[2]);
}
printf ("%s\n", xml_attrval (item, "ver"));

xml = xml_firstelem (version);
while (xml) {
   if (!strcmp (xml->name, "data")) {
printf ("<tr><td>%s</td>\n", xml_attrval (xml, "name"));
printf ("<td>");
if (!strcmp (xml_attrval (xml, "type"), "text")) {
   printf ("<textarea name=\"%s\" rows=5 cols=30>", xml_attrval (xml, "name"));
   xml_writecontent (stdout, xml);
   printf ("</textarea>\n");
} else {
   printf ("<input name=\"%s\" value=\"", xml_attrval (xml, "name"));
   xml_writecontent (stdout, xml);
   printf ("\">\n");
}
printf ("</td></tr>\n");
   } else if (!strcmp (xml->name, "sequence")) {
      break;
   } else if (!strcmp (xml->name, "parallel")) {
      break;
   } else if (!strcmp (xml->name, "task")) {
      break;
   }

   xml = xml_nextelem (xml);
}
   } else if (!strcmp (xml_attrval(query, "command"), "datasheet")) {
if (argc < 5) {
   sprintf (sbuf, "Missing arguments in datasheet command.\n");
   complain();
}

sprintf (sbuf, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"), xml_attrval (query, "ver"));
file = fopen (sbuf, "r");
if (!file) {
   printf ("%s\n", sbuf);
   sprintf (sbuf, "Unable to open procdef version file.\n", sbuf);
   complain();
}

version = xml_read (file);
fclose (file);

if (!version) {
   sprintf (sbuf, "Corrupt version file.\n", sbuf);
   complain();
}

datasheet = xml_create ("datasheet");
sprintf (sbuf, "%s_%s.xml", xml_attrval (query, "item"), xml_attrval (query, "ver"));
xml_set (datasheet, "procdef", sbuf);
xml_set (datasheet, "process", argv[4]);

xml = xml_firstelem (version);
while (xml) {
   if (!strcmp (xml->name, "data")) {
      holder = xml_create ("data");
      xml_set (holder, "id", xml_attrval (xml, "name"));
      xml_set (holder, "type", xml_attrval (xml, "type"));
      xml_append (datasheet, holder);
   } else if (!strcmp (xml->name, "sequence")) {
      break;
   } else if (!strcmp (xml->name, "parallel")) {
      break;
   } else if (!strcmp (xml->name, "task")) {
      break;
   }

   xml = xml_nextelem (xml);
}

xml_write (stdout, datasheet);
   } else if (!strcmp (xml_attrval(query, "command"), "edit")) {
sprintf (sbuf, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"), xml_attrval (query, "ver"));
file = fopen (sbuf, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef version file %s.\n", sbuf);
   complain();
}
version = xml_read (file);
fclose (file);
sprintf (sbuf, "%s_%s", xml_attrval (query, "item"), xml_attrval (query, "ver"));
edit_perm = user_perm (current_user, "wftkpdm", sbuf, "edit");
printf ("Content-type: text/html\n\n");
printf ("<html><head><title>wftk %s - %s</title><LINK href=\"pdm.css\" rel=\"stylesheet\" type=\"text/css\"></head>\n", edit_perm ? "edit" : "view", xml_attrval (version, "name"));
if (!strcmp ("", xml_attrval (query, "view"))) {
printf ("<frameset cols=\"300,*\">");
printf ("<frame name=overview src=\"%s?command=edit&item=%s&ver=%s&view=overview&target=detail\" scrolling=auto marginwidth=2>",
        xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"), xml_attrval (query, "ver"));
printf ("<frame name=detail src=\"%s?command=edit&item=%s&ver=%s&view=description\" scrolling=auto marginwidth=2>",
        xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"), xml_attrval (query, "ver"));
printf ("</frameset>");
} else {
printf ("<body bgcolor=\"ffffff\">\n");

if (!strcmp ("description", xml_attrval (query, "view"))) {
printf ("<h1>Descriptions of process \"%s\"</h1><hr>\n", xml_attrval (version, "name"));
printf ("<form method=post action=\"%s\">\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=\"%s\">\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=\"%s\">\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=action value=updatedescription>\n");
printf ("<table>\n");
printf ("<tr><td>Title:</td><td width=100%><input name=title value=\"%s\"></td></tr>\n",
        xml_attrval (version, "name"));
printf ("<tr><td colspan=2>Description:<br>");
printf ("<textarea name=desc rows=5 cols=40>");
holder = xml_firstelem (version);
while (holder) {
   if (!strcmp (holder->name, "note") &&
       !strcmp ("description", xml_attrval (holder, "type"))) {
      xml_writecontent (stdout, holder);
      break;
   }
   holder = xml_nextelem (holder);
}
printf ("</textarea></td></tr>\n");
/*
printf ("<tr><td>Title:</td><td><input name=insttitle value=\"");
while (holder) {
   if (!strcmp (holder->name, "note") &&
       !strcmp ("instancetitle", xml_attrval (holder, "type"))) {
      xml_writecontent (stdout, holder);
      break;
   }
   holder = xml_nextelem (holder);
}
printf ("\"></td></tr>\n");

printf ("<tr><td colspan=2>Description:<br>");
printf ("<textarea name=instdesc rows=5 cols=40>");
while (holder) {
   if (!strcmp (holder->name, "note") &&
       !strcmp ("instancedescription", xml_attrval (holder, "type"))) {
      xml_writecontent (stdout, holder);
      break;
   }
   holder = xml_nextelem (holder);
}
printf ("</textarea></td></tr>\n");
*/
if (edit_perm) {
   printf ("<tr><td colspan=2><center><input type=submit value=\"Update descriptions\">");
   printf ("</center></td></tr>\n");
}

printf ("</table>\n");
printf ("</form>\n");
} else if (!strcmp ("overview", xml_attrval (query, "view"))) {
printf ("<h1>Process \"%s\"</h1>\n", xml_attrval (version, "name"));
printf ("<a href=\"%s?command=edit&item=%s&ver=%s&view=description\"",
        xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
        xml_attrval (query, "ver"));
if (strcmp ("", xml_attrval (query, "target"))) {
   printf (" target=\"%s\"", xml_attrval (query, "target"));
}
printf (">Show descriptions</a><hr>\n");
printf ("<strong class=\"heading\">Roles</strong>\n");
printf ("<table>\n");
holder = xml_firstelem (version);
while (holder) {
   if (!strcmp (holder->name, "role")) {
      printf ("<tr><td class=\"role\"><img src=\"role.gif\"></td>");
      printf ("<td class=\"role\"><a href=\"");
      print_edit_command (holder);
      printf ("\"");
      print_target ();
      printf (">%s</a></td>", xml_attrval (holder, "name"));
      printf ("<td class=\"role\"><a href=\"");
      print_update_command ("moveup", holder, "");
      printf ("\"");
      print_target();
      printf ("><img src=\"up.gif\" alt=\"Move %s up the list\" border=0></a>",
              xml_attrval (holder, "name"));
      printf ("<a href=\"");
      print_update_command ("movedn", holder, "");
      printf ("\"");
      print_target();
      printf ("><img src=\"dn.gif\" alt=\"Move %s down the list\" border=0></a></td>",
              xml_attrval (holder, "name"));
      printf ("</tr>\n");
   }
   holder = xml_nextelem (holder);
}
if (edit_perm) {
   printf ("<tr><td class=\"role\">&nbsp;</td><td class=\"addrole\">");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=workflow&view=role\"",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   if (strcmp ("", xml_attrval (query, "target")))
      printf (" target=\"%s\"", xml_attrval (query, "target"));
   printf (">Add a role</a></td><td class=\"role\">&nbsp;</td></tr>\n");
}
printf ("</table><br>\n");
printf ("<strong class=\"heading\">Startup data</strong>\n");
printf ("<table>\n");
holder = xml_firstelem (version);
while (holder) {
   if (!strcmp (holder->name, "data") && !strcmp ("yes", xml_attrval (holder, "initial"))) {
      printf ("<tr><td class=\"data\"><img src=\"data.gif\"></td>");
      printf ("<td class=\"data\"><a href=\"");
      print_edit_command (holder);
      printf ("\"");
      print_target ();
      printf (">%s</a></td>", xml_attrval (holder, "name"));
      printf ("<td class=\"data\"><a href=\"");
      print_update_command ("moveup", holder, "");
      printf ("\"");
      print_target();
      printf ("><img src=\"up.gif\" alt=\"Move %s up the list\" border=0></a>",
              xml_attrval (holder, "name"));
      printf ("<a href=\"");
      print_update_command ("movedn", holder, "");
      printf ("\"");
      print_target();
      printf ("><img src=\"dn.gif\" alt=\"Move %s down the list\" border=0></a></td>",
              xml_attrval (holder, "name"));
      printf ("</tr>\n");
   }
   holder = xml_nextelem (holder);
}
if (edit_perm) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=workflow&view=data\"",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   if (strcmp ("", xml_attrval (query, "target")))
      printf (" target=\"%s\"", xml_attrval (query, "target"));
   printf (">Add a data item</a></td><td>&nbsp;</td></tr>\n");
}
printf ("</table><br>\n");
printf ("<strong class=\"heading\">Outline of action</strong>\n");
if (!outline_format (version)) {
   printf ("<p>The process has no actions defined yet.<br>\n");
}
printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=workflow&view=action\"",
        xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
        xml_attrval (query, "ver"));
if (strcmp ("", xml_attrval (query, "target")))
   printf (" target=\"%s\"", xml_attrval (query, "target"));
printf (">Add an action</a>\n");
if (current_user) {
   sprintf (sbuf, "%s_%s", xml_attrval (query, "item"), xml_attrval (query, "ver"));
   if (user_perm (current_user, "wftkpdm", sbuf, "checkin")) {
      printf ("<center><form action=\"%s\" method=post target=_top>\n",
              xml_attrval (environment, "SCRIPT_NAME"));
      printf ("<input type=hidden name=command value=checkin>\n");
      printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
      printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
      printf ("<input type=submit value=\"Check in\">\n");
      printf ("</form></center>\n");
   }
}
} else if (!strcmp ("task", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}

printf ("<h1>Task: %s</h1>\n", xml_attrval (xml, "label"));
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this task</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr><form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=task>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Label of task:</td><td><input name=\"label\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "label"));
printf ("<tr><td>Who performs the task:</td><td><select name=\"role\">");
holder = xml_firstelem (version);
while (holder) {
   if (!strcmp (holder->name, "role")) {
      printf ("<option");
      if (!strcmp (xml_attrval (holder, "name"), xml_attrval (xml, "role"))) {
         printf (" selected");
      }
      printf (">%s", xml_attrval (holder, "name"));
   }
   holder = xml_nextelem (holder);
}
printf ("</select></td></tr>\n");
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");

printf ("<strong class=\"heading\">Data collected during this task:</strong>\n");
printf ("<table>\n");
holder = xml_firstelem (xml);
while (holder) {
   if (!strcmp (holder->name, "data")) {
      printf ("<tr><td class=\"data\"><img src=\"data.gif\"></td>");
      printf ("<td class=\"data\"><a href=\"");
      print_edit_command (holder);
      printf ("\">%s</a></td>", xml_attrval (holder, "name"));
      printf ("<td class=\"data\"><img src=\"up.gif\" alt=\"Move %s up the list\" border=0>", xml_attrval (holder, "name"));
      printf (                    "<img src=\"dn.gif\" alt=\"Move %s down the list\" border=0></td>", xml_attrval (holder, "name"));
      printf ("</tr>\n");
   }
   holder = xml_nextelem (holder);
}
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&view=data\"");
   printf (">Add a data item</a></td><td>&nbsp;</td></tr>\n");
}
printf ("</table>\n");
} else if (!strcmp ("role", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}

printf ("<h1>%sRole: %s</h1>\n", add_flag ? "New " : "", xml_attrval (xml, "name"));
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this role</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=role>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Name of role:</td><td><input name=\"name\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "name"));
printf ("<tr><td>Local user(s) who fit the bill:</td><td><input name=\"local\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "local"));
printf ("<tr><td>Description:</td><td><textarea name=\"content\" rows=10 cols=30>");
xml_writecontent (stdout, xml);
printf ("</textarea></td></tr>\n");
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("data", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}
printf ("<h1>%sData item: %s</h1>\n", add_flag ? "New " : "", xml_attrval (xml, "name"));
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this data item</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=data>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Name :</td><td><input name=\"name\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "name"));
printf ("<tr><td>Type:</td><td><input name=\"type\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "type"));
printf ("<tr><td>Initial value:</td><td><textarea name=\"content\" rows=10 cols=30>");
xml_writecontent (stdout, xml);
printf ("</textarea></td></tr>\n");
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("sequence", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}

printf ("<h1>%sSequence</h1>\n", add_flag ? "New " : "");
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this sequence</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=sequence>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Sequence should loop?</td><td><input type=radio name=repeat value=yes");
if (!strcmp ("yes", xml_attrval (xml, "repeat"))) printf (" checked");
printf ("> Yes  <input type=radio name=repeat value=no");
if (!strcmp ("no", xml_attrval (xml, "repeat"))) printf (" checked");
printf (">No</td></tr>\n");
printf ("<tr><td>Name of index variable for loops:</td><td><input name=\"index\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "index"));
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");

printf ("<table>\n");
holder = xml_firstelem (xml);
while (holder) {
   printf ("<tr><td><img src=\"");
   print_element_graphic (holder);
   printf ("\"></td><td><a href=\"");
   print_edit_command (holder);
   printf ("\">");
   print_element (holder);
   printf ("</a></td>");
   printf ("<td><a href=\"");
   print_update_command ("moveup", holder, "");
   printf ("\"><img src=\"up.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" up the list\" border=0></a>");
   printf ("<a href=\"");
   print_update_command ("movedn", holder, "");
   printf ("\"><img src=\"dn.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" down the list\" border=0></a></td>");
   printf ("</tr>\n");
   holder = xml_nextelem (holder);
}
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td>");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&view=action\"");
   printf (">Add an action</a></td><td>&nbsp;</td></tr>\n");
}
printf ("</table><br>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("parallel", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}
printf ("<h1>%sParallel</h1>\n", add_flag ? "New " : "");
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this parallel block</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=parallel>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Parallel should loop after completion?</td><td><input type=radio name=repeat value=yes");
if (!strcmp ("yes", xml_attrval (xml, "repeat"))) printf (" checked");
printf ("> Yes  <input type=radio name=repeat value=no");
if (!strcmp ("no", xml_attrval (xml, "repeat"))) printf (" checked");
printf (">No</td></tr>\n");
printf ("<tr><td>Name of index variable for loops:</td><td><input name=\"index\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "index"));
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
printf ("<table>\n");
holder = xml_firstelem (xml);
while (holder) {
   printf ("<tr><td><img src=\"");
   print_element_graphic (holder);
   printf ("\"></td><td><a href=\"");
   print_edit_command (holder);
   printf ("\">");
   print_element (holder);
   printf ("</a></td>");
   printf ("<td><a href=\"");
   print_update_command ("moveup", holder, "");
   printf ("\"><img src=\"up.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" up the list\" border=0></a>");
   printf ("<a href=\"");
   print_update_command ("movedn", holder, "");
   printf ("\"><img src=\"dn.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" down the list\" border=0></a></td>");
   printf ("</tr>\n");
   holder = xml_nextelem (holder);
}
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td>");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&view=action\"");
   printf (">Add an action</a></td><td>&nbsp;</td></tr>\n");
}
printf ("</table><br>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("alert", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}
printf ("<h1>%sAlert %s</h1>\n", add_flag ? "New " : "", xml_attrval (xml, "to"));
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this alert</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=alert>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Type of alert:</td><td><input name=\"type\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "type"));
printf ("<tr><td>Recipient:</td><td><input name=\"to\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "to"));
printf ("<tr><td>Content:</td><td><textarea name=\"content\" rows=10 cols=30>");
xml_writecontent (stdout, xml);
printf ("</textarea></td></tr>\n");
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("situation", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}
printf ("<h1>%sSituation: %s</h1>\n", add_flag ? "New " : "", xml_attrval (xml, "name"));
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this situation</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=situation>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Name of situation:</td><td><input name=\"name\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "name"));
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("handle", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}
printf ("<h1>%s: \"%s\"</h1>\n", add_flag ? "New Handler" : "Handle situation", xml_attrval (xml, "situation"));
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this handler</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"");
print_update_command ("handle", xml, "");
printf ("\" method=post>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Name of situation:</td><td><input name=\"situation\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "situation"));
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
printf ("<table>\n");
holder = xml_firstelem (xml);
while (holder) {
   printf ("<tr><td><img src=\"");
   print_element_graphic (holder);
   printf ("\"></td><td><a href=\"");
   print_edit_command (holder);
   printf ("\">");
   print_element (holder);
   printf ("</a></td>");
   printf ("<td><a href=\"");
   print_update_command ("moveup", holder, "");
   printf ("\"><img src=\"up.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" up the list\" border=0></a>");
   printf ("<a href=\"");
   print_update_command ("movedn", holder, "");
   printf ("\"><img src=\"dn.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" down the list\" border=0></a></td>");
   printf ("</tr>\n");
   holder = xml_nextelem (holder);
}
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td>");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&view=action\"");
   printf (">Add an action</a></td><td>&nbsp;</td></tr>\n");
}
printf ("</table><br>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("if", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}
printf ("<h1>%sDecision</h1>\n", add_flag ? "New " : "");
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td class=\"adddata\">");
   printf ("<a href=\"%s?command=update&item=%s&ver=%s&loc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&action=delete\"");
   printf (">Delete this decision</a></td><td>&nbsp;</td></tr>\n");
}
printf ("<hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=update>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=loc value=%s>\n", xml_attrval (query, "loc"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));
printf ("<input type=hidden name=action value=if>\n");
printf ("<table border=0 cellpadding=0 cellborder=0>\n");
printf ("<tr><td>Expression to test:</td><td><input name=\"expr\" value=\"%s\"></td></tr>\n", xml_attrval (xml, "expr"));
if (edit_perm) printf ("<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr>\n");
printf ("</table></form>\n");
printf ("The first entry in this list of actions will be executed if the expression is true;");
printf ("otherwise execution will start at the second entry and continue as a sequence.");
printf ("<table>\n");
holder = xml_firstelem (xml);
while (holder) {
   printf ("<tr><td><img src=\"");
   print_element_graphic (holder);
   printf ("\"></td><td><a href=\"");
   print_edit_command (holder);
   printf ("\">");
   print_element (holder);
   printf ("</a></td>");
   printf ("<td><a href=\"");
   print_update_command ("moveup", holder, "");
   printf ("\"><img src=\"up.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" up the list\" border=0></a>");
   printf ("<a href=\"");
   print_update_command ("movedn", holder, "");
   printf ("\"><img src=\"dn.gif\" alt=\"Move ");
   print_element_name (holder);
   printf (" down the list\" border=0></a></td>");
   printf ("</tr>\n");
   holder = xml_nextelem (holder);
}
if (edit_perm && !add_flag) {
   printf ("<tr><td>&nbsp;</td><td>");
   printf ("<a href=\"%s?command=edit&item=%s&ver=%s&parentloc=",
           xml_attrval (environment, "SCRIPT_NAME"), xml_attrval (query, "item"),
           xml_attrval (query, "ver"));
   xml_getloc (xml, sbuf, sizeof (sbuf));
   printf ("%s", sbuf);
   printf ("&view=action\"");
   printf (">Add an action</a></td><td>&nbsp;</td></tr>\n");
}
printf ("</table><br>\n");
if (add_flag) xml_free (xml);
} else if (!strcmp ("action", xml_attrval (query, "view"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
   xml = xml_create("dummy");
}

printf ("<h1>New action</h1><hr>\n");
printf ("<form action=\"%s\" method=post>\n", xml_attrval (environment, "SCRIPT_NAME"));
printf ("<input type=hidden name=command value=edit>\n");
printf ("<input type=hidden name=item value=%s>\n", xml_attrval (query, "item"));
printf ("<input type=hidden name=ver value=%s>\n", xml_attrval (query, "ver"));
printf ("<input type=hidden name=parentloc value=%s>\n", xml_attrval (query, "parentloc"));

printf ("<table border=0 cellpadding=0 cellborder=0>\n");

printf ("<tr><td><input type=radio name=view value=task></td>\n");
printf ("<td><img src=task.gif></td><td>Assign a task to a person</td></tr>\n");
printf ("<tr><td><input type=radio name=view value=data></td>\n");
printf ("<td><img src=data.gif></td><td>Do a calculation</td></tr>\n");
printf ("<tr><td><input type=radio name=view value=if></td>\n");
printf ("<td><img src=if.gif></td><td>Make a decision</td></tr>\n");
printf ("<tr><td><input type=radio name=view value=situation></td>\n");
printf ("<td><img src=sit.gif></td><td>Situation</td></tr>\n");
printf ("<tr><td><input type=radio name=view value=alert></td>\n");
printf ("<td><img src=alert.gif></td><td>Send notification</td></tr>\n");

printf ("<tr><td><input type=radio name=view value=sequence></td>\n");
printf ("<td><img src=sequence.gif></td><td>Sublist (sequence)</td></tr>\n");
printf ("<tr><td><input type=radio name=view value=parallel></td>\n");
printf ("<td><img src=parallel.gif></td><td>Sublist (parallel)</td></tr>\n");
printf ("<tr><td colspan=3><center><input type=submit value=\"Continue add\"></center></td></tr>\n");
printf ("</table></form>\n");
if (add_flag) xml_free (xml);
}
printf ("</body></html>\n\n");
}
   } else if (!strcmp (xml_attrval(query, "command"), "update")) {
sprintf (sbuf, "%s_%s", xml_attrval (query, "item"), xml_attrval (query, "ver"));
if (!user_perm (current_user, "wftkpdm", sbuf, "edit")) {
   printf ("<h2>No edit authorization</h2><hr>");
   printf ("Sorry, your current user id (%s) doesn't have permission to edit this item version.",
           xml_attrval (current_user, "name"));
   printf ("  You might want to check with the version owner or with an administrator if you think that this is in error.");
   exit (0);
}
sprintf (version_file, "%s%s_%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval (query, "item"), xml_attrval (query, "ver"));
file = fopen (version_file, "r");
if (!file) {
   sprintf (sbuf, "Unable to open procdef version file %s.\n", sbuf);
   complain();
}
version = xml_read (file);
fclose (file);
version_dirty = 1;
printf ("Content-type: text/html\n\n");
printf ("<html><head><title>wftk update - %s</title><LINK href=\"pdm.css\" rel=\"stylesheet\" type=\"text/css\"></head>\n", xml_attrval (version, "name"));
printf ("<body bgcolor=\"ffffff\">\n");

if (!strcmp ("updatedescription", xml_attrval (query, "action"))) {
updated_flag = 0;
if (strcmp (xml_attrval (version, "name"), xml_attrval (query, "title"))) {
   xml_set (version, "name", xml_attrval (query, "title"));
   if (!updated_flag) {
      printf ("<h2>Description updated</h2><hr><ul>\n");
   }
   printf ("<li> Title was changed to '%s'\n", xml_attrval (query, "title"));
   updated_flag = 1;
}
if (!updated_flag) {
   printf ("<h2>Description not updated</h2><hr>\n");
   printf ("No update was necessary.\n");
} else {
   printf ("</ul>\n");
   printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
}
} else if (!strcmp ("moveup", xml_attrval (query, "action"))) {
} else if (!strcmp ("movedn", xml_attrval (query, "action"))) {
} else if (!strcmp ("role", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("role");

xml_set (xml, "name", xml_attrval (query, "name"));
xml_set (xml, "local", xml_attrval (query, "local"));
if (!add_flag) {
   while (holder = xml_first (xml)) xml_delete (holder);
}
xml_append (xml, xml_createtext (xml_attrval (query, "content")));

if (add_flag) xml_prepend (version, xml);

printf ("<h2>Role %s %s</h2><hr>\n", xml_attrval (xml, "name"), add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("data", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("data");

xml_set (xml, "name", xml_attrval (query, "name"));
xml_set (xml, "type", xml_attrval (query, "type"));
if (strcmp ("", xml_attrval (query, "initial"))) {
   xml_set (xml, "initial", xml_attrval (query, "initial"));
}
if (!strcmp ("", xml_attrval (query, "mode"))) {
   xml_set (xml, "mode", xml_attrval (query, "mode"));
}

if (!add_flag) {
   while (holder = xml_first (xml)) xml_delete (holder);
}
if (strcmp ("", xml_attrval (query, "content")))
   xml_append (xml, xml_createtext (xml_attrval (query, "content")));

if (add_flag) xml_append (parent, xml);
if (add_flag && strcmp (parent->name, "workflow") && strcmp (xml_attrval (xml, "mode"), "local")) {
   sprintf (sbuf, "workflow.data[%s]", xml_attrval (query, "name"));
   holder = xml_loc (version, sbuf);
   if (!holder) {
      xml = xml_create ("data");
      xml_set (xml, "name", xml_attrval (query, "name"));
      xml_set (xml, "type", xml_attrval (query, "type"));
      if (strcmp ("", xml_attrval (query, "content"))) 
         xml_append (xml, xml_createtext (xml_attrval (query, "content")));
      xml_append (version, xml);
   }
}
printf ("<h2>Data item %s %s</h2><hr>\n", xml_attrval (xml, "name"), add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("task", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("task");

xml_set (xml, "label", xml_attrval (query, "label"));
xml_set (xml, "role", xml_attrval (query, "role"));

if (add_flag) xml_append (parent, xml);

printf ("<h2>Task %s %s</h2><hr>\n", xml_attrval (xml, "label"), add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("if", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("if");

xml_set (xml, "if", xml_attrval (query, "if"));

if (add_flag) xml_append (parent, xml);

printf ("<h2>Decision %s</h2><hr>\n", add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("alert", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("alert");

xml_set (xml, "type", xml_attrval (query, "type"));
xml_set (xml, "to", xml_attrval (query, "to"));
if (!add_flag) {
   while (holder = xml_first (xml)) xml_delete (holder);
}
xml_append (xml, xml_createtext (xml_attrval (query, "content")));

if (add_flag) xml_append (parent, xml);

printf ("<h2>Alert %s</h2><hr>\n", add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("handle", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("handle");

xml_set (xml, "situation", xml_attrval (query, "situation"));

if (add_flag) xml_append (parent, xml);

printf ("<h2>Handler for %s %s</h2><hr>\n", xml_attrval (xml, "situation"), add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("sequence", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("sequence");

xml_set (xml, "repeat", xml_attrval (query, "repeat"));
xml_set (xml, "index", xml_attrval (query, "index"));

if (add_flag) xml_append (parent, xml);

printf ("<h2>Sequence %s</h2><hr>\n", add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("parallel", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) xml = xml_create ("parallel");

xml_set (xml, "repeat", xml_attrval (query, "repeat"));
xml_set (xml, "index", xml_attrval (query, "index"));

if (add_flag) xml_append (parent, xml);

printf ("<h2>Parallel %s</h2><hr>\n", add_flag ? "added" : "modified");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
} else if (!strcmp ("delete", xml_attrval (query, "action"))) {
if (strcmp ("", xml_attrval (query, "loc"))) {
   xml = xml_loc (version, xml_attrval (query, "loc"));
   if (!xml || xml == version) {
      sprintf (sbuf, "The location %s doesn't exist in this item.", xml_attrval (query, "loc"));
      complain ();
   }
   add_flag = 0;
} else {
   parent = xml_loc (version, xml_attrval (query, "parentloc"));
   if (!parent) {
      sprintf (sbuf, "The parent location %s doesn't exist in this item.", xml_attrval (query, "parentloc"));
      complain();
   }
   add_flag = 1;
}
if (add_flag) {
   printf ("<h2>Huh?</h2><hr>Trying to delete without a location doesn't even make sense.\n");
   exit(0);
}

xml_delete (xml);

printf ("<h2>Delete complete</h2><hr>\n");
printf ("The version has been updated.\n");
printf ("<script>parent.frames[0].location = parent.frames[0].location.href;</script>\n");
}
printf ("</body></html>\n\n");
   } else {
      sprintf (sbuf, "Unknown command '%s'\n", xml_attrval(query, "command"));
      complain();
   }

   if (directory && index_dirty) {
      sprintf (sbuf, "%s%s", PROCESS_DEFINITION_REPOSITORY, "index.xml");
      file = fopen (sbuf, "w");
      if (!file) {
         sprintf (sbuf, "Unable to write index file %s.\n", sbuf);
         complain();
      } else {
         xml_write (file, directory);
         fclose (file);
      }
   }

   if (item && item_dirty) {
      sprintf (sbuf, "%s%s.xml", PROCESS_DEFINITION_REPOSITORY, xml_attrval(item, "id"));
      file = fopen (sbuf, "w");
      if (!file) {
         sprintf (sbuf, "Unable to write item file %s.\n", sbuf);
         complain();
      } else {
         xml_write (file, item);
         fclose (file);
      }
   }

   if (version && version_dirty) {
      file = fopen (version_file, "w");
      if (!file) {
         sprintf (sbuf, "Unable to write item file %s.\n", version_file);
         complain();
      } else {
         xml_write (file, version);
         fclose (file);
      }
   }

   xml_free (input);
   if (directory) xml_free (directory);
   if (item) xml_free (item);
   if (version) xml_free (version);

   if (debug) fclose (debug);
   return (0);
}
