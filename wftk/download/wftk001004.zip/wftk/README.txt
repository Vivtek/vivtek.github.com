wftk : open-source workflow toolkit.                  Version:      0.5
http://www.vivtek.com/wftk.html                       Platform:     AOL,Win
(c) 2000 Vivtek.                                      Release date: 10/04/2000

Original author: Michael Roberts                      Email: wftk@vivtek.com

WFTK LICENSE TERMS
------------------
This is the wftk.  It's available to you under the GNU Public License (GPL), which you can
find in COPYING.txt.  The GNU License states that you can copy and modify this program
however you like, and give it to whomever you like, as long as you credit Vivtek with
the original work, make it clear that it's not Vivtek's fault if you broke things, and
that Vivtek doesn't warrant anything anyway.  In addition, your derived works have to
be GPL'd as well, to preserve other people's rights.

Parts of the wftk are available under the GNU Library License, meaning that you
can statically link library portions of the code into your own proprietary products, but 
you still have to make it known that portions of the wftk were used to make your products,
and that Vivtek did that work, and that people can get the source code at the project
home page at the Vivtek site.

In addition, the current distribution includes the expat XML Parser by James Clark.  The
version included is not covered by the GPL; I believe that the current version has been
GPL'd but I haven't taken the time to check.  Please do not distribute derivative versions
of the expat parser without checking the current licensing situation.

For all you regular open-source types out there, I'm aiming this program smack dab at the
corporate M$ junky crowd.  They don't know the GPL from ZZ Top, so I wanted to get
everybody on the same page before getting down to business.

WHAT'S WFTK?
------------
The wftk is an open-source workflow toolkit.  This means that eventually it will be possible
to use wftk components to build and integrate any type of workflow functionality into your
corporate systems, Web sites, desktop programs, or whatever other software you might have
lying around.  Eventually.

Right now, it's still fairly primitive, and can more exactly be seen as a particular and
rather basic workflow application.  This means that it can be used to manage and automate
tasks for a small group.  Much more information is available in the documentation directory.

WHAT'S WHERE
------------
OK.  This version is v0.5.  With this version, I've established the following directories:
 - datasheets - the default datasheet repository
 - doc        - installation, customization, code, and user documentation
 - (expat)    - the expat XML parser distribution
                (saves you a download but it's not part of wftk)
 - groups     - the default user group repository
 - include    - all include files used by C code, including localdefs.h
 - pdm        - code and executable directory for the procdef manager (PDM)
 - procdefs   - the default procdef repository
 - taskmgr    - code and executable directory for the task manager
 - user       - code and executable directory for the user/permissions module
 - users      - the default user repository
 - wftk       - code and executable directory for the core workflow engine
 - xmlapi     - code directory for the C-language XML manipulation module
 - xmltools   - code and executable directory for command-line XML manipulation tools
                (Used by the current task manager.  They'll go away soon, I hope.)

Those explanations are somewhat opaque, but read the documentation and the code and it
will all be crystal clear.  Note that the four default repository directories needn't
be located in the wftk directory, unless you're running the precompiled Windows version,
which *requires* this directory structure, and requires it moreover to be in C:\WFTK.
Version 1.0 will give you Windows peons the same flexibility as the Unix elite, by including
Registry configuration tools.  But not yet.

MODIFYING THE CODE
------------------
A word of warning.  You may get this installed, see all those juicy C files, modify some
stuff, and think that when you send me diffs I'll rejoice.  I won't.  The C code *isn't
the source code* -- it's derivative of the markup-language XML files which I use to 
document the code.  So changes must be made to those XML files, run through lpml.pl (which
is right up at the top of the directory tree where you can't miss it), and *then* compiled.

The Makefiles reflect this priority (at least I hope they all do).  But of course if you
modify the C files directly, the Makefile won't warn you.  That's why I'm warning you.
Now, if you actually do modify C files and fix or extend something, of course I will read
through your patches and incorporate the good stuff -- but it will be a lot more work if
you do it that way, and so I'll do it very, very slowly.

A NOTE FOR WINDOWS USERS
------------------------
Compiling under Windows is something I do less and less these days.  If you want to use my
system, note that there is a build.bat in each code directory.  That batch file runs LPML
to generate C source, then calls MSVC to compile each binary.  It's not smart, but it works.
For your local path settings to work, you'll need to modify MSVC.BAT in the top directory.
That just sets the PATH, INCLUDE, and LIB variables so MSVC can find things.  I haven't
tried this with other Windows compilers because I don't have any.  You're welcome to try
if that's what floats your boat.

If anybody wants to build an MSVC workspace that does what it needs to do, feel free to do
so.  I'll incorporate it in this distribution.

Note that to run LPML you'll need Perl.  I use ActivePerl on Windows, and I highly
recommend it, even if its licensing terms for inclusion of Perl in Windows programs are
really obscure.

INSTALLATION GUIDE
------------------
It's in the documentation directory (/doc) as, um, install.html.


Michael Roberts
wftk@vivtek.com
http://www.vivtek.com/wftk.html

