#include <stdio.h>
#include <string.h>
#include "xmlapi.h"
#include "xmlobj.h"
#include "xml_template.h"
#include "repmgr.h"
#include "time.h"
#ifdef WINDOWS
#include "process.h"
#include "direct.h"
#else
#include "unistd.h"
#endif
#ifndef WINDOWS
void strlwr (char * str) {
   if (!str) return;
   while (*str) {
      if (*str >= 'A' && *str <= 'Z') {
         *str += 'a' - 'A';
      }
      str++;
   }
}
#endif
main (int argc, char * argv[])
{
   char config_path[512];
   char commandline[1024];
   char * chmark;
   FILE * config_file;
   FILE * file;
   XML * repository = NULL;
   XML * list = NULL;
   XML * scratch = NULL;
   int loopmode = 0;
   int args;
   char * contextid = NULL;
   char * command;
   char * arg1;
   char * arg2;
   char * arg3;
   char * arg4;
   int i;

   int len;
   int no_initial_repository = 0;
   int argp = 1; /* We'll use this to skip flags like -r for location of the config file. */
   #define argsleft (argc - argp)
   XML * mark;
   XML * mark2;
   XML * holder;
   XML * defn;
   struct tm * timeptr;
   time_t julian;

   if (argc < 2) {
      command = "loop";
      argp = argc;
   }

   arg1 = "site.opm";
   while (argsleft && *argv[argp] == '-') {
      if (!strcmp (argv[argp], "-r")) {
         argp++;
         arg1 = argv[argp];  argp++;
      } else if (!strcmp (argv[argp], "-c")) {
         argp++;
         contextid = argv[argp]; argp++;
      }
   }
   *config_path = '\0';
   if (-1 == chdir(arg1)) {
      strcpy (commandline, arg1);
      chmark = strrchr (commandline, '/');
      if (!chmark) chmark = strrchr (commandline, '\\');
      if (!chmark) {
         strcpy (config_path, commandline);
      } else {
         strcpy (config_path, chmark + 1);
         *chmark = '\0';
         if (-1 == chdir (commandline)) {
            printf ("-100: Can't find directory %s\n", commandline);
            no_initial_repository = 1;
         }
      }
   }

   if (!no_initial_repository) {
      if (!*config_path) strcpy (config_path, "site.opm");
      config_file = fopen (config_path, "r");
      if (!config_file) { /*  && complain_if_no_file) {*/
         printf ("-101: Can't find repository file '%s'\n", config_path);
         no_initial_repository = 1;
      }
   }

   if (!no_initial_repository) {
      repository = xml_read_error (config_file);
      if (xml_is (repository, "xml-error")) {
         printf ("-200: Error reading repository definition '%s'; '%s' in line %s\n", config_path, xml_attrval (repository, "message"), xml_attrval (repository, "line"));
         xml_free (repository);
         repository = NULL;
      } else {
         repos_open (repository, NULL, "cmdline");
         if (*xml_attrval (repository, "error-state")) {
            printf ("-201: Error opening repository -- %s\n", xml_attrval (repository, "error-state"));
            xml_free (repository);
            repository = NULL;
         } else {
            printf ("+000: Repository open.\n");
         }
      }
      fclose (config_file);
   }

   if (contextid && repository) {
      if (repos_context_switch (repository, contextid)) {
         printf ("Context %s loaded\n", contextid);
      }
   }

   command = "loop";
   if (argsleft) command = argv[argp++];
   if (!command) command = "loop";
   args = argsleft;
   arg1 = arg2 = arg3 = arg4 = NULL;
   if (argsleft) arg1 = argv[argp++];
   if (argsleft) arg2 = argv[argp++];
   if (argsleft) arg3 = argv[argp++];
   if (argsleft) arg4 = argv[argp++];

   do {
      if (loopmode) {
         /* printf ("\nReady!%s\n", repository ? "" : " (no repository open)"); */
         fflush (stdout);
         if (!fgets(commandline, 1024, stdin)) {
            command = "bye";
         } else {
            command = strtok (commandline, " \r\n\t");
            if (!command) command = "null";
            args = 0;
            arg1 = strtok (NULL, " \r\n\t"); if (arg1) args++;
            arg2 = strtok (NULL, " \r\n\t"); if (arg2) args++;
            arg3 = strtok (NULL, " \r\n\t"); if (arg3) args++;
            arg4 = strtok (NULL, " \r\n\t"); if (arg4) args++;
         }
      }

      strlwr (command);


      if (!strcmp (command, "help")) {
printf ("repmgr (c) 2001, Vivtek, under GPL.\n");
printf ("-----------------------------------\n");
printf ("Repository definition: %s%s\n", config_path, repository ? "" : " (not open)");
printf ("Compiled: " __DATE__ " " __TIME__ "\n");
printf ("See http://www.vivtek.com/wftk/repmgr/ for more information.\n");
printf ("\n");
if (!loopmode) printf ("Usage: repmgr [command] [args]\n");
printf ("repos [list] or [file]      : Open new repository\n");
printf ("publish                     : Activate all non-notification publishers and pages\n");
printf ("publish [list]              : Activate all non-notification publishers for list\n");
printf ("publish [list] [key]        : Publish single object\n");
printf ("make                        : Publish all *pages* (pulls data)\n");
printf ("make    [page]              : Publish a single page (pulls data)\n");
printf ("add     [list] [file]       : Add object from file (use '-' to indicate stdin)\n");
printf ("del     [list] [key]        : Delete named object\n");
printf ("mod     [list] [file]       : Modify object from file (may duplicate key) (use '-' to indicate stdin)\n");
printf ("mod     [list] [file] [key] : Modify if key known (safer) (use '-' to indicate stdin)\n");
printf ("merge   [list] [file] [key] : Merge objects (key optional) (use '-' to indicate stdin)\n");
printf ("changed [list] [key]        : Log and publish object added or changed behind the scenes\n");
printf ("diff    [list] [key] [file] : Check difference between object and file\n");
printf ("test    [file]              : Test XML well-formedness of a file\n");
printf ("list    [list]              : List keys for objects\n");
printf ("changes [date]              : List changed lists since date (date in ISO format, e.g. 2001-12-13T11:12:52\n");
printf ("changes [date] [list]       : List changes to a list since date\n");
printf ("get     [list] [key]        : Retrieve XML object\n");
printf ("edit    [list] [key]        : Retrieve XML object as HTML form\n");
printf ("display [list] [key]        : Retrieve XML object as HTML display\n");
printf ("auth    [user] [password]   : Authenticate/retrieve user\n");
printf ("ingroup [user] [group]      : Test group membership/retrieve group\n");
printf ("tasks                       : List entire task index\n");
printf ("tasks   [list]              : List tasks for a list\n");
printf ("tasks   [list] [key]        : List tasks for a specific object\n");
printf ("todo                        : List all tasks assigned to current user\n");
printf ("xact                        : Start a transaction attached to the current session\n");
printf ("xact    [key]               : Attach an existing transaction to the current session\n");
printf ("commit                      : Commit the current transaction\n");
printf ("process                     : Perform all outstanding asynchronous processing\n");
printf ("process [list]              : Perform asynchronous processing for the named list\n");
printf ("process [list] [key]        : Perform asynchronous processing for the specified object\n");
printf ("form    [list]              : Build empty form for list\n");
printf ("defn    [list]              : Retrieve XML structure definition\n");
printf ("define  [list]              : Write new XML structure definition\n");
printf ("push    [list] [remote]     : Push modifications to remote list\n");
printf ("push_all[list] [remote]     : Push all data to remote list\n");
printf ("pull    [list] [remote]     : Pull modifications from remote list\n");
printf ("pull_all[list] [remote]     : Pull all data from remote list\n");
printf ("synch   [list] [remote]     : Pull modificiations, then push\n");
printf ("submit  [list] [file]       : Create object using file contents for primary attachment ('-' for stdin)\n");
printf ("store   [list] [fname] [file]: Same, but specifying a local storage filename\n");
printf ("attach  [list] [key] [fld] [file]: Writes attachment to a given field of an existing object\n");
printf ("retrieve[list] [key] [fld] [file]: Retrieves an attachment's content\n");
printf ("checkout[list] [key] [fld]  : Same, but marks the version for update\n");
printf ("getver  [list] [key] [fld]  : Retrieves version level of a field\n");
printf ("auth    [user] [password]   : Authorize user\n");
printf ("ingroup [user] [groupid]    : Check group membership\n");
printf ("context ([id])              : save or switch session context\n");
printf ("set     [name] [value]      : save context value\n");
printf ("get     [name]              : retrieve context value\n");
printf ("time                        : Show server's local time\n");
printf ("++done++\n\n");
      } else if (!strcmp (command, "repos")) {
if (args < 1) {
   printf ("repmgr: No directory or file supplied.\n");
   continue;
}

if (repository) xml_free (repository);
repository = NULL;

*config_path = '\0';
if (-1 == chdir(arg1)) {
   chmark = strrchr (arg1, '/');
   if (!chmark) chmark = strrchr (arg1, '\\');
   if (!chmark) {
      strcpy (config_path, arg1);
   } else {
      strcpy (config_path, chmark + 1);
      *chmark = '\0';
      if (-1 == chdir (arg1)) {
         printf ("-100: Can't find directory %s ++done++\n", arg1);
         continue;
      }
   }
}

if (!*config_path) strcpy (config_path, "site.opm");
config_file = fopen (config_path, "r");
if (!config_file) { /*  && complain_if_no_file) {*/
   printf ("-101: Can't find repository file '%s' ++done++\n", config_path);
   continue;
}

repository = xml_read_error (config_file);
if (xml_is (repository, "xml-error")) {
   printf ("-200: Error reading repository definition '%s'; '%s' in line %s ++done++\n", config_path, xml_attrval (repository, "message"), xml_attrval (repository, "line"));
   xml_free (repository);
   repository = NULL;
} else {
   repos_open (repository, NULL, "cmdline");
   if (*xml_attrval (repository, "error-state")) {
      printf ("-201: Error opening repository -- %s ++done++\n", xml_attrval (repository, "error-state"));
      xml_free (repository);
      repository = NULL;
   } else {
      printf ("+000: Repository open. ++done++\n");
   }
}
fclose (config_file);
      } else if (!strcmp (command, "publish")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   repos_publish_all (repository);
   printf ("+000: OK ++done++\n");
   continue;
}

if (args < 2) {
   repos_publish_list (repository, arg1);
   printf ("+000: OK ++done++\n");
   continue;
}

repos_publish_obj (repository, arg1, arg2);
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "make")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   repos_publish_pages (repository);
   printf ("+000: OK ++done++\n");
   continue;
}

repos_publish_page (repository, arg1);
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "add")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: add [list] [file] ++done++\n");
   continue;
}

if (*arg2 == '?' || *arg2 == '!') { /* Add using Notepad, or just add a blank record and trust the default values to do something sane. */
   mark = repos_get (repository, arg1, NULL); /* Get blank record. */
   if (*arg2 == '?') { /* Edit the blank record */
      xml_save (mark, "__edit.xml");
      xml_free (mark);
#ifdef WINDOWS
      _spawnl (_P_WAIT, "c:\\windows\\notepad.exe", "notepad", "__edit.xml", NULL);
#else
      system ("vi __edit.xml");
#endif
      mark = xml_load ("__edit.xml");
      if (xml_is (mark, "xml-error")) {
         printf ("-200: Bad XML: '%s' in line %s ++done++\n", xml_attrval (mark, "message"), xml_attrval (mark, "line"));
         xml_free (mark);
         continue;
      }
   }
} else
if (*arg2 == '-') { /* Get the new record from stdin. */
   scratch = xml_create ("s");
   xml_set (scratch, "s", "");
   xml_set (scratch, "list", arg1); /* Stash list name for later; we'll be clobbering the commandline. */
   arg1 = (char *) xml_attrval (scratch, "list");
   while (fgets(commandline, 1024, stdin)) {
      if (commandline[0] == '>' && commandline[1] == '>') {
         mark = xml_parse (xml_attrval (scratch, "s"));
         if (xml_is (mark, "xml-error")) {
            printf ("-200: Error reading input; '%s' in line %s ++done++\n", xml_attrval (mark, "message"), xml_attrval (mark, "line"));
            xml_free (mark);
            mark = NULL;
         }
         break;
      }
      xml_attrcat (scratch, "s", commandline);
   }
   if (!mark) continue;
} else {
   file = fopen (arg2, "r");
   if (!file) {
      printf ("-201: Unable to open file %s ++done++\n", arg2);
      continue;
   }

   mark = xml_read_error (file);
   fclose (file);
   if (xml_is (mark, "xml-error")) {
      printf ("-200: Error reading file '%s'; '%s' in line %s ++done++\n", arg2, xml_attrval (mark, "message"), xml_attrval (mark, "line"));
      xml_free (mark);
      continue;
   }
}

repos_add (repository, arg1, mark);
printf ("+000: OK - %s ++done++\n", repos_getkey (repository, arg1, mark));
xml_free (mark);
      } else if (!strcmp (command, "del")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: del [list] [key] ++done++\n");
   continue;
}

if (repos_del (repository, arg1, arg2)) {
   printf ("-400: Unable to delete ++done++\n");
} else {
   printf ("+000: OK ++done++\n");
}
      } else if (!strcmp (command, "mod")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: mod [list] [file] ++done++\n");
   continue;
}

if (*arg2 == '?') { /* Modify with Notepad. */
   mark = repos_get (repository, arg1, arg3);
   if (mark) {
      xml_save (mark, "__edit.xml");
      xml_free (mark);
#ifdef WINDOWS
      _spawnl (_P_WAIT, "c:\\windows\\notepad.exe", "notepad", "__edit.xml", NULL);
#else
      system ("vi __edit.xml");
#endif
      mark = xml_load ("__edit.xml");
      if (xml_is (mark, "xml-error")) {
         printf ("-200: Bad XML: '%s' in line %s ++done++\n", xml_attrval (mark, "message"), xml_attrval (mark, "line"));
         xml_free (mark);
         continue;
      }
   }
} else
if (*arg2 == '-') { /* Special handling. */
   scratch = xml_create ("s");
   xml_set (scratch, "s", "");
   xml_set (scratch, "list", arg1); /* Stash list name for later; we'll be clobbering the commandline. */
   arg1 = (char *) xml_attrval (scratch, "list");
   if (args >= 3) {
      xml_set (scratch, "oldkey", arg3);
      arg3 = (char *) xml_attrval (scratch, "list");
   }
   while (fgets(commandline, 1024, stdin)) {
      if (commandline[0] == '>' && commandline[1] == '>') {
         mark = xml_parse (xml_attrval (scratch, "s"));
         if (xml_is (mark, "xml-error")) {
            printf ("Error reading input; '%s' in line %s\n", xml_attrval (mark, "message"), xml_attrval (mark, "line"));
            xml_free (mark);
            mark = NULL;
         }
         break;
      }
      xml_attrcat (scratch, "s", commandline);
   }
   if (args >= 3) {
      arg3 = (char *) xml_attrval (scratch, "oldkey");
   }
   if (!mark) continue;
} else {
   file = fopen (arg2, "r");
   if (!file) {
      printf ("-301: Unable to open file %s\n", arg2);
      continue;
   }

   mark = xml_read_error (file);
   fclose (file);
   if (xml_is (mark, "xml-error")) {
      printf ("-200: Error reading file '%s'; '%s' in line %s\n", arg2, xml_attrval (mark, "message"), xml_attrval (mark, "line"));
      continue;
   }
}

if (args < 3) {
   if (repos_mod (repository, arg1, mark, NULL)) {
      printf ("+400: Unable to modify ++done++\n");
   } else {
      printf ("+000: OK ++done++\n");
   }
} else {
   if (repos_mod (repository, arg1, mark, arg3)) {
      printf ("+400: Unable to modify ++done++\n");
   } else {
      printf ("+000: OK ++done++\n");
   }
}
xml_free (mark);
      } else if (!strcmp (command, "merge")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: merge [list] [file] ++done++\n");
   continue;
}

if (*arg2 == '-') { /* Special handling. */
   scratch = xml_create ("s");
   xml_set (scratch, "s", "");
   xml_set (scratch, "list", arg1); /* Stash list name for later; we'll be clobbering the commandline. */
   arg1 = (char *) xml_attrval (scratch, "list");
   if (args >= 3) {
      xml_set (scratch, "oldkey", arg3);
      arg3 = (char *) xml_attrval (scratch, "list");
   }
   while (fgets(commandline, 1024, stdin)) {
      if (commandline[0] == '>' && commandline[1] == '>') {
         mark = xml_parse (xml_attrval (scratch, "s"));
         if (xml_is (mark, "xml-error")) {
            printf ("-200: Error reading input; '%s' in line %s\n", xml_attrval (mark, "message"), xml_attrval (mark, "line"));
            xml_free (mark);
            mark = NULL;
         }
         break;
      }
      xml_attrcat (scratch, "s", commandline);
   }
   if (args >= 3) {
      arg3 = (char *) xml_attrval (scratch, "oldkey");
   }
   if (!mark) continue;
} else {
   file = fopen (arg2, "r");
   if (!file) {
      printf ("-301: Unable to open file %s\n", arg2);
      continue;
   }

   mark = xml_read_error (file);
   fclose (file);
   if (xml_is (mark, "xml-error")) {
      printf ("-200: Error reading file '%s'; '%s' in line %s\n", arg2, xml_attrval (mark, "message"), xml_attrval (mark, "line"));
      continue;
   }
}

if (args < 3) {
   if (repos_mod (repository, arg1, mark, NULL)) {
      printf ("+400: Unable to modify ++done++\n");
   } else {
      printf ("+000: OK ++done++\n");
   }
} else {
   if (repos_mod (repository, arg1, mark, arg3)) {
      printf ("+400: Unable to modify ++done++\n");
   } else {
      printf ("+000: OK ++done++\n");
   }
}
xml_free (mark);
      } else if (!strcmp (command, "changed")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: changed [list] [key] ++done++\n");
   continue;
}

if (args < 3) {
   repos_mod (repository, arg1, NULL, arg2);
}
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "diff")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 3) {
   printf ("-001: Usage: diff [list] [key] [file] ++done++\n");
   continue;
}

mark2 = repos_get (repository, arg1, arg2);
if (!mark2) {
   printf ("-300: Unknown list/key combination %s/%s ++done++\n", arg1, arg2);
   continue;
}
defn = repos_defn (repository, arg1);

if (*arg3 == '-') { /* Special handling. */
   scratch = xml_create ("s");
   xml_set (scratch, "s", "");
   xml_set (scratch, "list", arg1); /* Stash list name for later; we'll be clobbering the commandline. */
   arg1 = (char *) xml_attrval (scratch, "list");
   while (fgets(commandline, 1024, stdin)) {
      if (commandline[0] == '>' && commandline[1] == '>') {
         mark = xml_parse (xml_attrval (scratch, "s"));
         if (xml_is (mark, "xml-error")) {
            printf ("-200: Error reading input; '%s' in line %s ++done++\n", xml_attrval (mark, "message"), xml_attrval (mark, "line"));
            xml_free (mark);
            mark = NULL;
         }
         break;
      }
      xml_attrcat (scratch, "s", commandline);
   }
   if (!mark) continue;
} else {
   file = fopen (arg3, "r");
   if (!file) {
      printf ("-201: Unable to open file %s ++done++\n", arg3);
      continue;
   }

   mark = xml_read_error (file);
   fclose (file);
   if (xml_is (mark, "xml-error")) {
      printf ("-200: Error reading file '%s'; '%s' in line %s ++done++\n", arg3, xml_attrval (mark, "message"), xml_attrval (mark, "line"));
      continue;
   }
}

printf ("+200: OK, data follows.\n");
holder = xmlobj_diff (mark2, defn, mark);
xml_write (stdout, holder);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
xml_free (mark);
xml_free (mark2);
xml_free (holder);
      } else if (!strcmp (command, "list")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

list = xml_create ("list");
if (args) {
   xml_set (list, "id", arg1);
} else {
   xml_set (list, "id", "_lists");
}

repos_list (repository, list);
if (*xml_attrval (list, "error-state")) {
   printf ("-302: %s ++done++\n", xml_attrval (list, "error-state"));
} else {
   printf ("+100: OK, data follows.  %s key(s) found:\n", xml_attrval (list, "count"));
   mark = xml_firstelem (list);
   while (mark) {
      if (!xml_is (mark, "field") && !xml_is (mark, "link")) {
         printf (" %s\n", xml_attrval (mark, "id"));
      }
      mark = xml_nextelem (mark);
   }
   printf ("+000: OK ++done++\n");
}
      } else if (!strcmp (command, "changes")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}
if (args < 1) {
   printf ("-001: No date given. ++done++\n");
   continue;
}

if (strlen (arg1) > 10) arg1[10] = ' ';

list = xml_create ("list");

if (args > 1) {
   repos_changes (repository, list, arg1, arg2);
   printf ("+100: OK, data follows.\n");
   mark = xml_firstelem (list);
   while (mark) {
      printf (" %s\t%s\t%s\t%s\n", xml_attrval (mark, "action"), xml_attrval (mark, "time"),
                                   xml_attrval (mark, "user"),   xml_attrval (mark, "id"));
      mark = xml_nextelem (mark);
   }
} else {
   repos_changes (repository, list, arg1, NULL);
   mark = xml_firstelem (list);
   while (mark) {
      printf (" %s\t%s\n", xml_attrval (mark, "id"), xml_attrval (mark, "time"));
      mark = xml_nextelem (mark);
   }
}
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "snapshot")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}
if (args < 1) {
   printf ("-001: No list given. ++done++\n");
   continue;
}

repos_snapshot (repository, arg1);
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "get")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: get [list] [key] ++done++\n");
   continue;
}

mark = repos_get (repository, arg1, args < 2 ? NULL : arg2);
if (!mark) {
   printf ("-301: Unable to retrieve object '%s'. ++done++\n", arg2);
   continue;
}

printf ("+200: OK, XML follows.\n");
xml_write (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "check")) {
      } else if (!strcmp (command, "test")) {
if (args < 1) {
   printf ("-001: Usage: test [file] ++done++\n");
   continue;
}

file = fopen (arg1, "r");
if (!file) {
   printf ("-201: Unable to open file %s ++done++\n", arg1);
   continue;
}

mark = xml_read_error (file);
fclose (file);
if (xml_is (mark, "xml-error")) {
   printf ("-200: Error reading file '%s'; '%s' in line %s ++done++\n", arg1, xml_attrval (mark, "message"), xml_attrval (mark, "line"));
   continue;
}

printf ("+000: File OK.\n");
      } else if (!strcmp (command, "edit")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: edit [list] [key] ++done++\n");
   continue;
}

mark = repos_form (repository, arg1, args < 2 ? NULL : arg2, "edit");
printf ("+200: OK, XML follows.\n");
xml_writehtml (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "display")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: display [list] [key] ++done++\n");
   continue;
}

mark = repos_form (repository, arg1, args < 2 ? NULL : arg2, "display");
printf ("+200: OK, XML follows.\n");
xml_writehtml (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "form")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: form [list] ++done++\n");
   continue;
}

mark = repos_form (repository, arg1, NULL, NULL);
printf ("+200: OK, XML follows.\n");
xml_writehtml (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "defn")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: defn [list] ++done++\n");
   continue;
}

mark = repos_defn (repository, arg1);
printf ("+200: OK, XML follows.\n");
xml_write (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "define")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: define [list] [file] ++done++\n");
   continue;
}

file = fopen (arg2, "r");
if (!file) {
   printf ("-201: Unable to open file %s ++done++\n", arg2);
   continue;
}

mark = xml_read_error (file);
fclose (file);
if (xml_is (mark, "xml-error")) {
   printf ("-200: Error reading file '%s'; '%s' in line %s ++done++\n", arg2, xml_attrval (mark, "message"), xml_attrval (mark, "line"));
   continue;
}

repos_define (repository, arg1, mark);
printf ("+000: OK ++done++\n");
xml_free (mark);
      } else if (!strcmp (command, "push")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: push [list] ([remote]) ++done++\n");
   continue;
}

i = repos_push (repository, arg1, args > 1 ? arg2 : NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "push_all")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: push_all [list] ([remote]) ++done++\n");
   continue;
}

i = repos_push_all (repository, arg1, args > 1 ? arg2 : NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "pull")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: pull [list] ([remote]) ++done++\n");
   continue;
}

i = repos_pull (repository, arg1, args > 1 ? arg2 : NULL, NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "pull_all")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: pull_all [list] ([remote]) ++done++\n");
   continue;
}

i = repos_pull_all (repository, arg1, args > 1 ? arg2 : NULL, NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "synch")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: synch [list] ([remote]) ++done++\n");
   continue;
}

i = repos_synch (repository, arg1, args > 1 ? arg2 : NULL, NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "submit")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: submit [list] [file] ++done++\n");
   continue;
}

i = repos_pull_all (repository, arg1, args > 1 ? arg2 : NULL, NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "store")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 3) {
   printf ("-001: Usage: store [list] [fname] [file] ++done++\n");
   continue;
}

i = repos_pull_all (repository, arg1, args > 1 ? arg2 : NULL, NULL);
printf ("+000: OK (%d objects transferred) ++done++\n", i);
      } else if (!strcmp (command, "attach")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 4) {
   printf ("-001: Usage: attach [list] [key] [field] [file] ++done++\n");
   continue;
}

file = fopen (arg4, "r");
if (!file) {
   printf ("-201: Unable to open file %s ++done++\n", arg4);
   continue;
}

repos_attach (repository, arg1, arg2, arg3, NULL, file);
fclose (file);
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "retrieve")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: retrieve [list] [key] [field] ([file]) ++done++\n");
   continue;
}

mark = repos_get (repository, arg1, arg2);
if (!mark) {
   printf ("-300: No such object (%s) ++done++\n", arg2);
   continue;
}

if (args > 2 && strcmp (arg3, "-")) {
   holder = xml_search (mark, "field", "id", arg3);
   if (!holder) {
      printf ("-300: Object has no attachment %s ++done++\n", arg3);
      xml_free (mark);
      continue;
   }
} else {
   holder = xml_search (mark, "field", "type", "document");
   if (!holder) {
      printf ("-300: Object has no attachment ++done++\n");
      xml_free (mark);
      continue;
   }
}

if (args < 4 || !strcmp (arg4, "-")) {
   file = stdout;
   printf ("+300: OK, binary data follows.\n");
   if (xml_attrvalnum (holder, "ver")) {
      mark = xml_locf (holder, ".ver[%s]", xml_attrval (holder, "ver"));
      if (mark) {
         printf ("Content-length: %s\n", xml_attrval (mark, "size"));
         printf ("Content-type: %s\n", xml_attrval (mark, "mimetype"));
      } else {
         printf ("Content-length: %s\n", xml_attrval (holder, "size"));
         printf ("Content-type: %s\n", xml_attrval (holder, "mimetype"));
      }
      printf ("Content-version: %s\n", xml_attrval (holder, "ver"));
   } else {
      printf ("Content-length: %s\n", xml_attrval (holder, "size"));
      printf ("Content-type: %s\n", xml_attrval (holder, "mimetype"));
   }
   printf ("\n");
} else {
   file = fopen (arg4, "w");
   if (!file) {
      printf ("-201: Unable to open file %s for writing ++done++\n", arg4);
      continue;
   }
}

repos_retrieve (repository, arg1, arg2, xml_attrval (holder, "id"), NULL, file);
if (file == stdout) {
   printf ("\n");
} else {
   fclose (file);
}
xml_free (mark);

printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "checkout")) {
if (!repository) {
   time (&julian);
   timeptr = localtime (&julian);
   printf ("+000: %04d-%02d-%02d %02d:%02d:%02d ++done++\n",
           timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
           timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec);
   continue;
}

repos_mark_time (repository, "now");
printf ("+000: %s ++done++\n", xml_attrval (repository, "now"));
      } else if (!strcmp (command, "getver")) {
printf ("+000: NOOP ++done++\n");
      } else if (!strcmp (command, "time")) {
if (!repository) {
   time (&julian);
   timeptr = localtime (&julian);
   printf ("+000: %04d-%02d-%02d %02d:%02d:%02d ++done++\n",
           timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
           timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec);
   continue;
}

repos_mark_time (repository, "now");
printf ("+000: %s ++done++\n", xml_attrval (repository, "now"));
      } else if (!strcmp (command, "echo")) {
         printf ("+000: %s ++done++\n", arg1);
      } else if (!strcmp (command, "auth")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: auth [userid] [password] ++done++\n");
   continue;
}

mark = repos_user_auth (repository, arg1, arg2);
if (!mark) {
   printf ("-301: Unable to authenticate user '%s'. ++done++\n", arg1);
   continue;
}

printf ("+200: OK, XML follows.\n");
xml_write (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "ingroup")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: ingroup [userid] [groupid] ++done++\n");
   continue;
}

mark = repos_user_ingroup (repository, arg1, arg2);
if (!mark) {
   printf ("-301: user '%s' not found in group '%s'. ++done++\n", arg1, arg2);
   continue;
}

printf ("+200: OK, XML follows.\n");
xml_write (stdout, mark);
xml_free (mark);
printf ("\n>>\n");
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "context")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   contextid = repos_context_save (repository);
   printf ("+000: OK - %s ++done++\n", contextid);
   free (contextid);
   contextid = NULL;
} else {
   mark = repos_context_switch (repository, arg1);
   if (!mark) {
      printf ("-301: context '%s' not found. ++done++\n", arg1);
   } else {
      printf ("+100: OK ++done++\n");
      xml_free (mark);
   }
}
      } else if (!strcmp (command, "tasks")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

list = xml_create ("list");
xml_set (list, "id", "_tasks");

/*TODO: tasks for specific list or object.*/

repos_list (repository, list);
if (*xml_attrval (list, "error-state")) {
   printf ("-302: %s ++done++\n", xml_attrval (list, "error-state"));
} else {
   printf ("+100: OK, data follows.  %s key(s) found:\n", xml_attrval (list, "count"));
   mark = xml_firstelem (list);
   while (mark) {
      printf (" %s: %s", xml_attrval (mark, "id"), xml_attrval (mark, "label"));
      if (*xml_attrval (mark, "user")) printf (" (%s)", xml_attrval (mark, "user"));
      if (*xml_attrval (mark, "role")) printf (" [%s]", xml_attrval (mark, "role"));
      printf ("\n");

      mark = xml_nextelem (mark);
   }
   printf ("+000: OK ++done++\n");
}
      } else if (!strcmp (command, "todo")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

list = xml_create ("list");
xml_set (list, "id", "_todo");

repos_list (repository, list);
if (*xml_attrval (list, "error-state")) {
   printf ("-302: %s ++done++\n", xml_attrval (list, "error-state"));
} else {
   printf ("+100: OK, data follows.  %s key(s) found:\n", xml_attrval (list, "count"));
   mark = xml_firstelem (list);
   while (mark) {
      printf (" %s: %s", xml_attrval (mark, "id"), xml_attrval (mark, "label"));
      if (*xml_attrval (mark, "user")) printf (" (%s)", xml_attrval (mark, "user"));
      if (*xml_attrval (mark, "role")) printf (" [%s]", xml_attrval (mark, "role"));
      printf ("\n");

      mark = xml_nextelem (mark);
   }
   printf ("+000: OK ++done++\n");
}
      } else if (!strcmp (command, "xact")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   contextid = repos_context_save (repository);
   printf ("+000: OK - %s ++done++\n", contextid);
   free (contextid);
   contextid = NULL;
} else {
   mark = repos_context_switch (repository, arg1);
   if (!mark) {
      printf ("-301: context '%s' not found. ++done++\n", arg1);
   } else {
      printf ("+100: OK ++done++\n");
      xml_free (mark);
   }
}
      } else if (!strcmp (command, "commit")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   contextid = repos_context_save (repository);
   printf ("+000: OK - %s ++done++\n", contextid);
   free (contextid);
   contextid = NULL;
} else {
   mark = repos_context_switch (repository, arg1);
   if (!mark) {
      printf ("-301: context '%s' not found. ++done++\n", arg1);
   } else {
      printf ("+100: OK ++done++\n");
      xml_free (mark);
   }
}
      } else if (!strcmp (command, "process")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: check [list] [key] ++done++\n");
   continue;
}

mark = repos_get (repository, arg1, arg2);
if (!mark) {
   printf ("-301: Unable to retrieve object '%s'. ++done++\n", arg2);
   continue;
}

xml_free (mark);
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "set")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 2) {
   printf ("-001: Usage: set [name] [value] ++done++\n");
   continue;
}

repos_context_set (repository, arg1, arg2);
printf ("+000: OK ++done++\n");
      } else if (!strcmp (command, "read")) {
if (!repository) {
   printf ("-000: No repository open. ++done++\n");
   continue;
}

if (args < 1) {
   printf ("-001: Usage: read [name] ++done++\n");
   continue;
}

if (contextid = repos_context_get (repository, arg1)) {
   printf ("+000: OK - %s ++done++\n", contextid);
   free (contextid);
   contextid = NULL;
} else {
   printf ("-100: no such value ++done++\n");
}
      } else if (!strcmp (command, "loop")) {
         printf ("repmgr v1.0 listening: type 'help' for help.\n++done++\n");
         loopmode = 1;
      } else if (!strcmp (command, "bye")) {
         if (loopmode) {
            loopmode = 0;
            printf ("+000: Ciao ragazzo. ++done++\n");
         }
      } else if (!strcmp (command, "serve")) {
         /* Reserved for later: set up a socket listener. */
      } else if (!strcmp (command, "null")) {
         /* Does nothing. */
      } else {
         printf ("-010: Unknown command %s. ++done++\n", command);
      }

      if (list) xml_free (list);
      list = NULL;
      if (scratch) xml_free (scratch);
      scratch = NULL;
   } while (loopmode);

   if (repository) xml_free (repository);
}
