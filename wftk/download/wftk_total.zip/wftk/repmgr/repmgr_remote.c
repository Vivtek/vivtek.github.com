#include "repmgr.h"
#include "time.h"
#ifdef WINDOWS
#include "windows.h"
#include "winsock.h"
#else
#include "sys/socket.h"
#include "netinet/in.h"
#include "netdb.h"
#include "fcntl.h"
#endif
#include "stdarg.h"
#ifndef REPMGR_NAMESPACE
#define REPMGR_NAMESPACE
#endif

#define FN_NAME(x) CONCAT(REPMGR_NAMESPACE,x)
#define CONCAT(x,y) CONCAT2(x,y)
#define CONCAT2(x,y) x ## y

struct _repos_remote {
   XML * parms;
#ifdef WINDOWS
   SOCKET sock;
#else
   int sock;
#endif
};
static void _repos_remote_cleanup (void * _sock) {
   struct _repos_remote * sock = (struct _repos_remote *) _sock;

   xml_free (sock->parms);
#ifdef WINDOWS
   if (sock->sock) closesocket (sock->sock);
#else
   if (sock->sock) close (sock->sock);
#endif

   free (sock);
}
static const char * _repos_receive (struct _repos_remote * sock)
{
   char *line;
   int bufsize = 0;
   int bufsizelen = sizeof (int);
   int bytes;
/*#ifdef WINDOWS
   ULONG flag = 1;
   ioctlsocket (sock->sock, FIONBIO, &flag);
#else
   int flags = fcntl (sock->sock, F_GETFL);

   fcntl (sock->sock, F_SETFL, flags | O_NONBLOCKING);
#endif*/

   getsockopt (sock->sock, SOL_SOCKET, SO_RCVBUF, (char *) &bufsize, &bufsizelen);
   if (!bufsize) bufsize = 1024; /* Why doesn't the getsockopt work on Solaris?  Dunno. */
   line = (char *) malloc (bufsize);

   xml_set (sock->parms, "buffer", "");
   do {
      bytes = recv (sock->sock, line, bufsize, 0);

      if (bytes > 0) xml_attrncat (sock->parms, "buffer", line, bytes);
   } while (!strstr (xml_attrval (sock->parms, "buffer"), "++done++"));

   free (line);
   return xml_attrval (sock->parms, "buffer");
}
static void _repos_send (struct _repos_remote * sock)
{
   send (sock->sock, xml_attrval (sock->parms, "outgoing"), strlen (xml_attrval (sock->parms, "outgoing")), 0);
}

static struct wftk_adaptor_info * 
             _repmgr_standard_adaptor_lookup_function (int adaptor_class,
                                                       int name_length,
                                                       const char * adaptor_descriptor);
WFTK_EXPORT XML * FN_NAME(repos_open) (XML * repository, WFTK_MODULE_LOOKUP_FN * lookup_function, const char * calling_app)
{
   struct _repos_remote * sock;
   const char * host = xml_attrval (repository, "host");
   const char * mark;
   struct hostent *server;
#ifdef WINDOWS
   WSADATA wsa;
#endif
   struct sockaddr_in name;

   repos_log (repository, 2, 0, NULL, "repos", "opening repository (%s)", calling_app ? calling_app : "no app named");

   if (*host) {
      if (xml_getbin (repository)) return (repository);
#ifdef WINDOWS
      WSAStartup (MAKEWORD (1, 0), &wsa);
#endif
      sock = (struct _repos_remote *) malloc (sizeof (struct _repos_remote));
      sock->parms = xml_create ("p");
      sock->sock = 0;
      xml_set (sock->parms, "mode", "sockets");
      xml_set (sock->parms, "host", host);
      mark = strchr (host, '!');
      if (!mark) {
         xml_set (sock->parms, "server", host);
         xml_set (sock->parms, "port", "4239");
      } else {
         xml_set (sock->parms, "server", "");
         xml_attrncat (sock->parms, "server", host, mark - host);
         host = mark + 1;
         mark = strchr (host, '!');
         if (mark) {
            xml_set (sock->parms, "port", "");
            xml_attrncat (sock->parms, "port", host, mark - host);
            xml_set (sock->parms, "repos", mark + 1);
         } else {
            xml_set (sock->parms, "port", "4239");
            xml_set (sock->parms, "repos", host);
         }
      }

      server = gethostbyname (xml_attrval (sock->parms, "server"));
      if (!server) {
         xml_setf (repository, "error-state", "Unable to resolve remote server name '%s'.", xml_attrval (sock->parms, "server"));
         _repos_remote_cleanup (sock);
         return repository;
      }

      sock->sock = socket (AF_INET, SOCK_STREAM, 0);
#ifdef WINDOWS
      if (sock->sock == INVALID_SOCKET) {
#else
      if (sock->sock < 0) {
#endif
         xml_set (repository, "error-state", "Unable to allocate socket.");
         sock->sock = 0;
         _repos_remote_cleanup (sock);
         return repository;
      }


      memset (&name, 0, sizeof (struct sockaddr_in));
      name.sin_family = AF_INET;
      name.sin_port = htons (xml_attrvalnum (sock->parms, "port"));
      memcpy (&name.sin_addr, server->h_addr_list[0], server->h_length);

      if (connect(sock->sock, (struct sockaddr *) &name, sizeof (struct sockaddr)) < 0) {
         xml_setf (repository, "error-state", "Unable to connect to server '%s:%s'", xml_attrval (sock->parms, "server"), xml_attrval (sock->parms, "port"));
         _repos_remote_cleanup (sock);
         return repository;
      }

      xml_set (sock->parms, "outgoing", "\n");
      _repos_send (sock);
      _repos_receive (sock); /* Throw away greeting. */
      if (*xml_attrval (sock->parms, "repos")) {
         xml_setf (sock->parms, "outgoing", "repos %s\n", xml_attrval (sock->parms, "repos"));
         _repos_send (sock);
         if (*_repos_receive (sock) == '-') {
            xml_setf (repository, "error-state", "Unable to open repository '%s'", xml_attrval (sock->parms, "repos"));
            _repos_remote_cleanup (sock);
            return repository;
         }
      }

      xml_setbin (repository, sock, _repos_remote_cleanup);
   } else {
      repos_log (repository, 0, 0, NULL, "repmgr", "Program compiled with remote client repository library: cannot open local repository.");
      return NULL;
   }

   return repository;
}
WFTK_EXPORT XML * FN_NAME(repos_open_file) (const char * repfile, WFTK_MODULE_LOOKUP_FN * lookup_function, const char * calling_app)
{
   return NULL;
}
WFTK_EXPORT void  FN_NAME(repos_close)     (XML * repository)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (!sock) return;

   _repos_remote_cleanup ((void *) sock);
   xml_setbin (repository, NULL, NULL);
}
WFTK_EXPORT int   FN_NAME(repos_create)  (XML * repository, const char * list)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_drop)    (XML * repository, const char * list)
{
   return 0;
}
WFTK_EXPORT XML * FN_NAME(repos_defn)    (XML * repository, const char * list_id)
{
   return NULL;
}
WFTK_EXPORT XML * FN_NAME(repos_list_choices) (XML * repository, const char *list_id, XML * obj, const char *field)
{
   XML * choices = NULL;

   return choices;
}
WFTK_EXPORT XML * FN_NAME(repos_form)    (XML * repository, const char * list_id, const char * key, const char * mode)
{
   return NULL;
}
WFTK_EXPORT int   FN_NAME(repos_define)  (XML * repository, const char * list, XML * defn)
{
   return 0;
}
WFTK_EXPORT XML * FN_NAME(repos_list) (XML * repository, XML * list)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   XML * copy;
   const char * line;
   const char * end;
   char * key;
   int count = 0;

   if (!sock) return NULL;

      xml_setf (sock->parms, "outgoing", "list %s\n", xml_attrval (list, "id"));
      _repos_send (sock);
      line = _repos_receive (sock);
      if (*line == '-') {
         xml_set (list, "error-state", line + 6);
         return (list);
      }
      line = strchr (line, '\n') + 1;
      while (*line == ' ') {
         count++;
         copy = xml_create ("record");
         end = strchr (line, '\n');
         if (!end) break;
         xml_set (copy, "id", "");
         xml_attrncat (copy, "id", line + 1, end - line - 1);
         xml_append (list, copy);
         line = end + 1;
      }
      xml_setnum (list, "count", count);
      xml_set (sock->parms, "buffer", "");
      return list;
}
/* TODO: make this work again... (it being inherently more scalable.) */
WFTK_EXPORT XML * FN_NAME(repos_list_first) (XML * repository, XML * list)
{
   return NULL;
}
WFTK_EXPORT XML * FN_NAME(repos_list_next) (XML * repository, XML * list)
{
   return NULL;
}
WFTK_EXPORT XML * FN_NAME(repos_changes) (XML * repository, XML * list, const char * date, const char * list_id)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   XML * record;
   char line[1024];
   char datecopy[32];
   int  count;
   char * end;
   char * mark;
   char * mark2;

   if (!sock) return NULL;

      memset (datecopy, '\0', 32);
      strncpy (datecopy, date, 31);
      if (strlen (datecopy) > 10) datecopy[10] = 'T';
      xml_setf (sock->parms, "outgoing", "changes %s %s\n", datecopy, list_id);
      _repos_send (sock);
      mark = (char *) _repos_receive (sock);
      if (*mark == '-') {
         xml_set (list, "error-state", mark + 6);
         return (list);
      }
      mark = strchr (mark, '\n') + 1;
      while (*mark == ' ') {
         count++;
         record = xml_create ("record");
         end = strchr (mark, '\n');
         if (!end) break;
         strncpy (line, mark + 1, end - mark);
         line[end - mark] = '\0';

         mark = line;
         mark2 = strchr (mark, '\t');
         if (mark2) *mark2 = '\0';
         xml_set (record, "action", mark);
         if (mark2) {
            mark = mark2 + 1;
            mark2 = strchr (mark, '\t');
            if (mark2) *mark2 = '\0';
            xml_set (record, "time", mark);
            if (mark2) {
               mark = mark2 + 1;
               mark2 = strchr (mark, '\t');
               if (mark2) *mark2 = '\0';
               xml_set (record, "user", mark);
               if (mark2) {
                  mark = mark2 + 1;
                  mark2 = strchr (mark, '\n');
                  if (mark2) *mark2 = '\0';
                  xml_set (record, "id", mark);
               }
            }
         }

         xml_append (list, record);

         mark = end + 1;
      }
      xml_setnum (list, "count", count);
      xml_set (sock->parms, "buffer", "");


   return list;
}
WFTK_EXPORT XML * FN_NAME(repos_snapshot) (XML * repository, const char * list_id)
{

}
WFTK_EXPORT int   FN_NAME(repos_add) (XML * repository, const char * list_id, XML * object)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "add %s -\n", list_id);
      _repos_send (sock);
      xml_set (sock->parms, "outgoing", xml_string (object));
      _repos_send (sock);
      xml_set (sock->parms, "outgoing", "\n>>\n");
      _repos_send (sock);
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   /* TODO: something with return values. */

   return 0;
}


WFTK_EXPORT int   FN_NAME(repos_del) (XML * repository, const char * list_id, const char * key)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "del %s %s\n", list_id, key);
      _repos_send (sock);
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   return 0;
}

WFTK_EXPORT int   FN_NAME(repos_mod) (XML * repository, const char * list_id, XML * object, const char * key)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (!object && !key) return 1; /* This combination can occur in error situations but has no semantics. */

   if (sock) { /* Remote. */
      if (key) {
         if (object) {
            xml_setf (sock->parms, "outgoing", "mod %s - %s\n", list_id, key);
         } else {
            xml_setf (sock->parms, "outgoing", "changed %s %s\n", list_id, key);
         }
      } else {
         xml_setf (sock->parms, "outgoing", "mod %s -\n", list_id);
      }
      _repos_send (sock);
      if (object) {
         xml_set (sock->parms, "outgoing", xml_string (object));
         _repos_send (sock);
         xml_set (sock->parms, "outgoing", "\n>>\n");
         _repos_send (sock);
      }
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_merge) (XML * repository, const char * list_id, XML * object, const char * key)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (!object) return 1;  /* Unlike mod, merge makes no sense in a key-only situation. */

      if (key) {
         xml_setf (sock->parms, "outgoing", "merge %s - %s\n", list_id, key);
      } else {
         xml_setf (sock->parms, "outgoing", "merge %s -\n", list_id);
      }
      _repos_send (sock);
      if (object) {
         xml_set (sock->parms, "outgoing", xml_string (object));
         _repos_send (sock);
         xml_set (sock->parms, "outgoing", "\n>>\n");
         _repos_send (sock);
      }
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
}
WFTK_EXPORT const char * FN_NAME(repos_getkey) (XML * repository, const char * list_id, XML * object)
{
   return ( xml_attrval (object, "key"));
}
WFTK_EXPORT XML * FN_NAME(repos_get)     (XML * repository, const char * list_id, const char * key)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   const char * line;
   XML * list;
   XML * ret;
   char * end;

   if (sock) { /* Remote. */
      if (key) {
         xml_setf (sock->parms, "outgoing", "get %s %s\n", list_id, key);
      } else {
         xml_setf (sock->parms, "outgoing", "get %s\n", list_id);
      }
      _repos_send (sock);
      line = _repos_receive (sock); /* TODO: mem leak? */
      if (*line == '-') return NULL;
      line = strchr (line, '\n') + 1;
      list = xml_create ("t");
      xml_set (list, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (list, "r", line, end - line + 1);
         } else {
            xml_attrcat (list, "r", line);
            break;
         }
         line = end + 1;
      }
      ret = xml_parse (xml_attrval (list, "r"));  /* TODO: parser dependency should be optional. */
      xml_free (list);
      xml_set (sock->parms, "buffer", "");
      xml_set (ret, "list", list_id);
      xml_set (ret, "key", key);
      return ret;
   }
   return NULL;
}
WFTK_EXPORT char * FN_NAME(repos_getvalue) (XML * repository, const char * list, const char * key, const char * field)
{
   /* retrieve obj then call xmlobj_get */
   return ("");
}
WFTK_EXPORT void FN_NAME(repos_setvalue) (XML * repository, const char * list, const char * key, const char * field, const char * value)
{
   /* This will be a while.  It fronts for the adaptor, of course. */
}
WFTK_EXPORT void FN_NAME(repos_log) (XML * repository, int level, int type, XML * object, const char * subsystem, const char * message, ...)
{
   va_list arglist;
   char * msg;
   char * l;
   struct tm * timeptr;
   time_t julian;
   FILE * log;
   int loglevel = 2;

   if (*xml_attrval (repository, "loglevel")) loglevel = xml_attrvalnum (repository, "loglevel");
   if (level > loglevel) return;

   va_start (arglist, message);
   msg = xml_string_formatv (message, arglist);
   l = (level == 0) ? "fatal" :
       ((level == 1) ? "warning" :
       ((level == 2) ? "notification" :
         "debug"));
   va_end (arglist);

   time (&julian);
   timeptr = localtime (&julian);

   /*log = _repos_fopen (repository, "repository.log", "a");  * TODO: make this a general list adaptor call. *
   if (log) {
      fprintf (log, "[%04d-%02d-%02d %02d:%02d:%02d] %s %s %s\n", 
                     timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
                     timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec,
                     l, subsystem, msg);
      fclose (log);
   }*/
   free (msg);

}
WFTK_EXPORT XML * FN_NAME(repos_user_auth) (XML * repository, const char * userid, const char * password)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   XML * userbase;
   XML * ret;
   const char * line;
   const char * end;

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "auth %s %s\n", userid, password);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '\n') + 1;
      userbase = xml_create ("t");
      xml_set (userbase, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (userbase, "r", line, end - line + 1);
         } else {
            xml_attrcat (userbase, "r", line);
            break;
         }
         line = end + 1;
      }
      ret = xml_parse (xml_attrval (userbase, "r"));
      xml_free (userbase);
      xml_set (sock->parms, "buffer", "");
      return ret;
   }

   return NULL;
}

WFTK_EXPORT XML * FN_NAME(repos_user_ingroup) (XML * repository, const char * userid, const char * groupid)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   XML * userbase;
   XML * ret;
   const char * line;
   const char * end;

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "ingroup %s %s\n", userid, groupid);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '\n') + 1;
      userbase = xml_create ("t");
      xml_set (userbase, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (userbase, "r", line, end - line + 1);
         } else {
            xml_attrcat (userbase, "r", line);
            break;
         }
         line = end + 1;
      }
      ret = xml_parse (xml_attrval (userbase, "r"));
      xml_free (userbase);
      xml_set (sock->parms, "buffer", "");
      return ret;
   }

   return NULL;
}
WFTK_EXPORT char * FN_NAME(repos_context_save) (XML * repository)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   char * ret;
   char * mark;
   const char * line;
   const char * end;

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "context\n");
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '-') + 1;
      ret = strdup (line);
      mark = strstr (ret, " ++done++");
      if (mark) *mark = '\0';
      else {
         mark = strchr (ret, '\n');
         if (mark) *mark = '\0';
      }
      return (ret);
   }

   return NULL;
}
WFTK_EXPORT XML * FN_NAME(repos_context_switch) (XML * repository, const char * contextid)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   XML * temp;
   XML * context;
   const char * line;
   const char * end;

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "context %s\n", contextid);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') {
         /*wftk_session_setcontext (repository, NULL);*/
         return NULL;
      }
      line = strchr (line, '\n') + 1;
      temp = xml_create ("t");
      xml_set (temp, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (temp, "r", line, end - line + 1);
         } else {
            xml_attrcat (temp, "r", line);
            break;
         }
         line = end + 1;
      }
      context = xml_parse (xml_attrval (temp, "r"));
      xml_free (temp);
      xml_set (sock->parms, "buffer", "");
      return (context);
   }
   return NULL;
}
WFTK_EXPORT void FN_NAME(repos_context_set) (XML * repository, const char * valname, const char * value)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   const char * line;

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "set % %s\n", valname, value);
      _repos_send (sock);

      line = _repos_receive (sock);
      xml_set (sock->parms, "buffer", "");
   }
}
WFTK_EXPORT char * FN_NAME(repos_context_get) (XML * repository, const char * valname)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);
   char * mark;
   char * ret;
   const char * line;
   const char * end;

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "read %s\n", valname);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, ' ') + 1;
      ret = strdup (line);
      mark = strchr (ret, ' ');
      if (mark) *mark = '\0';
      else {
         mark = strchr (ret, '\n');
         if (mark) *mark = '\0';
      }
      return (ret);
   }

   return NULL;
}
WFTK_EXPORT XML * FN_NAME(repos_get_layout) (XML * repository, const char * layout_id)
{
   return NULL;
}
WFTK_EXPORT int   FN_NAME(repos_pull)     (XML * repository, const char *list_id, const char *remote_id, XML * changelist)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_pull_all)     (XML * repository, const char *list_id, const char *remote_id, XML * changelist)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_push)     (XML * repository, const char *list_id, const char *remote_id)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_push_all)     (XML * repository, const char *list_id, const char *remote_id)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_synch)    (XML * repository, const char *list_id, const char *remote_id, XML * changelist)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_mark_time) (XML * repository, const char *attr)
{
   struct tm * timeptr;
   time_t julian;
   char now[32];
   const char * recv;
   char * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_set (sock->parms, "outgoing", "time\n");
      _repos_send (sock);
      xml_set (repository, attr, "");
      recv = _repos_receive (sock);
      if (*recv == '-') return 1;

      mark = strchr (recv + 6, '+');
      if (!mark) return 1;

      xml_attrncat (repository, attr, recv + 6, mark - recv - 7);
      return 0;
   }

   time (&julian);
   timeptr = localtime (&julian);
   sprintf (now, "%04d-%02d-%02d %02d:%02d:%02d",
                    timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
                    timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec);
   xml_set (repository, attr, now);
}
WFTK_EXPORT XML * FN_NAME(repos_attach_open) (XML * repository, const char *list_id, const char * key, const char * field, const char * filename)
{
   return NULL;
}
WFTK_EXPORT int   FN_NAME(repos_attach_write) (void * buf, size_t size, size_t number, XML * handle)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_attach_cancel) (XML * handle)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_attach_close) (XML * repository, XML * handle)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_attach) (XML * repository, const char * list_id, const char * key, const char * field, const char * filename, FILE * incoming)
{
   return 0;
}
WFTK_EXPORT void FN_NAME(repos_attach_getver) (XML * repository, const char * list_id, const char * key, const char * field)
{
}
WFTK_EXPORT XML * FN_NAME(repos_retrieve_open) (XML * repository, const char * list_id, const char * key, const char * field, const char * ver)
{
   return NULL;
}
WFTK_EXPORT int   FN_NAME(repos_retrieve_read) (void * buf, size_t size, size_t number, XML * handle)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_retrieve_close) (XML * handle)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_retrieve) (XML * repository, const char * list_id, const char * key, const char * field, const char * ver, FILE * outgoing)
{
   int  total = 0;
   return total;
}
WFTK_EXPORT XML * FN_NAME(repos_retrieve_load) (XML * repository, const char * list_id, const char * key, const char * field, const char * ver)
{
   return NULL;
}
WFTK_EXPORT int   FN_NAME(repos_report_start)  (XML * repository, const char * list, const char * name)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_report_close)  (XML * repository, const char * report)
{
   return 0;
}
WFTK_EXPORT int   FN_NAME(repos_report_cancel) (XML * repository, const char * report)
{
   return 0;
}
WFTK_EXPORT XML * FN_NAME(repos_report_getobj) (XML * repository, const char * report)
{
   return (NULL);
}
WFTK_EXPORT int   FN_NAME(repos_report_log)    (XML * repository, const char * report, const char * format, ...)
{
   return 0;
}
WFTK_EXPORT void FN_NAME(repos_workflow_start) (XML * repository, const char * list, const char * key, XML * wf_defn, const char * wf_id)
{
}
WFTK_EXPORT void FN_NAME(repos_task_add) (XML * repository, const char * list, const char * key, XML * task_defn)
{

}
WFTK_EXPORT XML * FN_NAME(repos_tasks) (XML * repository, XML * tasklist, const char * list, const char * key, const char * user)
{
   return NULL;
}
WFTK_EXPORT XML * FN_NAME(repos_task_get) (XML * repository, const char * list, const char * key, const char * local_key)
{
   return (NULL);
}
