The repository manager is a redesign and port of code I've been working on for a couple of years in
Perl, called "OPM" -- Online Publication Manager.  The point of OPM was (and is) to manage websites in
a data-driven manner; until recently, however, it was difficult to worth with and difficult to modify.

Since I've pulled it into the wftk project, I hope for synergy on both ends: on the one hand, the
adaptor architecture should make the repository manager easy to extend, and on the other, the repmgr
also embodies and encapsulates a lot of the motivation for workflow in the first place, providing a
nice framework for content management.

The executable itself is a command-line affair; once I have the time to mess with it, I'll extend it
to include CGI execution, and of course once I get the server daemon framework running we can start
to think about a repository manager service which would listen on specialty and FTP ports, maybe.
Or something.  I guess that will all be obvious once we get that far.

At any rate, unlike the popup framework, the repository manager is written in nice, safe ANSI C.  Like
most of the wftk, it is organized into two sections: the bulk of the work is in a library, and there
is a command-line wrapper around that library.  The library can thus be dropped into any application.
The command-line wrapper assumes that the repository definition will be found in site.opm in the
current directory (the .opm extension is, of course, a holdover from OPM and allows association under
Windows for a GUI front-end, forthcoming if I ever finish it), but the library doesn't really care
where you found your repository definition.

The repository manager can be thought of as:
 - A front-end for data management (manages RDBMS and local data on an equal footing)
 - A content management system (organizes websites and allows their structured design)
 - A document management system (maintains versioned binary files and metadata)

As such, it's squarely positioned to do a lot of the back-office tasks required by a medium-sized
business organizational unit.  Along with wftk for workflow and task management, plus some GUI
framework to present the whole thing in a manageable way, we're on our way to a solid set of
enterprise software.
