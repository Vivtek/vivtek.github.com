#include "repmgr.h"
#include "xml_template.h"
#include "wiki.h"
#include "time.h"
#ifdef WINDOWS
#include "windows.h"
#include "winsock.h"
#else
#include "sys/socket.h"
#include "netinet/in.h"
#include "netdb.h"
#include "fcntl.h"
#endif
#include "../wftk/wftk.h"   /* 2003-05-26 - Look, Ma!  Workflow integration! */
#include "../wftk/wftk_session.h"
#include "stdarg.h"

static FILE * _repos_fopen (XML * repos, const char * filename, const char * mode)
{
   XML * scratch = xml_create ("s");
   FILE * ret;

   xml_setf (scratch, "f", "%s%s", xml_attrval (repos, "basedir"), filename);
   ret = fopen (xml_attrval (scratch, "f"), mode);
   xml_free (scratch);
   return (ret);
}

struct _repos_remote {
   XML * parms;
#ifdef WINDOWS
   SOCKET sock;
#else
   int sock;
#endif
};
void _repos_remote_cleanup (void * _sock) {
   struct _repos_remote * sock = (struct _repos_remote *) _sock;

   xml_free (sock->parms);
#ifdef WINDOWS
   if (sock->sock) closesocket (sock->sock);
#else
   if (sock->sock) close (sock->sock);
#endif

   free (sock);
}
const char * _repos_receive (struct _repos_remote * sock)
{
   char *line;
   int bufsize = 0;
   int bufsizelen = sizeof (int);
   int bytes;
/*#ifdef WINDOWS
   ULONG flag = 1;
   ioctlsocket (sock->sock, FIONBIO, &flag);
#else
   int flags = fcntl (sock->sock, F_GETFL);

   fcntl (sock->sock, F_SETFL, flags | O_NONBLOCKING);
#endif*/

   getsockopt (sock->sock, SOL_SOCKET, SO_RCVBUF, (char *) &bufsize, &bufsizelen);
   if (!bufsize) bufsize = 1024; /* Why doesn't the getsockopt work on Solaris?  Dunno. */
   line = (char *) malloc (bufsize);

   xml_set (sock->parms, "buffer", "");
   do {
      bytes = recv (sock->sock, line, bufsize, 0);

      if (bytes > 0) xml_attrncat (sock->parms, "buffer", line, bytes);
   } while (!strstr (xml_attrval (sock->parms, "buffer"), "++done++"));

   free (line);
   return xml_attrval (sock->parms, "buffer");
}
void _repos_send (struct _repos_remote * sock)
{
   send (sock->sock, xml_attrval (sock->parms, "outgoing"), strlen (xml_attrval (sock->parms, "outgoing")), 0);
}

static struct wftk_adaptor_info * 
             _repmgr_standard_adaptor_lookup_function (int adaptor_class,
                                                       int name_length,
                                                       const char * adaptor_descriptor);
WFTK_EXPORT XML * repos_open (XML * repository, WFTK_MODULE_LOOKUP_FN * lookup_function, const char * calling_app)
{
   struct _repos_remote * sock;
   const char * host = xml_attrval (repository, "host");
   const char * mark;
   struct hostent *server;
#ifdef WINDOWS
   WSADATA wsa;
#endif
   struct sockaddr_in name;

   repos_log (repository, 2, 0, NULL, "repos", "opening repository (%s)", calling_app ? calling_app : "no app named");

   if (*host) {
      if (xml_getbin (repository)) return (repository);
#ifdef WINDOWS
      WSAStartup (MAKEWORD (1, 0), &wsa);
#endif
      sock = (struct _repos_remote *) malloc (sizeof (struct _repos_remote));
      sock->parms = xml_create ("p");
      sock->sock = 0;
      xml_set (sock->parms, "mode", "sockets");
      xml_set (sock->parms, "host", host);
      mark = strchr (host, '!');
      if (!mark) {
         xml_set (sock->parms, "server", host);
         xml_set (sock->parms, "port", "4239");
      } else {
         xml_set (sock->parms, "server", "");
         xml_attrncat (sock->parms, "server", host, mark - host);
         host = mark + 1;
         mark = strchr (host, '!');
         if (mark) {
            xml_set (sock->parms, "port", "");
            xml_attrncat (sock->parms, "port", host, mark - host);
            xml_set (sock->parms, "repos", mark + 1);
         } else {
            xml_set (sock->parms, "port", "4239");
            xml_set (sock->parms, "repos", host);
         }
      }

      server = gethostbyname (xml_attrval (sock->parms, "server"));
      if (!server) {
         xml_setf (repository, "error-state", "Unable to resolve remote server name '%s'.", xml_attrval (sock->parms, "server"));
         _repos_remote_cleanup (sock);
         return repository;
      }

      sock->sock = socket (AF_INET, SOCK_STREAM, 0);
#ifdef WINDOWS
      if (sock->sock == INVALID_SOCKET) {
#else
      if (sock->sock < 0) {
#endif
         xml_set (repository, "error-state", "Unable to allocate socket.");
         sock->sock = 0;
         _repos_remote_cleanup (sock);
         return repository;
      }


      memset (&name, 0, sizeof (struct sockaddr_in));
      name.sin_family = AF_INET;
      name.sin_port = htons (xml_attrvalnum (sock->parms, "port"));
      memcpy (&name.sin_addr, server->h_addr_list[0], server->h_length);

      if (connect(sock->sock, (struct sockaddr *) &name, sizeof (struct sockaddr)) < 0) {
         xml_setf (repository, "error-state", "Unable to connect to server '%s:%s'", xml_attrval (sock->parms, "server"), xml_attrval (sock->parms, "port"));
         _repos_remote_cleanup (sock);
         return repository;
      }

      xml_set (sock->parms, "outgoing", "\n");
      _repos_send (sock);
      _repos_receive (sock); /* Throw away greeting. */
      if (*xml_attrval (sock->parms, "repos")) {
         xml_setf (sock->parms, "outgoing", "repos %s\n", xml_attrval (sock->parms, "repos"));
         _repos_send (sock);
         if (*_repos_receive (sock) == '-') {
            xml_setf (repository, "error-state", "Unable to open repository '%s'", xml_attrval (sock->parms, "repos"));
            _repos_remote_cleanup (sock);
            return repository;
         }
      }

      xml_setbin (repository, sock, _repos_remote_cleanup);
   } else {
      /* Local repository, so we have to tell it about the adaptors we have statically linked. */
      wftk_session_init(repository);
      if (lookup_function) {
         wftk_session_setlookup (repository, (WFTK_MODULE_LOOKUP_FN) lookup_function);
      } else {
         wftk_session_setlookup (repository, (WFTK_MODULE_LOOKUP_FN) _repmgr_standard_adaptor_lookup_function);
      }
   }

   return repository;
}
WFTK_EXPORT XML * repos_open_file (const char * repfile, WFTK_MODULE_LOOKUP_FN * lookup_function, const char * calling_app)
{
   char * buf;
   char * chmark;
   FILE * file;
   XML * ret;

   if (-1 == chdir(repfile)) {
      buf = strdup (repfile);
      chmark = strrchr (buf, '/');
      if (!chmark) chmark = strrchr (buf, '\\');
      if (chmark) {
         *chmark = '\0';
         if (-1 == chdir (buf)) {
            free (buf);
            return NULL;
         }
         repfile = chmark + 1;
         if (!*repfile) repfile = "site.opm";
      }
   } else {
      buf = strdup (repfile);
      repfile = "site.opm"; /* TODO: um.  configurable?  But where?  Compilation? */
   }

   file = fopen (repfile, "r");
   if (!file) {
      free (buf);
      return NULL;
   }

   ret = xml_parse_general (file, (XMLAPI_DATARETRIEVE) fread);
   fclose (file);
   if (!xml_is (ret, "xml-error")) {
      repos_open (ret, (WFTK_MODULE_LOOKUP_FN *)lookup_function, calling_app);
      xml_set_nodup (ret, "basedir", buf);
      return ret;
   }
   xml_free (ret);
   free (buf);
   return NULL;
}
WFTK_EXPORT void  repos_close     (XML * repository)
{
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (!sock) return;

   _repos_remote_cleanup ((void *) sock);
   xml_setbin (repository, NULL, NULL);
}
WFTK_ADAPTOR_INFO_FN LIST_localdir_get_info;
WFTK_ADAPTOR_INFO_FN LIST_delim_get_info;
WFTK_ADAPTOR_INFO_FN LIST_lines_get_info;
WFTK_ADAPTOR_INFO_FN USER_list_get_info;
WFTK_ADAPTOR_INFO_FN DATASTORE_role_get_info;
WFTK_ADAPTOR_INFO_FN DSREP_list_get_info;
WFTK_ADAPTOR_INFO_FN PDREP_list_get_info;
WFTK_ADAPTOR_INFO_FN TASKINDEX_list_get_info;
WFTK_ADAPTOR_INFO_FN PERMS_list_get_info;
#ifdef ADAPTOR_LIST_MYSQL_STATIC
WFTK_ADAPTOR_INFO_FN LIST_mysql_get_info;
#endif
#ifdef ADAPTOR_LIST_ORACLE_STATIC
WFTK_ADAPTOR_INFO_FN LIST_oracle_get_info;
#endif
#ifdef ADAPTOR_ACTION_HTTP
WFTK_ADAPTOR_INFO_FN ACTION_http_get_info;
WFTK_ADAPTOR_INFO_FN ACTION_soap_get_info;
#endif

static struct wftk_adaptor_info * _repmgr_standard_adaptor_lookup_function (int adaptor_class, int name_length, const char * adaptor_descriptor)
{
   switch (adaptor_class) {
      case LIST:
         if (!name_length || (name_length == 8 && !strncmp ("localdir", adaptor_descriptor, 8))) {
            return LIST_localdir_get_info();
         }
         if ((name_length == 5 && !strncmp ("delim", adaptor_descriptor, 5))) {
            return LIST_delim_get_info();
         }
         if ((name_length == 5 && !strncmp ("lines", adaptor_descriptor, 5))) {
            return LIST_lines_get_info();
         }
#ifdef ADAPTOR_LIST_MYSQL_STATIC
         if (name_length == 5 && !strncmp ("mysql", adaptor_descriptor, 5)) {
            return LIST_mysql_get_info();
         }
#endif
#ifdef ADAPTOR_LIST_ORACLE_STATIC
         if (name_length == 6 && !strncmp ("oracle", adaptor_descriptor, 6)) {
            return LIST_oracle_get_info();
         }
#endif
         break;
      case USER:
         if (!name_length || (name_length == 4 && !strncmp ("list", adaptor_descriptor, 4))) {
            return USER_list_get_info();
         }
      case DATASTORE:
         if ((name_length == 4 && !strncmp ("role", adaptor_descriptor, 4))) {
            return DATASTORE_role_get_info();
         }
      case DSREP:
         if (!name_length || (name_length == 4 && !strncmp ("list", adaptor_descriptor, 4))) {
            return DSREP_list_get_info();
         }
      case PDREP:
         if (!name_length || (name_length == 4 && !strncmp ("list", adaptor_descriptor, 4))) {
            return PDREP_list_get_info();
         }
      case TASKINDEX:
         if (!name_length || (name_length == 4 && !strncmp ("list", adaptor_descriptor, 4))) {
            return TASKINDEX_list_get_info();
         }
      case PERMS:
         if (!name_length || (name_length == 4 && !strncmp ("list", adaptor_descriptor, 4))) {
            return PERMS_list_get_info();
         }
      case ACTION:
#ifdef ADAPTOR_ACTION_HTTP
         if (name_length == 4 && !strncmp ("http", adaptor_descriptor, 4)) {
            return ACTION_http_get_info();
         }
         if (name_length == 4 && !strncmp ("soap", adaptor_descriptor, 4)) {
            return ACTION_soap_get_info();
         }
#endif
      break;
   }
   return NULL;
}
int _repos_publish_file (XML * pubcon, XML * publisher, const char * filespec, XML * object);
int _repos_publish_page (XML * pubcon, XML * page, XML * object, XML * publisher);
void _repos_publish_prepare (XML * repository);
WFTK_EXPORT int   repos_publish_all  (XML * repository)
{
   XML * pub;
   XML * pubcon = xml_create ("pubcon");
   XML * pubto = xml_loc (repository, ".publish-to");

   repos_report_start (repository, "_publog", NULL);
   repos_report_log (repository, "_publog", "repos_publish_all");

   /* Publish pages first. */
   repos_publish_pages (repository);

   /* Mop up non-page publishers. */
   pub = xml_firstelem (repository);
   while (pub) {
      if (xml_is (pub, "publish")) {
         /*  xml_set (pubcon, "list", xml_attrval (pub, "from")); -- TODO: this was broken for over a year.  Sigh. */
         if (!*xml_attrval (pub, "to")) {
            if (pubto) xml_set (pubcon, "fullfilespec", xml_attrval (pubto, "dir")); else xml_set (pubcon, "fullfilespec", "./");
            xml_attrcat (pubcon, "fullfilespec", xml_attrval (pub, "as"));
            xml_set (pubcon, "filespec", xml_attrval (pub, "as"));
            _repos_publish_file (repository, pub, xml_attrval (pubcon, "fullfilespec"), NULL);
         }
      }
      pub = xml_nextelem (pub);
   }

   repos_report_close (repository, "_publog");
   xml_free (pubcon);
   return 0;
}

WFTK_EXPORT int   repos_publish_list (XML * repository, const char * list)
{
   XML * pub;
   XML * page;
   XML * pubto = xml_loc (repository, ".publish-to");
   XML * pubcon = xml_create ("pubcon");
   XML * hook;

   repos_report_start (repository, "_publog", NULL);
   repos_report_log (repository, "_publog", "repos_publish_list (%s)", list);
   _repos_publish_prepare (repository);

   hook = xml_create ("repository");
   xml_setbin (hook, repository, NULL);
   xml_append (pubcon, hook);

   hook = xml_create ("files");
   xml_append (pubcon, hook);

   xml_set (pubcon, "list", list);

   /* Iterate along publishers, publishing those emanating from the given list. */
   pub = xml_firstelem (repository);
   while (pub) {
      if (xml_is (pub, "publish")) {
         if (!strcmp (xml_attrval (pub, "from"), list)) {
            if (*xml_attrval (pub, "to")) {
               page = xml_search (repository, "page", "id", xml_attrval (pub, "to"));
               if (page) _repos_publish_page (pubcon, page, NULL, pub);
               else      repos_report_log (repository, "_publog", "No page id '%s' found for publisher id '%s'",
                                           xml_attrval (pub, "to"), xml_attrval (pub, "id"));
            } else if (*xml_attrval (pub, "as")) {
               if (pubto) xml_set (pubcon, "fullfilespec", xml_attrval (pubto, "dir")); else xml_set (pubcon, "fullfilespec", "./");
               xml_attrcat (pubcon, "fullfilespec", xml_attrval (pub, "as"));
               xml_set (pubcon, "filespec", xml_attrval (pub, "as"));
               _repos_publish_file (repository, pub, xml_attrval (pubcon, "fullfilespec"), NULL);
            } else {
               repos_report_log (repository, "_publog", "No destination ('to' or 'as') specified for publisher id '%s'",
                                 xml_attrval (pub, "id"));
            }
         }
      }
      pub = xml_nextelem (pub);
   }
   repos_report_close (repository, "_publog");
   xml_free (pubcon);
   return 0;
}

int _repos_publish_obj (XML * pubcon, const char * list, XML * object);
WFTK_EXPORT int   repos_publish_obj  (XML * repository, const char * list, const char * key)
{
   int ret;
   XML * object;
   XML * pubcon = xml_create ("pubcon");
   XML * hook;

   repos_report_start (repository, "_publog", NULL);
   repos_report_log (repository, "_publog", "repos_publish_obj (%s, %s)", list, key);
   _repos_publish_prepare (repository);

   hook = xml_create ("repository");
   xml_setbin (hook, repository, NULL);
   xml_append (pubcon, hook);

   hook = xml_create ("files");
   xml_append (pubcon, hook);

   /* Do the same, but give the specific key to be published. */
   /* Find the object. */
   object = repos_get (repository, list, key);
   if (!object) {
      repos_report_log (repository, "_publog", "object not found");
      repos_report_close (repository, "_publog");
      xml_free (pubcon);
      return 0;
   }

   ret = _repos_publish_obj (pubcon, list, object);
   xml_free (object);

   repos_report_close (repository, "_publog");
   xml_free (pubcon);
   return ret;
}

int _repos_publish_obj (XML * pubcon, const char * list, XML * object)
{
   XML * pub;
   XML * page;
   XML * hook;
   XML * pubto = NULL;
   int   free_pubcon;

   XML * repository;

   if (xml_is (pubcon, "pubcon")) { /* Normal mode. */
      repository = xml_search (pubcon, "repository", NULL, NULL);
      if (!repository) return 0;
      repository = xml_getbin(repository);
      if (!repository) return 0;
      free_pubcon = 0;
      pubto = xml_loc (repository, ".publish-to");
   } else { /* Library-internal call with no publishing context; this is the repository. */
      repository = pubcon;
      pubcon = xml_create ("pubcon");
      hook = xml_create ("repository");
      xml_setbin (hook, repository, NULL);
      xml_append (pubcon, hook);
      hook = xml_create ("files");
      xml_append (pubcon, hook);
      free_pubcon = 1;
   }

   xml_set (pubcon, "list", list);

   hook = xml_search (pubcon, "object", NULL, NULL);
   if (!hook) {
      hook = xml_create ("object");
      xml_append (pubcon, hook);
   }
   xml_setbin (hook, object, NULL);

   repos_log (repository, 4, 1, NULL, "repmgr", "publishing object from list '%s'", list);

   pub = xml_firstelem (repository);
   while (pub) {
      if (xml_is (pub, "publish")) {
         if (!strcmp (xml_attrval (pub, "from"), list)) {
            if (*xml_attrval (pub, "to")) {
               page = xml_search (repository, "page", "id", xml_attrval (pub, "to"));
               if (page) _repos_publish_page (pubcon, page, object, pub);
            } else {
               if (pubto) xml_set (pubcon, "fullfilespec", xml_attrval (pubto, "dir")); else xml_set (pubcon, "fullfilespec", "./");
               xml_attrcat (pubcon, "fullfilespec", xml_attrval (pub, "as"));
               xml_set (pubcon, "filespec", xml_attrval (pub, "as"));
               _repos_publish_file (pubcon, pub, xml_attrval (pubcon, "fullfilespec"), object);
            }
         }
      }
      pub = xml_nextelem (pub);
   }
   xml_delete (xml_search (pubcon, "object", NULL, NULL));
   if (free_pubcon) xml_free (pubcon);
   return 0;
}
void _repos_publish_prepare (XML * repository)
{
   XML * page;

   page = xml_search (repository, "page", NULL, NULL);
   while (page) {
      if (xml_is (page, "page")) {
         if (!*xml_attrval (page, "page")) xml_setf (page, "page", "%s.html", xml_attrval (page, "id"));
      }
      page = xml_search_next (repository, page, "page", NULL, NULL);
   }

   /* TODO: create default _info publisher, if necessary. */
}

WFTK_EXPORT int   repos_publish_pages  (XML * repository)
{
   XML * page;
   XML * publisher;
   int close_report;
   XML * pubcon = xml_create ("pubcon");
   XML * hook;

   close_report = !repos_report_start (repository, "_publog", NULL);
   repos_report_log (repository, "_publog", "repos_publish_pages");
   _repos_publish_prepare (repository);

   hook = xml_create ("repository");
   xml_setbin (hook, repository, NULL);
   xml_append (pubcon, hook);

   hook = xml_create ("files");
   xml_append (pubcon, hook);

   /* Iterate along the pages, publishing each in turn. */
   page = xml_search (repository, "page", NULL, NULL);
   while (page) {
      if (xml_is (page, "page")) {
         publisher = xml_search (repository, "publish", "to", xml_attrval (page, "id"));
         xml_set (pubcon, "list", publisher ? xml_attrval (publisher, "from") : "");
         _repos_publish_page (pubcon, page, NULL, publisher);
      }
      page = xml_search_next (repository, page, "page", NULL, NULL);
   }

   if (close_report) repos_report_close (repository, "_publog");
   xml_free (pubcon);
   return 0;
}


WFTK_EXPORT int   repos_publish_page  (XML * repository, const char * key)
{
   XML * page;
   XML * publisher;
   XML * pubcon = xml_create ("pubcon");
   XML * hook;

   repos_report_start (repository, "_publog", NULL);
   repos_report_log (repository, "_publog", "repos_publish_page (%s)", key);
   _repos_publish_prepare (repository);

   hook = xml_create ("repository");
   xml_setbin (hook, repository, NULL);
   xml_append (pubcon, hook);

   hook = xml_create ("files");
   xml_append (pubcon, hook);

   /* Given a page, publish it. */
   page = xml_search (repository, "page", "id", key);
   if (!page) {
      repos_report_log (repository, "_publog", "No such page as %s", key);
      repos_report_close (repository, "_publog");
      xml_free (pubcon);
   }

   publisher = xml_search (repository, "publish", "to", key);
   xml_set (pubcon, "list", publisher ? xml_attrval (publisher, "from") : "");
   _repos_publish_page (pubcon, page, NULL, NULL);

   repos_report_close (repository, "_publog");

   xml_free (pubcon);
   return 0;
}

void _repos_merge_layout (XML * repository, XML * publisher, XML * layout)
{
   XML * obj_layout;
   FILE * file;
   const char * replaces;
   XML * member;
   XML * mark;

   obj_layout = NULL;
   if (*xml_attrval (publisher, "defn")) {
      file = _repos_fopen (repository, xml_attrval (publisher, "defn"), "r");
      if (file) {
         obj_layout = xml_parse_general (file, (XMLAPI_DATARETRIEVE) fread);
         if (xml_is (obj_layout, "xml-error")) {
            repos_report_log (repository, "_publog", "Bad XML in layout definition %s for publisher %s",
                                                  xml_attrval (publisher, "defn"), xml_attrval (publisher, "id"));
            xml_free (obj_layout); 
            obj_layout = NULL;
         } else {
            if (xml_is (obj_layout, "list")) xml_set (publisher, "list-layout", "yes");
            xml_copyinto (publisher, obj_layout);
            obj_layout = publisher;
         }
         fclose (file);
         xml_set (publisher, "defn", "");
      } else {
         repos_report_log (repository, "_publog", "can't find layout definition %s for publisher %s",
                                                  xml_attrval (publisher, "defn"), xml_attrval (publisher, "id"));
      }
   } else {
      obj_layout = publisher;
   }

   if (obj_layout) {
      if (*xml_attrval (obj_layout, "list-layout")) {
         member = xml_firstelem (obj_layout);
         while (member) {
            replaces = xml_attrval (member, "replaces");
            if (!*replaces) replaces = "content";
            mark = xml_search (layout, "template:value", "name", replaces);
            if (mark) xml_replacewithcontent (mark, member);

            member = xml_nextelem (member);
         }
      } else {
         replaces = xml_attrval (obj_layout, "replaces");
         if (!*replaces) replaces = "content";
         mark = xml_search (layout, "template:value", "name", replaces);
         if (mark) xml_replacewithcontent (mark, obj_layout);
      }
   }
}

int _repos_publish_to_files (XML * pubcon, const char * filespec, XML * layout, XML * page, XML * object);
int _repos_publish_page (XML * pubcon, XML * page, XML * object, XML * publisher)
{
   XML * layout;
   XML * repository;
   XML * hook;
   XML * pubto;
   int   free_pubcon;

   if (xml_is (pubcon, "pubcon")) { /* Normal mode. */
      repository = xml_search (pubcon, "repository", NULL, NULL);
      if (!repository) return 0;
      repository = xml_getbin(repository);
      if (!repository) return 0;
      free_pubcon = 0;
   } else { /* Library-internal call with no publishing context; this is the repository. */
      repository = pubcon;
      pubcon = xml_create ("pubcon");
      hook = xml_create ("repository");
      xml_setbin (hook, repository, NULL);
      xml_append (pubcon, hook);
      hook = xml_create ("files");
      xml_append (pubcon, hook);
      free_pubcon = 1;
   }
   pubto = xml_loc (repository, ".publish-to");

   xml_delete (xml_search (pubcon, "page", NULL, NULL));
   hook = xml_create ("page");
   xml_setbin (hook, page, NULL);
   xml_append (pubcon, hook);

   xml_delete (xml_search (pubcon, "publisher", NULL, NULL));
   hook = xml_create ("publisher");
   xml_setbin (hook, publisher, NULL);
   xml_append (pubcon, hook);

   /* Find layout for page. */
   layout = repos_get_layout (repository, xml_attrval (page, "layout"));
   if (!layout) return 0;

   repos_log (repository, 4, 1, NULL, "repmgr", "publishing to page '%s'", xml_attrval (page, "id"));

   /* If an object is given, get the object format and merge it with the layout. */
   /* If no object layout is specified, then no mapping is necessary. */
   _repos_merge_layout (repository, publisher, layout);
   
   /* Publish filespec. */
   if (pubto) xml_set (pubcon, "fullfilespec", xml_attrval (pubto, "dir")); else xml_set (pubcon, "fullfilespec", "./");
   xml_attrcat (pubcon, "fullfilespec", xml_attrval (page, "page"));
   xml_set (pubcon, "filespec", xml_attrval (page, "page"));
   _repos_publish_to_files (pubcon, xml_attrval (pubcon, "fullfilespec"), layout, page, object);
   if (free_pubcon) xml_free (pubcon);
   return 1;
}
int _repos_publish_file (XML * pubcon, XML * publisher, const char * filespec, XML * object)
{
   XML * layout = NULL;
   XML * obj_layout;
   FILE * file;
   const char * replaces;
   XML * member;
   XML * mark;
   XML * hook;
   int   free_pubcon;

   XML * repository;

   if (xml_is (pubcon, "pubcon")) { /* Normal mode. */
      repository = xml_search (pubcon, "repository", NULL, NULL);
      if (!repository) return 0;
      repository = xml_getbin(repository);
      if (!repository) return 0;
      free_pubcon = 0;
   } else { /* Library-internal call with no publishing context; this is the repository. */
      repository = pubcon;
      pubcon = xml_create ("pubcon");
      hook = xml_create ("repository");
      xml_setbin (hook, repository, NULL);
      xml_append (pubcon, hook);
      hook = xml_create ("files");
      xml_append (pubcon, hook);
      free_pubcon = 1;
   }

   xml_delete (xml_search (pubcon, "page", NULL, NULL));

   /* If layout named, retrieve it. */
   if (*xml_attrval (publisher, "layout")) layout = repos_get_layout (repository, xml_attrval (publisher, "layout"));

   /* If an object is given, get the object format and merge it with the layout. */
   /* If no object layout is specified, then no mapping is necessary. */
   _repos_merge_layout (repository, publisher, layout);
   
   _repos_publish_to_files (pubcon, filespec, layout, NULL, object);
   if (free_pubcon) xml_free (pubcon);
   return 0;
}
static FILE * _repos_pagefile_open (XML * repos, const char * filename)
{
   XML * scratch = xml_create ("s");
   FILE * ret;

   xml_set_nodup (scratch, "dir", xmlobj_getconf (repos, "pagebase", xml_attrval (repos, "basedir")));
   if (*filename == '/' || *filename == '\\') {
      xml_set (scratch, "f", filename);
   } else {
      xml_setf (scratch, "f", "%s%s", xml_attrval (scratch, "dir"), filename);
   }
   ret = fopen (xml_attrval (scratch, "f"), "w");
   xml_free (scratch);
   return (ret);
}

char * _repos_publish_getvalue (XML * context, XML * object, const char * value);
int _repos_publish_to_files (XML * pubcon, const char * filespec, XML * layout, XML * page, XML * object)
{
   XML * result;
   XML * publisher;
   XML * list = NULL;
   XML * list_t;
   int free_list = 0;
   XML * mark;
   XML * first;
   XML * prev;
   XML * cur;
   XML * next;
   XML * last;
   XML * repository;
   XML * hook;
   char * filesp = NULL;
   FILE * file;
   XML * files;

   repository = xml_search (pubcon, "repository", NULL, NULL);
   repository = xml_getbin (repository);
   publisher = xml_search (pubcon, "publisher", NULL, NULL);
   if (publisher) publisher = xml_getbin (publisher);

   /* Express template, once if object is supplied or filespec is a single file; iteratively otherwise. */
   if (object || !strchr (filespec, '[') || !page) { /* This case is a single file, but may express a list. */
      repos_report_log (repository, "_publog", " -- write to %s", filespec);

      xml_set (pubcon, "file", filespec);
      if (object) {
         /* Format filespec as flat template. */
         filesp = xmlobj_format (object, NULL, filespec);
         xml_set (pubcon, "file", filesp);
      }
      repos_log (repository, 6, 1, NULL, "repmgr", "publishing single object to file %s", filesp ? filesp : filespec);

      /* Is the template a list template?  If so, attempt to figure out which list should be expressed. */
      list_t = xml_search (layout, "template:list", NULL, NULL);
      if (list_t) {
         xml_set (list_t, "list", xml_attrval (pubcon, "list"));
         if (!*xml_attrval (list_t, "list")) list_t = NULL;
      }
      if (!list_t) { /* Nope, not a list expression, just a plain old page. */
         result = xml_template_apply (pubcon, layout, object, _repos_publish_getvalue);
      } else {
         list = xml_search (pubcon, "list", NULL, NULL);
         if (list) list = xml_getbin (list);
         if (!list) { /* If the publishing context doesn't already have a list, retrieve the named list. */
            list = xml_create ("list");
            free_list = 1;
            xml_set (list, "id", xml_attrval (list_t, "list"));
            xml_set (list, "order", xml_attrval (list_t, "order"));
            if (!*xml_attrval (list, "order")) xml_set (list, "order", xml_attrval (publisher, "order"));
            xml_set (list, "record", "record");
            repos_list (repository, list);
            hook = xml_create ("list");
            xml_append (pubcon, hook);
            xml_setbin (hook, list, NULL);
         }
         result = xml_template_apply_list (pubcon, layout, list, NULL, _repos_publish_getvalue);
      }

      /* Write */
      file = _repos_pagefile_open (repository, filesp ? filesp : filespec);
      if (file) {
         repos_log (repository, 7, 1, NULL, "repmgr", "file %s opened successfully", filesp ? filesp : filespec);
         if (!*xml_attrval (result, "type") || !strcmp (xml_attrval (result, "type"), "page")) {
            fprintf (file, "<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">\n<html>\n");
            xml_writecontenthtml (file, result);
            fprintf (file, "\n</html>\n");
         } else {
            xml_writecontenthtml (file, result);
         }
         fclose (file);
         files = xml_search (pubcon, "files", NULL, NULL);
         if (!files) {
            files = xml_create ("files");
            xml_append (pubcon, files);
         }
         hook = xml_create ("file");
         xml_append (files, hook);
         xml_set (hook, "file", xml_attrval (pubcon, "file"));
      }
      xml_free (result);
      if (filesp) free (filesp);

      if (!*xml_attrval (publisher, "detail")) {
         if (free_list) xml_free (list);
         return 0;
      }

      /* So we're now going to write the detail page(s) of this list.  Let's retrieve the proper publisher. */
      if (publisher) publisher = xml_search (repository, "publish", "id", xml_attrval (publisher, "detail"));
      if (!publisher) {
         repos_report_log (repository, "_publog", "Detail publisher '%s' not found", xml_attrval (publisher, "detail"));
         if (free_list) xml_free (list);
         return 0;
      }
      /* TODO: load proper detail page, set in pubcon, error if not found. */
      /* TODO: heck, have to load right *layout*. */
   }

   /* If we're here, then this filespec refers to multiple files.  It might be a detail of a list published above. */
   repos_report_log (repository, "_publog", " -- write list %s to %s", xml_attrval (pubcon, "list"), filespec);
   repos_log (repository, 6, 1, NULL, "repmgr", "publishing multiple objects to files %s", filespec);

   if (!list) {
      list = xml_create ("list");
      free_list = 1;
      xml_set (list, "id", xml_attrval (pubcon, "list"));
      xml_set (list, "order", xml_attrval (publisher, "order"));
      xml_set (list, "record", "record");
      repos_list (repository, list);
      hook = xml_create ("list");
      xml_append (pubcon, hook);
      xml_setbin (hook, list, NULL);
   }

   /* TODO: rewrite all this below to store records in the pubcon by list/key combination and not by list position. */
   first = xml_firstelem (list);
   if (!first) {
      repos_report_log (repository, "_publog", "list empty");
      if (free_list) xml_free (list);
      return 0;
   }
   xml_set (list, "first", xml_attrval (first, "id"));
   first = repos_get (repository, xml_attrval (pubcon, "list"), xml_attrval (first, "id"));
   hook = xml_search (pubcon, "first", NULL, NULL);
   if (!hook) {
      hook = xml_create ("first");
      xml_append (pubcon, hook);
   }
   xml_setbin (hook, first, NULL);

   last = xml_lastelem (list);
   xml_set (list, "last", xml_attrval (last, "id"));
   if (strcmp (xml_attrval (list, "first"), xml_attrval (list, "last"))) {
      last = repos_get (repository, xml_attrval (pubcon, "list"), xml_attrval (last, "id"));
   } else {
      last = xml_copy (first);
   }
   hook = xml_search (pubcon, "last", NULL, NULL);
   if (!hook) {
      hook = xml_create ("last");
      xml_append (pubcon, hook);
   }
   xml_setbin (hook, last, NULL);

   xml_set (list, "cur", xml_attrval (first, "id"));
   cur = xml_copy (first);

   mark = xml_firstelem (list);
   next = xml_nextelem (mark);
   if (next) next = repos_get (repository, xml_attrval (pubcon, "list"), xml_attrval (next, "id"));
   hook = xml_search (pubcon, "next", NULL, NULL);
   if (!hook) {
      hook = xml_create ("next");
      xml_append (pubcon, hook);
   }
   xml_setbin (hook, next, NULL);
   prev = NULL;
   hook = xml_search (pubcon, "prev", NULL, NULL);
   if (!hook) {
      hook = xml_create ("prev");
      xml_append (pubcon, hook);
   }
   xml_setbin (hook, prev, NULL);

   mark = xml_firstelem (list);
   while (mark) {
      /* Format filespec as flat template. */
      filesp = xmlobj_format (cur, NULL, filespec);
      xml_set (pubcon, "file", filesp);

      result = xml_template_apply (pubcon, layout, cur, _repos_publish_getvalue);

      /* Write */
      file = _repos_pagefile_open (repository, filesp);
      if (file) {
         if (!*xml_attrval (result, "type") || !strcmp (xml_attrval (result, "type"), "page")) {
            fprintf (file, "<!doctype html public \"-//w3c//dtd html 4.0 transitional//en\">\n<html>\n");
            xml_writecontenthtml (file, result);
            fprintf (file, "\n</html>\n");
         } else {
            xml_writecontenthtml (file, result);
         }
         fclose (file);
         files = xml_search (pubcon, "files", NULL, NULL);
         if (!files) {
            files = xml_create ("files");
            xml_append (pubcon, files);
         }
         hook = xml_create ("file");
         xml_append (files, hook);
         xml_set (hook, "file", xml_attrval (pubcon, "file"));
      }
      free (filesp);
      xml_free (result);

      if (!next) break;

      mark = xml_nextelem (mark);

      if (prev) xml_free (prev);
      prev = cur;
      xml_setbin (xml_search (pubcon, "prev", NULL, NULL), prev, NULL);
      cur = next;
      next = xml_nextelem (mark);
      if (next) next = repos_get (repository, xml_attrval (pubcon, "list"), xml_attrval (next, "id"));
      xml_setbin (xml_search (pubcon, "next", NULL, NULL), next, NULL);
   }
   if (prev) xml_free (prev);
   if (cur) xml_free (cur);
   if (first) xml_free (first);
   if (last) xml_free (last);
   if (free_list) xml_free (list);
}
char * _repos_macro_resolve (XML * repository, XML * page, XML * object, XML * macro, const char * value);

/* Quick little hack. */
void xml_read_attr (XML * xml, const char * attr, FILE * file)
{
   char line[1024];

   xml_set (xml, attr, "");
   while (fgets (line, sizeof(line) - 1, file)) {
      xml_attrcat (xml, attr, line);
   }
}

char * _repos_publish_getvalue (XML * context, XML * object, const char * value)
{
   const char * val;
   XML * mark;
   XML * srch;
   XML * page = context;
   XML * list = NULL;
   XML * defn;
   XML * repository = context;
   char * chmark;
   char filename[256];
   char filename2[256];
   FILE * file;
   XML * wiki;
   XML * finished;
   XML * todo;


   /* Find top.  If the context *is* the top, then we haven't got a page. */
   if (xml_is (context, "pubcon")) {
      page = xml_search (context, "page", NULL, NULL);
      if (page) page = xml_getbin (page);
      repository = xml_search (context, "repository", NULL, NULL);
      if (repository) repository = xml_getbin (repository);
      list = xml_search (context, "list", NULL, NULL);
      if (list) list = xml_getbin (list);
      defn = repos_defn (repository, xml_attrval (context, "list"));
   } else { /* Don't know if this will ever get used, but ... */
      while (xml_parent (repository)) repository = xml_parent (repository);
      if (page == repository) page = NULL;
   }

   /* Macro value? */
   srch = repository;
   if (page) if (xml_parent(page)) srch = xml_parent(page);
   mark = NULL;
   while (!mark) {
      mark = xml_search (srch, "macro", "id", value);
      if (!mark) {
         if (srch == repository) break;
         srch = xml_parent (srch);
         if (!srch) break;
      }
   }
   if (mark) {
      val = _repos_macro_resolve (repository, page, object, mark, value);
      if (val) return ((char *)val);
   }

   /* Field value? */
   if (*value == '(') { /* Named object in context. */
      strncpy (filename, value+1, sizeof (filename)-1);
      chmark = strchr (filename, ')');
      if (chmark) {
         value += chmark - filename + 2;
         *chmark = '\0';
         object = xml_search (context, filename, NULL, NULL);
         if (xml_getbin (object)) object = xml_getbin (object);
      }
   }
   if (object) {
      if (!*value) { /* default value is URL of object */
         val = xmlobj_format (object, defn, xml_attrval (context, "filespec"));
         return ((char *) val);
      }
      if (strchr (value, '[')) {
         val = xmlobj_format (object, defn, value);
         if (val) return ((char *)val);
      } else {
         val = xmlobj_get (object, defn, value);
         mark = xml_search (defn, "field", "id", value);
         if (!strcmp ("wiki", xml_attrval (mark, "type"))) {
            wiki = wiki_parse (val);
            todo = xml_loc (repository, "todo");
            if (!todo) {
               todo = xml_create ("todo");
               xml_append (repository, todo);
            }
            finished = wiki_build (repository, wiki, todo);
            xml_free (wiki);
            free ((void *)val);
            val = xml_stringcontenthtml (finished);
            xml_free (finished);
         }
         if (val) return ((char *)val);
      }
      if (!strcmp (value, "_key")) {
         return (strdup (xml_attrval (object, "key")));
      }
      if (!strcmp (value, "_list")) {
         return (strdup (xml_attrval (object, "list")));
      }
   }

   /* Page attribute? */
   if (page) {
      val = xml_attrval (page, value);
      if (*val) return (xmlobj_format (object, NULL, val));
      if (!strcmp (val, "_page")) {
         return (strdup (xml_attrval (page, "id")));
      }
      if (!strcmp (value, "_section")) {
         if (xml_loc (page, ".page")) {
            return (strdup (xml_attrval (page, "id")));
         } else if (xml_is (xml_parent(page), "page")) {
            return (strdup (xml_attrval (xml_parent (page), "id")));
         } else {
            return (strdup (xml_attrval (page, "id")));
         }
      }
   }

   /* HTML text from text directory? */
   strcpy (filename, *xml_attrval (repository, "text") ? xml_attrval (repository, "text") : "opmtext");
   strcat (filename, "/");
   strcat (filename, xml_attrval (page, "id"));
   strcat (filename, "_");
   strcat (filename, value);

   sprintf (filename2, "%s.html", filename);
   file = _repos_fopen (repository, filename2, "r");
   if (!file) {
      sprintf (filename2, "%s.htm", filename);
      file = _repos_fopen (repository, filename2, "r");
   }
   if (file) {
      mark = xml_create ("scratch");
      xml_read_attr (mark, "scratch", file);
      val = strdup (xml_attrval (mark, "scratch"));
      xml_free (mark);
      fclose (file);
      return (char *) val;
   }

   /* Wiki text? */
   sprintf (filename2, "%s.wiki", filename);
   file = _repos_fopen (repository, filename2, "r");
   if (!file) {
      sprintf (filename2, "%s.txt", filename);
      file = _repos_fopen (repository, filename2, "r");
   }
   if (file) {
      mark = xml_create ("scratch");
      xml_read_attr (mark, "scratch", file);
      wiki = wiki_parse (xml_attrval (mark, "scratch"));
      xml_free (mark);
      todo = xml_loc (repository, "todo");
      if (!todo) {
         todo = xml_create ("todo");
         xml_append (repository, todo);
      }
      finished = wiki_build (repository, wiki, todo);
      xml_free (wiki);
      val = xml_stringcontenthtml (finished);
      xml_free (finished);
      fclose (file);
      return (char *) val;
   }

   /* Page field value? */
   if (page) {
      val = xmlobj_get (page, NULL, value);
      if (val) return ((char *)val);
   }

   return (strdup (""));
}
char * _repos_macro_tool_nav (XML * repository, XML * page, XML * object, XML * defn);
char * _repos_macro_resolve (XML * repository, XML * page, XML * object, XML * macro, const char * value)
{
   char * result;
   FILE * file;
   XML * defn = NULL;

   if (!*xml_attrval (macro, "tool") || !strcmp (xml_attrval (macro, "tool"), "value")) {
      if (!*xml_attrval (macro, "value")) {
         return (strdup (xml_attrval (macro, "value")));
      }
      return xml_stringcontenthtml (macro);
   }

   if (!strcmp (xml_attrval (macro, "tool"), "include")) {
      if (!*xml_attrval (macro, "defn")) {
         file = _repos_fopen (repository, xml_attrval (macro, "defn"), "r");
         if (file) {
            /* Read the file into a string. */
            defn = xml_create ("scratch");
            xml_read_attr (defn, "scratch", file);
            result = strdup (xml_attrval (defn, "scratch"));
            fclose (file);
            xml_free (defn);
            return (result);
         }
      }
      return (strdup (""));
   }

   if (!strcmp (xml_attrval (macro, "tool"), "nav")) {
      if (*xml_attrval (macro, "defn")) {
         file = _repos_fopen (repository, xml_attrval (macro, "defn"), "r");
         if (file) {
            defn = xml_parse_general (file, (XMLAPI_DATARETRIEVE) fread);
            fclose (file);
            if (xml_is (defn, "xml-error")) {
               xml_free (defn);
               defn = NULL;
            }
         }
      }
      return _repos_macro_tool_nav (repository, page, object, defn ? defn : macro);
   }

   return (strdup (""));
}
void _repos_macro_tool_nav_express_level (XML * result,
                                          XML * repository, XML * page, XML * object,
                                          XML * template,
                                          int curlevel, int pagelevel);
void _repos_macro_tool_nav_express (XML * result,
                                    XML * repository, XML * page, XML * object,
                                    XML * master, XML * template,
                                    int curlevel, int pagelevel);
char * _repos_macro_tool_nav (XML * repository, XML * page, XML * object, XML * defn)
{
   XML * mark;
   XML * result;
   XML * nav;
   int level;
   char * res;

   /* Find page in hierarchy. */
   level = 1;
   mark = xml_parent (page);
   while (mark && mark != repository) {
      level ++;
      mark = xml_parent (mark);
   }

   result = xml_create ("nav");
   _repos_macro_tool_nav_express_level (result, repository, page, object, defn, 1, level); /* This bit is recursive. */

   res = xml_stringcontenthtml (result);
   xml_free (result);

   return (res);
}
void _repos_macro_tool_nav_express_level (XML * result, XML * repository, XML * page, XML * object, XML * template, int curlevel, int pagelevel)
{
   XML * defn;
   XML * mark;

   /* Limit this whole thing to one level down from the current page. */
   if (curlevel > pagelevel + 1) return;

   /* Let's find the appropriate level expression in the nav template. */
   defn = xml_firstelem (template);
   while (defn && xml_is (defn, "nav:level")) {
      if (!strcmp (xml_attrval (defn, "level"), "*")) break;
      if (atoi (xml_attrval (defn, "level")) == curlevel) break;
      defn = xml_nextelem (defn);
   }

   /* If there is no level which matches, but we're not at the current page's level, then we increment the level and try again.
      This might be a series of local nav bars, after all. */
   if (!defn) {
      _repos_macro_tool_nav_express_level (result, repository, page, object, template, curlevel + 1, pagelevel);
      return;
   }

   /* Now we scan up to curlevel in the site tree above the current page, and generate the entries for the ancestor and all siblings
      of the ancestor.  When we hit a nav:level element, we'll increment curlevel and call this function again. */
   mark = xml_first (defn);
   while (mark) {
      _repos_macro_tool_nav_express (result, repository, page, object, template, mark, curlevel, pagelevel);
      mark = xml_next (mark);
   }
}

void _repos_macro_tool_nav_express_piece (XML * result,
                                          XML * repository, XML * page, XML * origpage, XML * object,
                                          XML * master, XML * template,
                                          int curlevel, int pagelevel,
                                          int selected, int parent_selected);  /* A mouthful! */
void _repos_macro_tool_nav_express (XML * result, XML * repository, XML * page, XML * object, XML * master, XML * template, int curlevel, int pagelevel)
{
   XML * res;
   XML * mark;
   XML * mark_but_one;
   XML * mark2;
   int i;

   if (!xml_is_element (template)) {
      xml_append (result, xml_copy (template));
      return;
   }

   if (!strcmp (xml_name (template), "nav:list")) {
      /* Find the right level. */
      if (curlevel > pagelevel) {
         mark_but_one = NULL;
         mark = page;
      } else if (curlevel == pagelevel) {
         mark_but_one = page;
         mark = xml_parent (page);
      } else {
         mark_but_one = page;
         mark = xml_parent(page);

         for (i = curlevel; i < pagelevel; i++) {
            mark_but_one = xml_parent (mark_but_one);
            mark = xml_parent (mark);
         }
      }

      /* Iterate through it, expressing pages. */
      mark = xml_firstelem (mark);
      while (mark) {
         if (xml_is (mark, "page")) {
            mark2 = xml_first (template);
            while (mark2) {
               _repos_macro_tool_nav_express_piece (result, repository, mark, page, object, master, mark2, curlevel, pagelevel, mark == page, mark == mark_but_one);
               mark2 = xml_next (mark2);
            }
         }
         mark = xml_nextelem (mark);
      }
   } else if (!strncmp (xml_name (template), "template:", 9)) {
      res = xml_template_apply (page, template, object, _repos_publish_getvalue);
      mark = xml_first (res);
      while (mark) {
         xml_append (result, xml_copy(mark));
         mark = xml_next (mark);
      }
      xml_free (res);
   } else {
      res = xml_create (xml_name (template));
      xml_copyattrs (res, template);
      mark = xml_first (template);
      while (mark) {
         _repos_macro_tool_nav_express (res, repository, page, object, master, mark, curlevel, pagelevel);
         mark = xml_next (mark);
      }
      xml_append (result, res);
   }
}

void _repos_macro_tool_nav_express_piece (XML * result,
                                          XML * repository, XML * page, XML * origpage, XML * object,
                                          XML * master, XML * template,
                                          int curlevel, int pagelevel,
                                          int selected, int parent_selected)
{
   XML * res;
   XML * mark;
   XML * mark_but_one;
   XML * mark2;
   int test;
   int i;

   if (!xml_is_element (template)) {
      xml_append (result, xml_copy (template));
      return;
   }

   if (!strcmp  (xml_name (template), "nav:type")) {
      /* Determine whether we express this or not. */
      if (!strcmp (xml_attrval (template, "test"), "selected")) {
         test = selected;
      } else if (!strcmp (xml_attrval (template, "test"), "unselected")) {
         test = !selected && !parent_selected;
      } else if (!strcmp (xml_attrval (template, "test"), "parentselected")) {
         test = parent_selected && !selected;
      } else {
         test = *xml_attrval (page, xml_attrval (template, "test"));
      }

      if (test) {
         res = xml_create ("nav");
         mark = xml_first (template);
         while (mark) {
            _repos_macro_tool_nav_express_piece (res, repository, page, origpage, object, master, mark, curlevel, pagelevel, selected, parent_selected);
            mark = xml_next (mark);
         }
         mark = xml_first (res);
         while (mark) {
            xml_append (result, xml_copy(mark));
            mark = xml_next (mark);
         }
         xml_free (res);
      }
   } else if (!strcmp  (xml_name (template), "nav:level")) {
      _repos_macro_tool_nav_express_level (result, repository, origpage, object, master, curlevel + 1, pagelevel);
   } else if (!strncmp (xml_name (template), "template:", 9)) {
      res = xml_template_apply (page, template, object, _repos_publish_getvalue);
      if (xml_is_element (res)) {
         mark = xml_first (res);
         while (mark) {
            xml_append (result, xml_copy(mark));
            mark = xml_next (mark);
         }
         xml_free (res);
      } else {
         xml_append (result, res);
      }
   } else {
      res = xml_create (xml_name (template));
      xml_copyattrs (res, template);
      mark = xml_first (template);
      while (mark) {
         _repos_macro_tool_nav_express_piece (res, repository, page, origpage, object, master, mark, curlevel, pagelevel, selected, parent_selected);
         mark = xml_next (mark);
      }
      xml_append (result, res);
   }
}
WFTK_EXPORT int   repos_create  (XML * repository, const char * list)
{
   return 0;
}
WFTK_EXPORT int   repos_drop    (XML * repository, const char * list)
{
   return 0;
}
WFTK_EXPORT XML * repos_defn    (XML * repository, const char * list_id)
{
   XML * list;
   XML * defn;
   int   later_check = 0;
   FILE * file;

   list = xml_locf (repository, ".list[%s]", list_id);
   if (!list) {
      /* System-defined lists, first list. */
      if (!strcmp (list_id, "_sessions")) {
         list = xml_parse ("<list id=\"_sessions\" storage=\"localdir:_sessions\">\n<field id=\"key\" special=\"key\"/>\n</list>");
      } else if (!strcmp (list_id, "_views")) {
         list = xml_parse ("<list id=\"_views\" storage=\"lines:_views\">\n<field id=\"key\" special=\"key\"/>\n<field id=\"view\" type=\"text\"/>\n</list>");
      } else if (!strcmp (list_id, "_tasks")) {
         list = xml_parse ("<list id=\"_tasks\"/>");
         later_check = 1;
      } else if (!strcmp (list_id, "_todo")) {
         list = xml_parse ("<list id=\"_todo\"/>");
         later_check = 1;
      } else if (!strcmp (list_id, "_taskindex")) {
         list = xml_parse ("<list id=\"_taskindex\"/>");
         later_check = 1;
      } else if (!strcmp (list_id, "_procdefs")) {
         list = xml_parse ("<list id=\"_procdefs\" storage=\"localdir:_procdefs\">\n<field id=\"key\" special=\"key\"/>\n</list>");
         later_check = 1;
      }

      if (list) xml_append (repository, list);
      if (!later_check) return list;
   }

   if (*xml_attrval (list, "defn")) {
      file = _repos_fopen (repository, xml_attrval (list, "defn"), "r");
      if (file) {
         defn = xml_parse_general (file, (XMLAPI_DATARETRIEVE) fread);
         if (!xml_is (defn, "xml-error")) {
            xml_copyinto (list, defn);
            xml_set (list, "defn", "");
            xml_free (defn);
         }
         fclose (file);
      }
   }

   if (!strcmp (list_id, "_todo") || !strcmp (list_id, "_tasks")) {
      /* Ensure no stupidity with key or default storage defns. */
      if (!*xml_attrval (list, "storage")) xml_set (list, "storage", "localdir:_tasks");
      if (!*xml_attrval (list, "key"))     xml_set (list, "key",     "key");
      if (!*xml_attrval (list, "format"))  xml_set (list, "format",  "object"); /* Formatting looks to object for labels, etc. */
      if (!*xml_attrval (list, "order"))   xml_set (list, "order",   "priority desc");

      /* _tasks requires some particular fields. */
      if (!xml_loc (list, ".field[only_after]")) xml_prepend_pretty (list, xml_parse ("<field id=\"only_after\">"));
      if (!xml_loc (list, ".field[priority]")) xml_prepend_pretty (list, xml_parse ("<field id=\"priority\" type=\"numeric\">"));
      if (!xml_loc (list, ".field[cost]")) xml_prepend_pretty (list, xml_parse ("<field id=\"cost\" type=\"numeric\">"));
      if (!xml_loc (list, ".field[sched_end]")) xml_prepend_pretty (list, xml_parse ("<field id=\"sched_end\">"));
      if (!xml_loc (list, ".field[sched_start]")) xml_prepend_pretty (list, xml_parse ("<field id=\"sched_start\">"));
      if (!xml_loc (list, ".field[user]")) xml_prepend_pretty (list, xml_parse ("<field id=\"user\">"));
      if (!xml_loc (list, ".field[role]")) xml_prepend_pretty (list, xml_parse ("<field id=\"role\">"));
      if (!xml_loc (list, ".field[label]")) xml_prepend_pretty (list, xml_parse ("<field id=\"label\">"));
      if (!xml_loc (list, ".field[state]")) xml_prepend_pretty (list, xml_parse ("<field id=\"state\">"));
      if (!xml_loc (list, ".field[id]")) xml_prepend_pretty (list, xml_parse ("<field id=\"id\">"));
      if (!xml_loc (list, ".field[obj]")) xml_prepend_pretty (list, xml_parse ("<field id=\"obj\">"));
      if (!xml_loc (list, ".field[list]")) xml_prepend_pretty (list, xml_parse ("<field id=\"list\">"));
      if (!xml_loc (list, ".field[key]")) xml_prepend_pretty (list, xml_parse ("<field id=\"key\" special=\"key\">"));
   } else if (!strcmp (list_id, "_taskindex")) {
      /* Ensure no stupidity with key or default storage defns. */
      if (!*xml_attrval (list, "storage")) xml_set (list, "storage", "delim:_taskindex");
      if (!*xml_attrval (list, "key"))     xml_set (list, "key",     "id");
      if (!*xml_attrval (list, "create"))  xml_set (list, "create",  "yes");
      if (!*xml_attrval (list, "order"))   xml_set (list, "order",   "priority desc");

      /* _taskindex requires some particular fields. */
      if (!xml_loc (list, ".field[only_after]")) xml_prepend_pretty (list, xml_parse ("<field id=\"only_after\">"));
      if (!xml_loc (list, ".field[priority]")) xml_prepend_pretty (list, xml_parse ("<field id=\"priority\" type=\"numeric\">"));
      if (!xml_loc (list, ".field[cost]")) xml_prepend_pretty (list, xml_parse ("<field id=\"cost\" type=\"numeric\">"));
      if (!xml_loc (list, ".field[sched_end]")) xml_prepend_pretty (list, xml_parse ("<field id=\"sched_end\">"));
      if (!xml_loc (list, ".field[sched_start]")) xml_prepend_pretty (list, xml_parse ("<field id=\"sched_start\">"));
      if (!xml_loc (list, ".field[user]")) xml_prepend_pretty (list, xml_parse ("<field id=\"user\">"));
      if (!xml_loc (list, ".field[role]")) xml_prepend_pretty (list, xml_parse ("<field id=\"role\">"));
      if (!xml_loc (list, ".field[label]")) xml_prepend_pretty (list, xml_parse ("<field id=\"label\">"));
      if (!xml_loc (list, ".field[state]")) xml_prepend_pretty (list, xml_parse ("<field id=\"state\">"));
      if (!xml_loc (list, ".field[internal_id]")) xml_prepend_pretty (list, xml_parse ("<field id=\"internal_id\">"));
      if (!xml_loc (list, ".field[obj]")) xml_prepend_pretty (list, xml_parse ("<field id=\"obj\">"));
      if (!xml_loc (list, ".field[list]")) xml_prepend_pretty (list, xml_parse ("<field id=\"list\">"));
      if (!xml_loc (list, ".field[key]")) xml_prepend_pretty (list, xml_parse ("<field id=\"key\">"));
      if (!xml_loc (list, ".field[id]")) xml_prepend_pretty (list, xml_parse ("<field id=\"id\">"));
   } else {
      if (!*xml_attrval (list, "storage")) xml_setf (list, "storage", "localdir:%s", list_id);
   }

   return list;
}
WFTK_EXPORT XML * repos_list_choices (XML * repository, const char *list_id, XML * obj, const char *field) {
   XML * list;
   XML * fld;
   WFTK_ADAPTOR * ad;
   XML * mark;
   XML * state;
   XML * choices = NULL;
   XML * choice;
   XML * holder;
   XML * val;
   const char * adaptor;
   char * adaptor_buf;
   char * label;
   XML * query;

   list = repos_defn (repository, list_id);
   fld = xml_locf (list, ".field[%s]", field);

   if (!strcmp (xml_attrval (fld, "type"), "select")) {
      mark = xml_firstelem (fld);
      while (mark) {
         if (xml_is (mark, "option")) {
            if (!choices) choices = xml_create ("select");
            xml_append_pretty (choices, xml_copy (mark));
         }
         mark = xml_nextelem (mark);
      }
      return (choices);
   }

   /* State? */
   if (!strcmp (field, "_state") || !strcmp (xml_attrval (fld, "type"), "state")) {
      if (!obj) return NULL;

      choices = xml_create ("select");
      xml_set (choices, "name", field);
      xml_set_nodup (choices, "state", xmlobj_get (obj, list, field));

      if (*xml_attrval (choices, "state")) {
         state = xml_search (list, "state", "id", xml_attrval (choices, "state"));
      } else {
         state = xml_search (list, "state", NULL, NULL);
         if (state) xml_set (choices, "state", xml_attrval (state, "id"));
      }

      mark = NULL;
      if (state) mark = xml_search (state, "transition", NULL, NULL);
      if (!mark) { /* No transitions (or no such state): all states are fair game. */
         mark = xml_search (list, "state", NULL, NULL);
         while (mark) {
            if (xml_is (mark, "state")) {
               holder = xml_create ("option");
               xml_set (holder, "value", xml_attrval (mark, "id"));
               if (!strcmp (xml_attrval (mark, "id"), xml_attrval (choices, "state"))) {
                  xml_set (holder, "selected", "yes");
               }
               xml_append (holder, xml_createtext (*xml_attrval (mark, "label")
                                                   ? xml_attrval (mark, "label")
                                                   : xml_attrval (mark, "id")));
               xml_append (choices, holder);
            }
            mark = xml_nextelem (mark);
         }
      } else { /* Current state has restricted transition list. */
         holder = xml_create ("option");
         xml_set (holder, "value", xml_attrval (choices, "state"));
         xml_set (holder, "selected", "yes");
         xml_append (holder, xml_createtext (*xml_attrval (state, "label")
                                             ? xml_attrval (state, "label")
                                             : xml_attrval (state, "id")));
         xml_append (choices, holder);
         while (mark) {
            if (xml_is (mark, "transition")) {
               state = xml_search (list, "state", "id", xml_attrval (mark, "to"));
               if (strcmp (xml_attrval (state, "id"), xml_attrval (choices, "state"))) {
                  holder = xml_create ("option");
                  xml_set (holder, "value", xml_attrval (mark, "to"));
                  xml_append (holder, xml_createtext (*xml_attrval (state, "label")
                                                      ? xml_attrval (state, "label")
                                                      : xml_attrval (state, "id")));
                  xml_append (choices, holder);
               }
            }
            mark = xml_nextelem (mark);
         }
      }
      xml_unset (choices, "state");
      return (choices);
   }

   /* Permissible actions? */
   if (!strcmp (field, "_action")) {
      /* TODO */
   }

   adaptor = strchr (field, ':') ? field : fld ? (*xml_attrval (fld, "choices") ? xml_attrval (fld, "choices") : xml_attrval (fld, "storage") ) : "";
   if (*adaptor && strcmp (adaptor, "record")) { /* Ask datastore adaptor */
      if (!strncmp (adaptor, "list:", 5)) {
         adaptor_buf = strdup (adaptor + 5);
         label = strchr (adaptor_buf, ';');
         if (label) {
            *label = '\0';
            label++;
         }
         query = xml_create ("list");
         xml_set (query, "id", adaptor_buf);
         repos_list (repository, query);
         choices = xml_create ("select");
         mark = xml_firstelem (query);
         while (mark) {
            if (!xml_is (mark, "field") && !xml_is(mark, "where") && !xml_is (mark, "link")) {
               choice = xml_create ("option");
               xml_set (choice, "value", xml_attrval (mark, "id"));
               if (label) {
                  xml_append (choice, xml_createtext_nodup (xmlobj_format (mark, NULL, label)));
               } else {
                  xml_append (choice, xml_createtext (xml_attrval (mark, "id")));
               }
               xml_append_pretty (choices, choice);
            }
            mark = xml_nextelem (mark);
         }
         xml_free (query);
         free (adaptor_buf);
         return (choices);
      }

      ad = wftk_get_adaptor (repository, DATASTORE, adaptor);
      if (!ad) return NULL;
      choices = wftk_call_adaptor (ad, "choices", field, obj, list);
      wftk_free_adaptor (repository, ad);
      return (choices);
   }

   if (!fld) return NULL;

   if (*xml_attrval (fld, "link")) { /* TODO: implement linked fields. */
      return NULL;
   }

   /* Are options supplied in the field spec? */
   mark = xml_firstelem (fld);
   while (mark) {
      if (xml_is (mark, "option")) {
         if (!choices) choices = xml_create ("select");
         xml_append_pretty (choices, xml_copy (mark));
      }
      mark = xml_nextelem (mark);
   }

   return choices;
}
WFTK_EXPORT XML * repos_form    (XML * repository, const char * list_id, const char * key, const char * mode)
{
   XML * list;
   if (!repository) return NULL;
   list = repos_defn (repository, list_id);
   if (!list) return NULL;
   return repos_form_direct (repository, list, key, mode);
}
WFTK_EXPORT XML * repos_form_object (XML * repository, const char * list_id, XML * object, const char * mode)
{
   XML * list;
   if (!repository) return NULL;
   list = repos_defn (repository, list_id);
   if (!list) return NULL;
   return repos_form_object_direct (repository, list, object, mode);
}
WFTK_EXPORT XML * repos_form_direct (XML * repository, XML * list, const char * key, const char * mode)
{
   XML * object;

   /* Retrieve the object. */
   if (key) {
      object = repos_get (repository, xml_attrval (list, "id"), key);
      if (!object) return NULL;
   } else {
      object = NULL;
   }

   return repos_form_object_direct (repository, list, object, mode);
}

void _repos_default_field_layout (XML * layout, XML * field, const char * mode);
WFTK_EXPORT XML * repos_form_object_direct (XML * repository, XML * list, XML * object, const char * mode)
{
   XML * layout = NULL;
   XML * field;
   XML * state;
   XML * parent_list;
   XML * defn_field;
   XML * actions;
   XML * tr;
   XML * td;
   XML * mark;
   char * view;
   WFTK_ADAPTOR * ad;

   if (!mode) mode = "new";

   /* Ask the list how we should lay the current object out, assuming there is one. */
   /* TODO: this is where we implement form construction from the system definition (or form lookup, or whatever). */
   /* 2004-02-14 - one method: _views (see repos_view_find) */
   view = repos_view_find (repository, list, object, mode);
   if (view) {
      repos_log (repository, 4, 0, NULL, "repmgr", "building _views-derived form in mode %s for object in class %s", mode, xml_attrval (list, "id"));
      layout = xml_createtext_nodup (repos_view_express (repository, list, object, view));
      free (view);
      return (layout);
   }


   /* Otherwise we build our default. */
   repos_log (repository, 4, 0, NULL, "repmgr", "building default form in mode %s for object in class %s", mode, xml_attrval (list, "id"));

   /* The default for tasks, of course, differs from the regular run of the mill object, as field information
      comes from the parent object and its list rather than (mostly) from the _tasks list. */
   if (!strcmp (xml_attrval (list, "id"), "_tasks") || !strcmp (xml_attrval (list, "id"), "_todo")) {
      list = repos_defn (repository, "_tasks");

      layout = xml_create ("table");
      repos_log (repository, 4, 0, NULL, "repmgr", "task's parent list is %s", xml_attrval (object, "list"));
      parent_list = repos_defn (repository, xml_attrval (object, "list"));
      /* For tasks, we first scan the object itself for fields, and display them using labeling info from the parent object's list. */
      field = xml_firstelem (object);
      while (field) {
         if (xml_is (field, "field")) {
            defn_field = xml_search (parent_list, "field", "id", xml_attrval (field, "id"));
            if (strcmp (xml_attrval (defn_field, "special"), "rest_xml")) {
               _repos_default_field_layout (layout, defn_field ? defn_field : field, mode);
            }
         }
         field = xml_nextelem (field);
      }

      /* We then scan the task defn for all fields with a display-mode attribute, and add them to the form. */
      field = xml_firstelem (list);
      while (field) {
         if (xml_is (field, "field") && *xml_attrval (field, "display-mode")) {
            _repos_default_field_layout (layout, field, (strcmp (mode, "edit") && strcmp (mode, "new")) ? mode : xml_attrval (field, "display-mode"));
         }
         field = xml_nextelem (field);
      }
   }

   /* If not a task, we build a simple layout. */
   if (!layout) {
      layout = xml_create ("table");
      field = xml_create ("input");
      xml_set (field, "name", "_control.list");
      xml_set (field, "type", "hidden");
      xml_set (field, "value", xml_attrval (list, "id"));
      xml_append_pretty (layout, field);
      if (object) {
         field = xml_create ("input");
         xml_set (field, "name", "_control.key");
         xml_set (field, "type", "hidden");
         xml_set_nodup (field, "value", xmlobj_getkey (object, list));
         xml_append_pretty (layout, field);
      }
      field = xml_firstelem (list ? ((!strcmp (xml_attrval (list, "format"), "object") && object) ? object : list) : object);
      while (field) {
         if (xml_is (field, "field") && strcmp (xml_attrval (field, "special"), "rest_xml")) { /* rest_xml fields are invisible. */
            _repos_default_field_layout (layout, field, mode);
         } /* TODO: how about lists and links? */
         field = xml_nextelem (field);
      }

      /* Add standard actions. */
      if ((!object || !strcmp (mode, "new") || !strcmp (mode, "edit")) && strcmp (xml_attrval (list, "defaultview"), "nobuttons")) {
         actions = repos_action_list_object_direct (repository, list, object, mode);
         tr = xml_create ("tr");
         td = xml_create ("td");
         xml_append_pretty (layout, tr);
         xml_append_pretty (tr, td);
         xml_set (td, "colspan", "2");
         tr = xml_create ("center");
         xml_append_pretty (td, tr);
         for (mark = xml_firstelem (actions); mark; mark = xml_nextelem (mark)) {
            field = xml_create ("input");
            xml_setf (field, "name", "_action.%s", xml_attrval (mark, "id"));
            xml_set (field, "type", "submit");
            xml_set  (field, "value", xml_attrval (mark, "label"));
            xml_append (tr, field);
            xml_append (tr, xml_create ("nbsp"));
            xml_append (tr, xml_create ("nbsp"));
         }
      }
   }

   return repos_format_object (repository, list, object, layout);
}
void _repos_default_field_layout (XML * layout, XML * field, const char * mode)
{
   XML * row;
   XML * col;
   XML * val;

   row = xml_create ("tr");
   col = xml_create ("td");
   xml_append (row, col);
   xml_append (col, xml_createtext (*xml_attrval (field, "label") ? xml_attrval (field, "label") : xml_attrval (field, "id")));
   if (strcmp (xml_attrval (field, "type"), "text") && strcmp (xml_attrval (field, "type"), "wiki")) {
      col = xml_create ("td");
      xml_append (row, col);
      val = xml_create ("template:value");
      xml_set (val, "name", xml_attrval (field, "id"));
      xml_set (val, "storage", xml_attrval (field, "storage"));
      xml_set (val, "mode", mode);
      xml_append (col, val);
   } else {
      xml_set (col, "colspan", "2");
      xml_append_pretty (layout, row);
      row = xml_create ("tr");
      col = xml_create ("td");
      xml_append (row, col);
      xml_set (col, "colspan", "2");
      val = xml_create ("template:value");
      xml_set (val, "name", xml_attrval (field, "id"));
      xml_set (val, "storage", xml_attrval (field, "storage"));
      xml_set (val, "mode", mode);
      xml_append (col, val);
   }
   xml_append_pretty (layout, row);
}
WFTK_EXPORT XML * repos_form_object_field  (XML * repository, XML * list, XML * object, const char * field_name)
{
   XML * field;
   XML * spec;
   XML * choices;
   XML * mark;
   XML * state;
   WFTK_ADAPTOR * ad;
   XML * val = NULL;
   char * value = NULL;
   const char * t;
   const char * f;

   spec = xml_locf (list ? list : object, ".field[%s]", field_name);
   if (object) value = xmlobj_get (object, list, field_name);

   /* Select drop-down if repos_list_choices can come up with a list of value choices. */
   /* Note: this includes state selection fields. */
   if (strchr (xml_attrval (spec, "storage"), ':') || !strcmp (xml_attrval (spec, "type"), "select")) {
      choices = repos_list_choices (repository, xml_attrval (list, "id"), object,
                                    strchr (xml_attrval (spec, "storage"), ':') ? xml_attrval (spec, "storage") : field_name);
      if (choices) {
         val = xml_create ("select");
         xml_set (val, "name", field_name);
         if (*xml_attrval (spec, "size")) xml_set (val, "size", xml_attrval (spec, "size"));
         if (*xml_attrval (spec, "class")) xml_set (val, "class", xml_attrval (spec, "class"));
         if (*xml_attrval (spec, "style")) xml_set (val, "style", xml_attrval (spec, "style"));
         mark = xml_firstelem (choices);
         while (mark) {
            if (value && !strcmp (value, xml_attrval (mark, "value"))) xml_set (mark, "selected", "yes");
            xml_append_pretty (val, xml_copy (mark));
            mark = xml_nextelem (mark);
         }
      }
      xml_free (choices);
      if (value) free (value);
      return (val);
   }

   /* Next, normal text fields. */
   if (!*xml_attrval (spec, "type") || !strcmp (xml_attrval (spec, "type"), "string")
                                    || !strcmp (xml_attrval (spec, "type"), "numeric")) {
      val = xml_create ("input");
      xml_set (val, "name", field_name);
      if (*xml_attrval (spec, "size")) xml_set (val, "size", xml_attrval (spec, "size"));
      if (*xml_attrval (spec, "class")) xml_set (val, "class", xml_attrval (spec, "class"));
      if (*xml_attrval (spec, "style")) xml_set (val, "style", xml_attrval (spec, "style"));
      if (value) xml_set_nodup (val, "value", xmlobj_get (object, list, field_name));
      return (val);
   }

   /* Attachment fields = upload fields. TODO: something sensible if an attachment is already present. */
   if (!strcmp (xml_attrval (spec, "type"), "document")) {
      val = xml_create ("input");
      xml_set (val, "name", xml_attrval (spec, "id"));
      xml_set (val, "type", "file");
      if (*xml_attrval (spec, "size")) xml_set (val, "size", xml_attrval (spec, "size"));
      if (*xml_attrval (spec, "class")) xml_set (val, "class", xml_attrval (spec, "class"));
      if (*xml_attrval (spec, "style")) xml_set (val, "style", xml_attrval (spec, "style"));

      if (value) free (value);
      return (val);
   }

   /* Text/Wiki fields, that is, textareas. */
   if (!strcmp (xml_attrval (spec, "type"), "text") || !strcmp (xml_attrval (spec, "type"), "wiki")) {
      val = xml_create ("textarea");
      xml_set (val, "name", field_name);
      if (*xml_attrval (spec, "rows")) xml_set (val, "rows", xml_attrval (spec, "rows"));
      if (*xml_attrval (spec, "cols")) xml_set (val, "cols", xml_attrval (spec, "cols"));
      if (*xml_attrval (spec, "class")) xml_set (val, "cols", xml_attrval (spec, "class"));
      if (*xml_attrval (spec, "style")) xml_set (val, "style", xml_attrval (spec, "style"));
      if (value) xml_append (val, xml_createtext_nodup (value));

      return (val);
   }

   /* State fields that didn't get handled by repos_list_choices */
   if (!strcmp (xml_attrval (spec, "type"), "state")) {
      val = xml_create ("div");
      xml_set (val, "name", field_name);
      if (*xml_attrval (spec, "class")) xml_set (val, "class", xml_attrval (spec, "class"));
      if (*xml_attrval (spec, "style")) xml_set (val, "style", xml_attrval (spec, "style"));
      state = xml_search (list, "state", NULL, NULL);
      if (state) {
         if (*xml_attrval (state, "label")) {
            xml_append (val, xml_createtextf ("(%s)", xml_attrval (state, "label")));
         } else {
            xml_append (val, xml_createtextf ("(%s)", xml_attrval (state, "id")));
         }
      } else {
         xml_append (val, xml_createtext ("(system will supply)"));
      }

      if (value) free (value);
      return (val);
   }

   /* System-determined fields (treated as simple text) */
   if (!strcmp (xml_attrval (spec, "type"), "system")) {
      val = xml_create ("div");
      xml_set (val, "name", field_name);
      if (*xml_attrval (spec, "class")) xml_set (val, "cols", xml_attrval (spec, "class"));
      if (*xml_attrval (spec, "style")) xml_set (val, "style", xml_attrval (spec, "style"));
      if (value) xml_append (val, xml_createtext_nodup (xmlobj_get (object, list, field_name)));
      else       xml_append (val, xml_createtext ("(system will supply)"));

      return (val);
   }

   /* Boolean fields (new 2004/03/04) */
   if (!strcmp (xml_attrval (spec, "type"), "bool") || !strncmp (xml_attrval (spec, "type"), "bool:", 5)) {
      if (!strncmp (xml_attrval (spec, "type"), "bool:", 5)) {
         f = xml_attrval (spec, "type") + 5;
         t = strchr (f, ':');
         if (t) {
            t++;
            xml_set (spec, "t", t);
            t--;
            xml_set (spec, "f", "");
            xml_attrncat (spec, "f", f, t-f);
         } else {
            if (!*xml_attrval (spec, "t")) xml_set (spec, "t", "1");
            xml_set (spec, "f", f);
         }
         xml_set (spec, "type", "bool");
      }
      if (!*xml_attrval (spec, "t")) xml_set (spec, "t", "1"); /* TODO: should there be a one-time preparation phase? */

      val = xml_create ("div");
      mark = xml_create ("input");
      xml_append_pretty (val, mark);
      xml_set (mark, "name", field_name);
      xml_set (mark, "type", "hidden");
      xml_set (mark, "value", xml_attrval (spec, "f"));
      mark = xml_create ("input");
      xml_append_pretty (val, mark);
      xml_set (mark, "name", field_name);
      xml_set (mark, "type", "checkbox");
      if (*xml_attrval (spec, "class")) xml_set (mark, "class", xml_attrval (spec, "class"));
      if (*xml_attrval (spec, "style")) xml_set (mark, "style", xml_attrval (spec, "style"));
      xml_set (mark, "value", xml_attrval (spec, "t"));

      if (value) {
         if (*value && strcmp (value, xml_attrval (spec, "f"))) xml_set (mark, "checked", "yes");
         free (value);
      }

      return (val);
   }

   /* Last chance: let the adaptor deal with it. */
   ad = wftk_get_adaptor (repository, DATATYPE, xml_attrval (spec, "type"));
   if (ad) {
      val = wftk_call_adaptor (ad, value ? "html" : "htmlblank", object, spec);
      wftk_free_adaptor (repository, ad);

      if (value) free (value);
      return (val);
   }

   if (value) free (value);
   return NULL;
}

WFTK_EXPORT XML * repos_format_object (XML * repository, XML * list, XML * object, XML * layout)
{
   XML * row;
   XML * col;
   XML * val;
   XML * spec;
   XML * field;
   XML * state;
   XML * mark;
   XML * holder;
   XML * choices;
   char * value;
   WFTK_ADAPTOR * ad;

   /* Express the object using the layout we just retrieved or built. */
   field = xml_firstelem (layout);
   while (field) {
      if (xml_is (field, "template:value")) {
         spec = xml_locf (list ? list : object, ".field[%s]", xml_attrval (field, "name"));
         val = NULL;
         if (!object || !strcmp (xml_attrval (field, "mode"), "new")) {
            val = repos_form_object_field (repository, list, NULL, xml_attrval (field, "name"));
         } else if (!strcmp (xml_attrval (field, "mode"), "edit")) {
            val = repos_form_object_field (repository, list, object, xml_attrval (field, "name"));
         } else {
            if (*xml_attrval (field, "storage")) {
               choices = repos_list_choices (repository, xml_attrval (list, "id"), object, xml_attrval (field, "storage"));
            } else {
               choices = NULL;
            }
            value = xmlobj_get (object, list, xml_attrval (field, "name"));
            if (choices) {
               for (mark = xml_firstelem (choices); mark; mark = xml_nextelem (mark)) {
                  if (!strcmp (value, xml_attrval (mark, "value"))) {
                     val = xml_createtext_nodup (xml_stringcontenthtml (mark));
                     break;
                  }
               }
            }
            if (!val) {
               val = xml_createtext_nodup (value);
            } else {
               free (value);
            }
         }
         if (!val) val = xml_createtext ("");
         xml_replace (field, val);
         field = val;
      } /* TODO: presumably we'll have some sort of list things too. */

      if (xml_firstelem (field)) {
         field = xml_firstelem (field);
      } else do {
         if (xml_nextelem (field)) {
            field = xml_nextelem (field);
            break;
         } else {
            field = xml_parent (field);
            if (!field) break;
         }
      } while (1);
   }

   /* Return the result. */
   return (layout);
}
WFTK_EXPORT char * repos_view_find (XML * repository, XML * list, XML * object, const char * mode)
{
   char * viewkey;
   char * viewkey_expressed;
   char * key;
   XML * view_object = object;
   char * ret;

   if (!list) return NULL;
   if (!view_object) view_object = list;

   /* Get viewkey -- TODO: implement said rule engine interface here, when we have a rule engine. */
   viewkey = strdup (xml_attrval (list, "viewkey"));
   if (!*viewkey) {
      free (viewkey);
      return NULL; /* TODO: make sure this behavior makes sense in the bigger picture.  When called from repos_form, it does. */
   }

   /* Do the flat-template thing, with extra fields. */
   /*xml_set (view_object, "_user", TODO: get current user from repository); */
   /* _state is already set for object, right?  TODO: test this. */
   xml_set (view_object, "_mode", mode);

   viewkey_expressed = xmlobj_format (view_object, list, viewkey);
   free (viewkey);
   key = xml_string_format ("%s_%s", xml_attrval (list, "id"), viewkey_expressed);
   free (viewkey_expressed);

   xml_unset (view_object, "_mode"); /* Clean up pseudofield. */

   /* Use the key just built to index _views. */
   repos_log (repository, 5, 0, NULL, "repmgr", "repos_view_find: looking for %s in _views", key);
   view_object = repos_get (repository, "_views", key);
   free (key);

   if (!view_object) return NULL;

   ret = xmlobj_get (view_object, NULL, "view");
   xml_free (view_object);
   return (ret);
}
WFTK_EXPORT char * repos_view_express (XML * repository, XML * list, XML * object, const char * view)
{
   XML  * scratch = xml_create ("s");
   char * mark;
   int    len;
   char * val;
   XML  * actions;
   XML  * xmark;

   xml_set (scratch, "s", "");

   mark = strstr (view, "[##");
   while (mark) {
      xml_attrncat (scratch, "s", view, mark - view);
      view = mark + 3;
      xml_set (scratch, "name", "");
      mark = strstr (view, "##]");
      if (mark) len = mark - view;
      else      len = strlen (view);
      xml_attrncat (scratch, "name", view, len);

      /* Evaluate the tag in "name" */
      val = NULL;
      if (!strncmp (xml_attrval (scratch, "name"), "input ", 6)) {
         xmark = repos_form_object_field (repository, list, object, xml_attrval (scratch, "name") + 6); /* This is some cool magic. */
         val = xml_stringhtml (xmark);
         xml_free (xmark);
      } else if (!strncmp (xml_attrval (scratch, "name"), "insert ", 7)) {
         /* TODO: do. */
      } else if (!strncmp (xml_attrval (scratch, "name"), "repeat ", 7)) {
         /* TODO: do. */
      } else if (!strncmp (xml_attrval (scratch, "name"), "if ", 3)) {
         /* TODO: do. */
      } else if (!strncmp (xml_attrval (scratch, "name"), "actions ", 8)) {
         actions = repos_action_list_object_direct (repository, list, object, xml_attrval (scratch, "name") + 8);
         for (xmark = xml_firstelem (actions); xmark; xmark = xml_nextelem (xmark)) {
            xml_attrcat (scratch, "s", "<input type=\"submit\" name=\"_action.");
            xml_attrcat (scratch, "s", xml_attrval (xmark, "id"));
            xml_attrcat (scratch, "s", "\" value=\"");
            xml_attrcat (scratch, "s", xml_attrval (xmark, "label"));
            xml_attrcat (scratch, "s", "\">&nbsp;&nbsp;");
         }
      } else if (!strncmp (xml_attrval (scratch, "name"), "control ", 8)) {
         xml_attrcat (scratch, "s", "<input type=\"hidden\" name=\"_control.list\" value=\"");
         xml_attrcat (scratch, "s", xml_attrval (list, "id"));
         xml_attrcat (scratch, "s", "\">\n");
         xml_attrcat (scratch, "s", "<input type=\"hidden\" name=\"_control.key\" value=\"");
         xml_attrcat (scratch, "s", repos_getkey (repository, xml_attrval (list, "id"), object));
         xml_attrcat (scratch, "s", "\">\n");
         xml_attrcat (scratch, "s", "<input type=\"hidden\" name=\"_control.mode\" value=\"");
         xml_attrcat (scratch, "s", xml_attrval (scratch, "name") + 8);
         xml_attrcat (scratch, "s", "\">\n");
      } else {
         if (object) val = xmlobj_get (object, list, xml_attrval (scratch, "name"));
      }

      if (val) {
         xml_attrcat (scratch, "s", val);
         free (val);
      }
      view += len;
      if (*view) view += 3; /* Skip the ending ##] */
      mark = strstr (view, "[##");
   }
   xml_attrcat (scratch, "s", view); 

   mark = strdup (xml_attrval (scratch, "s"));
   xml_free (scratch);
   return (mark);
}
WFTK_EXPORT int   repos_define  (XML * repository, const char * list, XML * defn)
{
   printf ("define\n");
   return 0;
}
WFTK_EXPORT XML * repos_list (XML * repository, XML * list)
{
   WFTK_ADAPTOR * ad;
   const char *id = xml_attrval (list, "id");
   XML * mark;
   XML * mark2;
   XML * copy;
   XML * user;
   const char * line;
   const char * end;
   char * key;
   int count = 0;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "list %s\n", xml_attrval (list, "id"));
      _repos_send (sock);
      line = _repos_receive (sock);
      if (*line == '-') {
         xml_set (list, "error-state", line + 6);
         return (list);
      }
      line = strchr (line, '\n') + 1;
      while (*line == ' ') {
         count++;
         copy = xml_create ("record");
         end = strchr (line, '\n');
         if (!end) break;
         xml_set (copy, "id", "");
         xml_attrncat (copy, "id", line + 1, end - line - 1);
         xml_append (list, copy);
         line = end + 1;
      }
      xml_setnum (list, "count", count);
      xml_set (sock->parms, "buffer", "");
      return list;
   }

   if (!strcmp (id, "_todo")) {
      user = wftk_session_getuser (repository);
      if (user) {
         mark = xml_create ("where");
         xml_set (mark, "field", "user");
         xml_set (mark, "value", xml_attrval (user, "id"));
         xml_prepend_pretty (list, mark);
      }
   }

   if (!strcmp (id, "_tasks") || !(strcmp (id, "_todo"))) {
      xml_set (list, "actual-list", id);
      xml_set (list, "id", "_taskindex");
   } else {
      xml_unset (list, "actual-list");
   }

   mark = NULL;
   if (*xml_attrval (list, "id")) {
      mark = repos_defn (repository, xml_attrval (list, "id"));
      if (mark) {
         xml_copyinto (list, mark);
      }
   }
   if (!strcmp (id, "_taskindex") && !*xml_attrval (list, "order")) xml_set (list, "order", "priority desc");

   if (!strcmp (xml_attrval (list, "storage"), "here")) return list; /* An immediate mode.  Handy, eh? */

   xml_set (list, "error-state", "");
   if (!strcmp (id, "_lists")) {
      mark = xml_firstelem (repository);
      while (mark) {
         if (xml_is (mark, "list") && *xml_attrval (mark, "id") != '_') { /* We don't return overridden pseudolists in _lists. */
            xml_append (list, xml_copy (mark));
            count++;
         }
         mark = xml_nextelem (mark);
      }
      xml_setnum (list, "count", count);
      return list;
   }
   if (!strcmp (id, "_pages")) {
      mark = xml_firstelem (repository);
      while (mark) {
         if (xml_is (mark, "page")) {
            xml_append (list, copy = xml_copy (mark));
            if (xml_parent (mark) != repository) xml_set (copy, "parent", xml_attrval (xml_parent(mark), "id"));
            count++;
            if (xml_firstelem (mark)) {
               mark = xml_firstelem (mark);
               continue;
            }
         }

         do {
            if (xml_nextelem (mark)) {
               mark = xml_nextelem (mark);
               break;
            } else {
               mark = xml_parent (mark);
               if (mark == repository) mark = NULL;
               if (!mark) break;
            }
         } while (1);
      }
      xml_setnum (list, "count", count);
      return list;
   }

   if (!mark && *xml_attrval (list, "id")) {
      xml_setf (list, "error-state", "List %s not defined in repository.", xml_attrval (list, "id"));
      repos_log (repository, 2, 0, NULL, "repmgr", "repos_list: list %s not defined", id);
      return (list);
   }

   /* Check for a list-from index and read from that if requested. */
   if (*xml_attrval (list, "list-from")) {
      mark = xml_locf (list, ".index[%s]", xml_attrval (list, "list-from"));
      if (mark) {
         mark = xml_copy (mark);
         xml_replacecontent (list, xml_createtext ("\n"));
         xml_copyinto (list, mark);
         xml_free (mark);
      }
      xml_unset (list, "id");
   }

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad) {
      repos_log (repository, 1, 1, NULL, "repmgr", "error while listing %s: can't find adaptor for '%s'",
                                                   xml_attrval (list, "id"), xml_attrval (list, "storage"));
      xml_setf (list, "error-state", "can't find adaptor for '%s'", xml_attrval (list, "storage"));
      return NULL;
   }
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   wftk_call_adaptor (ad, "query", list);
   wftk_free_adaptor (repository, ad);

   /* Clean up the result list. */
   mark = xml_firstelem (list); mark2 = NULL;
   while (mark) {
      if (xml_is (mark, "field") ||
          xml_is (mark, "where") ||
          xml_is (mark, "index") ||
          xml_is (mark, "state")) {
         xml_delete_pretty (mark);
         if (mark2) mark = mark2;
         else       mark = xml_firstelem (list);
      } else {
         mark2 = mark;
         mark = xml_nextelem (mark);
      }
   }
   /*while (mark = xml_loc(list, ".where")) xml_delete (mark);
   while (mark = xml_loc(list, ".index")) xml_delete (mark);*/

   if (*xml_attrval (list, "actual-list")) {
      xml_set (list, "id", xml_attrval (list, "actual-list"));
      xml_unset (list, "actual-list");

      if (!strcmp (xml_attrval (list, "id"), "_tasks") || !strcmp (xml_attrval (list, "id"), "_todo")) {
         mark = xml_firstelem (list);
         while (mark) {
            key = xmlobj_get (mark, NULL, "key");
            if (key) xml_set_nodup (mark, "id", key);
            xml_set_nodup (mark, "label", xmlobj_get (mark, NULL, "label"));
            xml_set_nodup (mark, "role",  xmlobj_get (mark, NULL, "role"));
            xml_set_nodup (mark, "user",  xmlobj_get (mark, NULL, "user"));
            mark = xml_nextelem (mark);
         }
      }
   }

   if (*xml_attrval (list, "error-state")) {
      repos_log (repository, 2, 0, NULL, "repmgr", "repos_list %s: %s", id, xml_attrval (list, "error-state"));
   }

   return list;
}
/* TODO: make this work again... (it being inherently more scalable.) */
WFTK_EXPORT XML * repos_list_first (XML * repository, XML * list)
{
   WFTK_ADAPTOR * ad;
   XML * ret;
   XML * mark;

   mark = repos_defn (repository, xml_attrval (list, "id"));
   if (mark) {
      xml_copyinto (list, mark);
   }

   /* Check for a list-from index and read from that if requested. */
   if (*xml_attrval (list, "list-from")) {
      mark = xml_locf (list, ".index[%s]", xml_attrval (list, "list-from"));
      if (mark) {
         mark = xml_copy (mark);
         xml_replacecontent (list, xml_createtext ("\n"));
         xml_copyinto (list, mark);
         xml_free (mark);
      }
   }

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad) return NULL;
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   ret = wftk_call_adaptor (ad, "first", list);
   wftk_free_adaptor (repository, ad);

   return ret;
}
WFTK_EXPORT XML * repos_list_next (XML * repository, XML * list)
{
   WFTK_ADAPTOR * ad;
   XML * ret;

   /* On list_next, we don't need to do the index substitution because it's already been done. */

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad) return NULL;
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   ret = wftk_call_adaptor (ad, "next", list);
   wftk_free_adaptor (repository, ad);

   return ret;
}
WFTK_EXPORT XML * repos_changes (XML * repository, XML * list, const char * date, const char * list_id)
{
   FILE * log;
   XML * scratch = xml_create ("s");
   XML * record = xml_create ("record");
   char line[1024];
   char datecopy[32];
   int  count;
   char * end;
   char * mark;
   char * mark2;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      memset (datecopy, '\0', 32);
      strncpy (datecopy, date, 31);
      if (strlen (datecopy) > 10) datecopy[10] = 'T';
      xml_setf (sock->parms, "outgoing", "changes %s %s\n", datecopy, list_id);
      _repos_send (sock);
      mark = (char *) _repos_receive (sock);
      if (*mark == '-') {
         xml_set (list, "error-state", mark + 6);
         return (list);
      }
      mark = strchr (mark, '\n') + 1;
      while (*mark == ' ') {
         count++;
         record = xml_create ("record");
         end = strchr (mark, '\n');
         if (!end) break;
         strncpy (line, mark + 1, end - mark);
         line[end - mark] = '\0';

         mark = line;
         mark2 = strchr (mark, '\t');
         if (mark2) *mark2 = '\0';
         xml_set (record, "action", mark);
         if (mark2) {
            mark = mark2 + 1;
            mark2 = strchr (mark, '\t');
            if (mark2) *mark2 = '\0';
            xml_set (record, "time", mark);
            if (mark2) {
               mark = mark2 + 1;
               mark2 = strchr (mark, '\t');
               if (mark2) *mark2 = '\0';
               xml_set (record, "user", mark);
               if (mark2) {
                  mark = mark2 + 1;
                  mark2 = strchr (mark, '\n');
                  if (mark2) *mark2 = '\0';
                  xml_set (record, "id", mark);
               }
            }
         }

         xml_append (list, record);

         mark = end + 1;
      }
      xml_setnum (list, "count", count);
      xml_set (sock->parms, "buffer", "");
      return list;
   }

   if (list_id) {
      xml_setf (scratch, "f", "_log/%s.txt", list_id);
      log = _repos_fopen (repository, xml_attrval (scratch, "f"), "r");
      if (log) {
         while (fgets (line, sizeof(line), log)) {
            mark = line;
            mark2 = strchr (mark, '\t');
            if (mark2) *mark2 = '\0';
            xml_set (record, "action", mark);
            if (mark2) {
               mark = mark2 + 1;
               mark2 = strchr (mark, '\t');
               if (mark2) *mark2 = '\0';
               xml_set (record, "time", mark);
               if (mark2) {
                  mark = mark2 + 1;
                  mark2 = strchr (mark, '\t');
                  if (mark2) *mark2 = '\0';
                  xml_set (record, "user", mark);
                  if (mark2) {
                     mark = mark2 + 1;
                     mark2 = strchr (mark, '\n');
                     if (mark2) *mark2 = '\0';
                     xml_set (record, "id", mark);
                  }
               }
            }

            if (date) {
               if (strcmp (date, xml_attrval (record, "time")) > -1) continue;
            }

            xml_append (list, xml_copy (record));
         }
         fclose (log);
      }
   } else {
      /* Scan directory, or ask adaptor or something.  TODO: write this! */
   }
   xml_free (scratch);
   xml_free (record);

   return list;
}
WFTK_EXPORT XML * repos_snapshot (XML * repository, const char * list_id)
{

}
void _repos_log (XML * repository, const char * action, const char * list_id, const char * key);
void _repos_cleanup_object (XML * object);
WFTK_EXPORT int   repos_add (XML * repository, const char * list_id, XML * object)
{
   WFTK_ADAPTOR * ad;
   XML * list;
   XML * index;
   XML * key_index;
   char * id;
   FILE * log;
   XML * mark;
   int workflow_started = 0;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "add %s -\n", list_id);
      _repos_send (sock);
      xml_set (sock->parms, "outgoing", xml_string (object));
      _repos_send (sock);
      xml_set (sock->parms, "outgoing", "\n>>\n");
      _repos_send (sock);
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   /* Find the list named. */
   list = repos_defn (repository, list_id);
   if (!list && strcmp (list_id, "_publog")) return 1;

   if (strcmp (list_id, "_tasks") && strcmp (list_id, "_todo") && strcmp (list_id, "_tasks_really") && strcmp (list_id, "_taskindex"))
      xml_set (object, "list", list_id); /* Make sure this is properly marked, otherwise all kinds of code is going to get confused. */

   /* Clean up special-meaning fields. */
   _repos_cleanup_object (object);

   /* Special field handling. */
   repos_mark_time (repository, "now");
   mark = xml_firstelem (list);
   while (mark) {
      if (xml_is (mark, "field")) {
         if (!strcmp (xml_attrval (mark, "special"), "add") ||
             !strcmp (xml_attrval (mark, "special"), "now")) {
            xmlobj_set (object, list, xml_attrval (mark, "id"), xml_attrval (repository, "now"));
         } else if (!strcmp (xml_attrval (mark, "special"), "constant")) {
            xmlobj_set (object, list, xml_attrval (mark, "id"), xml_attrval (mark, "value"));
         }
      }
      
      mark = xml_nextelem (mark);
   }

   /* TODO: this is where xact functionality will check for approval workflow and such, and create a transaction if necessary. */

   /* If the object is a _tasks object then we need to ensure that it has all the task fields it needs. */
   if (!strcmp (list_id, "_tasks") || !strcmp (list_id, "_todo")) {
      if (!xmlobj_is_field (object, NULL, "key"))   xmlobj_set (object, NULL, "key",   "");
      if (!xmlobj_is_field (object, NULL, "list"))  xmlobj_set (object, NULL, "list",  xml_attrval (object, "list"));
      if (!xmlobj_is_field (object, NULL, "obj"))   xmlobj_set (object, NULL, "obj",   xml_attrval (object, "process"));
      if (!xmlobj_is_field (object, NULL, "id"))    xmlobj_set (object, NULL, "id",    xml_attrval (object, "id"));
      if (!xmlobj_is_field (object, NULL, "state")) xmlobj_set (object, NULL, "state", "active");
      if (!xmlobj_is_field (object, NULL, "label")) xmlobj_set (object, NULL, "label", xml_attrval (object, "label"));
      if (!xmlobj_is_field (object, NULL, "role"))  xmlobj_set (object, NULL, "role",  xml_attrval (object, "role"));
      if (!xmlobj_is_field (object, NULL, "user"))  xmlobj_set (object, NULL, "user",  xml_attrval (object, "user"));
      if (!xmlobj_is_field (object, NULL, "sched_start")) xmlobj_set (object, NULL, "sched_start",  xml_attrval (object, "sched_start"));
      if (!xmlobj_is_field (object, NULL, "sched_end"))   xmlobj_set (object, NULL, "sched_end",  xml_attrval (object, "sched_end"));
      if (!xmlobj_is_field (object, NULL, "cost"))        xmlobj_set (object, NULL, "cost",  xml_attrval (object, "cost"));
      if (!xmlobj_is_field (object, NULL, "priority"))    xmlobj_set (object, NULL, "priority",  xml_attrval (object, "priority"));
      if (!xmlobj_is_field (object, NULL, "only_after"))  xmlobj_set (object, NULL, "only_after",  xml_attrval (object, "only_after"));

      if (!strcmp (list_id, "_todo")) {
         index = wftk_session_getuser (repository);
         if (index) xmlobj_set (object, NULL, "user", xml_attrval (index, "id"));
      }
   }

   /* If there is an index which is marked as having a special="key" field, then we let that index go first, to generate a key
      (this allows DBMS indexing of complex objects while the DB can make us guaranteed unique keys.) */
   /* TODO: this entire operation suffers from a lack of transaction atomicity. */
   key_index = xml_firstelem (list);
   while (key_index) {
      if (xml_is (key_index, "index")) {
         if (xml_search (key_index, "field", "special", "key")) { break; }
      }
      key_index = xml_nextelem (key_index);
   }

   if (key_index) { /* Whaddaya know, we found one. */
      ad = wftk_get_adaptor (repository, LIST, xml_attrval (key_index, "storage"));
      if (ad) {
         xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
         wftk_call_adaptor (ad, "add", key_index, object);
         /* TODO: Check error -- here's where transaction atomicity will be implemented. */
         wftk_free_adaptor (repository, ad);
      }
   }

   /* Now add the object to its main storage, possibly with a new key.  Take special objects into account. */
   if (!list) {
      if (!strcmp (list_id, "_publog")) { /* No defn to the contrary, we stash publish logs into a log file. */
         log = _repos_fopen (repository, "_publog.log", "a");
         fprintf (log, "%s ", xml_attrval (object, "start"));
         mark = xmlobj_field (object, NULL, "content");
         fprintf (log, "%s\n", xml_attrval (mark, "value"));
         fprintf (log, "\n");
         fclose (log);
         xml_free (object);
         return 0;
      }
   }

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad) return 1;
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   repos_getkey (repository, list_id, object);
   wftk_call_adaptor (ad, "add", list, object);
   if (*xml_attrval (ad->parms, "error")) {
      wftk_free_adaptor (repository, ad);
      return 1;
   }
   if (!*xml_attrval (ad->parms, "error")) {
      repos_log (repository, 3, 1, NULL, "repmgr", "repos_add on %s[%s]", list_id, repos_getkey (repository, list_id, object));
      if (strcmp (xml_attrval (list, "logging"), "off")) /* TODO: check overall setting as well.  Need a setting checker which scans upward. */
         _repos_log (repository, "add", list_id, repos_getkey (repository, list_id, object));
      _repos_publish_obj (repository, list_id, object);
   } else {
      repos_log (repository, 1, 1, NULL, "repmgr", "error while adding %s[%]: %s",
                                                   list_id,
                                                   repos_getkey (repository, list_id, object),
                                                   xml_attrval (ad->parms, "error"));
   }

   wftk_free_adaptor (repository, ad);

   /* Now we allow any existing non-key indices to write their own records.  Whew. */
   index = xml_firstelem (list);
   while (index) {
      if (xml_is (index, "index") && index != key_index) {
         ad = wftk_get_adaptor (repository, LIST, xml_attrval (index, "storage"));
         if (ad) {
            xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
            wftk_call_adaptor (ad, "add", index, object);
            /* TODO: Check error -- here's where transaction atomicity will be implemented. */
            wftk_free_adaptor (repository, ad);
         }
      }
      index = xml_nextelem (index);
   }

   /* If this was a task object, then we explicitly write it through into the _taskindex list, as long as it doesn't have state="completed". */
   if (!strcmp (list_id, "_tasks") || !strcmp (list_id, "_todo")) {
      xml_set_nodup (object, "state", xmlobj_get (object, NULL, "state"));
      if (strcmp (xml_attrval (object, "state"), "completed")) {
         index = xml_create ("record");
         id = xmlobj_format (object, NULL, "[list]~[obj]~[id]");
         xmlobj_fixkey (id);
         if (!strcmp (id, "~~")) {
            xmlobj_set_nodup (index, NULL, "id", xmlobj_get (object, NULL, "key"));
            free (id);
         } else {
            xmlobj_set_nodup (index, NULL, "id", id);
         }
         xmlobj_set_nodup (index, NULL, "key",         xmlobj_get (object, NULL, "key"));
         xmlobj_set_nodup (index, NULL, "list",        xmlobj_get (object, NULL, "list"));
         xmlobj_set_nodup (index, NULL, "obj",         xmlobj_get (object, NULL, "obj"));
         xmlobj_set_nodup (index, NULL, "internal_id", xmlobj_get (object, NULL, "id"));
         xmlobj_set_nodup (index, NULL, "state",       xmlobj_get (object, NULL, "state"));
         xmlobj_set_nodup (index, NULL, "label",       xmlobj_get (object, NULL, "label"));
         xmlobj_set_nodup (index, NULL, "role",        xmlobj_get (object, NULL, "role"));
         xmlobj_set_nodup (index, NULL, "user",        xmlobj_get (object, NULL, "user"));
         xmlobj_set_nodup (index, NULL, "sched_start", xmlobj_get (object, NULL, "sched_start"));
         xmlobj_set_nodup (index, NULL, "sched_end",   xmlobj_get (object, NULL, "sched_end"));
         xmlobj_set_nodup (index, NULL, "cost",        xmlobj_get (object, NULL, "cost"));
         xmlobj_set_nodup (index, NULL, "priority",    xmlobj_get (object, NULL, "priority"));
         xmlobj_set_nodup (index, NULL, "only_after",  xmlobj_get (object, NULL, "only_after"));
         repos_add (ad->session, "_taskindex", index);
         xml_free (index);
      }
   }

   /* To make sure that the object isn't saved multiple times by the workflow engine, we mark it as no-save. */
   xml_set (object, "no-save", "yes");

   /* WORKFLOW!  Now that the object is added and comfy in its new home, let's see if any workflow should be started as a result.
      TODO: rollback using transactions in case workflow fails. */
   /* Workflow specs may be multiple, and may be in either the object or the list definition.  Let's look at the object first, then the list. */
   mark = xml_search (object, "on", "action", "add");
   while (mark) {
      workflow_started = 1;
      repos_workflow_start_direct (repository, object, *xml_attrval (mark, "procdef") ? NULL : mark, xml_attrval (mark, "procdef"));
      mark = xml_search_next (object, mark, "on", "action", "add");
   }
   /* Now the list. */
   if (*xml_attrval (list, "workflow")) { /* Special abbreviation for convenience. */
      workflow_started = 1;
      repos_workflow_start_direct (repository, object, NULL, xml_attrval (list, "workflow"));
   }
   mark = xml_search (list, "on", "action", "add"); /* TODO: shouldn't this be restricted to top level? */
   while (mark) {
      workflow_started = 1;
      repos_workflow_start_direct (repository, object, *xml_attrval (mark, "procdef") ? NULL : mark, xml_attrval (mark, "procdef"));
      mark = xml_search_next (list, mark, "on", "action", "add");
   }

   /* If workflow was started, we have to store the (now changed) object -- but not via repos_mod, because this is still part of the add operation. */
   if (workflow_started) {
      repos_log (repository, 4, 1, NULL, "repmgr", "repos_add: saving after workflow start");
      xml_unset (object, "no-save");
      xml_unset (object, "repository");

      /* TODO: Since this is identical to the code in repos_mod, we oughta combine the two into a utility function. */
      ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
      if (!ad) return 0;
      xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

      wftk_call_adaptor (ad, "update", list, object);
      wftk_free_adaptor (repository, ad);

      /* TODO: this entire operation suffers from a lack of transaction atomicity. */
      index = xml_firstelem (list);
      while (index) {
         if (xml_is (index, "index")) {
            ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (index, "storage"));
            if (ad) {
               xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
               wftk_call_adaptor (ad, "update", index, object);
               /* TODO: Check error -- here's where transaction atomicity will be implemented. */
               wftk_free_adaptor (repository, ad);
            }
         }
         index = xml_nextelem (index);
      }
   }

   repos_log (repository, 4, 1, NULL, "repmgr", "repos_add: done with %s[%s]", list_id, repos_getkey (repository, list_id, object));

   return 0;
}
void _repos_cleanup_object (XML * object)
{
   XML * mark;
   XML * mark2;

   mark = xml_firstelem (object); mark2 = NULL;
   while (mark) {
      if (xml_is (mark, "field") && (  !strcmp (xml_attrval (mark, "id"), "_action")
                                        || !strcmp (xml_attrval (mark, "id"), "_control"))) {
         xml_delete_pretty (mark);
         if (mark2) mark = mark2;
         else       mark = xml_firstelem (object);
      } else {
         mark2 = mark;
         mark = xml_nextelem (mark);
      }
   }
}


WFTK_EXPORT int   repos_del (XML * repository, const char * list_id, const char * key)
{
   WFTK_ADAPTOR * ad;
   XML * list;
   XML * index;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "del %s %s\n", list_id, key);
      _repos_send (sock);
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   /* Find the list named. */
   list = repos_defn (repository, list_id);
   if (!list) return 0;

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad) return 0;
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   wftk_call_adaptor (ad, "delete", list, key);
   if (!*xml_attrval (ad->parms, "error")) {
      repos_log (repository, 3, 1, NULL, "repmgr", "repos_del: %s[%s]", list_id, key);
      if (strcmp (xml_attrval (list, "logging"), "off")) /* TODO: check overall setting as well.  Need a setting checker which scans upward. */
         _repos_log (repository, "del", list_id, key);
      _repos_publish_obj (repository, list_id, NULL); /* TODO: *not* the way to do this! */
   } else {
      repos_log (repository, 1, 1, NULL, "repmgr", "error deleting %s[%s]", list_id, key);
   }


   wftk_free_adaptor (repository, ad);

   /* TODO: this entire operation suffers from a lack of transaction atomicity. */
   index = xml_firstelem (list);
   while (index) {
      if (xml_is (index, "index")) {
         ad = wftk_get_adaptor (repository, LIST, xml_attrval (index, "storage"));
         if (ad) {
            xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
            wftk_call_adaptor (ad, "delete", index, key);
            /* TODO: Check error -- here's where transaction atomicity will be implemented. */
            wftk_free_adaptor (repository, ad);
         }
      }
      index = xml_nextelem (index);
   }
   return 0;
}
static int _repos_write_task (XML * repository, XML * object, const char * key);
WFTK_EXPORT int   repos_mod (XML * repository, const char * list_id, XML * object, const char * key)
{
   WFTK_ADAPTOR * ad;
   XML * list;
   XML * index;
   XML * mark;
   XML * field;
   XML * state;
   char * id;
   char * newstate;
   int error = 0;
   int object_local = 0;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (!object && !key) return 1; /* This combination can occur in error situations but has no semantics. */

   if (*xml_attrval (object, "no-save")) return 0;

   _repos_cleanup_object (object);

   if (sock) { /* Remote. */
      if (key) {
         if (object) {
            xml_setf (sock->parms, "outgoing", "mod %s - %s\n", list_id, key);
         } else {
            xml_setf (sock->parms, "outgoing", "changed %s %s\n", list_id, key);
         }
      } else {
         xml_setf (sock->parms, "outgoing", "mod %s -\n", list_id);
      }
      _repos_send (sock);
      if (object) {
         xml_set (sock->parms, "outgoing", xml_string (object));
         _repos_send (sock);
         xml_set (sock->parms, "outgoing", "\n>>\n");
         _repos_send (sock);
      }
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   /* If this is a _tasks object, use the special function. */
   if (!strcmp (list_id, "_tasks") || !strcmp (list_id, "_todo")) {
      return (_repos_write_task (repository, object, key));
   }
   if (!strcmp (list_id, "_tasks_really")) list_id = "_tasks";

   /* Find the list named. */
   list = repos_defn (repository, list_id);
   if (!list) return 0;

   /* TODO: is there a safe way to detect state transitions in the non-object "changed" context?  Probably not. */
   /* But we *can* detect transition to an archive-to state, because no actual object should be in that state. */

   if (object) {
      repos_mark_time (repository, "now");
      mark = xml_firstelem (list);
      while (mark) {
         if (xml_is (mark, "field")) {
            if (!strcmp (xml_attrval (mark, "special"), "mod") ||
                !strcmp (xml_attrval (mark, "special"), "now")) {
               xmlobj_set (object, list, xml_attrval (mark, "id"), xml_attrval (repository, "now"));
            } else if (!strcmp (xml_attrval (mark, "special"), "constant")) {
               xmlobj_set (object, list, xml_attrval (mark, "id"), xml_attrval (mark, "value"));
            }
         }
         mark = xml_nextelem (mark);
      }

      /* State transition? */
      field = xml_search (list, "field", "type", "state");
      if (!field) field = xml_search (object, "field", "id", "_state");
      if (field) {
         xml_set_nodup (object, "newstate", xmlobj_get (object, list, xml_attrval (field, "id")));
         if (strcmp (xml_attrval (object, "state"), xml_attrval (object, "newstate"))) { /* Transition! */
            state = xml_search (list, "state", "id", xml_attrval (object, "newstate"));
            if (!state) {
               xmlobj_set (object, list, xml_attrval (field, "id"), xml_attrval (object, "state"));
            } else {
               if (*xml_attrval (state, "archive-to")) { /* The current object will be checking out today. */
                  /* TODO: As with most of this code, we need to handle error conditions competently. */
                  repos_del (repository, list_id, key);
                  if (strcmp (xml_attrval (state, "archive-to"), "trash"))
                     repos_add (repository, xml_attrval (state, "archive-to"), object);
                  return 0;
               } else {
                  /* TODO: this is where transition handling will happen. */
               }
            }
         }
         xml_unset (object, "newstate");
      }

      ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
      if (!ad) return 0;
      xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

      if (key) xml_set (object, "key", key);

      wftk_call_adaptor (ad, "update", list, object);
      if (*xml_attrval (ad->parms, "error")) {
         error = 1;
      }
      wftk_free_adaptor (repository, ad);

      /* TODO: this entire operation suffers from a lack of transaction atomicity. */
      index = xml_firstelem (list);
      while (index) {
         if (xml_is (index, "index")) {
            ad = wftk_get_adaptor (repository, LIST, xml_attrval (index, "storage"));
            if (ad) {
               xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
               wftk_call_adaptor (ad, "update", index, object);
               /* TODO: Check error -- here's where transaction atomicity will be implemented. */
               wftk_free_adaptor (repository, ad);
            }
         }
         index = xml_nextelem (index);
      }

      /* If this is a task object update, then we write the change through to _taskindex as well. */
      if (!strcmp (list_id, "_tasks")) {
         id = xmlobj_format (object, NULL, "[list]~[obj]~[id]");
         xmlobj_fixkey (id);
         if (!strcmp (id, "~~")) {
            free (id);
            id = xmlobj_get (object, NULL, "key");
         }
         xml_set_nodup (object, "state", xmlobj_get (object, NULL, "state"));
         if (!strcmp (xml_attrval (object, "state"), "completed")) {
            repos_del (repository, "_taskindex", id);
            free (id);
         } else {
            mark = xml_copy (object);
            xml_set_nodup (mark, "key", id);
            xmlobj_set_nodup (mark, NULL, "internal_id", xmlobj_get (mark, NULL, "id"));
            xmlobj_set (mark, NULL, "id", xml_attrval (mark, "key"));
            repos_mod (repository, "_taskindex", mark, NULL);
            xml_free (mark);
         }
      }
   } else {
      /* Check for archive-to transition. */
      object_local = 1;
      object = repos_get (repository, list_id, key);

      field = xml_search (list, "field", "type", "state");
      if (field) {
         object = repos_get (repository, list_id, key);
         xml_set_nodup (object, "state", xmlobj_get (object, list, xml_attrval (field, "id")));
         state = xml_search (list, "state", "id", xml_attrval (object, "state"));
         if (*xml_attrval (state, "archive-to")) {
            repos_del (repository, list_id, key);
            repos_add (repository, list_id, object);
            xml_free (object);
            return 0;
         }
         xml_free (object);
      }

      /* TODO: this entire operation suffers from a lack of transaction atomicity. */
      index = xml_firstelem (list);
      while (index) {
         if (xml_is (index, "index")) {
            ad = wftk_get_adaptor (repository, LIST, xml_attrval (index, "storage"));
            if (ad) {
               xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
               wftk_call_adaptor (ad, "update", index, object);
               /* TODO: Check error -- here's where transaction atomicity will be implemented. */
               wftk_free_adaptor (repository, ad);
            }
         }
         index = xml_nextelem (index);
      }
   }


   if (!error) {
      repos_log (repository, 3, 1, NULL, "repmgr", "repos_mod on %s[%s]", list_id, repos_getkey (repository, list_id, object));
      if (strcmp (xml_attrval (list, "logging"), "off")) { /* TODO: check overall setting as well.  Need a setting checker which scans upward. */
         _repos_log (repository, "mod", list_id, object ? repos_getkey (repository, list_id, object) : key);
      }
      _repos_publish_obj (repository, list_id, object); /* TODO: What if the key changed? */
   } else {
      repos_log (repository, 1, 1, NULL, "repmgr", "error in repos_mod on %s[%s]: %d", list_id, repos_getkey (repository, list_id, object), error);
   }

   if (object_local) xml_free (object);
   return 0;
}
WFTK_EXPORT int   repos_merge (XML * repository, const char * list_id, XML * object, const char * key)
{
   WFTK_ADAPTOR * ad;
   XML * list;
   XML * obj;
   XML * diff;
   XML * patch;
   XML * mark;
   int retval;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   repos_log (repository, 3, 1, NULL, "repmgr", "repos_merge on %s[%s]", list_id, key);

   if (!object) return 1;  /* Unlike mod, merge makes no sense in a key-only situation. */

   if (sock) { /* Remote. */
      if (key) {
         xml_setf (sock->parms, "outgoing", "merge %s - %s\n", list_id, key);
      } else {
         xml_setf (sock->parms, "outgoing", "merge %s -\n", list_id);
      }
      _repos_send (sock);
      if (object) {
         xml_set (sock->parms, "outgoing", xml_string (object));
         _repos_send (sock);
         xml_set (sock->parms, "outgoing", "\n>>\n");
         _repos_send (sock);
      }
      if (*_repos_receive (sock) == '-') {
         return 1;
      } else {
         return 0;
      }
   }

   /* If this is a _tasks object, use the special function. */
   if (!strcmp (list_id, "_tasks") || !strcmp (list_id, "_todo")) {
      return (_repos_write_task (repository, object, key));
   }

   /* Find the list named. */
   list = repos_defn (repository, list_id);
   if (!list) return 0;

   repos_mark_time (repository, "now");
   mark = xml_firstelem (list);
   while (mark) {
      if (xml_is (mark, "field")) {
         if (!strcmp (xml_attrval (mark, "special"), "mod") ||
             !strcmp (xml_attrval (mark, "special"), "now")) {
            xmlobj_set (object, list, xml_attrval (mark, "id"), xml_attrval (repository, "now"));
         } else if (!strcmp (xml_attrval (mark, "special"), "constant")) {
            xmlobj_set (object, list, xml_attrval (mark, "id"), xml_attrval (mark, "value"));
         }
      }
      mark = xml_nextelem (mark);
   }

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad) return 0;
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   /* Make sure we have a key and that the object correctly reflects it. */
   if (!key) {
      key = (const char *) xmlobj_getkey (object, list);
      if (!key) return 0;
      xml_set_nodup (object, "key", (char *) key);
      key = xml_attrval (object, "key");
   } else {
      xml_set (object, "key", key);
   }

   /* Retrieve the object's current value. */
   obj = wftk_call_adaptor (ad, "get", list, key);
   wftk_free_adaptor (repository, ad);

   if (obj) {
      /* Perform a diff, then a patch, to do the merge. */
      diff = xmlobj_diff (obj, list, object);
      patch = xmlobj_patch (obj, list, diff);

      xml_free (diff);
      xml_free (patch);

      /* Call repos_mod to do the honors of actually storing the object. */
      /* TODO: consider how this interfaces with the whole transaction concept -- we probably don't want to throw out the diff. */
      retval = repos_mod (repository, list_id, obj, key);

      /* Free things up. */
      xml_free (obj);
   } else {
      repos_log (repository, 3, 1, NULL, "repmgr", "repos_merge: can't find %s[%s]; writing directly", list_id, key);
      retval = repos_mod (repository, list_id, object, key); /* Default to "mod" behavior if we can't find our object. */
   }

   return (retval);
}
static int _repos_write_task (XML * repository, XML * object, const char * key)
{
   XML * tasks_list;
   XML * repmgr_obj;
   XML * mark;
   XML * field;
   WFTK_ADAPTOR * ad;
   XML * wftk_obj;
   XML * ret;
   int repmgr_obj_changed = 0;
   int wftk_obj_changed = 0;
   int status_changed = 0;
   XML * diff;
   XML * patch;

   repos_log (repository, 4, 1, NULL, "repmgr", "_repos_write_task on _tasks[%s]", key);

   /* 1. Get repmgr task object for values in first and third categories. */
   tasks_list = repos_defn (repository, "_tasks");
   ad = wftk_get_adaptor (repository, LIST, "_tasks");
   if (!ad) return 0;

   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   repmgr_obj = wftk_call_adaptor (ad, "get", tasks_list, key);
   wftk_free_adaptor (repository, ad);

   if (!repmgr_obj) return (repos_add (repository, "_tasks", object));

   xml_set_nodup (repmgr_obj, "state", xmlobj_get (repmgr_obj, NULL, "state"));

   /* 1a. Make sure important system values aren't going to change or get dropped. */
   xmlobj_set_nodup (object, NULL, "id",   xmlobj_get (repmgr_obj, NULL, "id"));
   xmlobj_set_nodup (object, NULL, "list", xmlobj_get (repmgr_obj, NULL, "list"));
   xmlobj_set_nodup (object, NULL, "obj",  xmlobj_get (repmgr_obj, NULL, "obj"));
   xmlobj_set_nodup (object, NULL, "key",  xmlobj_get (repmgr_obj, NULL, "key"));

   /* 2. Ask wftk core for workflow-specific task information (values in the second category.) */
   wftk_obj = xml_create ("task");

   xml_set_nodup (repmgr_obj, "parent-list", xmlobj_get (repmgr_obj, NULL, "list"));
   xml_set_nodup (repmgr_obj, "parent-key",  xmlobj_get (repmgr_obj, NULL, "obj"));
   xml_set_nodup (repmgr_obj, "id",          xmlobj_get (repmgr_obj, NULL, "id"));
   if (*xml_attrval (repmgr_obj, "parent-key")) {
      xml_setf (wftk_obj, "dsrep",   "list:%s", xml_attrval (repmgr_obj, "parent-list"));
      xml_set  (wftk_obj, "process",            xml_attrval (repmgr_obj, "parent-key"));
      xml_set  (wftk_obj, "id",                 xml_attrval (repmgr_obj, "id"));

      wftk_task_retrieve (repository, wftk_obj);
   }

   /* 3. Has the status changed? */
   field = xmlobj_is_field (object, NULL, "state");
   if (field) {
      xml_set_nodup (object, "state", xmlobj_get_direct (field));
      if (strcmp (xml_attrval (repmgr_obj, "state"), xml_attrval (object, "state"))) {
         status_changed = 1;
      }
      xml_delete_pretty (field);
   }

   /* 4. Find out whether changes are being made to the fields in the wftk task (i.e. fields pulled from the parent object).
    *    Whether they are or not, these fields must also be removed from the incoming change object before we write the repmgr task object. 
    *    If a task-required field isn't given and the change is trying to set the task to complete, then we ignore the
    *    state change at this juncture.  ("Juncture" is a nice word, isn't it?)
    *    TODO: perhaps other format specs than non-blank would be convenient here.
    */
   mark = xml_firstelem (wftk_obj);
   while (mark) {
      if (xml_is (mark, "field")) {
         field = xmlobj_is_field (object, NULL, xml_attrval (mark, "id"));
         if (!field) {
            if (!strcmp (xml_attrval (mark, "required"), "yes")) status_changed = 0;
         } else {
            xml_set_nodup (object, "val1", xmlobj_get_direct (field));
            if (!*xml_attrval (object, "val1") && !strcmp (xml_attrval (mark, "required"), "yes")) status_changed = 0;
            xml_set_nodup (object, "val2", xmlobj_get_direct (mark));
            if (strcmp (xml_attrval (object, "val1"), xml_attrval (object, "val2"))) {
               xmlobj_set_direct (mark, xml_attrval (object, "val1"));
               wftk_obj_changed = 1;
            }
            xml_delete_pretty (field);
         }
      }
      mark = xml_nextelem (mark);
   }

   /* 5. The remaining fields and non-field XML in the change object are a diff (or replacement, we don't really care)
    *    for the repmgr raw task object.  Since we already have retrieved the repmgr obj, we don't want to call repos_merge, as
    *    that would simply retrieve it again.  Instead, we do the merge here, and call repos_mod on _tasks_really in order to
    *    save and index it, and do any state-determined archival.  (We need to reinsert the state field, of course.)
    */
   if (status_changed) xmlobj_set (object, NULL, "state", xml_attrval (object, "state"));
   diff = xmlobj_diff (repmgr_obj, tasks_list, object);

   xml_unset (diff, "state"); /* TODO: maybe remove other attributes as well? */
   patch = xmlobj_patch (repmgr_obj, tasks_list, diff);

   mark = xml_firstelem (patch);
   if (mark) repmgr_obj_changed = 1;

   xml_free (diff);
   xml_free (patch);

   if (repmgr_obj_changed) {
      repos_mod (repository, "_tasks_really", repmgr_obj, NULL);
   }

   /* TODO: same musing as in repos_merge as to whether we want to throw away the diff we just made. */

   /* 6. If the state changed, and the new state is "completed", then we call wftk_task_complete, which will also update any data
    *    appropriate from the parent object.  Otherwise, we simply call wftk_task_update.
    */
   if (status_changed && !strcmp (xml_attrval (object, "state"), "completed")) {
      wftk_task_complete (repository, wftk_obj);
   } else if (wftk_obj_changed) {
      wftk_task_update (repository, wftk_obj);
   }

   return (0);
}
WFTK_EXPORT const char * repos_getkey (XML * repository, const char * list_id, XML * object)
{
   const char * key;
   XML * defn;

   /* See if we've cached a key value. */
   key = xml_attrval (object, "key");
   if (*key) return (key);

   /* Else create a new key. */
   defn = repos_defn (repository, list_id);
   key = (const char *) xmlobj_getkey (object, defn);
   if (key) xml_set_nodup (object, "key", (char *) key);
   return xml_attrval (object, "key");
}
void _repos_log (XML * repository, const char * action, const char * list_id, const char * key)
{
   FILE * log;
   XML * scratch = xml_create ("s");
   struct tm * timeptr;
   time_t julian;

   xml_setf (scratch, "f", "_log/%s.txt", list_id);
   log = _repos_fopen (repository, xml_attrval (scratch, "f"), "a");
   if (log) {
      time (&julian);
      timeptr = localtime (&julian);
      fprintf (log, "%s\t%04d-%02d-%02d %02d:%02d:%02d\t\t%s\n",   /* TODO: include user information! */
                    action,
                    timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
                    timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec,
                    key);
      fclose (log);
   }
   xml_free (scratch);

}
static XML * _repos_get_pageobj (XML * repository, const char * key);
static void _repos_get_sublist (XML * repository, XML * obj, XML * list, XML * sublist);
static XML * _repos_get_task (XML * repository, const char * key);
WFTK_EXPORT XML * repos_get     (XML * repository, const char * list_id, const char * key)
{
   WFTK_ADAPTOR * ad;
   XML * list;
   XML * ret;
   const char * line;
   const char * end;
   XML * field;
   XML * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      if (key) {
         xml_setf (sock->parms, "outgoing", "get %s %s\n", list_id, key);
      } else {
         xml_setf (sock->parms, "outgoing", "get %s\n", list_id);
      }
      _repos_send (sock);
      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '\n') + 1;
      list = xml_create ("t");
      xml_set (list, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (list, "r", line, end - line + 1);
         } else {
            xml_attrcat (list, "r", line);
            break;
         }
         line = end + 1;
      }
      ret = xml_parse (xml_attrval (list, "r"));
      xml_free (list);
      xml_set (sock->parms, "buffer", "");
      xml_set (ret, "list", list_id);
      xml_set (ret, "key", key);
      return ret;
   }

   /* Handle selected pseudolists first. */
   if (!strcmp (list_id, "_lists")) {
   } else if (!strcmp (list_id, "_pages")) {
      return _repos_get_pageobj (repository, key);
   } else if (!strcmp (list_id, "_todo") || !strcmp (list_id, "_tasks")) {
      return _repos_get_task (repository, key);
   }

   /* Find the list named. */
   list = repos_defn (repository, list_id);
   if (!list) return NULL;

   /* Handle immediate-addressing mode. */
   if (!strcmp (xml_attrval (list, "storage"), "here")) {
      ret = xml_search (list, NULL, "id", key);
      return (xml_copy (ret));
   }

   /* Handle normal case: key given, use adaptor to retrieve record. */
   if (key && *key) {
      ad = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
      if (!ad) return NULL;
      xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));
      ret = wftk_call_adaptor (ad, "get", list, key);
      wftk_free_adaptor (repository, ad);
   } else { /* NULL-key case (build "blank" record) */
      ret = xml_create (*xml_attrval (list, "rec") ? xml_attrval (list, "rec") : "rec");

      mark = xml_firstelem (list);
      while (mark) {
         if (xml_is (mark, "field") || xml_is (mark, "link")) {
            field = xml_create (xml_name (mark));
            xml_set (field, "id", xml_attrval (mark, "id"));
            if (*xml_attrval (mark, "type"))    xml_set (field, "type", xml_attrval (mark, "type"));
            if (*xml_attrval (mark, "storage")) xml_set (field, "storage", xml_attrval (mark, "storage"));
            xml_append (field, xml_createtext (xml_attrval (mark, "default")));
            xml_append_pretty (ret, field);
         }
         mark = xml_nextelem (mark);
      }
   }

   /* Handle state, and make sure our marker attributes are set properly. */
   field = xml_search (list, "field", "type", "state");
   if (field) xml_set_nodup (ret, "state", xmlobj_get (ret, list, xml_attrval (field, "id")));
   xml_set (ret, "list", list_id);
   xml_set (ret, "key", key);

   /* Handle linked data in alternate storage. */
   field = xml_firstelem (list);
   while (field) {
      if (xml_is (field, "link") && (*xml_attrval (field, "storage") || *xml_attrval (field, "list"))) {
         _repos_get_sublist (repository, ret, list, field);
      }
      field = xml_nextelem (field);
   }

   return ret;
}
static void  _repos_get_sublist (XML * repository, XML * obj, XML * list, XML * sublist) {
   XML_ATTR * attr;
   const char * val;
   XML * linked;
   XML * linkto;
   XML * link_into;
   XML * rec;
   XML * field;

   linked = xml_copy (sublist);

   /* Attribute values are expressed in terms of parent object.  TODO: what about parent's parent? */
   attr = xml_attrfirst (linked);
   while (attr) {
      val = xml_attrvalue (attr);
      if (strchr (val, '[')) xml_set_nodup (linked, xml_attrname (attr), xmlobj_format (obj, list, xml_attrvalue (attr)));
      attr = xml_attrnext (attr);
   }

   xml_set (linked, "rec", *xml_attrval (sublist, "rec") ? xml_attrval (sublist, "rec") : "rec");

   link_into = obj;
   if (*xml_attrval (sublist, "id")) {
      linkto = xml_create ("link");
      xml_set (linkto, "id", xml_attrval (sublist, "id"));
      xml_append_pretty (obj, linkto);
      link_into = linkto;
      xml_set (linked, "rec", *xml_attrval (sublist, "rec") ? xml_attrval (sublist, "rec") : "link-to");
   }

   if (*xml_attrval (linked, "list")) {
      xml_set (list, "id", xml_attrval (linked, "storage"));
   }

   if (repos_list (repository, linked)) {
      linkto = xml_firstelem (linked);
      while (linkto) {
         rec = xml_copy (linkto);
      
         /* Handle linked data in alternate storage. */
         field = xml_firstelem (sublist);
         while (field) {
            if (xml_is (field, "link") && (*xml_attrval (field, "storage") || *xml_attrval (field, "list"))) {
               _repos_get_sublist (repository, rec, sublist, field);
            }
            field = xml_nextelem (field);
         }

         xml_append_pretty (link_into, xml_copy (linkto));
         linkto = xml_nextelem (linkto);
      }
   }
   xml_free (linked);
}
static XML * _repos_get_pageobj (XML * repository, const char * key)
{
   XML * list;
   XML * ret;
   XML * field;
   XML * mark;
   XML * page;
   XML * layout;
   FILE * file;
   char line[1024];
   int bytes;

   page = xml_search (repository, "page", "id", key);
   if (!page) return NULL;

   layout = repos_get_layout (repository, xml_attrval (page, "layout"));

   /* We scan the layout in order to find page-specific textual values (i.e. Wiki text).
      If the page is an object page, these might not exist, so we may be restricted to just
      putting the title and such in the editable object.  We can get arbitrarily clever with this.... */
   ret = xml_create ("record");
   xml_set (ret, "textbase", *xml_attrval (repository, "text") ? xml_attrval (repository, "text") : "opmtext");
   xml_set (ret, "list", "_pages");
   xml_set (ret, "key", key);
   xmlobj_set (ret, NULL, "id", xml_attrval (page, "id"));
   mark = xml_parent (page);
   if (xml_is (mark, "page")) {
      xmlobj_set (ret, NULL, "parent", xml_attrval (mark, "id"));
   } else {
      xmlobj_set (ret, NULL, "parent", "");
   }
   xmlobj_set (ret, NULL, "title", xml_attrval (page, "title"));
   xmlobj_set (ret, NULL, "layout", xml_attrval (page, "layout"));

   field = xml_search (layout, "template:value", NULL, NULL);
   while (field) {
      mark = xml_search (ret, "field", "id", xml_attrval (field, "id"));
      if (!mark) {
         /* Here we might need to get *really* clever.  Later, though.  TODO: same. */
         xmlobj_set (ret, NULL, xml_attrval(field, "id"), "");
         mark = xmlobj_field (ret, NULL, xml_attrval (field, "id"));
         xml_setf (ret, "filename", "%s/%s_%s.html", xml_attrval (ret, "textbase"), key, xml_attrval (field, "id"));
         file = _repos_fopen (repository, xml_attrval (ret, "filename"), "r");
         if (!file) {
            xml_setf (ret, "filename", "%s/%s_%s.htm", xml_attrval (ret, "textbase"), key, xml_attrval (field, "id"));
            file = _repos_fopen (repository, xml_attrval (ret, "filename"), "r");
         }
         if (!file) {
            xml_setf (ret, "filename", "%s/%s_%s.wiki", xml_attrval (ret, "textbase"), key, xml_attrval (field, "id"));
            file = _repos_fopen (repository, xml_attrval (ret, "filename"), "r");
         }
         if (!file) {
            xml_setf (ret, "filename", "%s/%s_%s.txt", xml_attrval (ret, "textbase"), key, xml_attrval (field, "id"));
            file = _repos_fopen (repository, xml_attrval (ret, "filename"), "r");
         }
         if (!file) {
            xml_unset (ret, "filename");
         } else {
            while (bytes = fread (line, 1, 1024, file)) {
              xml_textncat (mark, line, bytes);
            }
            fclose (file);
         }
      }
      field = xml_search_next (layout, field, "template:value", NULL, NULL);
   }

   return ret;
}
static XML * _repos_get_task (XML * repository, const char * key)
{
   XML * tasks_list;
   XML * repmgr_obj;
   XML * mark;
   char * _key;
   WFTK_ADAPTOR * ad;
   XML * wftk_obj;
   XML * ret;

   /* 0. Look aside to the task index if given multipart key. */
   repos_log (repository, 5, 2, NULL, "repmgr", "Getting task %s", key);
   if (strchr (key, '~')) {
      mark = repos_get (repository, "_taskindex", key);
      if (!mark) return NULL;
      _key = xmlobj_get (mark, NULL, "key");
      repos_log (repository, 5, 2, NULL, "repmgr", "Which is actually task %s", _key);
      xml_free (mark);
   } else {
      _key = strdup (key);
   }

   /* 1. Get repmgr task object for values in first and third categories. */
   tasks_list = repos_defn (repository, "_tasks");
   ad = wftk_get_adaptor (repository, LIST, "_tasks");
   if (!ad) return NULL;
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   repmgr_obj = wftk_call_adaptor (ad, "get", tasks_list, _key);
   wftk_free_adaptor (repository, ad);

   if (!repmgr_obj) {
      free (_key);
      return NULL;
   }

   /* 2. Ask wftk core for workflow-specific task information (values in the second category.) */
   wftk_obj = xml_create ("task");

   xml_set_nodup (repmgr_obj, "parent-list", xmlobj_get (repmgr_obj, NULL, "list"));
   xml_set_nodup (repmgr_obj, "parent-key",  xmlobj_get (repmgr_obj, NULL, "obj"));
   xml_set_nodup (repmgr_obj, "id",          xmlobj_get (repmgr_obj, NULL, "id"));
   if (*xml_attrval (repmgr_obj, "parent-key")) {
      xml_setf (wftk_obj, "dsrep",   "list:%s", xml_attrval (repmgr_obj, "parent-list"));
      xml_set  (wftk_obj, "process",            xml_attrval (repmgr_obj, "parent-key"));
      xml_set  (wftk_obj, "id",                 xml_attrval (repmgr_obj, "id"));

      wftk_task_retrieve (repository, wftk_obj);
   }

   /* 3. Construct return value. */
   ret = xml_create ("task");

   xml_set_nodup (ret, "key",          xmlobj_get (repmgr_obj, NULL, "key"));
   xml_set_nodup (ret, "list",         xmlobj_get (repmgr_obj, NULL, "list"));
   xml_set_nodup (ret, "obj",          xmlobj_get (repmgr_obj, NULL, "obj"));
   xml_set_nodup (ret, "state",        xmlobj_get (repmgr_obj, NULL, "state"));
   xml_set_nodup (ret, "label",        xmlobj_get (repmgr_obj, NULL, "label"));
   xml_set_nodup (ret, "role",         xmlobj_get (repmgr_obj, NULL, "role"));
   xml_set_nodup (ret, "user",         xmlobj_get (repmgr_obj, NULL, "user"));
   xml_set_nodup (ret, "sched_start",  xmlobj_get (repmgr_obj, NULL, "sched_start"));
   xml_set_nodup (ret, "sched_end",    xmlobj_get (repmgr_obj, NULL, "sched_end"));
   xml_set_nodup (ret, "cost",         xmlobj_get (repmgr_obj, NULL, "cost"));
   xml_set_nodup (ret, "only_after",   xmlobj_get (repmgr_obj, NULL, "only_after"));
   xml_set_nodup (ret, "priority",     xmlobj_get (repmgr_obj, NULL, "priority"));

   /* xmlobj_set_nodup (ret, NULL, "state", xmlobj_get (repmgr_obj, NULL, "state")); -- on second thought, this didn't make much sense. */

   mark = xml_firstelem (wftk_obj);
   while (mark) {
      if (xml_is (mark, "field")) xml_append_pretty (ret, xml_copy (mark));
      mark = xml_nextelem (mark);
   }

   xml_free (wftk_obj);

   /* Remove xmlobj fields for standard task attributes -- otherwise they'll appear in all forms. */
   xmlobj_unset (repmgr_obj, NULL, "key");
   xmlobj_unset (repmgr_obj, NULL, "list");
   xmlobj_unset (repmgr_obj, NULL, "obj");
   xmlobj_unset (repmgr_obj, NULL, "id");
   xmlobj_unset (repmgr_obj, NULL, "state");
   xmlobj_unset (repmgr_obj, NULL, "label");
   xmlobj_unset (repmgr_obj, NULL, "role");
   xmlobj_unset (repmgr_obj, NULL, "user");
   xmlobj_unset (repmgr_obj, NULL, "sched_start");
   xmlobj_unset (repmgr_obj, NULL, "sched_end");
   xmlobj_unset (repmgr_obj, NULL, "cost");
   xmlobj_unset (repmgr_obj, NULL, "only_after");
   xmlobj_unset (repmgr_obj, NULL, "priority");

   mark = xml_firstelem (repmgr_obj);
   while (mark) {
      if (xml_is (mark, "field")) xml_append_pretty (ret, xml_copy (mark));
      mark = xml_nextelem (mark);
   }

   free (_key);
   xml_free (repmgr_obj);

   return (ret);
}

XML * _repos_format_object (XML * repository, XML * object, XML * layout)
{

}
WFTK_EXPORT char * repos_getvalue (XML * repository, const char * list, const char * key, const char * field)
{
   /* retrieve obj then call xmlobj_get */
   return ("");
}
WFTK_EXPORT void repos_setvalue (XML * repository, const char * list, const char * key, const char * field, const char * value)
{
   /* This will be a while.  It fronts for the adaptor, of course. */
}
WFTK_EXPORT void repos_xml_free (XML * xml) {
   xml_free (xml);
}
WFTK_EXPORT void repos_log (XML * repository, int level, int type, XML * object, const char * subsystem, const char * message, ...)
{
   va_list arglist;
   char * msg;
   char * l;
   struct tm * timeptr;
   time_t julian;
   FILE * log;
   int loglevel = 2;

   if (*xml_attrval (repository, "loglevel")) loglevel = xml_attrvalnum (repository, "loglevel");
   if (level > loglevel) return;

   va_start (arglist, message);
   msg = xml_string_formatv (message, arglist);
   l = (level == 0) ? "fatal" :
       ((level == 1) ? "warning" :
       ((level == 2) ? "notification" :
         "debug"));
   va_end (arglist);

   time (&julian);
   timeptr = localtime (&julian);

   log = _repos_fopen (repository, "repository.log", "a");  /* TODO: make this a general list adaptor call. */
   if (log) {
      fprintf (log, "[%04d-%02d-%02d %02d:%02d:%02d] %s %s %s\n", 
                     timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
                     timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec,
                     l, subsystem, msg);
      fclose (log);
   }
   free (msg);

}
WFTK_EXPORT XML * repos_user_auth (XML * repository, const char * userid, const char * password)
{
   WFTK_ADAPTOR * ad;
   XML * userbase;
   const char * storage = "list:";
   XML * ret;
   const char * line;
   const char * end;
   XML * field;
   XML * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "auth %s %s\n", userid, password);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '\n') + 1;
      userbase = xml_create ("t");
      xml_set (userbase, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (userbase, "r", line, end - line + 1);
         } else {
            xml_attrcat (userbase, "r", line);
            break;
         }
         line = end + 1;
      }
      ret = xml_parse (xml_attrval (userbase, "r"));
      xml_free (userbase);
      xml_set (sock->parms, "buffer", "");
      return ret;
   }

   userbase = xml_loc (repository, ".userbase");
   if (!userbase) {
      storage = xml_attrval (userbase, "storage");
   }

   /* TODO: handling of multiple userbases. */
   ad = wftk_get_adaptor (repository, USER, storage);
   if (!ad) return NULL;

   ret = wftk_call_adaptor (ad, "auth", userid, password);
   wftk_free_adaptor (repository, ad);

   xml_set (ret, "id", userid);
   wftk_session_storeuser (repository, xml_copy (ret));
   return ret;
}
WFTK_EXPORT XML * repos_user_ingroup (XML * repository, const char * userid, const char * groupid)
{
   WFTK_ADAPTOR * ad;
   XML * userbase;
   const char * storage = "list:";
   XML * ret;
   const char * line;
   const char * end;
   XML * field;
   XML * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "ingroup %s %s\n", userid, groupid);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '\n') + 1;
      userbase = xml_create ("t");
      xml_set (userbase, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (userbase, "r", line, end - line + 1);
         } else {
            xml_attrcat (userbase, "r", line);
            break;
         }
         line = end + 1;
      }
      ret = xml_parse (xml_attrval (userbase, "r"));
      xml_free (userbase);
      xml_set (sock->parms, "buffer", "");
      return ret;
   }

   userbase = xml_loc (repository, ".userbase");
   if (!userbase) {
      storage = xml_attrval (userbase, "storage");
   }

   /* TODO: handling of multiple userbases. */
   ad = wftk_get_adaptor (repository, USER, storage);
   if (!ad) return NULL;

   ret = wftk_call_adaptor (ad, "ingroup", userid, groupid);
   wftk_free_adaptor (repository, ad);

   return ret;
}
WFTK_EXPORT char * repos_context_save (XML * repository)
{
   WFTK_ADAPTOR * ad;
   XML * context;
   char * ret;
   char * mark;
   const char * line;
   const char * end;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "context\n");
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, '-') + 1;
      ret = strdup (line);
      mark = strstr (ret, " ++done++");
      if (mark) *mark = '\0';
      else {
         mark = strchr (ret, '\n');
         if (mark) *mark = '\0';
      }
      return (ret);
   }

   context = wftk_session_getcontext (repository);
   if (!context) {
      context = xml_create ("context");
      wftk_session_setcontext (repository, context);
   }
   if (*xml_attrval (context, "key")) { /* This context has already been saved. */
      repos_mod (repository, "_sessions", context, NULL);
   } else {
      repos_add (repository, "_sessions", context);
   }
   return (strdup (xml_attrval (context, "key")));
}
WFTK_EXPORT XML * repos_context_switch (XML * repository, const char * contextid)
{
   WFTK_ADAPTOR * ad;
   XML * temp;
   XML * context;
   const char * line;
   const char * end;
   XML * field;
   XML * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "context %s\n", contextid);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') {
         wftk_session_setcontext (repository, NULL);
         return NULL;
      }
      line = strchr (line, '\n') + 1;
      temp = xml_create ("t");
      xml_set (temp, "r", "");
      while (line[0] != '>' || line[1] != '>') {
         end = strchr (line, '\n');
         if (end) {
            xml_attrncat (temp, "r", line, end - line + 1);
         } else {
            xml_attrcat (temp, "r", line);
            break;
         }
         line = end + 1;
      }
      context = xml_parse (xml_attrval (temp, "r"));
      xml_free (temp);
      xml_set (sock->parms, "buffer", "");
      wftk_session_setcontext (repository, context);
      return (context);
   }

   context = repos_get (repository, "_sessions", contextid);
   wftk_session_setcontext (repository, context);

   return (context);
}
WFTK_EXPORT void repos_context_set (XML * repository, const char * valname, const char * value)
{
   WFTK_ADAPTOR * ad;
   XML * context;
   const char * line;
   const char * end;
   XML * field;
   XML * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "set % %s\n", valname, value);
      _repos_send (sock);

      line = _repos_receive (sock);
      xml_set (sock->parms, "buffer", "");
      return;
   }

   context = wftk_session_getcontext (repository);
   if (!context) {
      context = xml_create ("context");
      wftk_session_setcontext (repository, context);
   }
   xmlobj_set (context, NULL, valname, value);
}
WFTK_EXPORT char * repos_context_get (XML * repository, const char * valname)
{
   WFTK_ADAPTOR * ad;
   XML * context;
   char * ret;
   char * mark;
   const char * line;
   const char * end;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_setf (sock->parms, "outgoing", "read %s\n", valname);
      _repos_send (sock);

      line = _repos_receive (sock);
      if (*line == '-') return NULL;
      line = strchr (line, ' ') + 1;
      ret = strdup (line);
      mark = strchr (ret, ' ');
      if (mark) *mark = '\0';
      else {
         mark = strchr (ret, '\n');
         if (mark) *mark = '\0';
      }
      return (ret);
   }

   context = wftk_session_getcontext (repository);
   if (!context) {
      context = xml_create ("context");
      wftk_session_setcontext (repository, context);
      return NULL;
   }
   return (xmlobj_get (context, NULL, valname));
}
WFTK_EXPORT XML * repos_get_layout (XML * repository, const char * layout_id)
{
   XML * ltop;
   XML * layout;
   XML * this_layout;
   XML * replace_layout;
   XML * layout_mark;
   const char * replaces;
   FILE * file;

   ltop = xml_loc (repository, ".layout");
   if (!ltop) {
      return NULL;
   }

   if (!layout_id) layout_id = xml_attrval (ltop, "default");
   if (!*layout_id) layout_id = xml_attrval (ltop, "default");

   if (!*layout_id) layout_id = xml_attrval (ltop, "id");
   if (!*layout_id) {
      layout_id = "top";
      xml_set (ltop, "id", "top");
   }

   this_layout = xml_locf (repository, ".cache.layout[%s]", layout_id);
   if (this_layout) {
      return (xml_copy (this_layout));
   }

   this_layout = xml_search (ltop, "layout", "id", layout_id);
   if (!this_layout) {
      return NULL;
   }

   layout = NULL;
   replace_layout = NULL;
   do {
      if (*xml_attrval (this_layout, "defn")) {
      file = _repos_fopen (repository, xml_attrval (this_layout, "defn"), "r");
         if (!file) {
            layout = xml_create ("layout-error");
            xml_setf (layout, "error", "Named layout definition file %s can't be opened.", xml_attrval (this_layout, "defn"));
            break;
         }
         layout = xml_parse_general (file, (XMLAPI_DATARETRIEVE) fread);
         fclose (file);
         if (xml_is (layout, "xml-error")) {
            xml_setf (layout, "error", "Named layout definition file %s is corrupt in line %s: [%s] %s\n", xml_attrval (this_layout, "defn"), xml_attrval (layout, "line"), xml_attrval (layout, "code"), xml_attrval (layout, "message"));
            break;
         }
      } else {
         layout = xml_copy (this_layout);
      }

      if (replace_layout) {
         layout_mark = xml_search (layout, "template:value", "id", replaces);
         if (!layout_mark) layout_mark = xml_search (layout, "template:value", "name", replaces);
         if (layout_mark) {
            xml_replacewithcontent (layout_mark, replace_layout);
         } else xml_free (replace_layout);
         replace_layout = NULL;
      }

      if (*xml_attrval (this_layout, "replace") && this_layout != ltop) {
         replace_layout = layout;
         replaces = xml_attrval (this_layout, "replace");
         layout = NULL;
         this_layout = xml_parent (this_layout);
      }
   } while (replace_layout);

   layout_mark = xml_loc (repository, ".cache");
   if (!layout_mark) {
      layout_mark = xml_create ("cache");
      xml_append (repository, layout_mark);
   }

   xml_set (layout, "id", layout_id);
   xml_append (layout_mark, layout);

   return (xml_copy (layout));
}
int _repos_pull_data (XML * repository, const char * list_id, const char * remote_id, int mode, XML * changelist);
WFTK_EXPORT int   repos_pull     (XML * repository, const char *list_id, const char *remote_id, XML * changelist)
{
   return _repos_pull_data (repository, list_id, remote_id, 0, changelist);
}
WFTK_EXPORT int   repos_pull_all     (XML * repository, const char *list_id, const char *remote_id, XML * changelist)
{
   XML * info;
   XML * last;
   struct tm * timeptr;
   time_t julian;
   char now[32];
   int ret = _repos_pull_data (repository, list_id, remote_id, 1, changelist);

   if (ret > 0) {
      info = xml_load ("_log/%s.info", list_id);
      if (xml_is (info, "xml-error")) {
         xml_free (info);
         info = NULL;
      }
      if (!info) {
         info = xml_create ("synchinfo");
      }
      last = NULL;
      last = xml_search (info, "field", "id", remote_id);
      if (!last) {
         last = xml_create ("field");
         xml_set (last, "id", remote_id);
         xml_append (info, last);
      }

      repos_mark_time (repository, "now");
      xml_set (last, "push", xml_attrval (repository, "now"));
      xml_save (info, "_log/%s.info", list_id);
      xml_free (info);
   }

   return ret;
}
int _repos_pull_data (XML * repository, const char *list_id, const char *remote_id, int mode, XML * changelist)
{
   XML * list;
   XML * remote;
   XML * info;
   XML * last;
   XML * changes;
   XML * cur;
   int count = 0;
   XML * obj;

   list = xml_search (repository, "list", "id", list_id);
   if (!list) {
      return -1;
   }

   if (!remote_id) {
      remote_id = xml_attrval (list, "pull");
      if (!*remote_id) {
         remote_id = xml_attrval (list, "mirror");
      }
      if (!*remote_id) {
         return -1;
      }
   }

   /* Only remote lists are supported right now. */
   remote = xml_search (repository, "remote", "host", remote_id);
   if (!remote) {
      remote = xml_create ("remote");
      xml_set (remote, "host", remote_id);
      xml_append (repository, remote);
   }
   repos_open (remote, NULL, "--remote--");
   if (*xml_attrval (remote, "error-state")) {
      xml_delete (remote);
      return -1;
   }

   /* OK.  Let's get a list of changes since our last pull. */
   info = xml_load ("_log/%s.info", list_id);
   if (xml_is (info, "xml-error")) {
      xml_free (info);
      info = NULL;
   }
   if (!info) {
      info = xml_create ("synchinfo");
   }
   last = NULL;
   last = xml_search (info, "field", "id", remote_id);
   if (!last) {
      last = xml_create ("field");
      xml_set (last, "id", remote_id);
      xml_set (last, "pull", "0000-00-00");
      xml_append (info, last);
   }

   if (changelist) changes = changelist;
   else            changes = xml_create ("list");
   if (!mode) {
      repos_changes (remote, changes, xml_attrval (last, "pull"), list_id);
   } else {
      xml_set (changes, "id", list_id);
      repos_list (remote, changes);
   }
   cur = xml_firstelem (changes);

   if (!cur) {
      if (!changelist) xml_free (changes);
      xml_free (info);
      return 0;
   }

   /* Now we write our current data into the info file. */
   repos_mark_time (remote, "now");
   repos_mark_time (repository, "now");
   xml_set (last, "pull", xml_attrval (remote, "now"));
   xml_set (last, "push", xml_attrval (repository, "now")); /* This is necessary in the case of a pull-fixup-synch process */
   xml_save (info, "_log/%s.info", list_id);

   /* Now we iterate along our change list and do the Right Thing for each change. */
   while (cur) {
      count++;
      if (!*xml_attrval (cur, "action") || !strcmp ("add", xml_attrval (cur, "action"))) {
         obj = repos_get (remote, list_id, xml_attrval (cur, "id"));
         repos_add (repository, list_id, obj);
         xml_free (obj);
      } else if (!strcmp ("del", xml_attrval (cur, "action"))) {
         repos_del (repository, list_id, xml_attrval (cur, "id"));
      } else if (!strcmp ("mod", xml_attrval (cur, "action"))) {
         obj = repos_get (remote, list_id, xml_attrval (cur, "id"));
         repos_merge (repository, list_id, obj, NULL); /* TODO: consider a list mode "synch-raw" which can force "mod" */
         xml_free (obj);
      }

      /* Note we can log other things without confusing our mirrors.  Might come in handy. */

      cur = xml_nextelem (cur);
   }

   if (!changelist) xml_free (changes);
   xml_free (info);

   return count;
}
int _repos_push_data (XML * repository, const char * list_id, const char * remote_id, int mode);
WFTK_EXPORT int   repos_push     (XML * repository, const char *list_id, const char *remote_id)
{
   return _repos_push_data (repository, list_id, remote_id, 0);
}
WFTK_EXPORT int   repos_push_all     (XML * repository, const char *list_id, const char *remote_id)
{
   XML * info;
   XML * last;
   int ret = _repos_push_data (repository, list_id, remote_id, 1);

   if (ret > 0) {
      info = xml_load ("_log/%s.info", list_id);
      if (xml_is (info, "xml-error")) {
         xml_free (info);
         info = NULL;
      }
      if (!info) {
         info = xml_create ("synchinfo");
      }
      last = NULL;
      last = xml_search (info, "field", "id", remote_id);
      if (!last) {
         last = xml_create ("field");
         xml_set (last, "id", remote_id);
         xml_append (info, last);
      }

      xml_set (last, "pull", xml_attrval (repository, "remote-time"));
      xml_save (info, "_log/%s.info", list_id);
      xml_free (info);
   }

   return ret;
}
int _repos_push_data (XML * repository, const char *list_id, const char *remote_id, int mode)
{
   XML * list;
   XML * remote;
   XML * info;
   XML * last;
   XML * changes;
   XML * cur;
   int count = 0;
   XML * obj;

   list = xml_search (repository, "list", "id", list_id);
   if (!list) {
      return -1;
   }

   if (!remote_id) {
      remote_id = xml_attrval (list, "push");
      if (!*remote_id) {
         remote_id = xml_attrval (list, "mirror");
      }
      if (!*remote_id) {
         return -1;
      }
   }

   /* Only remote lists are supported right now. */
   remote = xml_search (repository, "remote", "host", remote_id);
   if (!remote) {
      remote = xml_create ("remote");
      xml_set (remote, "host", remote_id);
      xml_append (repository, remote);
   }
   repos_open (remote, NULL, "--remote--");
   if (*xml_attrval (remote, "error-state")) {
      xml_delete (remote);
      return -1;
   }

   /* OK.  Let's get a list of changes since our last pull. */
   info = xml_load ("_log/%s.info", list_id);
   if (xml_is (info, "xml-error")) {
      xml_free (info);
      info = NULL;
   }
   if (!info) {
      info = xml_create ("synchinfo");
   }
   last = NULL;
   last = xml_search (info, "field", "id", remote_id);
   if (!last) {
      last = xml_create ("field");
      xml_set (last, "id", remote_id);
      xml_set (last, "push", "0000-00-00");
      xml_append (info, last);
   }

   changes = xml_create ("list");
   if (!mode) {
      repos_changes (repository, changes, xml_attrval (last, "push"), list_id);
   } else {
      xml_set (changes, "id", list_id);
      repos_list (repository, changes);
   }
   cur = xml_firstelem (changes);

   if (!cur) {
      xml_free (changes);
      xml_free (info);
      return 0;
   }

   /* Now we write our current data into the info file. */
   repos_mark_time (repository, "now");
   repos_mark_time (remote, "now");
   xml_set (repository, "remote-time", xml_attrval (remote, "now"));
   xml_set (last, "push", xml_attrval (repository, "now"));
   xml_save (info, "_log/%s.info", list_id);

   /* Now we iterate along our change list and do the Right Thing for each change. */
   while (cur) {
      count++;
      if (!*xml_attrval (cur, "action") || !strcmp ("add", xml_attrval (cur, "action"))) {
         obj = repos_get (repository, list_id, xml_attrval (cur, "id"));
         repos_add (remote, list_id, obj);
         xml_free (obj);
      } else if (!strcmp ("del", xml_attrval (cur, "action"))) {
         repos_del (remote, list_id, xml_attrval (cur, "id"));
      } else if (!strcmp ("mod", xml_attrval (cur, "action"))) {
         obj = repos_get (repository, list_id, xml_attrval (cur, "id"));
         repos_merge (remote, list_id, obj, NULL); /* TODO: consider a list mode "synch-raw" which can force "mod" */
         xml_free (obj);
      }

      /* Note we can log other things without confusing our mirrors.  Might come in handy. */

      cur = xml_nextelem (cur);
   }

   xml_free (changes);
   xml_free (info);

   return count;
}
WFTK_EXPORT int   repos_synch    (XML * repository, const char *list_id, const char *remote_id, XML * changelist)
{
   XML * list;
   XML * remote;
   XML * info;
   XML * last;
   XML * localchanges;
   XML * remotechanges;
   XML * cur;
   int count = 0;
   XML * obj;

   list = xml_search (repository, "list", "id", list_id);
   if (!list) {
      return -1;
   }

   if (!remote_id) {
      remote_id = xml_attrval (list, "mirror");
      if (!*remote_id) {
         if (*xml_attrval (list, "push")) return repos_push (repository, list_id, remote_id);
         if (*xml_attrval (list, "pull")) return repos_pull (repository, list_id, remote_id, NULL);
         return -1;
      }
   }

   /* Only remote lists are supported right now. */
   remote = xml_search (repository, "remote", "host", remote_id);
   if (!remote) {
      remote = xml_create ("remote");
      xml_set (remote, "host", remote_id);
      xml_append (repository, remote);
   }
   repos_open (remote, NULL, "--remote--");
   if (*xml_attrval (remote, "error-state")) {
      xml_delete (remote);
      return -1;
   }

   /* OK.  Let's get a list of changes since our last pull. */
   info = xml_load ("_log/%s.info", list_id);
   if (xml_is (info, "xml-error")) {
      xml_free (info);
      info = NULL;
   }
   if (!info) {
      info = xml_create ("synchinfo");
   }
   last = NULL;
   last = xml_search (info, "field", "id", remote_id);
   if (!last) {
      last = xml_create ("field");
      xml_set (last, "id", remote_id);
      xml_append (info, last);
   }
   if (!*xml_attrval (last, "push")) xml_set (last, "push", "0000-00-00");
   if (!*xml_attrval (last, "pull")) xml_set (last, "pull", "0000-00-00");

   if (changelist) remotechanges = changelist;
   else            remotechanges = xml_create ("list");
   repos_changes (remote, remotechanges, xml_attrval (last, "pull"), list_id);
   localchanges = xml_create ("list");
   repos_changes (repository, localchanges, xml_attrval (last, "push"), list_id);

   if (!xml_firstelem (remotechanges) && !xml_firstelem (localchanges)) {
      if (!changelist) xml_free (remotechanges);
      xml_free (localchanges);
      xml_free (info);
      return 0;
   }

   /* Now we iterate along our change lists and do the Right Thing for each change. */
   /* We first pull all changes from the remote list, then we push all changes from the local list. */
   cur = xml_firstelem (remotechanges);
   while (cur) {
      count++;
      if (!strcmp ("add", xml_attrval (cur, "action"))) {
         obj = repos_get (remote, list_id, xml_attrval (cur, "id"));
         repos_add (repository, list_id, obj);
         xml_free (obj);
      } else if (!strcmp ("del", xml_attrval (cur, "action"))) {
         repos_del (repository, list_id, xml_attrval (cur, "id"));
      } else if (!strcmp ("mod", xml_attrval (cur, "action"))) {
         obj = repos_get (remote, list_id, xml_attrval (cur, "id"));
         repos_merge (repository, list_id, obj, NULL); /* TODO: consider a list mode "synch-raw" which can force "mod" */
         xml_free (obj);
      }

      cur = xml_nextelem (cur);
   }
   cur = xml_firstelem (localchanges);
   while (cur) {
      count++;
      if (!strcmp ("add", xml_attrval (cur, "action"))) {
         obj = repos_get (repository, list_id, xml_attrval (cur, "id"));
         repos_add (remote, list_id, obj);
         xml_free (obj);
      } else if (!strcmp ("del", xml_attrval (cur, "action"))) {
         repos_del (remote, list_id, xml_attrval (cur, "id"));
      } else if (!strcmp ("mod", xml_attrval (cur, "action"))) {
         obj = repos_get (repository, list_id, xml_attrval (cur, "id"));
         repos_merge (remote, list_id, obj, NULL); /* TODO: consider a list mode "synch-raw" which can force "mod" */
         xml_free (obj);
      }

      cur = xml_nextelem (cur);
   }

   /* Now we write our current data into the info file.  Note that this allows us to avoid noticing
      our own changes next time we synch -- but without locking, it exposes us to missing some changes
      if somebody else synchs while we're busy.  That's why we need locking! */
   repos_mark_time (remote, "now");
   repos_mark_time (repository, "now");

   xml_set (last, "push", xml_attrval (repository, "now"));
   xml_set (last, "pull", xml_attrval (remote, "now"));
   xml_save (info, "_log/%s.info", list_id);

   xml_free (localchanges);
   if (!changelist) xml_free (remotechanges);
   xml_free (info);

   return count;
}
WFTK_EXPORT int   repos_mark_time (XML * repository, const char *attr)
{
   struct tm * timeptr;
   time_t julian;
   char now[32];
   const char * recv;
   char * mark;
   struct _repos_remote * sock = (struct _repos_remote *) xml_getbin (repository);

   if (sock) { /* Remote. */
      xml_set (sock->parms, "outgoing", "time\n");
      _repos_send (sock);
      xml_set (repository, attr, "");
      recv = _repos_receive (sock);
      if (*recv == '-') return 1;

      mark = strchr (recv + 6, '+');
      if (!mark) return 1;

      xml_attrncat (repository, attr, recv + 6, mark - recv - 7);
      return 0;
   }

   time (&julian);
   timeptr = localtime (&julian);
   sprintf (now, "%04d-%02d-%02d %02d:%02d:%02d",
                    timeptr->tm_year + 1900, timeptr->tm_mon + 1, timeptr->tm_mday,
                    timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec);
   xml_set (repository, attr, now);
}
WFTK_EXPORT XML * repos_attach_open (XML * repository, const char *list_id, const char * key, const char * field, const char * filename)
{
   XML * handle;
   XML * list;
   XML * fld;
   XML * fld_def;
   XML * object;
   WFTK_ADAPTOR * ad_l;
   WFTK_ADAPTOR * ad_f = NULL;

   /* Get list definition. */
   list = repos_defn (repository, list_id);
   if (!list) return 0;

   /* Retrieve object. */
   ad_l = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad_l) return NULL;
   xml_set (ad_l->parms, "basedir", xml_attrval (repository, "basedir"));

   object = wftk_call_adaptor (ad_l, "get", list, key);
   if (!object) {
      wftk_free_adaptor (repository, ad_l);
      return 0;
   }

   /* Find appropriate field -- in object first, then if not found, in list definition. */
   if (field && *field) {
      fld = xmlobj_is_field (object, list, field);
      fld_def = xml_search (list, "field", "id", field);
      if (!fld) {
         fld = xml_create ("field");
         xml_set (fld, "id", field);
         if (fld_def) {
            xml_set (fld, "type", xml_attrval (fld_def, "type"));
         } else {
            xml_set (fld, "type", "document");
         }
         xml_append_pretty (object, fld);
      }
   } else {
      fld = xml_search (object, "field", "type", "document");
      fld_def = xml_search (list, "field", "type", "document");
      if (!fld && !fld_def) {
         wftk_free_adaptor (repository, ad_l);
         xml_free (object);
         return 0;
      }
      if (!fld) {
         fld = xml_create ("field");
         xml_set (fld, "id", xml_attrval (fld_def, "id"));
         xml_append_pretty (object, fld);
      }
   }
   field = (char *) xml_attrval (fld, "id");

   /* Perform the actual attachment. */
   if (fld_def) {
      if (*xml_attrval (fld_def, "storage")) ad_f = wftk_get_adaptor (repository, LIST, *xml_attrval (fld_def, "id") ? xml_attrval (fld_def, "id") : xml_attrval (fld_def, "storage"));
      if (ad_f) xml_set (ad_f->parms, "basedir", xml_attrval (repository, "basedir"));
      if (*xml_attrval (fld_def, "ver-keep")) {
         if (!*xml_attrval (fld, "ver")) xml_set (fld, "ver", "0");
         xml_setnum (fld, "next-ver", xml_attrvalnum (fld, "ver") + 1);
      }
   } else {
      if (*xml_attrval (fld, "ver")) {
         xml_setnum (fld, "next-ver", xml_attrvalnum (fld, "ver") + 1);
      }
   }

   handle = wftk_call_adaptor (ad_f ? ad_f : ad_l, "attach_open", list, key, field, filename, xml_attrval (fld, "next-ver"));
   wftk_free_adaptor (repository, ad_l);
   if (ad_f) wftk_free_adaptor (repository, ad_f);

   xml_setnum (handle, "size", 0);
   xml_set (handle, "list", list_id);
   xml_set (handle, "key", key);
   xml_set (handle, "field", field);

   xml_free (object);

   return handle;
}
WFTK_EXPORT int   repos_attach_write (void * buf, size_t size, size_t number, XML * handle)
{
   WFTK_ADAPTOR * ad;

   if (!handle) return 0;
   if (!buf) return 0;
   if (!size || !number) return 0;

   ad = wftk_get_adaptor (handle, LIST, xml_attrval (handle, "adaptor"));
   if (!ad) return 0;
   wftk_call_adaptor (ad, "attach_write", buf, size, number, handle);
   wftk_free_adaptor (handle, ad);
   xml_setnum (handle, "size", xml_attrvalnum (handle, "size") + xml_attrvalnum (handle, "last-write"));
   return xml_attrvalnum (handle, "last-write");
}
WFTK_EXPORT int   repos_attach_cancel (XML * handle)
{
   WFTK_ADAPTOR * ad;

   if (!handle) return 0;

   ad = wftk_get_adaptor (handle, LIST, xml_attrval (handle, "adaptor"));
   if (!ad) return 0;
   wftk_call_adaptor (ad, "attach_cancel", handle);
   wftk_free_adaptor (handle, ad);
   return 0;
}
WFTK_EXPORT int   repos_attach_close (XML * repository, XML * handle)
{
   WFTK_ADAPTOR * ad;
   XML * list;
   XML * fld;
   XML * fld_def;
   XML * object;
   const char * list_id;
   const char * key;
   const char * field;
   WFTK_ADAPTOR * ad_l;

   if (!handle) return 0;
   list_id = xml_attrval (handle, "list");
   key = xml_attrval (handle, "key");
   field = xml_attrval (handle, "field");

   /* Get list definition. */
   list = repos_defn (repository, list_id);
   if (!list) return 0;

   /* Retrieve object. */
   ad_l = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad_l) return 0;
   xml_set (ad_l->parms, "basedir", xml_attrval (repository, "basedir"));

   object = wftk_call_adaptor (ad_l, "get", list, key);
   if (!object) {
      wftk_free_adaptor (repository, ad_l);
      return 0;
   }

   /* Find appropriate field -- in object first, then if not found, in list definition. */
   if (field && *field) {
      fld = xmlobj_is_field (object, list, field);
      fld_def = xml_search (list, "field", "id", field);
      if (!fld) {
         fld = xml_create ("field");
         xml_set (fld, "id", field);
         if (fld_def) {
            xml_set (fld, "type", xml_attrval (fld_def, "type"));
         } else {
            xml_set (fld, "type", "document");
         }
         xml_append_pretty (object, fld);
      }
   } else {
      fld = xml_search (object, "field", "type", "document");
      fld_def = xml_search (list, "field", "type", "document");
      if (!fld && !fld_def) {
         wftk_free_adaptor (repository, ad_l);
         xml_free (object);
         return 0;
      }
      if (!fld) {
         fld = xml_create ("field");
         xml_set (fld, "id", xml_attrval (fld_def, "id"));
         xml_append_pretty (object, fld);
      }
   }
   field = (char *) xml_attrval (fld, "id");

   /* Complete attachment process. */
   ad = wftk_get_adaptor (repository, LIST, xml_attrval (handle, "adaptor"));
   if (!ad) return 0;
   wftk_call_adaptor (ad, "attach_close", handle);
   wftk_free_adaptor (repository, ad);

   /* Update the object. */
   if (*xml_attrval (fld, "next-ver")) {
      xml_set (fld, "ver", xml_attrval (fld, "next-ver"));
      fld = xmlobj_ver_direct (fld, xml_attrval (fld, "ver"));
   }
   xml_set (fld, "size", xml_attrval (handle, "size"));
   xml_set (fld, "mimetype", xml_attrval (handle, "mimetype"));
   xml_set (fld, "location", xml_attrval (handle, "location"));

   wftk_call_adaptor (ad_l, "update", list, object);

   /* Log the change. */
   if (strcmp (xml_attrval (list, "logging"), "off")) { /* TODO: check overall setting as well.  Need a setting checker which scans upward. */
      _repos_log (repository, "mod", list_id, object ? repos_getkey (repository, list_id, object) : key);
   }
   _repos_publish_obj (repository, list_id, object);

   /* Free everything up. */
   wftk_free_adaptor (repository, ad_l);
   xml_free (object);

   return 0;
}
WFTK_EXPORT int   repos_attach (XML * repository, const char * list_id, const char * key, const char * field, const char * filename, FILE * incoming)
{
   XML * handle;
   XML * list;
   XML * fld;
   XML * fld_def;
   XML * object;
   WFTK_ADAPTOR * ad_l = NULL;
   WFTK_ADAPTOR * ad_f = NULL;
   char  buf[1024];
   int  total = 0;
   int  number;

   /* Get list definition. */
   list = repos_defn (repository, list_id);
   if (!list) return 0;

   /* Retrieve object. */
   ad_l = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
   if (!ad_l) return 0;
   xml_set (ad_l->parms, "basedir", xml_attrval (repository, "basedir"));

   object = wftk_call_adaptor (ad_l, "get", list, key);
   if (!object) {
      wftk_free_adaptor (repository, ad_l);
      return 0;
   }

   /* Find appropriate field -- in object first, then if not found, in list definition. */
   if (field && *field) {
      fld = xmlobj_is_field (object, list, field);
      fld_def = xml_search (list, "field", "id", field);
      if (!fld) {
         fld = xml_create ("field");
         xml_set (fld, "id", field);
         if (fld_def) {
            xml_set (fld, "type", xml_attrval (fld_def, "type"));
         } else {
            xml_set (fld, "type", "document");
         }
         xml_append_pretty (object, fld);
      }
   } else {
      fld = xml_search (object, "field", "type", "document");
      fld_def = xml_search (list, "field", "type", "document");
      if (!fld && !fld_def) {
         wftk_free_adaptor (repository, ad_l);
         xml_free (object);
         return 0;
      }
      if (!fld) {
         fld = xml_create ("field");
         xml_set (fld, "id", xml_attrval (fld_def, "id"));
         xml_append_pretty (object, fld);
      }
   }

   field = (char *) xml_attrval (fld, "id");

   /* Perform the actual attachment. */
   if (fld_def) {
      if (*xml_attrval (fld_def, "storage")) ad_f = wftk_get_adaptor (repository, LIST, *xml_attrval (fld_def, "id") ? xml_attrval (fld_def, "id") : xml_attrval (fld_def, "storage"));
      if (ad_f) xml_set (ad_f->parms, "basedir", xml_attrval (repository, "basedir"));
      if (*xml_attrval (fld_def, "ver-keep")) {
         if (!*xml_attrval (fld, "ver")) xml_set (fld, "ver", "0");
         xml_setnum (fld, "next-ver", xml_attrvalnum (fld, "ver") + 1);
      }
   } else {
      if (*xml_attrval (fld, "ver")) {
         xml_setnum (fld, "next-ver", xml_attrvalnum (fld, "ver") + 1);
      }
   }

   handle = wftk_call_adaptor (ad_f ? ad_f : ad_l, "attach_open", list, key, field, filename, xml_attrval (fld, "next-ver"));

   while (number = fread (buf, 1, sizeof (buf), incoming)) {
      total += number;
      wftk_call_adaptor (ad_f ? ad_f : ad_l, "attach_write", buf, 1, number, handle);
      if (number < sizeof(buf)) break;
   }

   wftk_call_adaptor (ad_f ? ad_f : ad_l, "attach_close", handle);
   xml_setnum (handle, "size", total);

   /* Update the object. */
   if (*xml_attrval (fld, "next-ver")) {
      xml_set (fld, "ver", xml_attrval (fld, "next-ver"));
      fld = xmlobj_ver_direct (fld, xml_attrval (fld, "ver"));
   }
   xml_set (fld, "size", xml_attrval (handle, "size"));
   xml_set (fld, "mimetype", xml_attrval (handle, "mimetype"));
   xml_set (fld, "location", xml_attrval (handle, "location"));

   wftk_call_adaptor (ad_l, "update", list, object);

   /* Log the change. */
   if (strcmp (xml_attrval (list, "logging"), "off")) { /* TODO: check overall setting as well.  Need a setting checker which scans upward. */
      _repos_log (repository, "att", list_id, object ? repos_getkey (repository, list_id, object) : key);
   }
   _repos_publish_obj (repository, list_id, object);

   /* Free everything up. */
   wftk_free_adaptor (repository, ad_l);
   if (ad_f) wftk_free_adaptor (repository, ad_f);
   xml_free (object);
   xml_free (handle);
   return total;
}
WFTK_EXPORT void repos_attach_getver (XML * repository, const char * list_id, const char * key, const char * field)
{
   XML * fld;
   XML * object;
   WFTK_ADAPTOR * ad_l;

   xml_set (repository, "result", "");

   object = repos_get (repository, list_id, key);
   if (!object) return;

   if (field && *field) {
      fld = xmlobj_is_field (object, NULL, field);
   } else {
      fld = xml_search (object, "field", "type", "document");
   }

   if (!fld) {
      xml_free (object);
      return;
   }
   xml_set (repository, "result", xml_attrval (fld, "ver"));
}
WFTK_EXPORT XML * repos_retrieve_open (XML * repository, const char * list_id, const char * key, const char * field, const char * ver)
{
   XML * handle;
   XML * list;
   XML * fld;
   XML * object;
   WFTK_ADAPTOR * ad_l;
   WFTK_ADAPTOR * ad;

   list = repos_defn (repository, list_id);
   if (!list) return 0;

   if (field && *field) {
      fld = xml_search (list, "field", "id", field);
   } else {
      fld = xml_search (list, "field", "type", "document");
   }
   if (!fld || (*xml_attrval (fld, "ver-keep") && (!ver || !*ver))) {
      /* Retrieve object if necessary. */
      ad_l = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
      if (!ad_l) return 0;
      xml_set (ad_l->parms, "basedir", xml_attrval (repository, "basedir"));

      object = wftk_call_adaptor (ad_l, "get", list, key);
      wftk_free_adaptor (repository, ad_l);
      if (!object) return 0;

      if (field && *field) {
         fld = xmlobj_is_field (object, list, field);
      } else {
         fld = xml_search (object, "field", "type", "document");
      }
      if (!fld) {
         xml_free (object);
         return 0;
      }
      ver = xml_attrval (fld, "ver");
   }
   field = (char *) xml_attrval (fld, "id");

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (fld, "storage") ? xml_attrval (fld, "storage") : xml_attrval (list, "storage"));
   if (!ad) {
      if (object) xml_free (object);
      return NULL;
   }
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   handle = wftk_call_adaptor (ad, "retrieve_open", list, key, fld, ver);
   wftk_free_adaptor (repository, ad);

   if (object) xml_free (object);
   return handle;
}
WFTK_EXPORT int   repos_retrieve_read (void * buf, size_t size, size_t number, XML * handle)
{
   WFTK_ADAPTOR * ad;
   int (*read_fn) (void *, int, int, void *);

   if (!handle) return 0;
   if (!buf) return 0;
   if (!size || !number) return 0;

   ad = wftk_get_adaptor (handle, LIST, xml_attrval (handle, "adaptor"));
   if (!ad) return 0;

   wftk_call_adaptor (ad, "retrieve_read", buf, size, number, handle);

   wftk_free_adaptor (handle, ad);
   
   return xml_attrvalnum (handle, "last-read");
}
WFTK_EXPORT int   repos_retrieve_close (XML * handle)
{
   WFTK_ADAPTOR * ad;

   if (!handle) return 0;

   ad = wftk_get_adaptor (handle, LIST, xml_attrval (handle, "adaptor"));
   if (!ad) return 0;
   wftk_call_adaptor (ad, "attach_close", handle);
   wftk_free_adaptor (handle, ad);
   return 0;
}
WFTK_EXPORT int   repos_retrieve (XML * repository, const char * list_id, const char * key, const char * field, const char * ver, FILE * outgoing)
{
   XML * handle;
   XML * list;
   XML * fld;
   XML * object = NULL;
   WFTK_ADAPTOR * ad_l;
   WFTK_ADAPTOR * ad;
   char  buf[1024];
   int  total = 0;
   int  number;

   list = repos_defn (repository, list_id);
   if (!list) return 0;

   if (field && *field) {
      fld = xml_search (list, "field", "id", field);
   } else {
      fld = xml_search (list, "field", "type", "document");
   }
   if (!fld || (*xml_attrval (fld, "ver-keep") && (!ver || !*ver))) {
      /* Retrieve object if necessary. */
      ad_l = wftk_get_adaptor (repository, LIST, *xml_attrval (list, "id") ? xml_attrval (list, "id") : xml_attrval (list, "storage"));
      if (!ad_l) return 0;
      xml_set (ad_l->parms, "basedir", xml_attrval (repository, "basedir"));

      object = wftk_call_adaptor (ad_l, "get", list, key);
      wftk_free_adaptor (repository, ad_l);
      if (!object) return 0;

      if (field && *field) {
         fld = xmlobj_is_field (object, list, field);
      } else {
         fld = xml_search (object, "field", "type", "document");
      }
      if (!fld) {
         xml_free (object);
         return 0;
      }
      ver = xml_attrval (fld, "ver");
   }
   field = (char *) xml_attrval (fld, "id");

   ad = wftk_get_adaptor (repository, LIST, *xml_attrval (fld, "storage") ? xml_attrval (fld, "storage") : xml_attrval (list, "storage"));
   if (!ad) {
      if (object) xml_free (object);
      return 0;
   }
   xml_set (ad->parms, "basedir", xml_attrval (repository, "basedir"));

   handle = wftk_call_adaptor (ad, "retrieve_open", list, key, fld, ver);

   do {
      wftk_call_adaptor (ad, "retrieve_read", buf, 1, sizeof(buf), handle);
      number = xml_attrvalnum (handle, "last-read");
      if (!number) break;
      total += number;
      fwrite (buf, 1, number, outgoing);
      if (number < sizeof(buf)) break;
   } while (1);

   wftk_call_adaptor (ad, "retrieve_close", handle);

   if (object) xml_free (object);
   xml_free (handle);
   return total;
}
WFTK_EXPORT XML * repos_retrieve_load (XML * repository, const char * list_id, const char * key, const char * field, const char * ver)
{
   XML * handle = repos_retrieve_open (repository, list_id, key, field, ver);
   XML * ret;

   if (!handle) return NULL;

   ret = xml_parse_general ((void *) handle, (XMLAPI_DATARETRIEVE) repos_retrieve_read);
   xml_free (handle);

   return ret;
}
WFTK_EXPORT int   repos_report_start  (XML * repository, const char * list, const char * name)
{
   XML * rep;
   XML * obj;

   if (!name) name = list;
   if (!name) return 1;
   rep = xml_locf (repository, ".report[%s]", name);
   if (rep) return 1;

   rep = xml_create ("report");
   xml_set (rep, "id", name);
   xml_append (repository, rep);

   obj = xml_create ("record");
   xml_set (obj, "list", list);
   repos_mark_time (obj, "start");
   xml_setbin (rep, obj, (XML_SETBIN_FREE_FN *) xml_free);

   return 0;
}
WFTK_EXPORT int   repos_report_close  (XML * repository, const char * report)
{
   XML * rep;
   XML * obj;

   rep = xml_locf (repository, ".report[%s]", report);
   if (!rep) return 1;

   obj = xml_getbin (rep);
   xml_unset (obj, "content");
   xml_setbin (rep, NULL, NULL);
   xml_delete (rep);

   repos_add (repository, xml_attrval (obj, "list"), obj);
   xml_delete (obj);

   return 0;
}
WFTK_EXPORT int   repos_report_cancel (XML * repository, const char * report)
{
   XML * rep;

   rep = xml_locf (repository, ".report[%s]", report);
   if (!rep) return 1;

   xml_delete (rep);
   return 0;
}
WFTK_EXPORT XML * repos_report_getobj (XML * repository, const char * report)
{
   XML * rep;

   rep = xml_locf (repository, ".report[%s]", report);
   if (!rep) return NULL;
   return (xml_getbin (rep));
}
WFTK_EXPORT int   repos_report_log    (XML * repository, const char * report, const char * format, ...)
{
   XML * rep;
   XML * obj;
   const char * content;
   XML * list;
   XML * mark;

   va_list args;
   char * colon;
   char * strarg;
   int intarg;
   char numbuf[sizeof (int) * 3 + 1];

   rep = xml_locf (repository, ".report[%s]", report);
   if (!rep) return 1;

   obj = xml_getbin (rep);
   if (!obj) return 1;

   content = xml_attrval (obj, "content");
   if (!*content) {
      list = repos_defn (repository, xml_attrval (obj, "list"));
      if (list) {
         mark = xml_search (list, "field", "special", "content");
         xml_set (obj, "content", xml_attrval (mark, "id"));
         content = xml_attrval (obj, "content");
      }
      if (!*content) {
         xml_set (obj, "content", "content");
         content = xml_attrval (obj, "content");
      }
   }
   mark = xmlobj_field (obj, NULL, content);

   va_start (args, format);
   while (colon = strchr (format, '%')) {
      xml_attrncat (mark, "value", format, colon-format);
      format = colon;
      format ++;
      switch (*format) {
         case 's':
            strarg = va_arg (args, char *);
            xml_attrcat (mark, "value", strarg);
            break;
         case 'd':
            intarg = va_arg (args, int);
            sprintf (numbuf, "%d", intarg);
            xml_attrcat (mark, "value", numbuf);
            break;
         default:
            xml_attrncat (mark, "value", format, 1);
            break;
      }
      format ++;
   }
   va_end (args);

   xml_attrcat (mark, "value", format);
   xml_attrcat (mark, "value", "\n");
}
WFTK_EXPORT char * repos_process (XML * repository, const char * list, const char * key)
{
   return NULL;
}
WFTK_EXPORT XML * repos_action_do (XML * repository, XML * action)
{
   return NULL;
}

WFTK_EXPORT XML * repos_action_do_object (XML * repository, XML * action, XML * object)
{
   return NULL;
}
WFTK_EXPORT XML * repos_action_list               (XML * repository, const char * list, const char * key, const char * mode)
{
   return (repos_action_list_direct (repository, repos_defn (repository, list), key, mode));
}
WFTK_EXPORT XML * repos_action_list_direct        (XML * repository, XML *        list, const char * key, const char * mode)
{
   XML * object = repos_get (repository, xml_attrval (list, "id"), key);
   XML * ret    = repos_action_list_object_direct (repository, list, object, mode);
   if (object) xml_free (object);
   return ret;
}
WFTK_EXPORT XML * repos_action_list_object        (XML * repository, const char * list, XML *     object, const char * mode)
{
   return (repos_action_list_object_direct (repository, repos_defn (repository, list), object, mode));
}

WFTK_EXPORT XML * repos_action_list_object_direct (XML * repository, XML *        list, XML *     object, const char * mode)
{
   XML * actions = xml_create ("list");
   XML * action;
   XML * states;
   XML * mark;

   if (!list) return (actions);

   if (!object || !strcmp (mode, "new")) { 
      action = xml_create ("action");
      xml_set (action, "id", "add");
      xml_setf (action, "label", "Add new %s", xml_attrval (list, "id")); /* TODO: label should be configurable. */
      xml_append (actions, action);
   } else {
      /* Standard actions against object. */
      action = xml_create ("action");
      xml_set (action, "id", "mod");
      xml_set (action, "label", "Update");
      xml_append (actions, action);  /* TODO: check actual permissions, view, etc. */
      action = xml_create ("action");
      xml_set (action, "id", "del");
      xml_set (action, "label", "Delete");
      xml_append (actions, action);

      /* State transitions also count as actions, of course.  We modify the name a little to avoid collisions (with a "state-" prefix). */
      states = repos_list_choices (repository, xml_attrval (list, "id"), object, "_state");
      for (mark = xml_firstelem (states); mark; mark = xml_nextelem (mark)) {
         if (!*xml_attrval (mark, "selected")) {
            action = xml_create ("action");
            xml_set (action, "id", "state-");
            xml_attrcat (action, "id", xml_attrval (mark, "value"));
            xml_set_nodup (action, "label", xml_stringcontenthtml (mark));
            xml_append (actions, action);
         }
      }
      if (states) xml_free (states);

      /* Completion of active, passive, and potential tasks are also all actions.  TODO: deal with these. */

      /* If the object itself is a task, completion might be added here if list_choices didn't already list it.  TODO: figure that out. */
   }

   /* TODO: pass the whole list in for rule processing to determine permissibility.  God knows what that will take. */

   return (actions);
}
WFTK_EXPORT void repos_workflow_start (XML * repository, const char * list, const char * key, XML * wf_defn, const char * wf_id)
{
   XML * obj = repos_get (repository, list, key);

   if (obj) {
      repos_workflow_start_direct (repository, obj, wf_defn, wf_id);
      repos_mod (repository, list, obj, key);
   }
   xml_free (obj);
}
WFTK_EXPORT void repos_workflow_start_direct (XML * repository, XML * obj, XML * wf_defn, const char * wf_id)
{
   XML * adhoc;

   xml_setf (obj, "repository", "list:%s", xml_attrval (obj, "list")); /* tell wftk_process_save what to do */

   /* If wf_defn is supplied, we start ad-hoc workflow. */
   if (wf_defn) {
      adhoc = xml_create ("sequence"); /* TODO: support parallel as well?  workflow-type=, maybe */
      xml_copyinto (adhoc, wf_defn);
      wftk_process_adhoc (repository, obj, adhoc);
      xml_free (adhoc);
   }

   /* If wf_id is supplied, we start a procdef from the default pdrep. */
   if (wf_id && *wf_id) {
      wftk_process_start (repository, obj, NULL, wf_id);
   }
}
WFTK_EXPORT void repos_task_add (XML * repository, const char * list, const char * key, XML * task_defn)
{
   XML * obj = repos_get (repository, list, key);

   if (obj) {
      repos_task_add_direct (repository, obj, task_defn);
      repos_mod (repository, list, obj, key);
   }
   xml_free (obj);
}
WFTK_EXPORT void repos_task_add_direct (XML * repository, XML * obj, XML * task_defn)
{

}
WFTK_EXPORT XML * repos_tasks (XML * repository, XML * tasklist, const char * list, const char * key, const char * user)
{
   XML * obj = repos_get (repository, list, key);
   XML * ret;

   if (obj) {
      ret = repos_tasks_direct (repository, tasklist, obj, user);
      xml_free (obj);
      return (ret);
   }
}
WFTK_EXPORT XML * repos_tasks_direct (XML * repository, XML * tasklist, XML * obj, const char * user)
{
   if (!tasklist) tasklist = xml_create ("list");
   if (user) xml_set   (tasklist, "userid", user);
   else      xml_unset (tasklist, "userid");

   wftk_task_list (repository, tasklist, obj);
   return (tasklist);
}
WFTK_EXPORT XML * repos_task_get (XML * repository, const char * list, const char * key, const char * local_key)
{
   char * list_id;
   char * task_key;
   XML * task;

   list_id = strdup (list);
   xmlobj_fixkey (list_id);
   task_key = xml_string_format ("%s~%s~%s", list_id, key, local_key);

   repos_log (repository, 5, 2, NULL, "repmgr", "repos_task_get: getting task %s", task_key);
   task = repos_get (repository, "_tasks", task_key);

   free (task_key);
   free (list_id);

   return (task);
}
WFTK_EXPORT XML * repos_task_get_direct (XML * repository, XML * obj, const char * local_key)
{
   return (repos_task_get (repository, xml_attrval (obj, "list"), xml_attrval (obj, "key"), local_key)); /* TODO: look for potentials n stuff. */
}
