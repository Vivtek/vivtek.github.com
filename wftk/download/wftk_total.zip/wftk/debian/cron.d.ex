#
# Regular cron jobs for the wftk package
#
0 4	* * *	root	wftk_maintenance
