?package(wftk):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="wftk" command="/usr/bin/wftk"
