#include <stdio.h>
#include "xmlapi.h"

XML * xml;
XML * found;
char * loc;
FILE * file;

int main (int argc, char *argv[])
{
   xml = xml_parse ("<item stuff=\"here\" and=\"more\"/>");
   xml_free (xml);

   printf ("\n\nOutput:\n");
   xml=  xml_read_error(stdin);
   xml_prepend (xml, xml_create("boogida"));
   xml_prepend (xml, xml_createtext ("This is a test & this is too."));
   xml_write (stdout, xml);

   printf ("\n\nHTML:\n");
   /*xml_writehtml (stdout, xml);*/
   printf ("%s", xml_stringhtml (xml));

   printf ("\n\n");
   found = xml_locf (xml, ".item(%d)", 1);
   if (found) xml_write (stdout, found);
   else       printf ("item(1) not found\n");

   if (found) found = xml_nextelem (found);
   if (found) loc = xml_getlocbuf (found);

   printf ("\nInput is an item? %s", xml_is (xml, "item") ? "yes" : "no");
   printf ("\nInput is an xml? %s", xml_is (xml, "xml") ? "yes" : "no");

   printf ("\n\n%s\n\n", loc);
   free (loc);
}

