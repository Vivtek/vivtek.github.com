#include <stdio.h>

#ifdef PYTHON
#define XMLAPI_MALLOC_PYTHON
#undef XMLAPI_MALLOC_NATIVE
#endif

#ifndef XMLAPI_MALLOC_NATIVE
#define XMLAPI_MALLOC_NATIVE
#endif

#ifdef XMLAPI_MALLOC_NATIVE
#include <malloc.h>
#define MALLOC(x) malloc(x)
#define REALLOC(x,y) realloc((x),(y))
#define FREE(x) free(x)
#endif

#ifdef XMLAPI_MALLOC_PYTHON
#include <python.h>
#define MALLOC(x) PyMem_Malloc(x)
#define REALLOC(x,y) PyMem_Realloc((x),(y))
#define FREE(x,y) PyMem_Free(x)
#endif

#include <string.h>
#include <stdlib.h>
#include <stdarg.h>




#ifndef PYTHON
#include <expat.h>
#endif

#include "xmlapi.h"

/* Note to self: put these *after* xmlapi.h... (What was I thinking?) */
XMLAPI char * xml_strdup (const char * str)
{
   char * ret;

   ret = MALLOC (strlen (str) + 1);
   strcpy (ret, str);
   return (ret);
}
XMLAPI void xml_strfree (char * str)
{
   free (str);
}
char * _xml_danger_char (const char * str)
{
   if (!str) return NULL;
   while (*str) {
      if (*str == '&' || *str == '<' || *str == '>' || *str == '"') return (char *) str;
      if ((unsigned) *str > 127) return (char *) str;
      str++;
   }
   return NULL;
}
char * _xml_string_tackonn (char * buffer, int * cursize, int * curptr, const char * data, int len)
{
   if (!len) return (buffer);
   if (len + *curptr + 1 > *cursize) {
      while (len + *curptr + 1 > *cursize) *cursize += 256;
      buffer = (char *) REALLOC ((void *) buffer, *cursize);
   }
   strncpy (buffer + *curptr, data, len);
   *curptr += len;
   buffer[*curptr] = '\0';
   return (buffer);
}
char * _xml_string_tackon (char * buffer, int * cursize, int * curptr, const char * data, int escaped)
{
   int len;
   long value;
   char *mark;
   char numbuf[sizeof (long) * 3 + 4];

   if (!data) return (buffer);
   if (!*data) return (buffer);

   if (escaped) {
      mark = _xml_danger_char (data);
      if (mark) {
         buffer = _xml_string_tackonn (buffer, cursize, curptr, data, mark - data);
         len = 1;
         switch (*mark) {
            case '&': buffer = _xml_string_tackonn (buffer, cursize, curptr, "&amp;", 5); break;
            case '<':  buffer = _xml_string_tackonn (buffer, cursize, curptr, "&lt;", 4);  break;
            case '>':   buffer = _xml_string_tackonn (buffer, cursize, curptr, "&gt;", 4);  break;
            case '"':   buffer = _xml_string_tackonn (buffer, cursize, curptr, "&quot;", 6);  break;
            default:
              if ((*mark & 0x00E0) == 0xC0) {
                  /* two bytes:   marker is 110x xxxx */
                  len = 2;
                  value = (mark[0] & 0x001F) * 64 + (mark[1] & 0x003F);
               } else if ((*mark & 0x00F0) == 0xE0) {
                  /* three bytes: marker is 1110 xxxx */
                  len = 3;
                  value = ((mark[0] & 0x000F) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F);
               } else if ((*mark & 0x00F8) == 0xF0) {
                  /* four bytes:  marker is 1111 0xxx */
                  len = 4;
                  value = (((mark[0] & 0x0007) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F)) * 64 + (mark[3] & 0x003F);
               } else if ((*mark & 0x00FC) == 0xF8) {
                  /* five bytes:  marker is 1111 10xx */
                  len = 5;
                  value = ((((mark[0] & 0x0003) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F)) * 64 + (mark[3] & 0x003F)) * 64 + (mark[4] & 0x003F);
               } else if ((*mark & 0x00FE) == 0xFC) {
                  /* six bytes:   marker is 1111 110x */
                  len = 6;
                  value = (((((mark[0] & 0x0001) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F)) * 64 + (mark[3] & 0x003F)) * 64 + (mark[4] & 0x003F)) * 64 + (mark[5] & 0x003F);
               } else {
                  value = 0x20; /* Illegal value, but instead of freaking out we'll do something quasi-normal. */
               }
               sprintf (numbuf, "&#%ld;", value);
               buffer = _xml_string_tackonn (buffer, cursize, curptr, numbuf, strlen (numbuf));
               break;
         }
         buffer = _xml_string_tackon (buffer, cursize, curptr, mark + len, 1);
         return (buffer);
      }
   }

   len = strlen (data);
   if (len + *curptr + 1 > *cursize) {
      while (len + *curptr + 1 > *cursize) *cursize += 256;
      buffer = (char *) REALLOC ((void *) buffer, *cursize);
   }
   *curptr += len;
   strcat (buffer, data);
   return (buffer);
}


char * xml_string_format (const char * format, ...)
{
   va_list args;
   char * ret;

   va_start (args, format);
   ret = xml_string_formatv (format, args);
   va_end (args);

   return ret;
}

char * xml_string_formatv (const char * format, va_list args)
{
   char * buffer = (char *) MALLOC (256);
   int cursize = 256;
   int curptr = 0;
   char * colon;
   char * strarg;
   int intarg;
   char numbuf[sizeof (int) * 3 + 1];

   *buffer = '\0';
   while (colon = strchr (format, '%')) {
      buffer = _xml_string_tackonn (buffer, &cursize, &curptr, format, colon - format);
      format = colon;
      format ++;
      switch (*format) {
         case 's':
            strarg = va_arg (args, char *);
            buffer = _xml_string_tackon (buffer, &cursize, &curptr, strarg, 0);
            break;
         case 'd':
            intarg = va_arg (args, int);
            sprintf (numbuf, "%d", intarg);
            buffer = _xml_string_tackon (buffer, &cursize, &curptr, numbuf, 0);
            break;
         default:
            buffer = _xml_string_tackonn (buffer, &cursize, &curptr, format, 1);
            break;
      }
      format ++;
   }

   buffer = _xml_string_tackon (buffer, &cursize, &curptr, format, 0);
   return (buffer);
}

char * _xml_string_append (char * buffer, int * cursize, int * curptr, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (!xml) return (buffer);

   if (xml->name == NULL) {
      if (xml->attrs) if (xml->attrs->value) buffer = _xml_string_tackon (buffer, cursize, curptr, xml->attrs->value, 1);
      return (buffer);
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, "<", 0);
   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name, 0);
   attr = xml->attrs;
   while (attr != NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, " ", 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->name, 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "=\"", 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->value, 1);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "\"", 0);
      attr = attr->next;
   }

   if (xml->children == NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "/>", 0);
      return (buffer);
   } else buffer = _xml_string_tackon (buffer, cursize, curptr, ">", 0);

   list = xml->children;
   while (list) {
      buffer = _xml_string_append (buffer, cursize, curptr, list->element);
      list = list->next;
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, "</", 0);
   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name, 0);
   buffer = _xml_string_tackon (buffer, cursize, curptr, ">", 0);

   return (buffer);
}

XMLAPI char * xml_string (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   if (!xml) return (ret);

   return (_xml_string_append (ret, &cursize, &curptr, xml));
}


XMLAPI char * xml_stringcontent (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;
   ELEMENTLIST * list;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   if (!xml) return (ret);

   list = xml->children;
   while (list) {
      ret = _xml_string_append (ret, &cursize, &curptr, list->element);
      list = list->next;
   }

   return (ret);
}

char * _xml_string_appendhtml (char * buffer, int * cursize, int * curptr, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (!xml) return (buffer);

   if (xml->name == NULL) {
      if (xml->attrs) if (xml->attrs->value) buffer = _xml_string_tackon (buffer, cursize, curptr, xml->attrs->value, 0);
      return (buffer);
   }

   if (xml_is (xml, "nbsp")) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "&nbsp;", 0);
      return (buffer);
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, "<", 0);
   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name, 0);
   attr = xml->attrs;
   while (attr != NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, " ", 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->name, 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "=\"", 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->value, 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "\"", 0);
      attr = attr->next;
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, ">", 0);
   if (xml->children == NULL) {
      if (!strcmp (xml->name, "p") ||
          !strcmp (xml->name, "a") ||
          !strcmp (xml->name, "textarea")) {
         buffer = _xml_string_tackon (buffer, cursize, curptr, "</", 0);
         buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name, 0);
         buffer = _xml_string_tackon (buffer, cursize, curptr, ">", 0);
      }
      return (buffer);
   }

   list = xml->children;
   while (list) {
      buffer = _xml_string_appendhtml (buffer, cursize, curptr, list->element);
      list = list->next;
   }

   if (!strcmp (xml->name, "li") ||
       !strcmp (xml->name, "opt")) {
      /* Do nothing. */
   } else {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "</", 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name, 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, ">", 0);
   }

   return (buffer);
}

XMLAPI char * xml_stringhtml (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   if (!xml) return (ret);

   return (_xml_string_appendhtml (ret, &cursize, &curptr, xml));
}


XMLAPI char * xml_stringcontenthtml (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;
   ELEMENTLIST * list;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   if (!xml) return (ret);

   list = xml->children;
   while (list) {
      ret = _xml_string_appendhtml (ret, &cursize, &curptr, list->element);
      list = list->next;
   }

   return (ret);
}

XMLAPI XML * xml_create (const char * name)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   memset (ret, 0, sizeof (struct _element));
   ret->name = xml_strdup (name);

   return (ret);
}
XMLAPI void xml_set (XML * xml, const char * name, const char * value)
{
   ATTR * attr;
   char * holder;

   if (!xml) return;
   if (!value) value = "";

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (attr) {
      holder = xml_strdup (value);
      FREE ((void *) (attr->value));
      attr->value = holder;
      attr->valsize = strlen (value) + 1;
      return;
   }

   if (xml->attrs == NULL) {
      attr = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs = attr;
   } else {
      attr = xml->attrs;
      while (attr->next) attr = attr->next;
      attr->next = (ATTR *) MALLOC (sizeof (struct _attr));
      attr = attr->next;
   }

   attr->next = NULL;
   attr->name = xml_strdup (name);
   if (value) {
      attr->value = xml_strdup (value);
      attr->valsize = strlen (value) + 1;
   } else {
      attr->value = xml_strdup ("");
      attr->valsize = 1;
   }
}
XMLAPI void xml_setf (XML * xml, const char *name, const char *format, ...)
{
   ATTR * attr;
   va_list args;
   char * value;

   if (!xml) return;
   va_start (args, format);
   value = xml_string_formatv (format, args);
   va_end (args);

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (attr) {
      FREE ((void *) (attr->value));
      attr->value = value;
      attr->valsize = 0;
      return;
   }

   if (xml->attrs == NULL) {
      attr = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs = attr;
   } else {
      attr = xml->attrs;
      while (attr->next) attr = attr->next;
      attr->next = (ATTR *) MALLOC (sizeof (struct _attr));
      attr = attr->next;
   }

   attr->next = NULL;
   attr->name = xml_strdup (name);
   attr->value = value;
   attr->valsize = 0;
}
XMLAPI void xml_setnum (XML * xml, const char *attr, int number)
{
   char buf[sizeof(number) * 3 + 1];
   sprintf (buf, "%d", number);
   xml_set (xml, attr, buf);
}
XMLAPI void xml_set_nodup (XML * xml, const char * name, char * value)
{
   ATTR * attr;

   if (!xml) return;
   if (!value) {
      xml_set (xml, name, "");
      return;
   }

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (attr) {
      FREE ((void *) (attr->value));
      attr->value = value;
      attr->valsize = 0;
      return;
   }

   if (xml->attrs == NULL) {
      attr = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs = attr;
   } else {
      attr = xml->attrs;
      while (attr->next) attr = attr->next;
      attr->next = (ATTR *) MALLOC (sizeof (struct _attr));
      attr = attr->next;
   }

   attr->next = NULL;
   attr->name = xml_strdup (name);
   if (value) {
      attr->value = value;
      attr->valsize = 0;
   } else {
      attr->value = xml_strdup (value);
      attr->valsize = 1;
   }
}
XMLAPI void xml_attrcat (XML * xml, const char * name, const char * value)
{
   ATTR * attr;
   int len;

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (!attr) xml_set (xml, name, value);
   else {
      if (value) {
         len = strlen (attr->value) + strlen (value) + 1;
         if (len > attr->valsize) {
            while (attr->valsize < len) attr->valsize += 256;
            attr->value = (char *) REALLOC (attr->value, attr->valsize);
         }
         strcat (attr->value, value);
      }
   }
}
XMLAPI void xml_attrncat (XML * xml, const char * name, const char * value, int length)
{
   ATTR * attr;
   int len;

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (!attr) {
      xml_set (xml, name, "");
      attr = xml->attrs;
      while (attr) {
         if (!strcmp (attr->name, name)) break;
         attr = attr->next;
      }
   }
   if (!attr) return; /* This is probably a dumb way to handle low-mem situations, but... */

   if (value) {
      len = strlen (attr->value) + length + 1;
      if (len > attr->valsize) {
         while (attr->valsize < len) attr->valsize += 256;
         attr->value = (char *) REALLOC (attr->value, attr->valsize);
      }
      strncat (attr->value, value, length);
   }
}
XMLAPI void xml_unset (XML * xml, const char * name)
{
   ATTR * prev;
   ATTR * attr;

   attr = xml->attrs;
   prev = NULL;
   while (attr) {
      if (attr->name && !strcmp (attr->name, name)) break;
      prev = attr;
      attr = attr->next;
   }

   if (!attr) return;

   if (prev) prev->next = attr->next;
   else      xml->attrs = attr->next;

   FREE ((void *) (attr->value));
   FREE ((void *) (attr));
}
XMLAPI const char * xml_attrval (XML * element,const char * name)
{
   ATTR * attr;

   if (!element) return ("");
   attr = element->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) return (attr->value);
      attr = attr->next;
   }
   return ("");
}
XMLAPI int xml_attrvalnum (XML * element, const char * name)
{
   return (atoi (xml_attrval (element, name)));
}
XMLAPI const char * xml_textval (XML * element)
{
   ATTR * attr;

   if (!element) return ("");
   if (xml_is_element (element)) return ("");
   attr = element->attrs;
   if (attr) {
      if (attr->value) return (attr->value);
   }
   return ("");
}
XMLAPI void xml_prepend (XML * parent, XML * child)
{
   ELEMENTLIST * list;

   child->parent = parent;

   list = (ELEMENTLIST *) MALLOC (sizeof(struct _list));
   list->element = child;
   list->prev = NULL;
   list->next = parent->children;
   if (list->next) list->next->prev = list;

   if (parent->children == NULL) {
      parent->lastchild = list;
   }
   parent->children = list;
}
XMLAPI void xml_append (XML * parent, XML * child)
{
   ELEMENTLIST * list;
   ELEMENTLIST * ch;

   child->parent = parent;

   list = (ELEMENTLIST *) MALLOC (sizeof(struct _list));
   list->element = child;
   list->prev = parent->lastchild;
   if (list->prev) list->prev->next = list;
   list->next = NULL;

   if (parent->children == NULL) {
      parent->children = list;
   }
   parent->lastchild = list;
}
XMLAPI void xml_append_pretty (XML * parent, XML * child)
{
   if (!xml_first (parent)) xml_append (parent, xml_createtext ("\n"));
   xml_append (parent, child);
   xml_append (parent, xml_createtext ("\n"));
}
XMLAPI void xml_prepend_pretty (XML * parent, XML * child)
{
   if (!xml_first (parent)) xml_prepend (parent, xml_createtext ("\n"));
   xml_prepend (parent, child);
   xml_prepend (parent, xml_createtext ("\n"));
}
XMLAPI void xml_replace (XML * xml, XML * newxml)
{
   ELEMENTLIST * list;

   if (xml == NULL) return;
   if (xml->parent == NULL) return;
   if (newxml == NULL) xml_delete (xml);

   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return;

   newxml->parent = xml->parent;
   list->element = newxml;

   xml_free (xml);
}
XMLAPI void xml_replacecontent (XML * parent, XML * child)
{
   XML * first;

   if (parent == NULL) return;
   while (first = xml_first (parent)) {
      xml_delete (first);
   }
   if (child != NULL) xml_prepend (parent, child);
}
XMLAPI void xml_replacewithcontent (XML * xml, XML * source)
{
   ELEMENTLIST * list;
   XML * src;
   XML * target;

   if (xml == NULL) return;
   if (xml->parent == NULL) return;
   if (source == NULL) xml_delete (xml);

   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return;

   src = xml_first (source);
   if (!src) {
      xml_delete (xml);
      return;
   }
   target = xml_copy (src);

   target->parent = xml->parent;
   list->element = target;

   src = xml_next (src);
   while (src) {
      target = xml_insertafter (target, xml_copy (src));
      src = xml_next (src);
   }
}
XMLAPI XML * xml_insertbefore (XML * orig, XML * new)
{
   ELEMENTLIST * list;
   ELEMENTLIST * ch;

   if (orig == NULL) return new;
   if (orig->parent == NULL) return new;
   if (new == NULL) return new;

   list = orig->parent->children;
   while (list != NULL && list->element != orig) list = list->next;
   if (list == NULL) return new;

   new->parent = orig->parent;

   ch = (ELEMENTLIST *) MALLOC (sizeof(struct _list));
   ch->element = new;
   ch->next = list;
   ch->prev = list->prev;
   if (!ch->prev) orig->parent->children = ch;
   else           ch->prev->next = ch;
   list->prev = ch;

   return (new);
}
XMLAPI XML * xml_insertafter (XML * orig, XML * new)
{
   ELEMENTLIST * list;
   ELEMENTLIST * ch;

   if (orig == NULL) return new;
   if (orig->parent == NULL) return new;
   if (new == NULL) return new;

   list = orig->parent->children;
   while (list != NULL && list->element != orig) list = list->next;
   if (list == NULL) return new;

   new->parent = orig->parent;

   ch = (ELEMENTLIST *) MALLOC (sizeof(struct _list));
   ch->element = new;
   ch->prev = list;
   ch->next = list->next;
   if (!ch->next) orig->parent->lastchild = ch;
   else           ch->next->prev = ch;
   list->next = ch;

   return (new);
}
XMLAPI XML * xml_createtext (const char * value)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   memset (ret, 0, sizeof (struct _element));
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   if (value) {
      ret->attrs->value = xml_strdup (value);
      ret->attrs->valsize = strlen (value) + 1;
   } else {
      ret->attrs->value = xml_strdup ("");
      ret->attrs->valsize = 1;
   }

   return (ret);
}
XMLAPI XML * xml_createtext_nodup (char * value)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   memset (ret, 0, sizeof (struct _element));
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   if (value) {
      ret->attrs->value = value;
      ret->attrs->valsize = strlen (value) + 1;
   } else {
      ret->attrs->value = xml_strdup ("");
      ret->attrs->valsize = 1;
   }

   return (ret);
}
XMLAPI XML * xml_createtextlen (const char * value, int len)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   memset (ret, 0, sizeof (struct _element));
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   ret->attrs->value = (char *) MALLOC (len + 1);
   ret->attrs->valsize = len + 1;
   strncpy (ret->attrs->value, value, len);
   ret->attrs->value[len] = '\0';

   return (ret);
}
XMLAPI XML * xml_createtextf (const char * format, ...)
{
   XML * ret;
   char * value;
   va_list args;

   va_start (args, format);
   value = xml_string_formatv (format, args);
   va_end (args);

   ret = (XML *) MALLOC (sizeof (struct _element));
   memset (ret, 0, sizeof (struct _element));
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   ret->attrs->value = value;
   ret->attrs->valsize = strlen (value) + 1;

   return (ret);
}
XMLAPI void xml_textcat (XML * xml, const char * value)
{
   ATTR * attr;
   int len;

   if (xml_is_element (xml)) return; /* We refuse to work with non-elements. */
   if (!value) return;

   attr = xml->attrs;
   if (!attr) {
      xml->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs->name = NULL;
      xml->attrs->next = NULL;
      xml->attrs->value = xml_strdup (value);
      xml->attrs->valsize = strlen (value) + 1;
      return;
   }

   len = strlen (attr->value) + strlen (value) + 1;
   if (len > attr->valsize) {
      while (attr->valsize < len) attr->valsize += 256;
      attr->value = (char *) REALLOC (attr->value, attr->valsize);
   }
   strcat (attr->value, value);
}
XMLAPI void xml_textncat (XML * xml, const char * value, int length)
{
   ATTR * attr;
   int len;

   if (xml_is_element (xml)) return; /* We refuse to work with non-elements. */

   attr = xml->attrs;
   if (!attr) {
      xml_textcat (xml, "");
      attr = xml->attrs;
      if (!attr) return; /* Shouldn't happen...*/
   }

   len = strlen (attr->value) + length + 1;
   if (len > attr->valsize) {
      while (attr->valsize < len) attr->valsize += 256;
      attr->value = (char *) REALLOC (attr->value, attr->valsize);
   }
   strncat (attr->value, value, length);
}
void _xml_fwrite_escaped (void * data, XMLAPI_DATAWRITE write, char * str) {
   int len;
   long value;
   char * mark;
   char numbuf[20];

   do {
      mark = _xml_danger_char (str);
      if (mark) {
         if (mark != str) (*write) (str, 1, mark - str, data);
         len = 1;
         switch (*mark) {
            case '&': (*write) ("&amp;", 1, 5, data); break;
            case '<':  (*write) ("&lt;", 1, 4, data);  break;
            case '>':   (*write) ("&gt;", 1, 4, data);  break;
            case '"':   (*write) ("&quot;", 1, 6, data);  break;
            default:
              if ((*mark & 0x00E0) == 0xC0) {
                  /* two bytes:   marker is 110x xxxx */
                  len = 2;
                  value = (mark[0] & 0x001F) * 64 + (mark[1] & 0x003F);
               } else if ((*mark & 0x00F0) == 0xE0) {
                  /* three bytes: marker is 1110 xxxx */
                  len = 3;
                  value = ((mark[0] & 0x000F) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F);
               } else if ((*mark & 0x00F8) == 0xF0) {
                  /* four bytes:  marker is 1111 0xxx */
                  len = 4;
                  value = (((mark[0] & 0x0007) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F)) * 64 + (mark[3] & 0x003F);
               } else if ((*mark & 0x00FC) == 0xF8) {
                  /* five bytes:  marker is 1111 10xx */
                  len = 5;
                  value = ((((mark[0] & 0x0003) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F)) * 64 + (mark[3] & 0x003F)) * 64 + (mark[4] & 0x003F);
               } else if ((*mark & 0x00FE) == 0xFC) {
                  /* six bytes:   marker is 1111 110x */
                  len = 6;
                  value = (((((mark[0] & 0x0001) * 64 + (mark[1] & 0x003F)) * 64 + (mark[2] & 0x003F)) * 64 + (mark[3] & 0x003F)) * 64 + (mark[4] & 0x003F)) * 64 + (mark[5] & 0x003F);
               } else {
                  value = 0x20; /* Illegal value, but instead of freaking out we'll do something quasi-normal. */
               }
               sprintf (numbuf, "&#%ld;", value);
               (*write) (numbuf, 1, strlen(numbuf), data);
         }
         str = mark + len;
      }
   } while (mark);
   len = strlen (str);
   if (len) (*write) (str, 1, len, data);
}
void _xml_fwrite (void * data, XMLAPI_DATAWRITE write, char * str) {
   int len;
   len = strlen (str);
   if (len) (*write) (str, 1, len, data);
}
XMLAPI void xml_write (FILE * file, XML * xml) { xml_write_general ((void *) file, (XMLAPI_DATAWRITE) fwrite, xml); }
XMLAPI void xml_write_general (void * data, XMLAPI_DATAWRITE write, XML * xml) {
   ATTR * attr;
   ELEMENTLIST * list;

   if (!xml) return;
   if (xml->name == NULL) {
      if (xml->attrs) if (xml->attrs->value) _xml_fwrite_escaped (data, write, xml->attrs->value);
      return;
   }
   _xml_fwrite (data, write, "<");
   _xml_fwrite (data, write, xml->name);
   attr = xml->attrs;
   while (attr != NULL) {
      _xml_fwrite (data, write, " ");
      _xml_fwrite (data, write, attr->name);
      _xml_fwrite (data, write, "=\"");
      _xml_fwrite_escaped (data, write, attr->value);
      _xml_fwrite (data, write, "\"");
      attr = attr->next;
   }
   if (xml->children == NULL) {
      _xml_fwrite (data, write, "/>");
      return;
   } else _xml_fwrite (data, write, ">");
   xml_writecontent_general (data, write, xml);
   _xml_fwrite (data, write, "</");
   _xml_fwrite (data, write, xml->name);
   _xml_fwrite (data, write, ">");
}
XMLAPI void xml_writecontent (FILE * file, XML * xml) { xml_writecontent_general ((void *) file, (XMLAPI_DATAWRITE) fwrite, xml); }
XMLAPI void xml_writecontent_general (void * data, XMLAPI_DATAWRITE write, XML * xml)
{
   ELEMENTLIST * list;

   if (!xml) return;
   list = xml->children;
   while (list) {
      xml_write_general (data, write, list->element);
      list = list->next;
   }
}
XMLAPI void xml_writehtml (FILE * file, XML * xml) { xml_writehtml_general ((void *) file, (XMLAPI_DATAWRITE) fwrite, xml); }
XMLAPI void xml_writehtml_general (void * data, XMLAPI_DATAWRITE write, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (!xml) return;
   if (xml->name == NULL) {
      if (xml->attrs) if (xml->attrs->value) _xml_fwrite (data, write, xml->attrs->value);
      return;
   }

   if (xml_is (xml, "nbsp")) {
      _xml_fwrite (data, write, "&nbsp;");
      return;
   }

   _xml_fwrite (data, write, "<");
   _xml_fwrite (data, write, xml->name);
   attr = xml->attrs;
   while (attr != NULL) {
      _xml_fwrite (data, write, " ");
      _xml_fwrite (data, write, attr->name);
      _xml_fwrite (data, write, "=\"");
      _xml_fwrite_escaped (data, write, attr->value);
      _xml_fwrite (data, write, "\"");
      attr = attr->next;
   }
   _xml_fwrite (data, write, ">");
   if (xml->children == NULL) {
      if (!strcmp (xml->name, "p") ||
          !strcmp (xml->name, "a") ||
          !strcmp (xml->name, "textarea")) {
         _xml_fwrite (data, write, "</");
         _xml_fwrite (data, write, xml->name);
         _xml_fwrite (data, write, ">");
      }
      return;
   }

   xml_writecontenthtml_general (data, write, xml);
   if (!strcmp (xml->name, "li") ||
       !strcmp (xml->name, "opt")) {
   } else {
      _xml_fwrite (data, write, "</");
      _xml_fwrite (data, write, xml->name);
      _xml_fwrite (data, write, ">");
   }
}
XMLAPI void xml_writecontenthtml (FILE * file, XML * xml) { xml_writecontenthtml_general ((void *) file, (XMLAPI_DATAWRITE) fwrite, xml); }
XMLAPI void xml_writecontenthtml_general (void * data, XMLAPI_DATAWRITE write, XML * xml)
{
   ELEMENTLIST * list;

   if (!xml) return;
   list = xml->children;
   while (list) {
      xml_writehtml_general (data, write, list->element);
      list = list->next;
   }
}
XMLAPI int xml_output (char * f, XML * xml, int mode)
{
   FILE * file;

   file = fopen (f, "w");
   if (!file) return 0;

   switch (mode) {
      case 1: xml_writecontent (file, xml); break;
      case 2: xml_writehtml (file, xml); break;
      case 3: xml_writecontenthtml (file, xml); break;
      default: xml_write (file, xml); break;
   }

   fclose (file);
   return 1;
}
XMLAPI XML * xml_load (const char * spec, ...)
{
   va_list args;
   char * filename;
   FILE * file;
   XML * ret;

   va_start (args, spec);
   filename = xml_string_formatv (spec, args);
   va_end (args);

   file = fopen (filename, "r");
   free (filename);
   if (!file) {
      return NULL;
   }

   ret = xml_read_error (file);
   fclose (file);

   return ret;
}
XMLAPI int xml_save (XML * xml, const char * spec, ...)
{
   va_list args;
   char * filename;
   FILE * file;
   XML * ret;

   va_start (args, spec);
   filename = xml_string_formatv (spec, args);
   va_end (args);

   file = fopen (filename, "w");
   free (filename);
   if (!file) {
      return 1;
   }

   xml_write (file, xml);
   fprintf (file, "\n");

   fclose (file);
   return 0;
}
XMLAPI void xml_free (XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (xml == NULL) return;

   if (xml->cleanup && xml->extra) {
      (*(xml->cleanup)) (xml->extra);
   }

   if (xml->name != NULL) FREE ((void *) (xml->name));
   while (xml->attrs) {
      attr = xml->attrs;
      xml->attrs = xml->attrs->next;
      if (attr->name != NULL) FREE ((void *) (attr->name));
      if (attr->value != NULL) FREE ((void *) (attr->value));
      xml->attrs = attr->next;
      FREE ((void *) attr);
   }

   while (xml->children) {
      list = xml->children;
      xml->children = list->next;
      if (list->element != NULL) xml_free (list->element);
      FREE ((void *) list);
   }
   FREE ((void *) xml);
}
XMLAPI void xml_delete(XML * piece)
{
   ELEMENTLIST * list;
   if (!piece) return;
   if (piece->parent != NULL) {
      list = piece->parent->children;
      while (list != NULL && list->element != piece) list = list->next;
      if (list != NULL) {
         if (list->next != NULL) list->next->prev = list->prev;
         if (list->prev != NULL) list->prev->next = list->next;
      }
      if (list == piece->parent->children) piece->parent->children = list->next;
      if (list == piece->parent->lastchild) piece->parent->lastchild = list->prev;
      if (list != NULL) FREE ((void *) list);
   }
   xml_free (piece);
}
XMLAPI void xml_delete_pretty(XML * piece)
{
   XML * prev = xml_prev (piece);
   XML * next = xml_next (piece);

   if (!strcmp (xml_textval (next), "\n")) xml_delete (next);
   xml_delete (piece);
   if (!xml_prev (prev) && !strcmp (xml_textval (prev), "\n")) xml_delete (prev);
}
XMLAPI XML * xml_first(XML * xml)
{
   if (xml == NULL) return NULL;
   if (xml->children == NULL) return NULL;
   return (xml->children->element);
}
XMLAPI XML * xml_firstelem(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return NULL;
   list = xml->children;
   while (list != NULL) {
      if (list->element->name != NULL) break;
      list = list->next;
   }
   if (list != NULL) return (list->element);
   return NULL;
}

XMLAPI XML * xml_last(XML *xml)
{
   if (xml == NULL) return NULL;
   if (xml->lastchild == NULL) return NULL;
   return (xml->lastchild->element);
}
XMLAPI XML * xml_lastelem(XML *xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return NULL;
   list = xml->lastchild;
   while (list != NULL) {
      if (list->element->name != NULL) break;
      list = list->prev;
   }
   if (list != NULL) return (list->element);
   return NULL;
}
XMLAPI XML * xml_next(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   if (list->next == NULL) return (NULL);
   return (list->next->element);
}
XMLAPI XML * xml_nextelem(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   while (list->next != NULL) {
      if (list->next->element->name != NULL) break;
      list = list->next;
   }
   if (list->next == NULL) return (NULL);
   return (list->next->element);
}
XMLAPI XML * xml_prev(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   if (list->prev == NULL) return (NULL);
   return (list->prev->element);
}
XMLAPI XML * xml_prevelem(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   while (list->prev != NULL) {
      if (list->prev->element->name != NULL) break;
      list = list->prev;
   }
   if (list->prev == NULL) return (NULL);
   return (list->prev->element);
}
XMLAPI XML * xml_loc (XML * start, const char * loc)
{
   char * mark;
   const char * attrval;
   char piece[64];
   int i;
   int count;

   if (!loc) return (start);
   if (!*loc) return (start);

   if (*loc == '.') return (xml_loc (xml_first (start), loc + 1));

   while (start && start->name == NULL) start = xml_next (start);
   if (!start) return (NULL);

   while (*loc == ' ') loc++;
   i = 0;
   while (*loc && *loc != '.') piece[i++] = *loc++;
   piece[i] = '\0';
   if (*loc) loc++;
   while (*loc == ' ') loc++;

   mark = strchr (piece, ']');
   if (mark) *mark = '\0';
   mark = strchr (piece, '(');
   if (mark) {
      *mark++ = '\0';
      count = atoi (mark);
      mark = NULL;
   } else {
      count = 0;
      mark = strchr (piece, '[');
      if (mark) {
         *mark++ = '\0';
      }
   }

   while (start) {
      if (start->name == NULL) {
         start = xml_next (start);
         continue;
      }
      if (strcmp (start->name, piece)) {
         start = xml_next (start);
         continue;
      }
      if (count) {
         count --;
         start = xml_next (start);
         continue;
      }
      if (!mark) {
         if (*loc) return (xml_loc (xml_first (start), loc));
         return (start);
      }
      attrval = xml_attrval(start, "id");
      if (attrval) {
         if (strcmp (attrval, mark)) {
            start = xml_next (start);
            continue;
         }
         if (*loc) return (xml_loc (xml_first(start), loc));
         return (start);
      }
      attrval = xml_attrval(start, "name");
      if (attrval) {
         if (strcmp (attrval, mark)) {
            start = xml_next (start);
            continue;
         }
         if (*loc) return (xml_loc (xml_first(start), loc));
         return (start);
      }
   }
   return (NULL);
}

XMLAPI XML * xml_locf (XML *start, const char * loc, ...)
{
   va_list args;
   char * locator;
   XML * found;

   va_start (args, loc);
   locator = xml_string_formatv (loc, args);
   va_end (args);

   found = xml_loc (start, locator);
   FREE (locator);
   return (found);
}
XMLAPI void xml_getloc (XML * xml, char *loc, int len)
{
   int s;
   int count;
   XML * sib;
   if (xml->parent != NULL) {
      xml_getloc (xml->parent, loc, len);
   } else {
      *loc = '\0';
   }
   s = strlen (loc);
   if (s > 0 && s < len-1) { strcat (loc, "."); s++; }
   len -= s;
   loc += s;
   if (strlen(xml->name) < len) {
      strcpy (loc, xml->name);
   } else {
      strncpy (loc, xml->name, len-1);
      loc[len-1] = '\0';
   }
   if (xml->parent == NULL) return;
   sib = xml_first(xml->parent);
   count = 0;
   while (sib != xml && sib != NULL) {
      if (sib->name != NULL) {
         if (!strcmp (sib->name, xml->name)) count ++;
      }
      sib = xml_next(sib);
   }
   if (count > 0 && s > 4) {
      strcat (loc, "(");
      sprintf (loc + strlen(loc), "%d", count);
      strcat (loc, ")");
   }
}
char * _xml_getlocbuf_buf (XML * xml, char *buffer, int *cursize, int *curptr)
{
   int s;
   int count;
   XML * sib;
   char countbuf[sizeof(int) * 3 + 1];

   if (xml->parent != NULL) {
      _xml_getlocbuf_buf (xml->parent, buffer, cursize, curptr);
      buffer = _xml_string_tackon (buffer, cursize, curptr, ".", 0);
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name, 0);

   if (xml->parent == NULL) return (buffer);

   sib = xml_first(xml->parent);
   count = 0;
   while (sib != xml && sib != NULL) {
      if (sib->name != NULL) {
         if (!strcmp (sib->name, xml->name)) count ++;
      }
      sib = xml_next(sib);
   }
   if (count > 0) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "(", 0);
      sprintf (countbuf, "%d", count);
      buffer = _xml_string_tackon (buffer, cursize, curptr, countbuf, 0);
      buffer = _xml_string_tackon (buffer, cursize, curptr, ")", 0);
   }

   return (buffer);
}

XMLAPI char * xml_getlocbuf (XML * xml)
{
   char * buf = (char *) MALLOC (256);
   int  cursize = 256;
   int  curptr = 0;

   *buf = '\0';
   return (_xml_getlocbuf_buf (xml, buf, &cursize, &curptr));
}
#ifndef PYTHON
void startElement(void *userData, const char *name, const char **atts)
{
   XML ** parent;
   XML * element;

   element = xml_create (name);
   while (*atts) {
      xml_set(element, atts[0], atts[1]);
      atts += 2;
   }

   parent = (XML **) userData;
   if (*parent != NULL) xml_append (*parent, element);
   *parent = element;
}
void endElement(void *userData, const char *name)
{
   XML ** element;

   element = (XML **) userData;
   if ((*element)->parent != NULL) *element = (*element)->parent;
}
void charData (void *userData, const XML_Char *s, int len) {
   XML ** parent;

   parent = (XML **) userData;
   xml_append (*parent, xml_createtextlen ((char *) s, len));
}

XMLAPI XML * xml_read (FILE * file)
{
   XML_Parser parser;
   char buf[BUFSIZ];
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   do {
      len = fread(buf, 1, sizeof(buf), file);
      done = len < sizeof(buf);
      if (!XML_Parse(parser, buf, len, done)) {
         xml_free (ret);
         XML_ParserFree(parser);
         return NULL;
      }
   } while (!done);
   XML_ParserFree(parser);

   return (ret);
}
XMLAPI XML * xml_read_error (FILE * file)
{
   XML_Parser parser;
   char buf[BUFSIZ];
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   do {
      len = fread(buf, 1, sizeof(buf), file);
      done = len < sizeof(buf);
      if (!XML_Parse(parser, buf, len, done)) {
         xml_free (ret);
         ret = xml_create ("xml-error");
         xml_setnum (ret, "code", XML_GetErrorCode(parser));
         xml_set    (ret, "message", XML_ErrorString(XML_GetErrorCode(parser)));
         xml_setnum (ret, "line", XML_GetCurrentLineNumber(parser));
         done = 1;
      }
   } while (!done);
   XML_ParserFree(parser);

   return (ret);
}
XMLAPI XML * xml_parse (const char * buf)
{
   XML_Parser parser;
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   len = strlen (buf);
   if (!XML_Parse(parser, buf, len, done)) {
      xml_free (ret);
      ret = xml_create ("xml-error");
      xml_setnum (ret, "code", XML_GetErrorCode(parser));
      xml_set    (ret, "message", XML_ErrorString(XML_GetErrorCode(parser)));
      xml_setnum (ret, "line", XML_GetCurrentLineNumber(parser));
   }
   XML_ParserFree(parser);

   return (ret);
}
XMLAPI XML * xml_parse_general (void * data, XMLAPI_DATARETRIEVE get_buf)
{
   XML_Parser parser;
   char buf[BUFSIZ+1];
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   do {
      memset (buf, '\0', BUFSIZ+1);
      len = (*get_buf)(buf, 1, BUFSIZ, data);
      if (len > strlen (buf)) len = strlen (buf);
      if (len == 0) break;
      if (!XML_Parse(parser, buf, len, done)) {
         if (ret) xml_free (ret);
         ret = xml_create ("xml-error");
         xml_setnum (ret, "code", XML_GetErrorCode(parser));
         xml_set    (ret, "message", XML_ErrorString(XML_GetErrorCode(parser)));
         xml_setnum (ret, "line", XML_GetCurrentLineNumber(parser));
         done = 1;
      }
   } while (!done);
   XML_ParserFree(parser);

   if (!ret) {
      ret = xml_create ("xml-error");
      xml_setnum (ret, "code", 3);
      xml_set    (ret, "message", "no data received");
      xml_setnum (ret, "line", 0);
   }

   return (ret);
}
#endif
XMLAPI XML * xml_copy (XML * orig)
{
   XML * copy = NULL;
   XML * child;
   ATTR * attr;

   if (!orig) return copy;

   if (!orig->name) {
      if (!orig->attrs)             copy = xml_createtext ("");
      else if (!orig->attrs->value) copy = xml_createtext ("");
      else                          copy = xml_createtext (orig->attrs->value);
      return copy;
   }

   copy = xml_create (orig->name);
   attr = orig->attrs;
   while (attr) {
      xml_set (copy, attr->name, attr->value);
      attr = attr->next;
   }

   child = xml_first (orig);
   while (child) {
      xml_append (copy, xml_copy (child));
      child = xml_next (child);
   }

   return (copy);
}
XMLAPI XML * xml_copyinto (XML * target, XML * source)
{
   XML * child;
   ATTR * attr;

   if (!source) return target;
   if (!source->name) {
      if (target) {
         if (source->attrs) if (source->attrs->value) xml_append (target, xml_createtext (source->attrs->value));
         return (target);
      }
      if (source->attrs) if (source->attrs->value) target = xml_createtext (source->attrs->value);
      return (target);
   }

   if (!target) target = xml_create (source->name);

   attr = source->attrs;
   while (attr) {
      xml_set (target, attr->name, attr->value);
      attr = attr->next;
   }

   child = xml_first (source);
   while (child) {
      xml_append (target, xml_copy (child));
      child = xml_next (child);
   }

   return (target);
}
XMLAPI XML * xml_copyattrs (XML * target, XML * source)
{
   ATTR * attr;

   if (!source) return target;
   if (!source->name) {
      if (target) return (target);

      if (source->attrs) if (source->attrs->value) target = xml_createtext (source->attrs->value);
      return (target);
   }

   if (!target) target = xml_create (source->name);

   attr = source->attrs;
   while (attr) {
      xml_set (target, attr->name, attr->value);
      attr = attr->next;
   }

   return (target);
}
XMLAPI XML_ATTR * xml_attrfirst (XML * element)
{
   if (!element) return NULL;
   return element->attrs;
}
XMLAPI XML_ATTR * xml_attrnext (XML_ATTR * attr)
{
   if (!attr) return NULL;
   return attr->next;
}
const char *xml_attrname  (XML_ATTR * attr) { return (attr->name);  }
const char *xml_attrvalue (XML_ATTR * attr) { return (attr->value); }
XMLAPI int xml_is (XML * xml, const char * name)
{
   if (!xml) return 0;
   if (!xml->name) return 0;
   if (!strcmp (xml->name, name)) return 1;
   return 0;
}
XMLAPI int xml_is_element (XML * xml)
{
   if (!xml) return 0;
   if (!xml->name) return 0;
   return 1;
}
XMLAPI const char * xml_name (XML * xml)
{
   if (!xml) return 0;
   return xml->name;
}
XMLAPI XML * xml_parent (XML * xml)
{
   if (!xml) return 0;
   return xml->parent;  /* Null if none, guaranteed. */
}
XMLAPI void * xml_getbin (XML * xml)
{
   if (!xml) return 0;
   return xml->extra;
}
XMLAPI void xml_setbin (XML * xml, void * bin, void (*cleanup) (void *))
{
   if (!xml) return;
   xml->extra = bin;
   xml->cleanup = cleanup;
}
XMLAPI void xml_rename (XML * xml, const char * name)
{
   if (!xml) return;
   if (!name) return;
   free (xml->name);
   xml->name = strdup (name);
}
XMLAPI XML * xml_search (XML * start, const char * element, const char * attr, const char * value)
{
   int found = 0;
   XML * cur = start;
   XML * next = NULL;

   if (!xml_is_element (start)) return NULL;

   while (!found) {
      found = 1;
      if (element) {
         if (!xml_is (cur, element)) found = 0;
      }
      if (found && attr) {
         if (value) {
            if (strcmp (value, xml_attrval (cur, attr))) found = 0;
         }
         else if (!*xml_attrval (cur, attr)) found = 0;
      }

      if (found) return cur;

      next = xml_firstelem (cur); /* TODO: Make this an xml_nextdepthfirst. */
      while (!next) {
         if (!next) next = xml_nextelem (cur);
         if (!next) {
            /*if (cur == start || !cur) return NULL;*/
            cur = xml_parent (cur);
            if (cur == start || !cur) return NULL;
         }
      }

      cur = next;
   }
}
XMLAPI XML * xml_searchf (XML * start, const char * element, const char * attr, const char * format, ...);
XMLAPI XML * xml_search_next (XML * top, XML * start, const char * element, const char * attr, const char * value)
{
   int found = 0;
   XML * cur = start;
   XML * next;

   if (!xml_is_element (start)) return NULL;

   while (!found) {
      next = xml_firstelem (cur);
      while (!next) {
         if (!next) next = xml_nextelem (cur);
         if (!next) {
            if (cur == top || !cur) return NULL;
            cur = xml_parent (cur);
         }
      }

      cur = next;

      found = 1;
      if (element) {
         if (!xml_is (cur, element)) found = 0;
      }
      if (found && attr) {
         if (value) {
            if (strcmp (value, xml_attrval (cur, attr))) found = 0;
         }
         else if (!*xml_attrval (cur, attr)) found = 0;
      }

      if (found) return cur;
   }
}
XMLAPI XML * xml_searchf_next (XML * top, XML * start, const char * element, const char * attr, const char * format, ...);
XMLAPI XML * xml_search_all (XML * start, const char * element, const char * attr, const char * value)
{
   XML * result = xml_create ("s");
   XML * hit;
   int count = 0;
   XML * cur;

   cur = xml_search (start, element, attr, value);
   while (cur) {
      hit = xml_create ("loc");
      xml_set_nodup (hit, "loc", xml_getlocbuf (cur));
      xml_append (result, hit);
      count++;

      cur = xml_search_next (start, cur, element, attr, value);
   }

   xml_setnum (result, "count", count);
   return result;
}
XMLAPI XML * xml_searchf_all (XML * start, const char * element, const char * attr, const char * format, ...);
XMLAPI int xml_toutf8_attr (XML * xml, const char * attrname)
{
   ATTR * attr;
   char * buffer = (char *) MALLOC (256);
   int cursize = 256;
   int curptr = 0;
   char * mark;
   char * mark2;
   char valbuf[3] = "\0\0";
   int count = 0;

   if (!xml) return (0);
   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, attrname)) break;
      attr = attr->next;
   }
   if (!attr) return (0);
   if (!attr->value) return (0);
   if (!strlen (attr->value)) return (0);

   cursize = attr->valsize;
   curptr = 0;
   buffer = (char *) MALLOC (cursize);
   *buffer = '\0';

   mark = attr->value;
   do {
      mark2 = mark; while (*mark2 && (unsigned int) *mark2 < 128) mark2++;
      if (*mark2) {
         count++;
         buffer = _xml_string_tackonn (buffer, &cursize, &curptr, mark, mark2 - mark);
         valbuf[0] = 0xC0 + (*(unsigned char *) mark2) / 64;
         valbuf[1] = 0x80 + (unsigned int) (*mark2 & 0x3F);
         buffer = _xml_string_tackonn (buffer, &cursize, &curptr, valbuf, 2);
         mark = mark2 + 1;
      } else {
         buffer = _xml_string_tackon (buffer, &cursize, &curptr, mark, 0);
      }
   } while (*mark2);

   FREE (attr->value);
   attr->value = buffer;
   attr->valsize = cursize;

   return (count);
}
XMLAPI int xml_toutf8_text (XML * xml)
{
   ATTR * attr;
   char * buffer = (char *) MALLOC (256);
   int cursize = 256;
   int curptr = 0;
   char * mark;
   char * mark2;
   char valbuf[3] = "\0\0";
   int count = 0;

   if (!xml) return (0);
   attr = xml->attrs;
   if (!attr) return (0);
   if (!attr->value) return (0);
   if (!strlen (attr->value)) return (0);

   cursize = attr->valsize;
   curptr = 0;
   buffer = (char *) MALLOC (cursize);
   *buffer = '\0';

   mark = attr->value;
   do {
      mark2 = mark; while (*mark2 && (*mark2 & 0x007F == *mark2)) mark2++;
      if (*mark2) {
         count++;
         buffer = _xml_string_tackonn (buffer, &cursize, &curptr, mark, mark2 - mark);
         valbuf[0] = 0xC0 + (*(unsigned char *) mark2) / 64;
         valbuf[1] = 0x80 + (unsigned int) (*mark2 & 0x3F);
         buffer = _xml_string_tackonn (buffer, &cursize, &curptr, valbuf, 2);
         mark = mark2 + 1;
      } else {
         buffer = _xml_string_tackon (buffer, &cursize, &curptr, mark, 0);
      }
   } while (*mark2);

   FREE (attr->value);
   attr->value = buffer;
   attr->valsize = cursize;

   return (count);
}
XMLAPI int xml_toraw_str (char * buffer, const char * utf8)
{
   int count = 0;
   if (!buffer) return 0;
   if (!utf8) { *buffer = '\0'; return 0; }

   while (*utf8) {
      *buffer = *utf8;

      if ((unsigned int) *buffer > 128) {
         utf8++;
         *buffer = (*(unsigned char *)buffer & 0x1F) * 64 + (*(unsigned char *)utf8 & 0x3F) * 64;
         if (*utf8) utf8++;
      } else utf8++; /* Don't want to double-increment past the end of the string if the encoding's screwed up! */
      buffer++;
   }
   *buffer = '\0';
   return (count);
}
struct _xml_sort_hdl {
  XML * sort;
  XML * elem;
};
int _xml_sort_comparison (const void * a, const void * b);
XMLAPI XML * xml_sort (XML * list, XML * sort)
{
   int i;
   XML * child;
   struct _xml_sort_hdl * array;
   ELEMENTLIST * elist;

   /* Count the children. */
   i=0; child = xml_firstelem (list);
   while (child) {
      i++;
      child = xml_nextelem (child);
   }
   if (i < 2) return list;

   /* Build the array. */
   array = (struct _xml_sort_hdl *) malloc (i * sizeof (struct _xml_sort_hdl));
   i=0; child = xml_firstelem (list);
   while (child) {
      array[i].sort = sort;
      array[i].elem = child;
      i++;
      child = xml_nextelem (child);
   }

   /* Sort the array. */
   qsort (array, i, sizeof (struct _xml_sort_hdl), _xml_sort_comparison);

   /* Rearrange the children, being very slick about it. */
   i = 0; elist = list->children;
   while (elist) {
      if (elist->element->name) {
         elist->element = array[i].elem;
         i++;
      }
      elist = elist->next;
   }

   free ((void *) array);

   return list;
}
int _xml_sort_comparison (const void * a, const void * b)
{
   XML * sort;
   int res;
   int ia, ib;
   struct _xml_sort_hdl * _a = (struct _xml_sort_hdl *) a;
   struct _xml_sort_hdl * _b = (struct _xml_sort_hdl *) b;

   if (a == b) return 0;

   sort = _a->sort;
   while (sort) {
      if (!strcmp (xml_attrval (sort, "op"), "num")) {
         ia = xml_attrvalnum (_a->elem, xml_attrval (sort, "field"));
         ib = xml_attrvalnum (_b->elem, xml_attrval (sort, "field"));
         if (ia < ib) res = -1;
         if (ia > ib) res = 1;
      } else {
         res = strcmp (xml_attrval (_a->elem, xml_attrval (sort, "field")), xml_attrval (_b->elem, xml_attrval (sort, "field")));
      }

      if (!strcmp (xml_attrval (sort, "dir"), "desc")) res = - res;
      if (res) return res;

      sort = xml_firstelem (sort);
   }
   return 0;
}
XMLAPI XML * xml_assemble (XML * start, XML * src)
{
   XML * copy;
   XML * hrefs;
   XML * href;
   const char * ref;
   XML * assembled;
   XML * repl;

   if (*xml_attrval (start, "href") == '#') {
      assembled = xml_assemble (xml_search (src, xml_name (start), "id", xml_attrval (start, "href") + 1), src);
      xml_unset (assembled, "id");
      xml_unset (assembled, "SOAP-ENC:root");
      return (assembled);
   }

   copy = xml_copy (start);
   hrefs = xml_search_all (copy, NULL, "href", NULL);
   href = xml_firstelem (hrefs);
   while (href) {
      repl = xml_loc (copy, xml_attrval (href, "loc"));
      ref = xml_attrval (repl, "href");
      if (*ref == '#') {
         assembled = xml_assemble (xml_search (src, NULL, "id", ref + 1), src);
         xml_rename (assembled, xml_name (repl));
         xml_unset (assembled, "id");
         xml_unset (assembled, "SOAP-ENC:root");
         xml_replace (repl, assembled);
      }
      href = xml_nextelem (href);
   }

   xml_free (hrefs);
   return copy;
}
