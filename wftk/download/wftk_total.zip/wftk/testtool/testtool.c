#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xmlapi.h>

XML * tests;

void print_xml_error (const char * filename, XML * error);
void compile_action_plan (XML * defn);
void run_action_plan (const char * filename);

int main(int argc, char *argv[])
{
   char * filename;
   FILE * in;
   XML * mark;

filename = "define.tst";
in = fopen (filename, "r");
if (!in) {
   printf ("No '%s' found in current directory.\n", filename);
   exit (1);
}

printf ("Reading define.tst\n");
tests = xml_read_error(in);
fclose (in);

if (xml_is (tests, "xml-error")) {
   print_xml_error (filename, tests);
   exit (1);
}
   compile_action_plan (tests);
   run_action_plan (xml_attrval (tests, "filename"));

   return (0);  
}

void compile_action_plan (XML * defn) {
XML * test;
XML * action;
XML * p;
FILE * out;
int subtests = 0;
int assertions = 0;

action = xml_create ("action");
test = xml_firstelem (defn);
if (!*xml_attrval (defn, "name")) xml_setf (defn, "name", "test%s", xml_attrval (defn, "number"));

while (test) {
   if (xml_is (test, "test")) { /* Subtest */
      subtests++;
      p = xml_create ("run");
      if (*xml_attrval (defn, "number")) {
         xml_setf (test, "number", "%s.%d", xml_attrval (defn, "number"), subtests);
      } else {
         xml_setf (test, "number", "%d", subtests);
      }
      if (!*xml_attrval (test, "name")) xml_setf (test, "name", "test%s", xml_attrval (test, "number"));
      xml_set (p, "name", xml_attrval (test, "name"));
      xml_setf (p, "filename", "%s.act", xml_attrval (test, "name")); /* TODO: filename mask here %s.act */
      xml_append_pretty (action, p);
      compile_action_plan (test);
   } else if (xml_is (test, "setup")) { /* Setup */
      xml_append_pretty (action, xml_copy (test));
   } else if (xml_is (test, "do")) { /* Action */
      xml_append_pretty (action, xml_copy (test));
   } else if (xml_is (test, "assert")) { /* Assertion */
      assertions++;
      p = xml_copy (test);
      if (*xml_attrval (defn, "number")) {
         xml_setf (p, "number", "%s-%d", xml_attrval (defn, "number"), assertions);
      } else {
         xml_setf (p, "number", "%d", assertions);
      }
      xml_append_pretty (action, p);
   }

   test = xml_nextelem (test); /* TODO: an xml_nextelemdepthfirst would be more appropriate. */
}

xml_setf (defn,   "filename", "%s.act", xml_attrval (defn, "name")); /* TODO: filename mask here %s.act */
xml_setf (defn,   "result",   "%s.rsl", xml_attrval (defn, "name")); /* TODO: filename mask here %s.rsl */
xml_setf (action, "result",   "%s.rsl", xml_attrval (defn, "name")); /* TODO: ditto */
printf ("writing action plan %s\n", xml_attrval (defn, "filename"));
out = fopen (xml_attrval (defn, "filename"), "w");
if (out) {
   xml_write (out, action);
   fprintf (out, "\n");
   fclose (out);
}
xml_free (action);
}
void run_action_plan (const char * filename) {
FILE * file;
XML * plan;
XML * action;
XML * result;

file = fopen (filename, "r");
if (file) {
   plan = xml_read (file);
   if (plan) {
      fclose (file);
      result = xml_create ("record");
      printf ("Running action plan %s\n", xml_attrval (plan, "name"));
      action = xml_firstelem (plan);
      while (action) {
         if (xml_is (action, "run")) {
            run_action_plan (xml_attrval (action, "filename"));
         } else if (xml_is (action, "setup")) {
            printf ("Performing setup action\n");
         } else if (xml_is (action, "do")) {
            printf ("Performing code action\n");
         } else if (xml_is (action, "assert")) {
            printf ("Performing assertion %s\n", xml_attrval (action, "number"));
         }
         action = xml_nextelem (action);
      }
      file = fopen (xml_attrval (plan, "result"), "w");
      if (file) {
         xml_write (file, result);
         fprintf (file, "\n\n");
         fclose (file);
      } else {
         printf ("Unable to write to result file %s\n", xml_attrval (plan, "result"));
      }
      xml_free (plan);
   } else {
      fclose (file);
   }
}
}
void print_xml_error (const char * filename, XML * error)
{
   printf ("XML error %d: %s at line %d of '%s'.\n", xml_attrvalnum (error, "code"),
                                                     xml_attrval (error, "message"),
                                                     xml_attrvalnum (error, "line"),
                                                     filename);
}
