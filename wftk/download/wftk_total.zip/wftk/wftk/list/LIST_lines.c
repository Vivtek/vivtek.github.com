#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef WINDOWS
#include <io.h>
#else
#include <dirent.h>
#endif
#include <errno.h>
#include <malloc.h>
#include "../wftk.h"
#include "../wftk_internals.h"
static char *names[] = 
{
   "init",
   "free",
   "info",
   "create",
   "destroy",
   "add",
   "update",
   "delete",
   "get",
   "query",
   "first",
   "next",
   "rewind",
   "prev",
   "last",
   "attach_open",
   "attach_write",
   "attach_close",
   "attach_cancel",
   "retrieve_open",
   "retrieve_read",
   "retrieve_close"
};

XML * LIST_lines_init (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_free (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_info (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_create (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_destroy (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_add (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_update (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_delete (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_get (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_query (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_first (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_next (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_rewind (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_prev (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_last (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_attach_open (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_attach_write (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_attach_close (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_attach_cancel (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_retrieve_open (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_retrieve_read (WFTK_ADAPTOR * ad, va_list args);
XML * LIST_lines_retrieve_close (WFTK_ADAPTOR * ad, va_list args);

static WFTK_API_FUNC vtab[] = 
{
   LIST_lines_init,
   LIST_lines_free,
   LIST_lines_info,
   LIST_lines_create,
   LIST_lines_destroy,
   LIST_lines_add,
   LIST_lines_update,
   LIST_lines_delete,
   LIST_lines_get,
   LIST_lines_query,
   LIST_lines_first,
   LIST_lines_next,
   LIST_lines_rewind,
   LIST_lines_prev,
   LIST_lines_last,
   LIST_lines_attach_open,
   LIST_lines_attach_write,
   LIST_lines_attach_close,
   LIST_lines_attach_cancel,
   LIST_lines_retrieve_open,
   LIST_lines_retrieve_read,
   LIST_lines_retrieve_close
};

static struct wftk_adaptor_info _LIST_lines_info =
{
   22,
   names,
   vtab
};
struct wftk_adaptor_info * LIST_lines_get_info ()
{
   return & _LIST_lines_info;
}
XML * LIST_lines_init (WFTK_ADAPTOR * ad, va_list args)
{
   const char * parms;
   char * mark;

   parms = xml_attrval (ad->parms, "parm");
   if (!*parms) {
      xml_set (ad->parms, "subdir", "");
      return NULL;
   }

   /* TODO: get current directory as basedir. */

   mark = strchr (parms, ';');
   if (!mark) {
      xml_set (ad->parms, "subdir", parms);
      return NULL;
   }
   xml_set (ad->parms, "subdir", "");
   xml_attrncat (ad->parms, "subdir", parms, mark - parms);
   parms = mark + 1;
   mark = strchr (parms, ';');
   if (mark) {
      xml_set (ad->parms, "suffix", "");
      xml_attrncat (ad->parms, "suffix", parms, mark - parms);
      xml_set (ad->parms, "prefix", mark + 1);
   } else {
      xml_set (ad->parms, "suffix", parms);
   }
   if (mark = strchr (xml_attrval (ad->parms, "suffix"), ',')) {
      xml_set (ad->parms, "multsuffix", "yes");
      xml_set (ad->parms, "defsuffix", "");
      xml_attrncat (ad->parms, "defsuffix", xml_attrval (ad->parms, "suffix"), mark - xml_attrval (ad->parms, "suffix"));
   } else {
      if (*xml_attrval (ad->parms, "multsuffix")) xml_set (ad->parms, "multsuffix", "");
      xml_set (ad->parms, "defsuffix", xml_attrval (ad->parms, "suffix"));
   }

   return (XML *) 0;
}
XML * LIST_lines_free (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * LIST_lines_info (WFTK_ADAPTOR * ad, va_list args) {
   XML * info;

   info = xml_create ("info");
   xml_set (info, "type", "list");
   xml_set (info, "name", "lines");
   xml_set (info, "ver", "1.0.0");
   xml_set (info, "compiled", __TIME__ " " __DATE__);
   xml_set (info, "author", "Michael Roberts");
   xml_set (info, "contact", "wftk@vivtek.com");
   xml_set (info, "extra_functions", "0");

   return (info);
}
XML * _LIST_lines_read_obj (FILE * file, XML * list, XML * obj)
{
   XML * ret = obj ? obj : xml_create ("record");
   XML * mark;
   char * ptr;
   char * ptr2;
   char line[2048];

   mark = xml_firstelem (list);
   while (mark) {
      if (xml_is (mark, "field")) {
         if (!strcmp (xml_attrval (mark, "type"), "text")) {
            while (fgets (line, sizeof(line), file)) {
               if (!strcmp (line, "@@\n")) break;
               xml_attrcat (ret, "temp", line);
            }
            xmlobj_set (ret, list, xml_attrval (mark, "id"), xml_attrval (ret, "temp"));
            xml_unset (ret, "temp");
         } else {
            *line = '\0';
            fgets (line, sizeof(line), file);
            ptr = line;
            if (line[strlen(line)-1] == '\n') line[strlen(line)-1] = '\0';
            while (*ptr) {
               if (*ptr == '\\') {
                  if (ptr[1] == 'n') {
                     *ptr = '\n';
                     ptr2 = ptr+1;
                     while (*ptr2) {
                        ptr2[0] = ptr2[1];
                        ptr2++;
                     }
                  } else if (ptr[1] == '\\') {
                     *ptr = '\\';
                     ptr2 = ptr+1;
                     while (*ptr2) {
                        ptr2[0] = ptr2[1];
                        ptr2++;
                     }
                  }
               }
               ptr++;
            }
            xmlobj_set (ret, list, xml_attrval (mark, "id"), line);
         }
      }
      mark = xml_nextelem (mark);
   }

   return (ret);
}
XML * LIST_lines_get (WFTK_ADAPTOR * ad, va_list args) {
   XML * scratch = xml_create ("scratch");
   XML * ret = NULL;
   XML * list = NULL;
   char * key;
   FILE * file;
   char * mark;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }
   key = va_arg (args, char *);

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));

   xml_set (scratch, "dir", xml_attrval (ad->parms, "basedir"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (scratch, "dir", "/");
   }
   if (*xml_attrval (ad->parms, "prefix")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "prefix"));
   }
   xml_attrcat (scratch, "dir", key);
   xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "defsuffix"));

   file = fopen (xml_attrval (scratch, "dir"), "r");
   if (!file) {
      xml_setf (ad->parms, "error", "Unable to open list item file %s", xml_attrval (scratch, "dir"));
   } else {
      ret = _LIST_lines_read_obj (file, list, NULL);
      fclose (file);
   }

   if (ret) xml_set (ret, "key", key);

   xml_free (scratch);
   return ret;
}
void _LIST_lines_scan (WFTK_ADAPTOR * ad, XML * list) {
#ifdef WINDOWS
   long hFile;
   struct _finddata_t c_file;
#else
   DIR * dir;
   struct dirent * entry;
#endif
   char * cp;
   char * mark;
   const char * prefix;
   int  count = 0;
   XML * scratch = xml_create ("s");
   XML * record;

   xml_set (list, "count", "0");
   xml_replacecontent (list, NULL); /* Delete any existing contents. */

   xml_set (scratch, "dir", xml_attrval (ad->parms, "basedir"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (scratch, "dir", "/");
   }

   prefix = xml_attrval (ad->parms, "prefix");
   xml_setf (scratch, "spec", "%s%s*%s", xml_attrval (scratch, "dir"), prefix, xml_attrval (ad->parms, "defsuffix")); /* TODO: multiple suffixes */
#ifdef WINDOWS
   hFile = _findfirst (xml_attrval (scratch, "spec"), &c_file);
   if (hFile < 0L) {
#else
   if (!*xml_attrval (scratch, "dir")) xml_set (scratch, "dir", ".");
   dir = opendir (xml_attrval (scratch, "dir"));
   if (!dir) {
#endif
      xml_free (scratch);
      return;
   }

#ifndef WINDOWS
   entry = readdir (dir);
   if (!entry) {
      xml_free (scratch);
      return;
   }
#endif

   do {
#ifndef WINDOWS
      if (strlen (entry->d_name) < strlen (xml_attrval (ad->parms, "defsuffix"))) continue;
      if (*entry->d_name == '.') continue; /* Eliminates directory stubs in Unix, also eliminates null-key records. */
      if (*prefix) if (strncmp (prefix, entry->d_name, strlen (prefix))) continue;
      mark = entry->d_name + strlen (entry->d_name) - strlen (xml_attrval (ad->parms, "defsuffix"));
      if (strcmp (mark, xml_attrval (ad->parms, "defsuffix"))) continue; /* TODO: multiple suffixes. */
#endif

      count++;
      record = xml_create ("record");
#ifdef WINDOWS
      cp = strdup (c_file.name);
#else
      cp = strdup (entry->d_name);
#endif
      if (!*xml_attrval (ad->parms, "multsuffix")) {
         mark = strchr (cp, '.');
         if (mark) *mark = '\0';
      }
      xml_setf (record, "id", "%s", cp + strlen (xml_attrval (ad->parms, "prefix")));
      free (cp);
      xml_append (list, record);

#ifdef WINDOWS
   } while (-1 != _findnext (hFile, &c_file));
#else
   } while (entry = readdir (dir));
#endif

   xml_setnum (list, "count", count);
   xml_free (scratch);

#ifdef WINDOWS
   _findclose (hFile);
#else
   closedir (dir);
#endif
}
XML * LIST_lines_query (WFTK_ADAPTOR * ad, va_list args)
{
   XML * defn;
   XML * list;
   XML * scratch;
   XML * cur;
   XML * ret;
   XML * sort;
   XML * scan;
   FILE * file;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));

   defn = xml_copy (list);

   _LIST_lines_scan (ad, list);

   if (!*xml_attrval (list, "select") && !*xml_attrval (list, "order") && !*xml_attrval (list, "where")) return list;

   /* If requested, we load the files -- note that we're not going to get sophisticated and select fields yet or anything. */
   scratch = xml_create ("s");

   xml_set (scratch, "dir", xml_attrval (ad->parms, "basedir"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (scratch, "dir", "/");
   }

   cur = xml_firstelem (list);
   while (cur) {
      xml_setf (scratch, "file", "%s%s%s%s", xml_attrval (scratch, "dir"), xml_attrval (scratch, "prefix"), xml_attrval (cur, "id"), xml_attrval (ad->parms, "defsuffix")); /* TODO: multiple suffixes. */

      file = fopen (xml_attrval (scratch, "file"), "r");
      if (!file) {
         cur = xml_nextelem (cur);
         if (cur) {
            xml_delete (xml_prevelem (cur));
         } else {
            xml_delete (xml_lastelem (list));
         }
         continue;
      } else {
          _LIST_lines_read_obj (file, defn, cur);
         fclose (file);
      }

      if (*xml_attrval (list, "order")) {
         xml_set_nodup (cur, "_sort", strchr (xml_attrval (list, "order"), '[')
                                      ? xmlobj_format (cur, defn, xml_attrval (list, "order"))
                                      : xmlobj_get (cur, defn, xml_attrval (list, "order")));
      }

      cur = xml_nextelem (cur);
   }

   /* And now we sort the files as requested. */
   if (*xml_attrval (list, "order")) {
      sort = xml_create ("sort");
      xml_set (sort, "field", "_sort");
      xml_set (sort, "op", xml_attrval (list, "op"));
      xml_sort (list, sort);
      xml_free (sort);
   }

   xml_free (scratch);
   xml_free (defn);
   return list;
}
XML * LIST_lines_first (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;
   XML * ret;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));

   _LIST_lines_scan (ad, list);
   xml_set (list, "cur", "");

   ret = xml_firstelem (list);
   if (ret) xml_set_nodup (list, "cur", xml_getlocbuf (ret));
   else     xml_set (list, "cur", "EOF");
   return (ret);
}
XML * LIST_lines_next (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;
   XML * cur;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }

   if (*xml_attrval (list, "cur")) {
      if (!strcmp (xml_attrval (list, "cur"), "EOF")) return NULL;

      cur = xml_loc (list, xml_attrval (list, "cur"));
      if (cur) cur = xml_nextelem (cur);
      if (cur) xml_set_nodup (list, "cur", xml_getlocbuf (cur));
      else     xml_set (list, "cur", "EOF");
      return (cur);
   }

   cur = xml_firstelem (list);
   if (cur) xml_set_nodup (list, "cur", xml_getlocbuf (cur));
   else     xml_set (list, "cur", "EOF");
   return (cur);
}
XML * LIST_lines_rewind (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }
   xml_set (list, "cur", "");
}
XML * LIST_lines_prev (WFTK_ADAPTOR * ad, va_list args)
{
   XML * list;
   XML * cur;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }

   if (!*xml_attrval (list, "cur")) return NULL;

   if (!strcmp (xml_attrval (list, "cur"), "EOF")) {
      cur = xml_lastelem (list);
      if (cur) xml_set_nodup (list, "cur", xml_getlocbuf (cur));
      else     xml_set (list, "cur", "");
      return (cur);
   }

   cur = xml_loc (list, xml_attrval (list, "cur"));
   if (cur) cur = xml_prevelem (cur);
   if (cur) xml_set_nodup (list, "cur", xml_getlocbuf (cur));
   else     xml_set (list, "cur", "");
   return (cur);
}
XML * LIST_lines_last (WFTK_ADAPTOR * ad, va_list args)
{
   XML * list;
   XML * ret;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }

   xml_set (list, "cur", "EOF");

   ret = xml_lastelem (list);
   if (ret) xml_set_nodup (list, "cur", xml_getlocbuf (ret));
   else     xml_set (list, "cur", "");
   return (ret);
}
XML * LIST_lines_create (WFTK_ADAPTOR * ad, va_list args) { return 0; }
XML * LIST_lines_destroy (WFTK_ADAPTOR * ad, va_list args) { return 0; }
void _LIST_lines_write_obj (FILE * file, XML * obj, XML * list)
{
   XML * mark;
   char * value;
   char * ptr;
   int terminate;

   mark = xml_firstelem (list);
   terminate = 0;
   while (mark) {
      if (xml_is (mark, "field")) {
         if (terminate) {
            fprintf (file, "@@\n");
         }
         terminate = 0;
         value = xmlobj_get (obj, list, xml_attrval (mark, "id"));
         if (!value) {
            fputc ('\n', file);
         } else if (!strcmp (xml_attrval (mark, "type"), "text")) {
            fprintf (file, "%s\n", value);
            terminate = 1;
         } else {
            ptr = value;
            while (*ptr) {
               if (*ptr == '\n') {
                  fputc ('\\', file);
                  fputc ('n', file);
               } else if (*ptr == '\\') {
                  fputc ('\\', file);
                  fputc ('\\', file);
               } else {
                  fputc (*ptr, file);
               }
               ptr++;
            }
            fputc ('\n', file);
         }
         if (value) free (value);
      }
      mark = xml_nextelem (mark);
   }
}
XML * LIST_lines_add (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;
   XML * obj;
   const char * key;
   int cleanup = 0;
   XML * mark;
   XML * ret;
   XML * scratch;
   FILE * file;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }
   obj = va_arg (args, XML *);
   if (!obj) {
      xml_set (ad->parms, "error", "No object given.");
      return (XML *) 0;
   }

   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));

   key = xml_attrval (obj, "key");
   if (!*key) {
      key = xml_attrval (list, "key");
      if (*key) {
         key = xml_attrval (obj, key);
      } else {
         mark = xml_search (obj, "field", NULL, NULL);
         if (!mark) {
            xml_set (ad->parms, "error", "No key can be determined.");
            return (XML *) 0;
         }
         key = xml_attrval (mark, "value");
         if (!*key) {
            key = xml_stringcontent (mark);
            if (!*key) {
               free ((void *)key);
               xml_set (ad->parms, "error", "No key can be determined.");
               return (XML *) 0;
            }
            cleanup = 1;
         }
      }
   }

   scratch = xml_create ("s");
   xml_set (scratch, "dir", xml_attrval (ad->parms, "basedir"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (scratch, "dir", "/");
   }
   xml_setf (scratch, "file", "%s%s%s%s", xml_attrval (scratch, "dir"), xml_attrval (ad->parms, "prefix"), key, xml_attrval (ad->parms, "defsuffix")); /* TODO: multiple suffixes? */
   if (cleanup) free ((void *)key);

   file = fopen (xml_attrval (scratch, "file"), "w");
   if (!file) {
      xml_setf (ad->parms, "error", "Object file %s cannot be opened for writing.", xml_attrval (scratch, "file"));
   } else {
      _LIST_lines_write_obj (file, obj, list);
      fclose (file);
   }

   xml_free (scratch);
   return NULL;
}
XML * LIST_lines_update (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;
   XML * obj;
   const char * oldkey;
   const char * key;
   int cleanup = 0;
   XML * mark;
   XML * ret;
   XML * scratch;
   FILE * file;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }
   obj = va_arg (args, XML *);
   if (!obj) {
      xml_set (ad->parms, "error", "No object given.");
      return (XML *) 0;
   }

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));

   oldkey = xml_attrval (obj, "key");

   key = xml_attrval (list, "key");
   if (key) {
      mark = xml_search (obj, "field", "id", key);
      if (mark) {
         key = xml_attrval (mark, "value");
         if (!*key) {
            key = xml_stringcontent (mark);
            if (!*key) {
               free ((void *) key);
               key = "";
            } else {
               cleanup = 1;
            }
         }
      }
   }

   if (!*key) key = oldkey;

   if (!*key) {
      mark = xml_search (obj, "field", NULL, NULL);
      if (!mark) {
         xml_set (ad->parms, "error", "No key can be determined.");
         return (XML *) 0;
      } else {
         key = xml_attrval (mark, "value");
         if (!*key) {
            key = xml_stringcontent (mark);
            if (!*key) {
               free ((void *)key);
               xml_set (ad->parms, "error", "No key can be determined.");
               return (XML *) 0;
            }
            cleanup = 1;
         }
      }
   }

   scratch = xml_create ("s");
   xml_set (scratch, "dir", xml_attrval (ad->parms, "basedir"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (scratch, "dir", "/");
   }
   xml_setf (scratch, "file", "%s%s%s%s", xml_attrval (scratch, "dir"), xml_attrval (ad->parms, "prefix"), key, xml_attrval (ad->parms, "defsuffix")); /* TODO: multiple suffixes? */

   file = fopen (xml_attrval (scratch, "file"), "w");
   if (!file) {
      xml_setf (ad->parms, "error", "Object file %s cannot be opened for writing.", xml_attrval (scratch, "file"));
   } else {
      _LIST_lines_write_obj (file, obj, list);
      fclose (file);
      if (*oldkey && strcmp (oldkey, key)) {
         xml_setf (scratch, "delfile", "%s%s%s%s", xml_attrval (scratch, "dir"), xml_attrval (ad->parms, "prefix"), oldkey, xml_attrval (ad->parms, "defsuffix")); /* TODO: multiple suffixes? */
         unlink (xml_attrval (scratch, "delfile"));
      }
   }

   if (cleanup) free ((void *)key);

   xml_free (scratch);
   return NULL;
}
XML * LIST_lines_delete (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;
   XML * obj;
   char * key;
   int cleanup = 0;
   XML * mark;
   XML * ret;
   XML * scratch;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }
   key = va_arg (args, char *);
   if (!key) {
      xml_set (ad->parms, "error", "No object given.");
      return (XML *) 0;
   }

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));

   scratch = xml_create ("s");
   xml_set (scratch, "dir", xml_attrval (ad->parms, "basedir"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (scratch, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (scratch, "dir", "/");
   }
   xml_setf (scratch, "file", "%s%s%s%s", xml_attrval (scratch, "dir"), xml_attrval (ad->parms, "prefix"), key, xml_attrval (ad->parms, "defsuffix")); /* TODO: multiple suffixes? */
   if (cleanup) free (key);

   unlink (xml_attrval (scratch, "file"));

   xml_free (scratch);
   return NULL;
}
XML * LIST_lines_attach_open (WFTK_ADAPTOR * ad, va_list args) {
   XML * list;
   char * key;
   char * field;
   char * filename;
   char * ver;
   struct stat statbuf;
   XML * mark;
   XML * ret;
   FILE * file;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list descriptor given.");
      return (XML *) 0;
   }
   key = va_arg (args, char *);
   field = va_arg (args, char *);
   filename = va_arg (args, char *);
   ver = va_arg (args, char *);
   if (!ver) ver = "0";

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));

   /* If we're not given a fieldname, then we'll just scan the list definition to find the first "document"-type field. */
   if (!field) {
      mark = xml_search (list, "field", "type", "document");
      if (!mark) {
         xml_set (ad->parms, "error", "No attachment field given and no default exists.");
         return NULL;
      }
      field = (char *) xml_attrval (mark, "id");
   }

   ret = xml_create ("attachment-handle");

   xml_set (ret, "dir", xml_attrval (ad->parms, "basedir"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (ret, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (ret, "dir", "/");
   }
   xml_setf (ret, "adaptor", "lines:%s", xml_attrval (ret, "dir"));

   /* If we're supplied with a filename, then that file can't already exist in our controlled
      directory. */
   if (filename && *filename) {
      xml_setf (ret, "location", filename);
      xml_setf (ret, "file", "%s%s", xml_attrval (ret, "dir"), filename);
      xml_set (ret, "tempfile", xml_attrval (ret, "file"));
      if (stat (xml_attrval (ret, "file"), &statbuf) != -1) { /* File exists already. */
         xml_setf (ad->parms, "error", "File %s is already present.", filename);
         xml_free (ret);
         return NULL;
      }
   } else {
      xml_setf (ret, "location", "_att_%s_%s_%s.dat", key, field, ver);
      xml_setf (ret, "file", "%s%s", xml_attrval (ret, "dir"), xml_attrval (ret, "location"));
      xml_setf (ret, "tempfile", "%s_newatt_%s_%s_%s.dat", xml_attrval (ret, "dir"), key, field, ver);
   }

   file = fopen (xml_attrval (ret, "file"), "w");
   if (!file) {
      xml_setf (ad->parms, "error", "Unable to open file %s for writing.", xml_attrval (ret, "file"));
      xml_free (ret);
      return NULL;
   }

   xml_setbin (ret, file, (XML_SETBIN_FREE_FN *)fclose);
   xml_set (ret, "content-type", "text/plain");

   return (ret);
}
XML * LIST_lines_attach_write (WFTK_ADAPTOR * ad, va_list args) {
   void * buffer;
   int size, number;
   XML * handle;

   if (!args) {
      xml_set (ad->parms, "error", "No arguments given.");
      return NULL;
   }
   buffer = va_arg (args, void *);
   size = va_arg (args, int);
   number = va_arg (args, int);
   handle = va_arg (args, XML *);

   xml_setnum (handle, "last-write", fwrite (buffer, size, number, xml_getbin(handle)));
   return NULL;
}
XML * LIST_lines_attach_cancel (WFTK_ADAPTOR * ad, va_list args) {
   XML * handle;

   if (!args) {
      xml_set (ad->parms, "error", "No arguments given.");
      return NULL;
   }
   handle = va_arg (args, XML *);

   fclose (xml_getbin (handle));
   unlink (xml_attrval (handle, "tempfile"));
   return NULL;
}
XML * LIST_lines_attach_close (WFTK_ADAPTOR * ad, va_list args) {
   XML * handle;

   if (!args) {
      xml_set (ad->parms, "error", "No arguments given.");
      return NULL;
   }
   handle = va_arg (args, XML *);

   fclose (xml_getbin (handle));
   rename (xml_attrval (handle, "tempfile"), xml_attrval (handle, "file"));
   return NULL;
}
XML * LIST_lines_retrieve_open (WFTK_ADAPTOR * ad, va_list args) {
   XML * list = NULL;
   XML * fld;
   char * key;
   char * field;
   char * ver;
   XML * mark;
   XML * ret;
   FILE * file;
   WFTK_ADAPTOR * ad2;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list given.");
      return (XML *) 0;
   }
   key = va_arg (args, char *);
   fld = va_arg (args, XML *);

   xml_setf (ad->parms, "spec", "lines:%s", xml_attrval (list, "id"));

   ret = xml_create ("attachment-handle");

   xml_set (ret, "dir", xml_attrval (ad->parms, "basedir"));
   if (!*xml_attrval (ad->parms, "subdir")) xml_set (ad->parms, "subdir", xml_attrval (list, "id"));
   if (strcmp (xml_attrval (ad->parms, "subdir"), ".")) {
      xml_attrcat (ret, "dir", xml_attrval (ad->parms, "subdir"));
      xml_attrcat (ret, "dir", "/");
   }
   xml_setf (ret, "adaptor", "lines:%s", xml_attrval (ret, "dir"));

   if (fld) {
      xml_set (ret, "location", xml_attrval (fld, "location"));
   }
   if (!*xml_attrval (ret, "location")) xml_setf (ret, "location", "_att_%s_%s_%s.dat", key, xml_attrval (fld, "id"), xml_attrval (fld, "ver"));
   xml_setf (ret, "file", "%s%s", xml_attrval (ret, "dir"), xml_attrval (ret, "location"));

   file = fopen (xml_attrval (ret, "file"), "r");
   if (!file) {
      xml_setf (ad->parms, "error", "Unable to open file %s for reading.", xml_attrval (ret, "location"));
      xml_free (ret);
      return NULL;
   }

   xml_setbin (ret, file, (XML_SETBIN_FREE_FN *) fclose);
   xml_set (ret, "content-type", "text/plain");

   return (ret);
}
XML * LIST_lines_retrieve_read (WFTK_ADAPTOR * ad, va_list args) {
   void * buffer;
   int size, number;
   XML * handle;

   if (!args) {
      xml_set (ad->parms, "error", "No arguments given.");
      return NULL;
   }
   buffer = va_arg (args, void *);
   size = va_arg (args, int);
   number = va_arg (args, int);
   handle = va_arg (args, XML *);

   xml_setnum (handle, "last-read", fread (buffer, size, number, xml_getbin(handle)));
   return NULL;
}
XML * LIST_lines_retrieve_close (WFTK_ADAPTOR * ad, va_list args) {
   XML * handle;

   if (!args) {
      xml_set (ad->parms, "error", "No arguments given.");
      return NULL;
   }
   handle = va_arg (args, XML *);

   fclose (xml_getbin (handle));
   return NULL;
}
