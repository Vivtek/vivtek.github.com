#include <stdio.h>
#include <stdarg.h>
#include "repmgr.h"
static char *names[] = 
{
   "init",
   "free",
   "info",
   "new",
   "load",
   "save",
   "delete",
   "archive"
};

XML * DSREP_list_init (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_free (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_info (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_new (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_load (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_save (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_delete (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_list_archive (WFTK_ADAPTOR * ad, va_list args);

static WFTK_API_FUNC vtab[] = 
{
   DSREP_list_init,
   DSREP_list_free,
   DSREP_list_info,
   DSREP_list_new,
   DSREP_list_load,
   DSREP_list_save,
   DSREP_list_delete,
   DSREP_list_archive
};

static struct wftk_adaptor_info _DSREP_list_info =
{
   8,
   names,
   vtab
};
struct wftk_adaptor_info * DSREP_list_get_info ()
{
   return & _DSREP_list_info;
}
XML * DSREP_list_init (WFTK_ADAPTOR * ad, va_list args) {
   const char * parms;
   XML * mark;

   parms = xml_attrval (ad->parms, "parm");
   if (!*parms) parms = "";

   if (*parms) {
      mark = repos_defn (ad->session, parms);
      if (!mark) xml_setf (ad->parms, "error", "List '%s' is not defined in the repository.", parms);
      xml_setf (ad->parms, "spec", "list:%s", parms);
      xml_set (ad->parms, "list", parms);
      return NULL;
   }

   mark = xml_search (ad->session, "list", "dsrep-default", "yes");
   if (!mark) mark = xml_search (ad->session, "list", NULL, NULL);
   if (!mark) {
      xml_setf (ad->parms, "error", "No lists defined in repository.");
   } else {
      xml_set (ad->parms, "list", xml_attrval (mark, "id"));
      xml_setf (ad->parms, "spec", "list:%s", xml_attrval (mark, "id"));
   }

   return (XML *) 0;
}
XML * DSREP_list_free (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * DSREP_list_info (WFTK_ADAPTOR * ad, va_list args) {
   XML * info;

   info = xml_create ("info");
   xml_set (info, "type", "dsrep");
   xml_set (info, "name", "list");
   xml_set (info, "ver", "1.0.0");
   xml_set (info, "compiled", __DATE__ " " __TIME__);
   xml_set (info, "author", "Michael Roberts");
   xml_set (info, "contact", "wftk@vivtek.com");
   xml_set (info, "extra_functions", "0");

   return (info);
}
XML * DSREP_list_new  (WFTK_ADAPTOR * ad, va_list args)
{
   char * id = (char *) 0;
   XML * ret = xml_create ("record");

   if (args) id = va_arg (args, char *);
   if (id) xml_set (ret, "id", id);

   repos_add (ad->session, xml_attrval (ad->parms, "list"), ret);

   return ret;
}
XML * DSREP_list_load (WFTK_ADAPTOR * ad, va_list args) {
   char *id = (char *) 0;

   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No ID given.");
      return (XML *) 0;
   }

   return (repos_get (ad->session, xml_attrval (ad->parms, "list"), id));
}
XML * DSREP_list_save (WFTK_ADAPTOR * ad, va_list args) {
   XML * ds = NULL;

   if (args) ds = va_arg (args, XML *);
   if (!ds) {
      xml_set (ad->parms, "error", "No datasheet given.");
      return (XML *) 0;
   }

   repos_mod (ad->session, xml_attrval (ad->parms, "list"), ds, NULL);

   return ds;
}
XML * DSREP_list_delete (WFTK_ADAPTOR * ad, va_list args) {
   char * id = (char *) 0;

   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No ID given.");
      return (XML *) 0;
   }

   repos_del (ad->session, xml_attrval (ad->parms, "list"), id);
   return (XML *) 0;
}
XML * DSREP_list_archive (WFTK_ADAPTOR * ad, va_list args) { return (XML *) NULL; }
