#include <stdio.h>
#include <stdarg.h>
#include "repmgr.h"
static char *names[] = 
{
   "init",
   "free",
   "info",
   "version",
   "load"
};

XML * PDREP_list_init (WFTK_ADAPTOR * ad, va_list args);
XML * PDREP_list_free (WFTK_ADAPTOR * ad, va_list args);
XML * PDREP_list_info (WFTK_ADAPTOR * ad, va_list args);
XML * PDREP_list_version (WFTK_ADAPTOR * ad, va_list args);
XML * PDREP_list_load (WFTK_ADAPTOR * ad, va_list args);

static WFTK_API_FUNC vtab[] = 
{
   PDREP_list_init,
   PDREP_list_free,
   PDREP_list_info,
   PDREP_list_version,
   PDREP_list_load
};

static struct wftk_adaptor_info _PDREP_list_info =
{
   5,
   names,
   vtab
};
struct wftk_adaptor_info * PDREP_list_get_info ()
{
   return & _PDREP_list_info;
}
XML * PDREP_list_init (WFTK_ADAPTOR * ad, va_list args) {
   const char * parms;
   XML * mark;

   parms = xml_attrval (ad->parms, "parm");
   if (!*parms) parms = "";

   if (*parms) {
      mark = repos_defn (ad->session, parms);
      if (!mark) xml_setf (ad->parms, "error", "List '%s' is not defined in the repository.", parms);
      xml_set (ad->parms, "list", parms);
      xml_setf (ad->parms, "spec", "list:%s", parms);
      return NULL;
   }

   mark = xml_search (ad->session, "list", "pdrep-default", "yes");
   if (mark) {
      xml_set (ad->parms, "list", xml_attrval (mark, "id"));
      xml_setf (ad->parms, "spec", "list:%s", xml_attrval (mark, "id"));
   } else {
      xml_set (ad->parms, "list", "_procdefs");
      xml_set (ad->parms, "spec", "list:_procdefs");
   }

   return (XML *) 0;
}
XML * PDREP_list_free (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * PDREP_list_info (WFTK_ADAPTOR * ad, va_list args) {
   XML * info;

   info = xml_create ("info");
   xml_set (info, "type", "pdrep");
   xml_set (info, "name", "list");
   xml_set (info, "ver", "1.0.0");
   xml_set (info, "compiled", __TIME__ " " __DATE__);
   xml_set (info, "author", "Michael Roberts");
   xml_set (info, "contact", "wftk@vivtek.com");
   xml_set (info, "extra_functions", "0");

   return (info);
}
XML * PDREP_list_version  (WFTK_ADAPTOR * ad, va_list args)
{
   char * id = (char *) 0;
   XML * value;

   xml_set (ad->parms, "error", "");
   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No ID given.");
      return (XML *) 0;
   }

   repos_attach_getver (ad->session, xml_attrval (ad->parms, "list"), id, NULL);

   value = xml_create ("value");
   xml_set (value, "value", xml_attrval (ad->session, "result"));

   return value;
}
XML * PDREP_list_load (WFTK_ADAPTOR * ad, va_list args) {
   char *id = (char *) 0;
   char *ver = (char *) 0;
   XML * ret;

   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No ID given.");
      return (XML *) 0;
   }
   ver = va_arg (args, char *);
   if (!ver) {
      xml_set (ad->parms, "error", "No version given.");
      return (XML *) 0;
   }

   ret = repos_retrieve_load (ad->session, xml_attrval(ad->parms, "list"), id, NULL, ver);

   return ret;
}
