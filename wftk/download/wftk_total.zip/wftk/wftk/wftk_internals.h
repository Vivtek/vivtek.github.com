
#ifndef WFTK_EXPORT
#define WFTK_EXPORT
#endif

#ifdef DEBUG
#define DBG(x,y) config_debug_message (x, y);
#define DBG1(x,y,z) config_debug_message (x, y, z);
#define DBG2(x,y,z,now) config_debug_message (x, y, z, now);
#else
#define DBG(x,y) ;
#define DBG1(x,y,z) ;
#define DBG2(x,y,z,now) ;
#endif
XML * _procdef_load (XML * session, XML * datasheet);
char * _wftk_value_special (XML * session, XML * datasheet, const char * name);
