#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "../wftk.h"
#include "../wftk_session.h"
#include "../wftk_internals.h"
static char *names[] = 
{
   "init",
   "free",
   "info",
   "get",
   "set",
   "store",
   "isnull",
   "makenull",
   "choices"
};

XML * DATASTORE_role_init     (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_free     (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_info     (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_get      (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_set      (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_store    (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_isnull   (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_makenull (WFTK_ADAPTOR * ad, va_list args);
XML * DATASTORE_role_choices  (WFTK_ADAPTOR * ad, va_list args);

static WFTK_API_FUNC vtab[] = 
{
   DATASTORE_role_init,
   DATASTORE_role_free,
   DATASTORE_role_info,
   DATASTORE_role_get,
   DATASTORE_role_set,
   DATASTORE_role_store,
   DATASTORE_role_isnull,
   DATASTORE_role_makenull,
   DATASTORE_role_choices
};

static struct wftk_adaptor_info _DATASTORE_role_info =
{
   9,
   names,
   vtab
};
struct wftk_adaptor_info * DATASTORE_role_get_info ()
{
   return & _DATASTORE_role_info;
}
XML * DATASTORE_role_init (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * DATASTORE_role_free (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * DATASTORE_role_info (WFTK_ADAPTOR * ad, va_list args) {
   XML * info;

   info = xml_create ("info");
   xml_set (info, "type", "datastore");
   xml_set (info, "name", "role");
   xml_set (info, "ver", "2.0");
   xml_set (info, "compiled", __TIME__ " " __DATE__);
   xml_set (info, "author", "Michael Roberts");
   xml_set (info, "contact", "wftk@vivtek.com");
   xml_set (info, "extra_functions", "0");

   return (info);
}
XML * DATASTORE_role_get  (WFTK_ADAPTOR * ad, va_list args)
{
   XML * datasheet = (XML *) 0;
   char * name;
   char * colon;

   if (args) datasheet = va_arg (args, XML *);
   if (!datasheet) {
      xml_set (ad->parms, "error", "No datasheet supplied.");
      return (XML *) 0;
   }
   name = va_arg (args, char *);
   if (!name) {
      xml_set (ad->parms, "error", "No role named.");
      return (XML *) 0;
   }

   colon = strchr (name, ':');
   return (wftk_session_stashvalue (ad->session, wftk_role_user (ad->session, datasheet, colon ? colon + 1 : name)));
}
XML * DATASTORE_role_set  (WFTK_ADAPTOR * ad, va_list args)
{
   XML * datasheet = (XML *) 0;
   char * name;
   char * value;
   char * colon;

   if (args) datasheet = va_arg (args, XML *);
   if (!datasheet) {
      xml_set (ad->parms, "error", "No datasheet supplied.");
      return (XML *) 0;
   }
   name = va_arg (args, char *);
   if (!name) {
      xml_set (ad->parms, "error", "No role named.");
      return (XML *) 0;
   }
   value = va_arg (args, char *);

   colon = strchr (name, ':');
   wftk_role_assign (ad->session, datasheet, colon ? colon + 1 : name, value);
   return (XML *) 0;
}
XML * DATASTORE_role_store (WFTK_ADAPTOR * ad, va_list args)
{
   XML * data = (XML *) 0;
   char * name;
   char * value;
   char * colon;

   if (args) data = va_arg (args, XML *);
   if (!data) {
      xml_set (ad->parms, "error", "No data given.");
      return (XML *) 0;
   }
   if (!xml_parent (data)) {
      xml_set (ad->parms, "error", "Data not in datasheet.");
      return (XML *) 0;
   }

   wftk_role_assign (ad->session, xml_parent(data), xml_attrval (data, "id"), xml_attrval (data, "value"));

   return (XML *) 0;
}
XML * DATASTORE_role_isnull   (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * DATASTORE_role_makenull (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * DATASTORE_role_choices (WFTK_ADAPTOR * ad, va_list args)
{
   XML * list = NULL;
   XML * obj = NULL;
   const char * field;
   const char * colon;
   WFTK_ADAPTOR * u_ad;
   XML * choices;
   XML * mark;
   XML * option;
   XML * users;
   XML * user;

   if (args) field = va_arg (args, const char *);
   if (!field) {
      xml_set (ad->parms, "error", "No field given.");
      return (XML *) 0;
   }
   obj = va_arg (args, XML *);
   list = va_arg (args, XML *);

   u_ad = wftk_get_adaptor (ad->session, USER, "list"); /* TODO: wow -- we need some way of specifying the default user adaptor for the repository... */
   if (!u_ad) return (NULL);
   colon = strchr (field, ':');
   users =  wftk_call_adaptor (u_ad, "roleusers", colon ? colon + 1 : field);

   choices = xml_create ("select");
   mark = xml_firstelem (users);
   while (mark) {
      if (xml_is (mark, "user")) {
         option = xml_create ("option");
         xml_set (option, "value", xml_attrval (mark, "id"));
         user = wftk_call_adaptor (u_ad, "get", xml_attrval (mark, "id"));
         xml_append (option, xml_createtext (*xml_attrval (user, "name") ? xml_attrval (user, "name") : xml_attrval (mark, "id")));
         xml_free (user);
         xml_append_pretty (choices, option);
      }
      mark = xml_nextelem (mark);
   }

   wftk_free_adaptor (ad->session, u_ad);

   xml_free (users);
   return (choices);
}
