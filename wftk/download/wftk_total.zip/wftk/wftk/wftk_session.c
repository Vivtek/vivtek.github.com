#include <stdarg.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "wftk_session.h"
#include "time.h"
#include "stdarg.h"
#include "wftk_internals.h"
#include "xmlapi.h"
#include "xmlobj.h"
/*#include "localdefs.h" -- don't know whether I want this or not at this point. */
#ifdef WINDOWS
#include <windows.h>  /* For DLL machinery for adaptor loading. */
#endif

#ifdef WFTK_WITH_REPMGR
#include "../repmgr/repmgr.h"
#endif

static void wftk_session_free (WFTK_SESSION * sess);
WFTK_EXPORT XML * wftk_session_alloc ()
{
   WFTK_SESSION * sess;
   XML * ret = xml_create ("wftk-session");

   sess = (WFTK_SESSION *) malloc (sizeof (struct wftk_session));
   memset ((void *) sess, '\0', sizeof (struct wftk_session));
   xml_setbin (ret, sess, (XML_SETBIN_FREE_FN *)wftk_session_free);

   return ret;
}
static void wftk_session_free (WFTK_SESSION * sess)
{
   WFTK_ADAPTOR_LIST * list;
   WFTK_CACHE_LIST * cachelist;
   if (!sess) return;

   while (sess->ads) {
      wftk_free_adaptor (NULL, sess->ads->ad);
      list = sess->ads->next;
      free (sess->ads);
      sess->ads = list;
   }

   while (sess->cache) {
      xml_free (sess->cache->cached);
      cachelist = sess->cache->next;
      free(sess->cache);
      sess->cache = cachelist;
   }

   if (sess->user)      xml_free (sess->user);
   if (sess->context)   xml_free (sess->context);
   if (sess->config)    xml_free (sess->config);
   if (sess->datasheet) xml_free (sess->datasheet);
   if (sess->procdef)   xml_free (sess->procdef);
   if (sess->values)    xml_free (sess->values);
}
WFTK_EXPORT void * wftk_session_init (XML * session)
{
   WFTK_SESSION * sess;
   XML * mark;

   if (!session) return NULL;

   if (!xml_is (session, "wftk-session")) {
      mark = xml_search (session, "wftk-session", NULL, NULL);
      if (!mark) {
         mark = xml_create ("wftk-session");
         xml_prepend (session, xml_createtext ("\n"));
         xml_prepend (session, mark);
         xml_prepend (session, xml_createtext ("\n"));
      }
      session = mark;
   }

   sess = xml_getbin (session);
   if (!sess) {
      sess = (WFTK_SESSION *) malloc (sizeof (struct wftk_session));
      memset ((void *) sess, '\0', sizeof (struct wftk_session));
      xml_setbin (session, sess, (XML_SETBIN_FREE_FN *)wftk_session_free);
   }

   return sess;
}
WFTK_EXPORT void wftk_session_cleanup (XML * session)
{
   XML * mark;
   WFTK_SESSION * sess;

   if (xml_is (session, "wftk-session")) {
      sess = xml_getbin (session);
      if (sess) {
         wftk_session_free (sess);
         xml_setbin (session, NULL, NULL);
      }
   } else {
      mark = xml_search (session, "wftk-session", NULL, NULL);
      if (mark) xml_delete (mark);
   }
}
WFTK_EXPORT void wftk_session_configure (XML * session, XML * config)
{
   WFTK_SESSION * sess = wftk_session_init (session);
   sess->config = config;
}
WFTK_EXPORT void   wftk_session_setlookup  (XML * session, WFTK_MODULE_LOOKUP_FN fn)
{
   WFTK_SESSION * sess = wftk_session_init (session);
   sess->static_module_lookup = fn;
}
WFTK_EXPORT void wftk_session_current (XML * session, XML * object)
{
   WFTK_SESSION * sess = wftk_session_init (session);

   if (!sess) return;
   if (!object) return;

   if (xml_is (object, "datasheet")) {
      sess->datasheet = object;
      return;
   }
   if (xml_is (object, "procdef")) {
      sess->procdef = object;
      return;
   }
}
WFTK_EXPORT XML * wftk_session_cache (XML * session, XML * key, int * flag)
{
   WFTK_SESSION * sess = wftk_session_init (session);
   WFTK_CACHE_LIST * list;
   XML_ATTR * attr;

   if (flag) *flag = 0;

   if (!session) return key;
   if (!key) return key;

   return key; /* TODO: figure out whether this is worth saving, and how not to do it wrong. */

   list = sess->cache;
   while (list) {
      if (xml_is (key, xml_name (list->cached))) {
         attr = xml_attrfirst (key);
         while (attr) {
            if (strcmp (xml_attrvalue (attr), xml_attrval (list->cached, xml_attrname(attr)))) break;
            attr = xml_attrnext (attr);
         }
         if (!attr) break;
      }
      list = list->next;
   }

   if (list) {
      if (flag) *flag = 1;
      xml_free (key);
      return list->cached;
   }

   list = sess->cache;
   sess->cache = (WFTK_CACHE_LIST *) malloc (sizeof (WFTK_CACHE_LIST));
   sess->cache->cached = key;
   sess->cache->next = list;

   return key;
}

WFTK_EXPORT XML * wftk_session_cachecheck (XML * session, XML * key)
{
   WFTK_SESSION * sess = wftk_session_init (session);
   WFTK_CACHE_LIST * list;
   XML_ATTR * attr;

   if (!session) return NULL;
   if (!key) return NULL;

   list = sess->cache;
   while (list) {
      if (xml_is (key, xml_name(list->cached))) {
         attr = xml_attrfirst (key);
         while (attr) {
            if (strcmp (xml_attrvalue (attr), xml_attrval (list->cached, xml_attrname(attr)))) break;
            attr = xml_attrnext (attr);
         }
         if (!attr) break;
      }
      list = list->next;
   }

   if (list) {
      return list->cached;  /* Found. */
   }

   return NULL; /* Not found. */
}
WFTK_EXPORT void wftk_session_setuser (XML * session, char * userid)
{
   WFTK_SESSION * sess = wftk_session_init (session);

   if (!session) return;
   if (sess->user) { xml_free (sess->user); }

   sess->user = xml_create ("user");
   xml_set (sess->user, "id", userid);
}
WFTK_EXPORT void wftk_session_storeuser (XML * session, XML * user)
{
   WFTK_SESSION * sess = wftk_session_init (session);

   if (!session) return;
   if (sess->user) { xml_free (sess->user); }

   sess->user = user;
}
WFTK_EXPORT XML * wftk_session_getuser (XML * session)
{
   WFTK_SESSION * sess = wftk_session_init (session);

   if (!session) return NULL;
   return (sess->user);
}
WFTK_EXPORT void wftk_session_setcontext (XML * session, XML * context)
{
   WFTK_SESSION * sess = wftk_session_init (session);

   if (!session) return;
   if (sess->context) { xml_free (sess->context); }

   sess->context = context;
}
WFTK_EXPORT XML * wftk_session_getcontext (XML * session)
{
   WFTK_SESSION * sess = wftk_session_init (session);

   if (!session) return NULL;
   return (sess->context);
}
WFTK_EXPORT XML * wftk_session_stashvalue (XML * session, const char * value)
{
   WFTK_SESSION * sess = wftk_session_init (session);
   XML * holder;

   if (!sess->values) sess->values = xml_create ("list");

   holder = xml_create ("value");
   xml_set (holder, "value", value);
   xml_append (sess->values, holder);

   return holder;
}

WFTK_EXPORT void wftk_session_freevalue (XML * session, const char * value)
{
   WFTK_SESSION * sess = wftk_session_init (session);
   XML_ATTR * attribute;
   XML * pointer = xml_firstelem (sess->values);

   while (pointer) {
      attribute = xml_attrfirst (pointer);
      while (attribute) {
         if (xml_attrvalue (attribute) == value) { /* Note test of pointer equality! */
            xml_delete (pointer);
            return;
         }
         attribute = xml_attrnext (attribute);
      }
      pointer = xml_nextelem (pointer);
   }
}
struct loaded_library {
   int adaptor_class;
   char adaptor[32]; /* Note the limit on adaptor name.  Since typical names are "localxml" or "oracle"
                        this limit should be quite sufficient. */
   char filename[256]; /* Here we'll build the path to the DLL. */
#ifdef WINDOWS
   HINSTANCE inst; /* This is how we'll do it under Win32.  Under Unix, I still have to learn how... */
#endif
   struct wftk_adaptor_info * ai;
   struct loaded_library * next;
};
struct loaded_library * loaded_libraries = NULL;
void wftk_config_cleanup ()
{
   struct loaded_library * ll;

   while (loaded_libraries) {
      ll = loaded_libraries;
      loaded_libraries = ll->next;
#ifdef WINDOWS
      FreeLibrary (ll->inst);
#endif
      free (ll);
   }
}
static void wftk_config_adaptor_log (XML * session, WFTK_ADAPTOR * ad, int level, const char * message)
{
#ifndef WFTK_WITH_REPMGR
   if (level < 3) {
      wftk_config_debug_message ('A', "[%d]%s (%d): %s", ad->num, xml_attrval (ad->parms, "spec"), level, message);
   }
#else
   repos_log (session, level, 0, NULL, "adaptor", "class %d %s: %s", ad->num, xml_attrval (ad->parms, "spec"), message);
#endif
}
static WFTK_ADAPTOR * wftk_config_get_adaptor (XML * session, int adaptor_class, const char * adaptor_descriptor, int name_length)
{
   char namebuf[64];
   struct loaded_library * library;
   WFTK_ADAPTOR_INFO_FN * func;
   struct wftk_adaptor_info * ai = NULL;
   char * dll_start = "";

   WFTK_ADAPTOR * ret;
   WFTK_SESSION * sess = wftk_session_init (session);

   if (sess->static_module_lookup) ai = (sess->static_module_lookup) (adaptor_class, name_length, adaptor_descriptor);

   if (!ai && name_length) { /* The adaptor isn't statically linked, anyway.  Let's try finding it dynamically, if it's named. */
      switch (adaptor_class) {
         case DSREP:
            dll_start = "DSREP_";
            break;
         case DATASTORE:
            dll_start = "DATASTORE_";
            break;
         case DATATYPE:
            dll_start = "DATATYPE_";
            break;
         case PDREP:
            dll_start = "PDREP_";
            break;
         case USER:
            dll_start = "USER_";
            break;
         case LIST:
            dll_start = "LIST_";
            break;
         case PERMS:
            dll_start = "PERMS_";
            break;
         case TASKINDEX:
            dll_start = "TASKINDEX_";
            if (!name_length) {  /* The default not being a static link, we have to check the config for an explicit name. */
               adaptor_descriptor = (char *) wftk_config_get_value (session, "taskindex.default");
               if (strchr (adaptor_descriptor, ':')) name_length = strchr (adaptor_descriptor, ':') - adaptor_descriptor;
               else                                  name_length = strlen (adaptor_descriptor);
            }
            break;
         case NOTIFY:
            dll_start = "NOTIFY_";
            if (!name_length) {
               adaptor_descriptor = (char *) wftk_config_get_value (session, "notify.default");
               if (strchr (adaptor_descriptor, ':')) name_length = strchr (adaptor_descriptor, ':') - adaptor_descriptor;
               else                                  name_length = strlen (adaptor_descriptor);
            }
            break;
         case ACTION:
            dll_start = "ACTION_";
            break;
         case DEBUG_MSG:
            dll_start = "DEBUG_MSG_";
            break;
         default:
            return (WFTK_ADAPTOR *) 0;
      }

      /* Is this DLL already loaded?  Check the loaded list. */
      library = loaded_libraries;
      strncpy (namebuf, adaptor_descriptor, name_length);
      while (library) {
         if (adaptor_class == library->adaptor_class && !strcmp (namebuf, library->adaptor)) {
            ai = library->ai;
            break;
         }
         library = library->next;
      }

#ifdef WINDOWS
      if (!ai) {
         /* Look for a properly named DLL.  When I figure out dynaloading under Unix this will expand. */
         library = (struct loaded_library *) malloc (sizeof (struct loaded_library));
         library->adaptor_class = adaptor_class;
         strcpy (library->adaptor, namebuf);
         strcpy (namebuf, dll_start);
         strncat (namebuf, adaptor_descriptor, name_length);
         strcat (namebuf, ".dll");
         library->inst = LoadLibrary (namebuf);
         if (!library->inst) {
#ifndef WFTK_WITH_REPMGR
            wftk_config_debug_message ('A', "Failed to load library %s (%d).\n", namebuf, GetLastError());
#else
            repos_log (session, 1, 0, NULL, "adaptor", "Failed to load library %s (%d).", namebuf, GetLastError());
#endif
            free (library);
            return NULL;
         }
         strcpy (namebuf, dll_start);
         strncat (namebuf, adaptor_descriptor, name_length);
         strcat (namebuf, "_get_info");
         func = (WFTK_ADAPTOR_INFO_FN *) GetProcAddress (library->inst, namebuf);
         if (!func) {
#ifndef WFTK_WITH_REPMGR
            wftk_config_debug_message ('A', "Adaptor doesn't export %s.\n", namebuf);
#else
            repos_log (session, 1, 0, NULL, "adaptor", "Adaptor doesn't export %s.", namebuf);
#endif
            free (library);
            return NULL;
         }
         ai = (*func) ();
      }
#endif
   }
   if (!ai) return (WFTK_ADAPTOR *) 0; /* No luck. */

   ret = (WFTK_ADAPTOR *) malloc (sizeof (struct wftk_adaptor) + ai->nfuncs * sizeof (void *));
   if (!ret) return (WFTK_ADAPTOR *) 0;

   ret->num     = adaptor_class;
   ret->parms   = (void *) 0;     /* This will be filled in by the caller. */
   ret->nfuncs  = ai->nfuncs;
   ret->names   = ai->names;
   ret->vtab    = ai->vtab;
   ret->session = session;
   ret->log     = (WFTK_ADAPTOR_LOG_FN) wftk_config_adaptor_log;
   return (ret);
}
static WFTK_ADAPTORLIST * wftk_config_get_adaptorlist (XML * session, int adaptor_class)
{
   const char * spec = "";
   int adaptors = 0;
   int i;
   const char * mark;
   char * mark2;
   char * adaptorbuffer;
   WFTK_ADAPTOR * ad_repmgr = NULL; /* Just to be sure. */
   WFTK_ADAPTORLIST * list;

   switch (adaptor_class) {
      case TASKINDEX:
         spec = wftk_config_get_value (session, "taskindex.always");
         ad_repmgr = wftk_get_adaptor (session, TASKINDEX, "list:");
         break;
      case NOTIFY:
         spec = wftk_config_get_value (session, "notify.always");
         break;
      default:
         return (WFTK_ADAPTORLIST *) 0;
   }

   if (!*spec && !ad_repmgr) return (WFTK_ADAPTORLIST *) 0;

   /* First pass: count semicolons, so we know how large a list structure to allocate. */
   mark = spec;
   adaptorbuffer = (char *) malloc (strlen (spec) + 1);
   do {
      mark = strchr (mark, ';');
      if (!mark) break;
      adaptors++; mark++;
   } while (mark);

   if (ad_repmgr) adaptors++;

   list = (WFTK_ADAPTORLIST *) malloc (sizeof (WFTK_ADAPTOR_LIST) + adaptors * sizeof (WFTK_ADAPTOR *));
   list->count = adaptors;

   if (ad_repmgr) list->ads[0] = ad_repmgr;

   for (i=ad_repmgr ? 1 : 0, mark = spec; i < adaptors; i++) {
      strcpy (adaptorbuffer, mark);
      mark = strchr(mark, ';');
      if (mark) { mark++; while (*mark == ' ') mark++; }
      mark2 = strchr (adaptorbuffer, ';');
      if (mark2) *mark2 = '\0';

      list->ads[i] = wftk_get_adaptor (session, adaptor_class, adaptorbuffer);
   }

   free ((void *) adaptorbuffer);
   return (list);
}
static XML * config_find_option (XML * xml, const char * name) {
   int len;
   XML * x;
   char * mark = strchr (name, '.');

   if (mark) len = mark - name;
   else      len = strlen (name);

   x = xml_firstelem (xml);
   while (x) {
      if (!strncmp (xml_attrval (x, "name"), name, len) ||
          !strncmp (xml_attrval (x, "id"), name, len)   ||
          !strncmp ("?", name, len)) {
         if (mark) {
            return (config_find_option (x, mark + 1));
         }
         return (x);
      }
      x = xml_nextelem (x);
   }
   return NULL;
}
static XML * config_get_option (XML * session, const char * valuename) {
   WFTK_SESSION * sess = wftk_session_init(session);
   if (sess) {
      if (sess->config) {
         return (config_find_option (sess->config, valuename));
      }
   }
   return NULL;
}
WFTK_EXPORT const char * wftk_config_get_value (XML * session, const char * valuename) {
   XML * mark = config_get_option (session, valuename);
   if (mark) return (xml_attrval (mark, "value"));

   /*if (!strcmp (valuename, "pdrep.localxml.directory")) return PROCDEF_DIRECTORY;
   if (!strcmp (valuename, "dsrep.localxml.directory")) return DATASHEET_DIRECTORY;
   if (!strcmp (valuename, "user.localxml.directory")) return USER_DIRECTORY;
   if (!strcmp (valuename, "group.localxml.directory")) return GROUP_DIRECTORY;
   if (!strcmp (valuename, "taskindex.odbc.?.conn")) return ODBC_CONNECTION;*/
   return "";
}
WFTK_EXPORT void wftk_config_debug_message (char type, const char * message, ...)
{
   va_list arglist;

   va_start (arglist, message);
   printf ("DEBUG %c:", type);
   vprintf (message, arglist);
   printf ("\n");
   va_end (arglist);
}
WFTK_EXPORT WFTK_ADAPTOR * wftk_get_adaptor (XML * session, int adaptor_class, const char * adaptor_descriptor)
{
   const char * mark;
   WFTK_ADAPTOR * ad;
   WFTK_ADAPTOR_LIST * list;
   XML * list_defn = NULL;
   const char * list_id = NULL;

   WFTK_SESSION * sess = wftk_session_init (session);

   #ifdef WFTK_WITH_REPMGR
   if (adaptor_class == LIST && !strchr (adaptor_descriptor, ':')) {
      list_defn = repos_defn (session, adaptor_descriptor);
      if (list_defn) {
         list_id = adaptor_descriptor;
         adaptor_descriptor = xml_attrval (list_defn, "storage");
         if (!*adaptor_descriptor) adaptor_descriptor = list_id;
      }
   }
   #endif

   /* Maybe we've already got this adaptor in our list? */
   if (session) {
      list = sess->ads;
      while (list) {
         if (list->ad->num == adaptor_class) {
            if (!adaptor_descriptor) return (list->ad);
            if (!strcmp (adaptor_descriptor, xml_attrval (list->ad->parms, "spec"))) return (list->ad);
         }
         list = list->next;
      }
   }

   /* Ask the config module for the initial setup.  If this is an unknown adaptor name, nothing's alloc'd and we return. */
   if (adaptor_descriptor) {
      for (mark = adaptor_descriptor; *mark && *mark != ':'; mark++);
      ad = wftk_config_get_adaptor (session, adaptor_class, adaptor_descriptor, mark - adaptor_descriptor);
   } else {

      ad = wftk_config_get_adaptor (session, adaptor_class, NULL, 0);
   }
   if (!ad) return ((WFTK_ADAPTOR *) 0);

   /* Get the parms structure started.  The adaptor initializer will take it from here. */
   ad->parms = xml_create ("parms");
   if (adaptor_descriptor) {
      if (*mark) mark++;
      xml_set (ad->parms, "parm", mark);
   }

   /* 2004-01-06: here's the cleverness. */
   if (list_id) xml_set (ad->parms, "list", list_id);

   /* Call the initializer. */
   xml_set (ad->parms, "error", "");
   (ad->vtab[0]) (ad, (va_list) 0);
   if (*xml_attrval (ad->parms, "error")) {
#ifndef WFTK_WITH_REPMGR
      wftk_config_debug_message ('A', "[%d]init: %s", adaptor_class, xml_attrval (ad->parms, "error"));
#else
      repos_log (session, 1, 0, NULL, "adaptor", "class %d init: %s", adaptor_class, xml_attrval (ad->parms, "error"));
#endif
      xml_free (ad->parms);
      free (ad);
      return ((WFTK_ADAPTOR *) 0);
   }

   /* Add the new adaptor to the list. */
   if (session) {
      list = malloc (sizeof (WFTK_ADAPTOR_LIST));
      list->next = sess->ads;
      list->ad = ad;
      sess->ads = list;
   }

   /* Return the initialized adaptor. */
   return (ad);
}
WFTK_EXPORT void wftk_free_adaptor (XML * session, WFTK_ADAPTOR * ad)
{
   if (session) return;

   (ad->vtab[1]) (ad, (va_list) 0);  /* Let the adaptor do whatever it needs to do in order to clean up. */
   xml_free (ad->parms);
   free (ad);
}
WFTK_EXPORT XML * wftk_call_adaptor (WFTK_ADAPTOR * ad, const char * function, ...)
{
   va_list argptr;
   XML * retval;
   int func;

   if (!ad) return (XML *) 0;

   for (func = 0; func < ad->nfuncs; func++) {
      if (!strcmp (function, ad->names[func])) break;
   }
   if (func == ad->nfuncs) {
#ifndef WFTK_WITH_REPMGR
      wftk_config_debug_message ('A', "[%d]%s: function '%s' unknown", ad->num, xml_attrval (ad->parms, "spec"), function);
#else
      repos_log (ad->session, 1, 0, NULL, "adaptor", "class %d %s: function '%s' unknown", ad->num, xml_attrval (ad->parms, "spec"), function);
#endif
      return ((XML *) 0);
   }

   xml_set (ad->parms, "error", "");

   va_start (argptr, function);
   retval = (ad->vtab[func]) (ad, argptr);
   va_end (argptr);

   if (*xml_attrval (ad->parms, "error")) {
#ifndef WFTK_WITH_REPMGR
      wftk_config_debug_message ('A', "[%d]%s:%s - %s", ad->num, xml_attrval (ad->parms, "spec"), function, xml_attrval (ad->parms, "error"));
#else
      repos_log (ad->session, 1, 0, NULL, "adaptor", "class %d %s, function '%s': %s", ad->num, xml_attrval (ad->parms, "spec"), function, xml_attrval (ad->parms, "error"));
#endif
   }
   return (retval);
}
WFTK_EXPORT WFTK_ADAPTORLIST * wftk_get_adaptorlist (XML * session, int adaptorclass)
{
   return (wftk_config_get_adaptorlist (session, adaptorclass));
}
WFTK_EXPORT void wftk_free_adaptorlist (XML * session, WFTK_ADAPTORLIST * list)
{
   int i;
   if (!list) return;

   for (i=0; i < list->count; i++) {
      wftk_free_adaptor (session, list->ads[i]);
   }

   free (list);
}
WFTK_EXPORT int wftk_call_adaptorlist (WFTK_ADAPTORLIST * list, const char * function, ...)
{
   va_list argptr;
   int i;
   XML * retval;
   int func;

   if (!list) return 0;

   va_start (argptr, function);

   for (i=0; i < list->count; i++) {
      if (!(list->ads[i])) continue;
      for (func = 0; func < list->ads[i]->nfuncs; func++) {
         if (!strcmp (function, list->ads[i]->names[func])) break;
      }
      if (func == list->ads[i]->nfuncs) {
#ifndef WFTK_WITH_REPMGR
         wftk_config_debug_message ('A', "[%d]%s: function '%s' unknown", list->ads[i]->num, xml_attrval (list->ads[i]->parms, "spec"), function);
#else
         repos_log (list->ads[i]->session, 1, 0, NULL, "adaptor", "class %d %s: function '%s' unknown", list->ads[i]->num, xml_attrval (list->ads[i]->parms, "spec"), function);
#endif
      } else {
         xml_set (list->ads[i]->parms, "error", "");

         retval = (list->ads[i]->vtab[func]) (list->ads[i], argptr);

         if (*xml_attrval (list->ads[i]->parms, "error")) {
#ifndef WFTK_WITH_REPMGR
            wftk_config_debug_message ('A', "[%d]%s:%s - %s", list->ads[i]->num, xml_attrval (list->ads[i]->parms, "spec"), function, xml_attrval (list->ads[i]->parms, "error"));
#else
            repos_log (list->ads[i]->session, 1, 0, NULL, "adaptor", "class %d %s, function '%s': %s", list->ads[i]->num, xml_attrval (list->ads[i]->parms, "spec"), function, xml_attrval (list->ads[i]->parms, "error"));
#endif
         }
         if (retval) xml_free (retval);
      }
   }

   va_end (argptr);

   return (1);
}
