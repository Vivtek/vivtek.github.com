#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "repmgr.h"
static char *names[] = 
{
   "init",
   "free",
   "info",

   "insert",
   "select",
   "update",
   "delete",
   "colget",
   "colput",
   "xmlget",
   "xmlput",

   "procnew",
   "procdel",
   "procget",
   "procput",
   "proclist",
   "proccomplete",
   "procerror",

   "tasknew",
   "taskdel",
   "taskget",
   "taskput",
   "tasklist",
   "taskcomplete",
   "taskreject",

   "reqnew",
   "reqdel",
   "reqget",
   "reqput",
   "reqlist",
   "reqaccept",
   "reqdecline"
};

XML * TASKINDEX_list_init (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_free (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_info (WFTK_ADAPTOR * ad, va_list args);

XML * TASKINDEX_list_insert (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_select (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_update (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_delete (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_colget (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_colput (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_xmlget (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_xmlput (WFTK_ADAPTOR * ad, va_list args);

XML * TASKINDEX_list_procnew (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_procdel (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_procget (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_procput (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_proclist (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_proccomplete (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_procerror (WFTK_ADAPTOR * ad, va_list args);

XML * TASKINDEX_list_tasknew (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_taskdel (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_taskget (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_taskput (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_tasklist (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_taskcomplete (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_taskreject (WFTK_ADAPTOR * ad, va_list args);

XML * TASKINDEX_list_reqnew (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_reqdel (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_reqget (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_reqput (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_reqlist (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_reqaccept (WFTK_ADAPTOR * ad, va_list args);
XML * TASKINDEX_list_reqdecline (WFTK_ADAPTOR * ad, va_list args);

static WFTK_API_FUNC vtab[] = 
{
   TASKINDEX_list_init,
   TASKINDEX_list_free,
   TASKINDEX_list_info,

   TASKINDEX_list_insert,
   TASKINDEX_list_select,
   TASKINDEX_list_update,
   TASKINDEX_list_delete,
   TASKINDEX_list_colget,
   TASKINDEX_list_colput,
   TASKINDEX_list_xmlget,
   TASKINDEX_list_xmlput,

   TASKINDEX_list_procnew,
   TASKINDEX_list_procdel,
   TASKINDEX_list_procget,
   TASKINDEX_list_procput,
   TASKINDEX_list_proclist,
   TASKINDEX_list_proccomplete,
   TASKINDEX_list_procerror,

   TASKINDEX_list_tasknew,
   TASKINDEX_list_taskdel,
   TASKINDEX_list_taskget,
   TASKINDEX_list_taskput,
   TASKINDEX_list_tasklist,
   TASKINDEX_list_taskcomplete,
   TASKINDEX_list_taskreject,

   TASKINDEX_list_reqnew,
   TASKINDEX_list_reqdel,
   TASKINDEX_list_reqget,
   TASKINDEX_list_reqput,
   TASKINDEX_list_reqlist,
   TASKINDEX_list_reqaccept,
   TASKINDEX_list_reqdecline
};

static struct wftk_adaptor_info _TASKINDEX_list_info =
{
   32,
   names,
   vtab
};
struct wftk_adaptor_info * TASKINDEX_list_get_info ()
{
   return & _TASKINDEX_list_info;
}
XML * TASKINDEX_list_init (WFTK_ADAPTOR * ad, va_list args) {
   const char * parms;
   XML * mark;

   parms = xml_attrval (ad->parms, "parm");
   if (!*parms) parms = "";

   if (*parms) {
      mark = repos_defn (ad->session, parms);
      if (!mark) xml_setf (ad->parms, "error", "List '%s' is not defined in the repository.", parms);
      xml_setf (ad->parms, "spec", "list:%s", parms);
      return NULL;
   }

   xml_set (ad->parms, "list", "_tasks");
   xml_set (ad->parms, "spec", "list:_tasks");

   return (XML *) 0;
}
XML * TASKINDEX_list_free (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
XML * TASKINDEX_list_info (WFTK_ADAPTOR * ad, va_list args) {
   XML * info;

   info = xml_create ("info");
   xml_set (info, "type", "taskindex");
   xml_set (info, "name", "list");
   xml_set (info, "ver", "1.1.0");
   xml_set (info, "compiled", __TIME__ " " __DATE__);
   xml_set (info, "author", "Michael Roberts");
   xml_set (info, "contact", "wftk@vivtek.com");
   xml_set (info, "extra_functions", "0");

   return (info);
}
XML * TASKINDEX_list_insert (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * TASKINDEX_list_delete (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * TASKINDEX_list_update (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * TASKINDEX_list_select (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * TASKINDEX_list_xmlput (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * TASKINDEX_list_xmlget (WFTK_ADAPTOR * ad, va_list args) { return NULL;      }
XML * TASKINDEX_list_colput (WFTK_ADAPTOR * ad, va_list args) { return (XML *) 0; }
XML * TASKINDEX_list_colget (WFTK_ADAPTOR * ad, va_list args) { return NULL;      }
XML * TASKINDEX_list_procnew (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
XML * TASKINDEX_list_procdel (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
XML * TASKINDEX_list_procget (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
XML * TASKINDEX_list_procput (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
XML * TASKINDEX_list_proclist (WFTK_ADAPTOR * ad, va_list args) { return NULL; /* TODO: is this really the right thing to do? */ }
XML * TASKINDEX_list_proccomplete (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
XML * TASKINDEX_list_procerror (WFTK_ADAPTOR * ad, va_list args) { return NULL; }
static XML * _TASKINDEX_list_tasknew_w_status (WFTK_ADAPTOR * ad, va_list args, char * status);
XML * TASKINDEX_list_tasknew (WFTK_ADAPTOR * ad, va_list args) { return _TASKINDEX_list_tasknew_w_status (ad, args, "active"); }
XML * _TASKINDEX_list_tasknew_w_status (WFTK_ADAPTOR * ad, va_list args, char * status)
{
   XML * task = (XML *) 0;

   if (args) task = va_arg (args, XML *);
   if (!task) {
      xml_set (ad->parms, "error", "No task given.");
      return (XML *) 0;
   }

   xmlobj_set (task, NULL, "state", status);
   repos_add (ad->session, "_tasks", task);

   return (NULL);  /* Was returning task, which caused the task to be freed.  That seems wrong.  Cost me three days hard debugging, anyway. */
}
XML * TASKINDEX_list_taskdel (WFTK_ADAPTOR * ad, va_list args) {
   char *process;
   char *id;
   XML * s;
   XML * index;

   if (args) process = va_arg (args, char *);
   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No task given.");
      return (XML *) 0;
   }

   if (process) { /* Here we need to look up using _taskindex. */
      s = xml_create ("s");
      xml_setf (s, "key", "%s~%s", process, id);
      index = repos_get (ad->session, "_taskindex", xml_attrval (s, "key"));
      if (index) {
         id = xmlobj_get (index, NULL, "key");
         repos_del (ad->session, "_tasks", id);
         free (id);
         repos_del (ad->session, "_taskindex", xml_attrval (s, "key"));
      }
      xml_free (s);
   } else {
      repos_del (ad->session, "_tasks",     id);
      repos_del (ad->session, "_taskindex", id);
   }

   return (XML *) 0;
}
XML * TASKINDEX_list_taskget (WFTK_ADAPTOR * ad, va_list args)
{
   XML * task = (XML *) 0;
   XML * index;
   XML * s;
   char * indexid;
   char * id;

   if (args) task = va_arg (args, XML *);
   if (!task) {
      xml_set (ad->parms, "error", "No task given.");
      return (XML *) 0;
   }

   indexid = xmlobj_format (task, NULL, "[list]~[obj]~[id]");
   xmlobj_fixkey (indexid);
   if (!strcmp (indexid, "~~")) {
      free (indexid);
      indexid = xmlobj_get (task, NULL, "key");
   }

   index = repos_get (ad->session, "_taskindex", indexid);
   xml_copyinto (task, index);
   free (indexid);
   xml_free (index);
   return task;
}
XML * TASKINDEX_list_taskput (WFTK_ADAPTOR * ad, va_list args)
{
   XML * task = (XML *) 0;
   XML * parm;
   XML * index;
   char * indexid;
   char * id;

   if (args) task = va_arg (args, XML *);
   if (!task) {
      xml_set (ad->parms, "error", "No task given.");
      return (XML *) 0;
   }

   indexid = xmlobj_format (task, NULL, "[list]~[obj]~[id]");
   xmlobj_fixkey (indexid);
   if (!strcmp (indexid, "~~")) {
      free (indexid);
      indexid = xmlobj_get (task, NULL, "key");
   }

   index = repos_get (ad->session, "_taskindex", indexid);

   if (index) {
      id = xmlobj_get (index, NULL, "key");
      repos_merge (ad->session, "_tasks_really", task, id);
      free (id);
   } else {
      repos_merge (ad->session, "_tasks_really", task, NULL);
   }

   free (indexid);
   return (XML *) 0;
}
XML * TASKINDEX_list_tasklist (WFTK_ADAPTOR * ad, va_list args) {
   XML * list = (XML *) 0;

   if (args) list = va_arg (args, XML *);
   if (!list) {
      xml_set (ad->parms, "error", "No list specified.");
      return (XML *) 0;
   }

   xml_set (list, "id", "_taskindex");
   repos_list (ad->session, list);
   
   return list;
}
static XML * _TASKINDEX_list_taskupdate (WFTK_ADAPTOR * ad, va_list args, XML * merge);
XML * TASKINDEX_list_taskcomplete (WFTK_ADAPTOR * ad, va_list args)
{
   XML * merge = xml_create ("record");
   XML * ret;

   (ad->log)(ad->session, ad, 5, "taskcomplete");

   xmlobj_set (merge, NULL, "state", "complete");
   xmlobj_set (merge, NULL, "completed", "!now");

   ret = _TASKINDEX_list_taskupdate (ad, args, merge);
   xml_free (merge);
   return (ret);
}

XML * _TASKINDEX_list_taskupdate (WFTK_ADAPTOR * ad, va_list args, XML * merge)
{
   char * process = NULL;
   char * id = NULL;
   XML * s;
   XML * index;

   if (args) process = va_arg (args, char *);
   if (!process) process = "";
   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No task given.");
      return (XML *) 0;
   }

   xml_setf (ad->parms, "s", "taskupdate -- process %s, id %s", process, id);
   (ad->log)(ad->session, ad, 5, xml_attrval (ad->parms, "s"));
   if (process) {
      s = xml_create ("s");
      xml_setf (s, "key", "%s~%s", process, id);
      index = repos_get (ad->session, "_taskindex", xml_attrval (s, "key"));
      if (index) {
         id = xmlobj_get (index, NULL, "key");
         repos_merge (ad->session, "_tasks_really", merge, id);
         free (id);
      }
      xml_free (s);
   } else {
      repos_merge (ad->session, "_tasks_really", merge, id);
   }

   return (XML *) 0;
}
XML * TASKINDEX_list_taskreject (WFTK_ADAPTOR * ad, va_list args)
{
   XML * merge = xml_create ("record");
   XML * ret;

   xmlobj_set (merge, NULL, "state", "rejected");

   ret = _TASKINDEX_list_taskupdate (ad, args, merge);
   xml_free (merge);
   return (ret);
}
XML * TASKINDEX_list_reqnew (WFTK_ADAPTOR * ad, va_list args) { return _TASKINDEX_list_tasknew_w_status (ad, args, "request"); }
XML * TASKINDEX_list_reqdel (WFTK_ADAPTOR * ad, va_list args) { return TASKINDEX_list_taskdel (ad, args); }
XML * TASKINDEX_list_reqget (WFTK_ADAPTOR * ad, va_list args) { return TASKINDEX_list_taskget (ad, args); }
XML * TASKINDEX_list_reqput (WFTK_ADAPTOR * ad, va_list args) { return TASKINDEX_list_taskput (ad, args); }
XML * TASKINDEX_list_reqlist (WFTK_ADAPTOR * ad, va_list args) { return TASKINDEX_list_tasklist (ad, args); } /* TODO: this needs state=request to work */
XML * TASKINDEX_list_reqaccept (WFTK_ADAPTOR * ad, va_list args)
{
   XML * merge = xml_create ("record");
   XML * ret;

   xmlobj_set (merge, NULL, "state", "active");

   ret = _TASKINDEX_list_taskupdate (ad, args, merge);
   xml_free (merge);
   return (ret);
}
XML * TASKINDEX_list_reqdecline (WFTK_ADAPTOR * ad, va_list args) { return TASKINDEX_list_taskdel (ad, args); }
