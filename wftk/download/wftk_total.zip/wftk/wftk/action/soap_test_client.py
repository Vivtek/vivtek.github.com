import SOAPpy
SOAPpy.Config.debug=1
server = SOAPpy.SOAPProxy("http://localhost:8080/")
#print server.map_ret("Hello world")
print server.list(list_id="Archivalienakzession")

#server = SOAPpy.SOAPProxy("http://ww6.borland.com/webservices/BorlandBabel/BorlandBabel.exe/soap/IBorlandBabel")
#print server.BabelFish(translationmode="Eleet", sourcedata="This is a test string which rocks, dude.")
