# Note: this is from the SOAP.py sample code, but instrumented with the print statement in 'echo'
#       so we can see what's happening when.

import SOAPpy
SOAPpy.Config.debug=1

def echo(s):
    return s + s # repeats a string twice

def list_ret(s):
    return [1, 2, s]

def map_ret(s):
    map = {}
    map['hi'] = "hello"
    map['lois'] = s
    return map

class test_object:
   def __init__(self):
      self.test_fld = 'field1';

def obj_ret(s):
   t = test_object()
   t.another = s
   return t

server = SOAPpy.SOAPServer(("localhost", 8080))
server.registerFunction(echo)
server.registerFunction(list_ret)
server.registerFunction(map_ret)
server.registerFunction(obj_ret)
server.serve_forever()
