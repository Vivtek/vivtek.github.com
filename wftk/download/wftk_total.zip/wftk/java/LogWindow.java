package de.startext.wftk;

import java.util.*;



public class LogWindow
{
  public static void logHtml(String htmlCode)
  {
  }

  public static void logXmlLink(String label, String xmlCode)
  {
  }
}