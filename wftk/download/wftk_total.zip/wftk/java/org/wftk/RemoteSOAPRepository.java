// Copyright (c) 2003, Vivtek.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
package org.wftk;
import java.io.*;
import java.util.HashMap;
public class RemoteSOAPRepository extends Repository {
   String server;

   public RemoteSOAPRepository (String server) {
      this.server = server;
   }

   void _get (Entry e) throws WftkException
   {
      //text_log (3, "Get entry " + e.list_id + "[" + e.key + "]");

      simple_soap ss = new simple_soap(server, "get");
      ss.add_parm ("list_id", e.list_id);
      ss.add_parm ("key", e.key);
      if (authtoken != null) ss.add_parm ("auth", authtoken);
      try {
         ss.call ();
      }
      catch (SimpleSOAPException ex) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      //link_log (6, "XML returned", ss.XMLResult);

      e.values = ss.map_value;
   }
   void _get_task (Entry e, String list, String key, String local_key) throws WftkException
   {
      simple_soap ss = new simple_soap(server, "get");
      ss.add_parm ("list_id", list);
      ss.add_parm ("key", key);
      ss.add_parm ("task_key", local_key);
      if (authtoken != null) ss.add_parm ("auth", authtoken);
      try {
         ss.call ();
      }
      catch (SimpleSOAPException ex) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      //System.out.println ("XMLResult: " + ss.XMLResult);

      e.values = ss.map_value;
      //System.out.println (e.values);
      e.key = e.get("key");
      // TODO: delete 'key' value.  (Which isn't a field.)
   }

   String _format (String list_id, String key, String mode) throws WftkException
   {
      simple_soap ss = new simple_soap(server, "get");
      ss.add_parm ("list_id", list_id);
      ss.add_parm ("key", key);
      ss.add_parm ("mode", mode);
      if (authtoken != null) ss.add_parm ("auth", authtoken);
      try {
         ss.call ();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      return (ss.simple_value);
   }

   void _add (String list, Entry obj) throws WftkException
   {
      simple_soap ss = new simple_soap(server, "add");
      ss.add_parm ("list_id", list);
      if (authtoken != null) ss.add_parm ("auth", authtoken);

      java.util.Iterator iterator = obj.values().iterator();
      String field;
      while (iterator.hasNext()) {
         field = (String) iterator.next();
         ss.add_parm ("fld_" + field, obj.get(field));
      }

      try {
         ss.call();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      obj.key = ss.simple_value;
   } 

   void _merge (String list, Entry obj, String key) {}

   void _mod (String list, Entry obj, String key) throws WftkException
   {
      simple_soap ss = new simple_soap(server, "merge");
      ss.add_parm ("list_id", list);
      ss.add_parm ("key", key);
      if (authtoken != null) ss.add_parm ("auth", authtoken);

      java.util.Collection keys = obj.values.keySet();
      java.util.Iterator iterator = keys.iterator();
      String field;
      while (iterator.hasNext()) {
         field = (String) iterator.next();
         ss.add_parm ("fld_" + field, obj.get(field));
      }
      try {
         ss.call();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      obj.key = ss.simple_value;
   }

   void _del (String list, String key) {}

   void _list (List l) throws WftkException
   {
      simple_soap ss = new simple_soap(server, "list");
      ss.add_parm ("list_id", l.id);
      if (authtoken != null) ss.add_parm ("auth", authtoken);
      try {
         ss.call ();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      l.clear();

      if (ss.vector_value != null) {
         java.util.Iterator it = ss.vector_value.iterator();
         while (it.hasNext()) {
            if (ss.return_type == 1) {
               l.add_entry ((String) it.next());
            } else {
               l.add_entry ((HashMap) it.next());
            }
         }
      }
   }

   void _tasks (List t) throws WftkException {
      simple_soap ss = new simple_soap(server, "tasks");
      try {
         ss.call ();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }

      t.clear();

      if (ss.vector_value != null) {
         java.util.Iterator it = ss.vector_value.iterator();
         while (it.hasNext()) {
            if (ss.return_type == 1) {
               t.add_entry ((String) it.next());
            } else {
               t.add_entry ((HashMap) it.next());
            }
         }
      }
   }
   void _tasks (List t, Entry e) throws WftkException {
      simple_soap ss = new simple_soap(server, "get");
      ss.add_parm ("list_id", e.list_id);
      ss.add_parm ("key", e.key);
      ss.add_parm ("mode", "tasks");
      if (authtoken != null) ss.add_parm ("auth", authtoken);
      try {
         ss.call ();
      }
      catch (SimpleSOAPException ex) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }


      t.clear();

      if (ss.vector_value != null) {
         java.util.Iterator it = ss.vector_value.iterator();
         while (it.hasNext()) {
            if (ss.return_type == 1) {
               t.add_entry ((String) it.next());
            } else {
               t.add_entry ((HashMap) it.next());
            }
         }
      }
   }

   void _todo (List t) throws WftkException {
      simple_soap ss = new simple_soap(server, "todo");
      try {
         ss.call ();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }
      t.clear();

      if (ss.vector_value != null) {
         java.util.Iterator it = ss.vector_value.iterator();
         while (it.hasNext()) {
            if (ss.return_type == 1) {
               t.add_entry ((String) it.next());
            } else {
               t.add_entry ((HashMap) it.next());
            }
         }
      }
   }

   boolean _auth (String userid, String passwd) throws WftkException {
      simple_soap ss = new simple_soap(server, "auth");
      ss.add_parm ("userid", userid);
      ss.add_parm ("password", passwd);
      try {
         ss.call();
      }
      catch (SimpleSOAPException e) {
         throw new WftkException ("Problem calling SOAP server '" + server + "'");
      }
      authtoken = ss.simple_value;
      return true;  // TODO: implement authorization failure, along with, you know, security and stuff.
   }
}
