package org.wftk;
public class Group extends Entry {
   public List members () {
      return null;
   }
   public List roles() {
      return null;
   }
}
