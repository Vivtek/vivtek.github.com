package org.wftk;
public class Role extends Entry {
   public List tasks() {
      return null;
   }
   public List users() {
      return null;
   }
}
