package org.wftk;
public class LogStream implements Log {
   public void textLog (String str) {
      System.out.println (str);
   }
   public void linkLog (String linktext, String content) {
      System.out.println ("");
      System.out.println (linktext);
      System.out.println ("-----------------------------------------------");
      System.out.println (content);
      System.out.println ("");
   }
}
