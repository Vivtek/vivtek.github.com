package org.wftk;
import java.util.Map;
import java.util.Vector;
public class List {
   public Repository rep = null;
   public String id = null;
   public String where = null;
   Vector keys = null;
   Map results = null;
   //public list_defn defn;  -- TODO: this is a logical class.

   public List (Repository r) {
      rep = r;
   }
   public List (Repository r, String list_id) {
      rep = r;
      id = list_id;
   }

   public Vector keys () { return (keys == null ? new Vector() : keys); }
   public int count () { return (keys == null ? 0 : keys.size ()); }

   void add_entry (String just_the_key) {
      if (id.equals("_tasks") || id.equals("_todo")) {
         Task e = new Task (rep, id, just_the_key);  // TODO: is there a more elegant way of doing this?  Could some Java guru answer this?
         add_entry (e);
      } else {
         Task e = new Task (rep, id, just_the_key);
         add_entry (e);
      }
   }
   void add_entry (java.util.HashMap map) {
      String key = (String) map.get ("key");  // TODO: "key" will work for tasks, anyway, but we'll probably want to be a little more careful.
                                              //       Check whether map.get throws an exception for a non-existent key.  (No, it doesn't.)
      if (key==null) key = (String) map.get ("id");
      if (id.equals("_tasks") || id.equals("_todo")) {
         Task e = new Task (rep, id, key);
         e.values = map;
         add_entry (e);
      } else {
         Entry e = new Entry (rep, id, key);
         e.values = map;
         add_entry (e);
      }
   }
   void add_entry (Entry e) {
      if (results == null) { results = new java.util.HashMap(); keys = new Vector(); }
      results.put (e.key, e);
      keys.add (e.key);
   }
   public void clear () {
      results = null;
      keys = null;
   }

   public Entry get (int index) {
      return ((Entry) results.get (keys.elementAt (index))); // TODO: perhaps this is too much?  Maybe there's an ordered Map?
   }
   public Entry get (String key) {
      return ((Entry) results.get (key));
   }

   public String get_key (int index) {
      return ((String) keys.elementAt (index));
   }

   public String get_label (String key) {
      Entry e = (Entry) get(key);
      String l = e.get ("label");
      if (l != null) { return l; }
      return (key);  // TODO: construct a label using the defined label format for the list.
   }

   public String key (int index) {
      return ((String) keys.elementAt (index));
   }
}
