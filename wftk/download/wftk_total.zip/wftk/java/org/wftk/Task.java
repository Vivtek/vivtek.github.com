package org.wftk;
public class Task extends Entry {
   public Task (Repository r, String list, String key_in) {
      rep = r;
      list_id = list;
      key = key_in;
   }

   public boolean is_task() { return true; }
   public void complete () {
   }
}
