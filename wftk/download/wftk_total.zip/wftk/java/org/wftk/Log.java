package org.wftk;
public interface Log {
   void textLog (String str);
   void linkLog (String linktext, String content);
}
