// Copyright (c) 2003, Vivtek.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
package org.wftk;
import java.io.*;     // For stream interaction.
import java.util.Vector;
import org.xml.sax.XMLReader;   // The following for SAX parsing.
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;

public class xml {
   private static boolean force_pure=false;
   private boolean pure_java=force_pure;
   static {
      try {
         System.loadLibrary("xmlapi_jni");
      }
      catch (Exception e) {
         force_pure=true;
      }
   }

   public boolean make_pure() {
      if (_native_xml != 0) { return false; }  // Initially, we refuse to convert a native XML object to a pure one.  TODO: re-evaluate policy.
      pure_java = true;
      return (true);
   }
   public boolean is_pure() { return pure_java; }

   // For pure-Java trees, we keep an element name and the list of attributes.
   private String element_name;
   private Vector element_attrs;
   private String textcontent;
   private boolean is_element;

   // -----------------------------------------------------
   // Housekeeping members
   // -----------------------------------------------------
   private int _native_xml = 0; // Saves pointer to XML structure on C heap.
   private xml _parent = null;     // Prevents parent from being garbage-collected (and freeing the XML) until we're quite done with it.
   private Vector handles = null;  // A list of all nodes which have the current object as _parent.

   private boolean officially_closed = false;

   // -----------------------------------------------------
   // Housekeeping functions.
   // -----------------------------------------------------
   private void attach_handle (xml newhandle)
   {
      xml attach_to = this;
      while (attach_to._parent != null) attach_to = attach_to._parent;

      if (attach_to.handles == null) attach_to.handles=new Vector ();
      attach_to.handles.add(newhandle);
      newhandle._parent = attach_to;
   }
   private void attach_to_parent (xml newparent)
   {
      newparent.attach_handle (this);
   }
   private void detach_handle (xml handle)
   {
      if (handles == null) return;

      if (handles.remove (handle)) {
         handle._parent = null;
      }

      if (handles.isEmpty() && officially_closed) {
         close();
      }
   }
   private void detach_from_parent ()
   {
      if (_parent == null) return;
      _parent.detach_handle (this);
   }

   public void close ()
   {
      element_name = null;
      if (pure_java) return; // The rest is handling the heap.

      if (handles == null || handles.isEmpty()) {
         if (_parent == null) { // No children, no parent: deallocate native structure, if any.
            if (_native_xml != 0) {
               xml_free ();
               _native_xml = 0;
            }
         } else {
            xml parent_ref = _parent;
            detach_from_parent();
            _native_xml = 0;
         }
      } else {
         officially_closed = true; // We'll really close when all our children close.
      }
   }

   public boolean is_live()
   {
      if (handles != null && !handles.isEmpty()) return true;
      return false;
   }

   ///c:\\progra~1\\s1studio_jdk\\j2sdk1.4.1_02\\bin\\javac xmlobj.java
   ///xmlobj.java:39: finalize() in xml cannot override finalize() in java.lang.Object
   ///; attempting to assign weaker access privileges; was protected
   //
   // So the idea is that in the last ditch, finalize would close the object if necessary.
   // But finalize has other ideas.
   //
   //void finalize ()
   //{
   //   this.close();
   //}
   public xml newhandle ()
   {
      xml handle = new xml();
      attach_handle (handle);

      handle._native_xml = this._native_xml;  // Start out looking at the same XML.

      return handle;
   }
   public void handle_to (xml other)
   {
      if (is_live()) return; // TODO: should throw exception.

      other.attach_handle (this);

      _native_xml = other._native_xml;
   }

   // ------------------------------------------------------
   // Reading XML from strings and files.
   // ------------------------------------------------------
   // parse_general: TODO: redo in Java
   // void read (InputStream file) NOTE: no need for separate "parse" and "read" in Java.

   public void parse (java.io.InputStream in) throws Exception
   {
      close (); // Make sure we don't orphan any existing content here.
      if (is_live()) return; // TODO: Need to throw an exception, actually.

      parse_state p = new parse_state(this);
      p.use_input (in);

      p.parse (); // This throws an exception if passed something InputSource can't handle.
   }
   public void parse (java.io.Reader in) throws Exception
   {
      close (); // Make sure we don't orphan any existing content here.
      if (is_live()) return; // TODO: Need to throw an exception, actually.

      parse_state p = new parse_state(this);
      p.use_input (in);

      p.parse (); // This throws an exception if passed something InputSource can't handle.
   }
   public void parse (java.lang.String in) throws Exception
   {
      close (); // Make sure we don't orphan any existing content here.
      if (is_live()) return; // TODO: Need to throw an exception, actually.

      parse_state p = new parse_state(this);
      p.use_input (in);

      p.parse (); // This throws an exception if passed something InputSource can't handle.
   }

   private class parse_state extends DefaultHandler {
      xml top;
      xml current;
      xml inner;
      XMLReader xr;
      InputSource in;

      parse_state (xml caller) throws Exception {
         top = caller;
         current = null;
         inner = null;
         xr = XMLReaderFactory.createXMLReader();

         xr.setContentHandler(this);
         xr.setErrorHandler(this);
      }

      // Building input thingies.
      public void use_input (java.io.InputStream byteStream) { in = new InputSource (byteStream); }
      public void use_input (java.io.Reader characterStream) { in = new InputSource (characterStream); }
      public void use_input (java.lang.String string) {
         StringReader sr = new StringReader (string);
         in = new InputSource (sr);
      }

      public void parse() throws Exception {
         xr.parse(in);
      }

      public void startElement (String uri, String name, String qName, Attributes atts)
      {
         String element_name;
         if ("".equals (uri))
            element_name = qName;
         else
            element_name = name;  // TODO: XMLAPI currently ignores namespaces entirely.  This is a story that *really* needs revisiting.

         if (current == null) {
            top.create (element_name);
            for (int i=0; i < atts.getLength(); i++) {
               top.set (atts.getQName (i), atts.getValue(i));
            }
            current = top.newhandle();
         } else {
            if (inner == null) inner = new xml();
            inner.create (element_name);
            for (int i=0; i < atts.getLength(); i++) {
               inner.set (atts.getQName (i), atts.getValue(i));
            }
            current.append (inner);
            xml temp = current;
            current = inner;
            inner = temp;
            inner.close ();
         }
      }

      public void endElement (String uri, String name, String qName)
      {
         current.to_parent();
      }

      public void endDocument ()
      {
         current.close();
      }

      public void characters (char ch[], int start, int length)
      {
         xml char_node = new xml();
         String sb = new String(ch, start, length);
         char_node.createtext (sb);
         current.append (char_node);
         char_node.close();
      }
   }

   // -----------------------------------------------------
   // Constructors
   // -----------------------------------------------------
   public xml () { }
   public xml (String str) throws Exception {
      parse (str);
   }
   public xml (Reader r) throws Exception {
      parse (r);
   }

   // -----------------------------------------------------
   // Formatting XML strings.
   // -----------------------------------------------------
   public native String string();
   public native String stringhtml();
   public native String stringcontent();
   public native String stringcontenthtml();

   // -----------------------------------------------------
   // Writing to files.
   //  *NOTE* -- has to be rewritten as pure Java in order to use Java's I/O.
   // -----------------------------------------------------
   public void write (OutputStream file) {
      // TODO: write this.
   }
   public void writehtml (OutputStream file) {
      // TODO: write this.
   }
   public void writecontent (OutputStream file) {
      // TODO: write this.
   }
   public void writecontenthtml (OutputStream file) {
      // TODO: write this.
   }

   // ------------------------------------------------------
   // Attribute access.
   // ------------------------------------------------------
   public native String attrval (String key);
   // attrvalnum - not needed
   public native String[] attrlist (); // A list of attribute names.
   //native ?? attrs ();  // A mapping of name->value -- I know how this works in Python; have to look it up for Java.  (TODO: use Vector)
   public native void set (String key, String value);
   // setf, setnum, set_nodup - not needed
   public native void unset (String key);
   public native void attrcat (String key, String str);

   // ------------------------------------------------------
   // Subelement identification, iteration, handle navigation.
   // ------------------------------------------------------
   public native String name ();
   public native boolean is_element ();
   public native boolean is_a (String name);

   public void to_parent () // Move handle to parent.  This is a good foot-shooter, I think.
   {
      _nav_carefully (xml_parent());
   }
   public xml parent () // Returns a new handle object which refers to the XML parent of the current object.
   {
      xml p = this.newhandle();
      p.to_parent();
      return (p);
   }
   private native int xml_parent ();  // Returns *XML handle* of native parent.

   public native xml[] elements (); // Returns new handles to all the children of the current object.

   // Low-level iterators/navigation
   private void _nav_carefully (int to_where) {
      if (to_where != 0) {
         _native_xml = to_where;
         _nav_ok = true;
      } else {
         _nav_ok = false;
      }
   }
   private boolean _nav_ok = false;
   public boolean nav_ok () { return _nav_ok; }

   public void to_first () { _nav_carefully (xml_first()); }
   public void to_firstelem () { _nav_carefully (xml_firstelem()); }
   public void to_next () { _nav_carefully (xml_next()); }
   public void to_nextelem () { _nav_carefully (xml_nextelem()); }
   public void to_last () { _nav_carefully (xml_last()); }
   public void to_lastelem () { _nav_carefully (xml_lastelem()); }
   public void to_prev () { _nav_carefully (xml_prev()); }
   public void to_prevelem () { _nav_carefully (xml_prevelem()); }

   private native int xml_first ();
   private native int xml_firstelem ();
   private native int xml_next ();
   private native int xml_nextelem ();
   private native int xml_last ();
   private native int xml_lastelem ();
   private native int xml_prev ();
   private native int xml_prevelem ();

   // High-level iterator -- a nested class may be more appropriate to Java.  Actually, I think handle navigation works better....
   public void iterate (xml parent, String type, String dir) { // TODO: default type='elem', dir='f' from Python; Java equiv?
      // TODO: implement
   }
   public xml iterator() {
      // TODO: implement
      return new xml();
   }
   public void rewind () {
      // TODO: implement
   }
   public xml advance () {
      // TODO: implement
      return this;
   }

   // ---------------------------------------------
   // Element manipulation
   // ---------------------------------------------
   private native void xml_create(String name);
   public void create (String name) {
      close();
      if (is_live()) return; // TODO: throw exception here.

      if (pure_java) {
         element_name = name;
      } else {
         xml_create (name);
      }
   }
   public native void createtext(String name);
   public native void textcat(String name);
   public native void delete();
   private native void xml_free ();
   public native void delete_pretty();
   public xml new_copy () {
      xml ret = new xml();
      ret.copy (this);      
      return ret;
   }
   public void copy(xml other)
   {
      close();
      if (is_live()) return; // TODO: exception.

      xml_copy (other);
   }
   private native void xml_copy (xml other);
   public native void copyinto (xml other);
   public native void copyattrs (xml other);

   public void replace (xml other) {
      xml_replace (other);
      _native_xml = other._native_xml;
      other.close();
   }
   private native void xml_replace (xml other);
   public native void xml_replacecontent (xml other);
   public native void replacewithcontent (xml other);

   private native void xml_prepend (xml newchild);
   public void prepend (xml newchild)
   {
      attach_handle (newchild);
      xml_prepend (newchild);
   }
   private native void xml_prepend_pretty (xml newchild);
   public void prepend_pretty (xml newchild)
   {
      attach_handle (newchild);
      xml_prepend_pretty (newchild);
   }
   private native void xml_append (xml newchild);
   public void append (xml newchild)
   {
      attach_handle (newchild);
      xml_append (newchild);
   }
   private native void xml_append_pretty (xml newchild);
   public void append_pretty (xml newchild)
   {
      attach_handle (newchild);
      xml_append_pretty (newchild);
   }

   public native xml xml_insertafter (xml something);  // Huh?  I forget the semantics...
   public native xml xml_insertbefore (xml something);
   

   // ---------------------------------------------
   // Finding pieces of XML
   // ---------------------------------------------
   public void to_loc (String location) { _nav_carefully (xml_loc (location)); }
   private native int xml_loc (String location);

   public native String getloc ();
   public native xml search (String elem, String attr, String val);
   public native xml[] search_all (String elem, String attr, String val);

   // ---------------------------------------------
   // Binary pointer access?  Not sure how healthy this is for Java.
   // ---------------------------------------------

   // ---------------------------------------------
   // UTF8 stuff -- don't know how this should react to Java, either.
   // ---------------------------------------------

   // ---------------------------------------------
   // Sorting -- as this only works on lists, it's not relative to an instance
   // ---------------------------------------------
   //native static sort (xml[] list, xml sort);

   // ---------------------------------------------
   // SOAP assembly
   // ---------------------------------------------
   public void assemble (xml start, xml src) {
      close();
      if (is_live()) return; // TODO: throw exception here.

      xml_assemble (start, src);
   }
   private native void xml_assemble (xml start, xml src);

}
