package org.wftk;
import java.util.Map;
import java.util.Collection;

public class Entry {
   public Repository rep = null; // Every entry knows its own repository.
   public String key = null;
   public String list_id = null;
   public Map attributes = null;
   Map values = null;
   public String state = null;
   private String html = null;
   private String display_html = null;

   public Entry () {
   }
   public Entry (Repository r) {
      rep = r;
   }
   public Entry (Repository r, String list) {
      rep = r;
      list_id = list;
   }
   public Entry (Repository r, String list, String key_in) {
      rep = r;
      list_id = list;
      key = key_in;
   }

   public Collection values () { return values.keySet (); }
   public int value_count () { return values.size (); }

   public String key () {
      return key;
   }
   public String get (String field) {
      return ((String) values.get ((Object) field));
   }
   public String label (String field) {
      return field; // TODO: an actual field label
   }
   public void set (String field, String value) {
      display_html = null;
      html = null;
      if (values == null) values = new java.util.HashMap();
      values.put (field, value);
   }
   public void add (Repository r, String list) {
      rep = r;
      
   }
   public void add (String list) throws WftkException {
      if (rep == null) throw new WftkException("No repository defined for entry");
      rep.add (list, this);      
   }
   public void add () throws WftkException {
      if (rep == null) throw new WftkException("No repository defined for entry");
      if (list_id == null) throw new WftkException("Entry not attached to list");
      rep.add (list_id, this);
   }
   public String html_edit () throws WftkException {
      if (html == null) {
         html = rep.format (list_id, key, "edit");
      }
      return html;
   }
   public boolean is_editable () { return true; } // TODO: Maybe make this check some logic.
   public boolean is_task () { 
      if (list_id == "_tasks") return true;
      if (list_id == "_todo")  return true;
      return false; // TODO: is this really the best logic?
   }
   public String html_display () throws WftkException {
      if (display_html == null) {
         System.out.println ("getting display");
         display_html = rep.format (list_id, key, "display");
      }
      return display_html;
   }

   public void update () throws WftkException {
      rep.mod (list_id, this, key);
   }
   public void refresh () throws WftkException {
      rep._get (this);
   }

   public Entry get_task (String key) throws WftkException {
      return (rep.get_task(this, key));
   }

   public List tasks () throws WftkException {
      List t = new List(rep);
      t.id = "_tasks";

      rep._tasks (t, this);

      return (t);
   }
   public List roles () throws WftkException {
      return null;
   }

   /* ---- Task entries ------ */
   public void complete() throws WftkException {
      set ("state", "completed");
      update ();
   }
}
