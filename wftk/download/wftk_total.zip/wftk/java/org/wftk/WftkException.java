package org.wftk;
public class WftkException extends Exception {
   private String desc;
   public WftkException (String e) { desc = e; }
   public String toString () { return desc; }
}
