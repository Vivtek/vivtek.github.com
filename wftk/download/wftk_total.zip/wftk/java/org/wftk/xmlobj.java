package org.wftk;
public class xmlobj extends xml {
   static {
      System.loadLibrary("xmlapi_jni");
   }

   // ---------------------------------------------
   // Constructors
   // ---------------------------------------------

   // ---------------------------------------------
   // Getting and setting list definition.
   // The list definition is an XML structure which does some of what a DTD should be doing.
   // We simply provide a reference to a regular old "xml" object for this.
   // ---------------------------------------------
   xml _list;
   void define (xml list) {
      this._list = list;
   }
   public xml defn () {
      return this._list;
   }

   // ---------------------------------------------
   // Field reading.
   // ---------------------------------------------
   public native String get (String field);
   public native String key ();
   public native String format (String format);

   // ---------------------------------------------
   // Field writing.  Note that we can choose element or field storage.
   // ---------------------------------------------
   public native void set (String key, String value);
   public native void set_elem (String key, String value);

   // ---------------------------------------------
   // Diff/patch functionality
   // ---------------------------------------------
   public native xmlobj diff (xmlobj changed);
   public native xmlobj undiff (xmlobj diff);
   public native xmlobj patch (xmlobj diff);

   // ---------------------------------------------
   // Versioning functionality
   // ---------------------------------------------

   // ---------------------------------------------
   // Value lists
   // ---------------------------------------------

   // ---------------------------------------------
   // Sorting lists of xmlobj records
   // ---------------------------------------------
   static native xml list_sort (xml[] list, xml defn, String order);
}
