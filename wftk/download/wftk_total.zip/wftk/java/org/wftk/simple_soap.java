// Copyright (c) 2003, Vivtek.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
package org.wftk;
import java.net.*;
import java.io.*;
import java.util.Vector;
import java.util.HashMap;
class SimpleSOAPException extends Exception {
   private String desc;
   SimpleSOAPException (String e) {
      desc = e;
   }
   public String toString () { return desc; }
}
public class simple_soap {
  String server;
  String function;

  public class parm {
     public String name;
     public String value;
     public String type;
     public parm (String _name, String _value)
     {
        name = _name;
        value = _value;
        type = "xsd:string";
     }
     public parm (String _name, String _value, String _type)
     {
        name = _name;
        value = _value;
        type = _type;
     } 
  }
  Vector parms;

  public simple_soap(String server_in, String function_in) {
     server = server_in;
     function = function_in;
  }

  public void set_server(String server_in) {
     server = server_in;
  }
  public String get_server () {
     return (server);
  }

  public void set_function (String function_in) {
     function = function_in;
  }
  public String get_function () {
     return (function);
  }

  public void clear_parms() {
     parms = null;
  }
  private void init_parms() {
     if (parms != null) return;
     parms = new Vector();
  }
  public void add_parm (String p, String val) {
     init_parms();
     parm pm = new parm (p, val);
     parms.add (pm);
  }
  public void add_parm (String p, String val, String type) {
     init_parms();
     parm pm = new parm (p, val, type);
     parms.add (pm);
  }

  public void call() throws SimpleSOAPException {
    HttpURLConnection connection;

    try {
      URL u = new URL(server);
      URLConnection uc = u.openConnection();
      connection = (HttpURLConnection) uc;
      init_parms();

      connection.setDoOutput(true);
      connection.setDoInput(true);
      connection.setRequestMethod("POST");
      connection.setRequestProperty("SOAPAction", "dummy_action");
    }
    catch (Exception e) {
      throw new SimpleSOAPException ("Can't configure connection to server '" + server + "': " + e);
    }

    try {
      OutputStream out = connection.getOutputStream();
      Writer wout = new OutputStreamWriter(out);
      
      wout.write("<?xml version='1.0'?>\r\n");  
      wout.write("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\">\r\n"); 
      wout.write("<SOAP-ENV:Body>\r\n");
      wout.write("<" + function + " SOAP-ENC:root=\"1\">\r\n");
      for (int i=0; i < parms.size(); i++) {
         parm p = (parm) parms.get(i);
         wout.write("<" + p.name + " xsi:type=\"" + p.type + "\">" + p.value + "</" + p.name + ">\r\n");
      }
      wout.write("</" + function + ">\r\n");
      wout.write("</SOAP-ENV:Body>\r\n"); 
      wout.write("</SOAP-ENV:Envelope>\r\n"); 
      
      wout.flush();
      wout.close();
    }
    catch (Exception e) {
      throw new SimpleSOAPException ("Can't connect to server '" + server + "' (or connection lost): " + e);
    }

    InputStream in;
    try {
       in = connection.getInputStream();
    }
    catch (Exception e) {
       throw new SimpleSOAPException ("Problems reading from server '" + server + "': " + e);
    }

    xml reply;
    try {
       reply = new xml();
       reply.parse (in);
       in.close();
    }
    catch (Exception e) {
      throw new SimpleSOAPException ("Problems parsing XML: " + e);
    }

    xml view = reply.newhandle();
    view.to_firstelem();  // Go to Body.
    view.to_firstelem();  // Go to first response.

    // Preprocess results.
    interpret(view, reply);
    view.close();
    reply.close();      
  }
   public String XMLResult;
   public int return_type;
   public String  simple_value;
   public Vector  vector_value;
   public HashMap map_value;

   private void interpret (xml incoming, xml reply)
   {

      xml _result = incoming.newhandle();
      _result.to_firstelem();

      xml result = new xml();
      result.assemble (_result, reply);

      String rtype = result.attrval ("xsi:type");

      if (rtype.startsWith ("xsd:")) { // Simple value.
         return_type = 0;
         simple_value = dequote(result.stringcontent());
      } else if (rtype.endsWith ("Array")) { // Um, array value.  (May be an array of mappings.)
         return_type = 1;
         vector_value = new Vector();
         result.to_firstelem();
         while (result.nav_ok()) {
            xml child = result.newhandle();
            child.to_firstelem();
            if (child.nav_ok()) {   // list of (String->String) mappings
               return_type = 3; // *Any* mapping item makes this a list of mappings, which is probably dangerous should we end up with a mixture....
               HashMap child_map = new HashMap();
               while (child.nav_ok()) {
                  child_map.put (child.name(), dequote (child.stringcontent()));
                  child.to_nextelem();
               }
               vector_value.add (child_map);
            } else {                // list of strings
               vector_value.add (dequote(result.stringcontent()));
            }
            child.close();
            result.to_nextelem();
         }
      } else { // Must be a String->String mapping.
         return_type = 2;
         map_value = new HashMap();
         result.to_firstelem();
         while (result.nav_ok()) {
            map_value.put (result.name(), dequote (result.stringcontent()));
            result.to_nextelem();
         }
      }

      XMLResult = result.string();  // Save reconstructed result.

      result.close();
   }

   public String dequote (String str) {
      str = str.replaceAll ("&lt;", "<");
      str = str.replaceAll ("&gt;", ">");
      str = str.replaceAll ("&quot;", "\"");
      str = str.replaceAll ("&amp;", "&");

      return (str);
   }

   public String getVectorValue (int index) {
      if (return_type!=1) return null;
      return ((String) vector_value.get(index));
   }
   public String getMapValue (String key) {
      if (return_type==0) return simple_value;
      if (return_type==1) return null;
      return ((String) map_value.get(key));
   }
}
