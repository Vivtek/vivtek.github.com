package org.wftk;
public class User extends Entry {
   public List tasks () {
      return null;
   }
   public void assign (Task task) {
   }
   public List roles () {
      return null;
   }
}
