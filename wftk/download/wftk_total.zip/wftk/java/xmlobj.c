#include "xml_jni.h"
#include "xmlobj_jni.h"
#include <xmlapi.h>
#include <xmlobj.h>
/*
 * Class:     xml
 * Method:    xml_create
 * Signature: (Ljava/lang/String;)Lxml;
 */
static XML * _get_native (JNIEnv *env, jobject this);
static void _set_native (JNIEnv *env, jobject this, XML * xml);
static jstring _to_jstring (JNIEnv *env, char * str);

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1create (JNIEnv *env, jobject this, jstring name_j)
{
   const char *name;
   XML * xml;

   // 1. Unpack string into UTF-8-encoded buffer (the Java string is of course in Unicode).
   name = (*env)->GetStringUTFChars (env, name_j, 0);

   // 2. Create the XML, then release the string buffer.
   xml = xml_create (name);
   (*env)->ReleaseStringUTFChars(env, name_j, name);

   // 3. Put new XML into object.
   _set_native (env, this, xml);
}

/*
 * Class:     xml
 * Method:    xml_free
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1free (JNIEnv *env, jobject this)
{
   xml_free (_get_native (env, this));
}




/*
 * Class:     xml
 * Method:    string
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_org_wftk_xml_string (JNIEnv *env, jobject this)
{
   return (_to_jstring (env, xml_string (_get_native (env, this))));
}
static XML * _get_native (JNIEnv *env, jobject this)
{
   jclass xml_class;
   jfieldID fid;
   jint nx;

   xml_class = (*env)->GetObjectClass (env, this);
   fid = (*env)->GetFieldID (env, xml_class, "_native_xml", "I");
   nx = (*env)->GetIntField (env, this, fid);

   return ((XML *) nx);
}
static void _set_native (JNIEnv *env, jobject this, XML * xml)
{
   jclass xml_class;
   jfieldID fid;

   xml_class = (*env)->GetObjectClass (env, this);
   fid = (*env)->GetFieldID (env, xml_class, "_native_xml", "I");
   (*env)->SetIntField (env, this, fid, (long) xml);
}
static jstring _to_jstring (JNIEnv *env, char * str)
{
   jstring jstr = (*env)->NewStringUTF(env, str);
   xml_strfree (str);   /* NOTE: using "free" here invokes the wrong heap's free, apparently.  Muy importante: use the right free! */
   return jstr;
}
JNIEXPORT jstring JNICALL Java_org_wftk_xml_stringhtml (JNIEnv *env, jobject this)
{
   return (_to_jstring (env, xml_stringhtml (_get_native (env, this))));
}

JNIEXPORT jstring JNICALL Java_org_wftk_xml_stringcontent (JNIEnv *env, jobject this)
{
   return (_to_jstring (env, xml_stringcontent (_get_native (env, this))));
}

JNIEXPORT jstring JNICALL Java_org_wftk_xml_stringcontenthtml (JNIEnv *env, jobject this)
{
   return (_to_jstring (env, xml_stringcontenthtml (_get_native (env, this))));
}
/*
 * Class:     xml
 * Method:    attrval
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_org_wftk_xml_attrval (JNIEnv *env, jobject this, jstring key_j)
{
   const char *key;
   jstring value;

   key = (*env)->GetStringUTFChars (env, key_j, 0);
   value = (*env)->NewStringUTF(env, xml_attrval (_get_native (env, this), key));
   (*env)->ReleaseStringUTFChars(env, key_j, key);
   return value;
}

/*
 * Class:     xml
 * Method:    set
 * Signature: (Ljava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_org_wftk_xml_set (JNIEnv *env, jobject this, jstring key_j, jstring value_j)
{
   const char * key;
   const char * value;

   key = (*env)->GetStringUTFChars (env, key_j, 0);
   value = (*env)->GetStringUTFChars (env, value_j, 0);
   xml_set (_get_native (env, this), key, value);
   (*env)->ReleaseStringUTFChars(env, key_j, key);
   (*env)->ReleaseStringUTFChars(env, value_j, value);
}

JNIEXPORT void JNICALL Java_org_wftk_xml_unset (JNIEnv *env, jobject this, jstring key_j)
{
   const char *key;

   key = (*env)->GetStringUTFChars (env, key_j, 0);
   xml_unset (_get_native (env, this), key);
   (*env)->ReleaseStringUTFChars(env, key_j, key);
}
JNIEXPORT void JNICALL Java_org_wftk_xml_createtext (JNIEnv *env, jobject this, jstring content_j)
{
   XML * xml;
   const char * content = (*env)->GetStringUTFChars (env, content_j, 0);

   xml = xml_createtext (content);
   (*env)->ReleaseStringUTFChars(env, content_j, content);
   _set_native (env, this, xml);
}

JNIEXPORT void JNICALL Java_org_wftk_xml_textcat (JNIEnv *env, jobject this, jstring content_j)
{
   const char *content;

   content = (*env)->GetStringUTFChars (env, content_j, 0);
   xml_textcat (_get_native (env, this), content);
   (*env)->ReleaseStringUTFChars(env, content_j, content);
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1prepend (JNIEnv *env, jobject this, jobject other)
{
   xml_prepend (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1prepend_1pretty (JNIEnv *env, jobject this, jobject other)
{
   xml_prepend_pretty (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1append (JNIEnv *env, jobject this, jobject other)
{
   xml_append (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1append_1pretty (JNIEnv *env, jobject this, jobject other)
{
   xml_append_pretty (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1parent (JNIEnv *env, jobject this)
{
   return ((jint) xml_parent (_get_native (env, this)));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_attrcat (JNIEnv *env, jobject this, jstring key_j, jstring value_j)
{
   const char * key;
   const char * value;

   key = (*env)->GetStringUTFChars (env, key_j, 0);
   value = (*env)->GetStringUTFChars (env, value_j, 0);
   xml_attrcat (_get_native (env, this), key, value);
   (*env)->ReleaseStringUTFChars(env, key_j, key);
   (*env)->ReleaseStringUTFChars(env, value_j, value);
}

JNIEXPORT jstring JNICALL Java_org_wftk_xml_name (JNIEnv *env, jobject this)
{
   return (*env)->NewStringUTF(env, xml_name (_get_native (env, this)));
}

JNIEXPORT jboolean JNICALL Java_org_wftk_xml_is_1element (JNIEnv *env, jobject this)
{
   return ((jboolean) xml_is_element (_get_native (env, this)));
}

JNIEXPORT jboolean JNICALL Java_org_wftk_xml_is_1a (JNIEnv *env, jobject this, jstring name_j)
{
   const char *name;
   jboolean value;

   name = (*env)->GetStringUTFChars (env, name_j, 0);
   value = (jboolean) xml_is (_get_native (env, this), name);
   (*env)->ReleaseStringUTFChars(env, name_j, name);
   return value;
}

JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1first (JNIEnv *env, jobject this)     { return ((jint) xml_first (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1firstelem (JNIEnv *env, jobject this) { return ((jint) xml_firstelem (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1next (JNIEnv *env, jobject this)      { return ((jint) xml_next (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1nextelem (JNIEnv *env, jobject this)  { return ((jint) xml_nextelem (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1last (JNIEnv *env, jobject this)      { return ((jint) xml_last (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1lastelem (JNIEnv *env, jobject this)  { return ((jint) xml_lastelem (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1prev (JNIEnv *env, jobject this)      { return ((jint) xml_prev (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1prevelem (JNIEnv *env, jobject this)  { return ((jint) xml_prevelem (_get_native (env, this))); }
JNIEXPORT jint JNICALL Java_org_wftk_xml_xml_1loc (JNIEnv *env, jobject this, jstring str)
{
   const char *locator;
   jint ret;

   locator = (*env)->GetStringUTFChars (env, str, 0);
   ret = (jint) xml_loc (_get_native (env, this), locator);
   (*env)->ReleaseStringUTFChars (env, str, locator);
   return ret;
}
JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1copy (JNIEnv *env, jobject this, jobject other)
{
   _set_native (env, this, xml_copy (_get_native (env, other)));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_copyinto (JNIEnv *env, jobject this, jobject other)
{
    xml_copyinto (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_copyattrs (JNIEnv *env, jobject this, jobject other)
{
    xml_copyattrs (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1replace (JNIEnv *env, jobject this, jobject other)
{
    xml_replace (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1replacecontent (JNIEnv *env, jobject this, jobject other)
{
    xml_replacecontent (_get_native (env, this), _get_native (env, other));
}

JNIEXPORT void JNICALL Java_org_wftk_xml_xml_1assemble (JNIEnv *env, jobject this, jobject start, jobject src)
{
   _set_native (env, this, xml_assemble (_get_native (env, start), _get_native (env, src)));
}
/*
 * Class:     xml
 * Method:    attrlist
 * Signature: ()[Ljava/lang/String;
 */
JNIEXPORT jobjectArray JNICALL Java_org_wftk_xml_attrlist (JNIEnv *env, jobject this)
{

}




/*
 * Class:     xml
 * Method:    elements
 * Signature: ()[Lxml;
 */
JNIEXPORT jobjectArray JNICALL Java_org_wftk_xml_elements (JNIEnv *env, jobject this)
{

}




/*
 * Class:     xml
 * Method:    delete
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_org_wftk_xml_delete (JNIEnv *env, jobject this)
{

}


/*
 * Class:     xml
 * Method:    delete_pretty
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_org_wftk_xml_delete_1pretty (JNIEnv *env, jobject this)
{

}



/*
 * Class:     xml
 * Method:    replacewithcontent
 * Signature: (Lxml;)V
 */
JNIEXPORT void JNICALL Java_org_wftk_xml_replacewithcontent (JNIEnv *env, jobject this, jobject other)
{

}


/*
 * Class:     xml
 * Method:    xml_insertafter
 * Signature: (Lxml;)Lxml;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xml_xml_1insertafter (JNIEnv *env, jobject this, jobject other)
{

}


/*
 * Class:     xml
 * Method:    xml_insertbefore
 * Signature: (Lxml;)Lxml;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xml_xml_1insertbefore (JNIEnv *env, jobject this, jobject other)
{

}



/*
 * Class:     xml
 * Method:    getloc
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_org_wftk_xml_getloc (JNIEnv *env, jobject this)
{

}


/*
 * Class:     xml
 * Method:    search
 * Signature: (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lxml;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xml_search (JNIEnv *env, jobject this, jstring elem, jstring attr, jstring val)
{

}


/*
 * Class:     xml
 * Method:    search_all
 * Signature: (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[Lxml;
 */
JNIEXPORT jobjectArray JNICALL Java_org_wftk_xml_search_1all (JNIEnv *env, jobject this, jstring elem, jstring attr, jstring val)
{

}



/*
 * Class:     xmlobj
 * Method:    get
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_org_wftk_xmlobj_get (JNIEnv *env, jobject this, jstring key)
{

}


/*
 * Class:     xmlobj
 * Method:    key
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_org_wftk_xmlobj_key (JNIEnv *env, jobject this)
{

}


/*
 * Class:     xmlobj
 * Method:    format
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_org_wftk_xmlobj_format  (JNIEnv *env, jobject this, jstring format)
{

}


/*
 * Class:     xmlobj
 * Method:    set
 * Signature: (Ljava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_org_wftk_xmlobj_set (JNIEnv *env, jobject this, jstring key, jstring value)
{

}


/*
 * Class:     xmlobj
 * Method:    set_elem
 * Signature: (Ljava/lang/String;Ljava/lang/String;)V
 */
JNIEXPORT void JNICALL Java_org_wftk_xmlobj_set_1elem (JNIEnv *env, jobject this, jstring key, jstring value)
{

}


/*
 * Class:     xmlobj
 * Method:    diff
 * Signature: (Lxmlobj;)Lxmlobj;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xmlobj_diff (JNIEnv *env, jobject this, jobject other)
{

}


/*
 * Class:     xmlobj
 * Method:    undiff
 * Signature: (Lxmlobj;)Lxmlobj;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xmlobj_undiff (JNIEnv *env, jobject this, jobject other)
{

}


/*
 * Class:     xmlobj
 * Method:    patch
 * Signature: (Lxmlobj;)Lxmlobj;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xmlobj_patch (JNIEnv *env, jobject this, jobject other)
{

}


/*
 * Class:     xmlobj
 * Method:    list_sort
 * Signature: ([Lxml;Lxml;Ljava/lang/String;)Lxml;
 */
JNIEXPORT jobject JNICALL Java_org_wftk_xmlobj_list_1sort (JNIEnv *env, jclass cl, jobjectArray list, jobject defn, jstring order)
{

}
