import org.wftk.*;

class wrappertest {
   public static void main(String[] args) {
      try {
         System.out.println ("test_1 (create, string) - " + test_1() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_1 (create, string): " + e);
      }
      try {
         System.out.println ("test_2 (attributes I) - " + test_2() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_2 (attributes I): " + e);
      }
      try {
         System.out.println ("test_3 (text nodes) - " + test_3() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_3 (text nodes): " + e);
      }
      try {
         System.out.println ("test_4 (append) - " + test_4() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_4 (append): " + e);
      }
      try {
         System.out.println ("test_5 (parsing) - " + test_5() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_5 (parsing): " + e);
      }
      try {
         System.out.println ("test_6 (loc) - " + test_6() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_6 (loc): " + e);
      }
      try {
         System.out.println ("test_7 (copy, replace) - " + test_7() + "\n");
      } catch (Exception e) {
         System.out.println ("Exception in test_7 (copy, replace): " + e);
      }

      try {
         System.out.println ("test_simple_soap_1 - " + test_simple_soap_1());
      } catch (Exception e) {
         System.out.println ("Exception in test_simple_soap_1: " + e);
      }

      try {
         System.out.println ("test_repos_soap_1 - " + test_repos_soap_1());
      } catch (Exception e) {
         System.out.println ("Exception in test_repos_soap_1: " + e);
      }
   }
   public static String test_1() throws Exception {
xml    xml = new xml();
String str = "not called";

xml.create ("element");
str = xml.string ();
xml.close();
if ("<element/>".equals(str)) return ("ok");
return ("fail: " + str);
   }
   public static String test_2() throws Exception {
xml     xml = new xml();
boolean everything_ok = true;
String  problem = "";
String  str;

xml.create ("element");
xml.set ("attr1", "value1");
xml.set ("attr2", "value2");
str = xml.attrval ("attr1");
if (!str.equals("value1")) { everything_ok=false; problem += str + " "; }
str = xml.string ();
if (!str.equals("<element attr1=\"value1\" attr2=\"value2\"/>")) { everything_ok=false; problem += str + " "; }
xml.unset ("attr2");
str = xml.string ();
if (!str.equals("<element attr1=\"value1\"/>")) { everything_ok=false; problem += str + " "; }

xml.close();
if (everything_ok) return ("ok");
return ("fail: " + str);
   }
   public static String test_3() throws Exception {
xml     xml = new xml();
boolean everything_ok = true;
String  problem = "";
String  str;

xml.createtext ("this is a text node");
str = xml.string ();
if (!str.equals("this is a text node")) { everything_ok=false; problem += str + " "; }

xml.textcat (" - right?");
str = xml.string ();
if (!str.equals("this is a text node - right?")) { everything_ok=false; problem += str + " "; }

xml.close();
if (everything_ok) return ("ok");
return ("fail: " + str);
   }
   public static String test_4() throws Exception {
xml     xml1 = new xml();
xml     xml2 = new xml();
boolean everything_ok = true;
String  problem = "";
String  str;

xml1.create ("top");
xml2.create ("child");
xml1.append (xml2);
str = xml1.string ();
if (!str.equals("<top><child/></top>")) { everything_ok=false; problem += str + " "; }

xml2.close ();
xml2.create ("child2");
xml1.prepend (xml2);
str = xml1.string ();
if (!str.equals("<top><child2/><child/></top>")) { everything_ok=false; problem += str + " "; }

str = xml2.string();
if (!str.equals("<child2/>")) { everything_ok=false; problem += str + " "; }

xml2.close();
str = xml1.string ();
if (!str.equals("<top><child2/><child/></top>")) { everything_ok=false; problem += str + " "; }

xml1.close();

if (everything_ok) return ("ok");
return ("fail: " + problem);
   }
   public static String test_5() throws Exception {
xml     xml = new xml();
boolean everything_ok = true;
String  problem = "";
String  str;
String  test = "<top><child><inner-child/></child><child2/></top>";

try {
   xml.parse (test);
   str = xml.string ();
}
catch (Throwable e)
{
   str = "Exception thrown: " + e;
}
if (!str.equals(test)) { everything_ok=false; problem += "[a] " + str + " "; }
xml.close();

test = "<top><child>some text</child><child2>more text</child2></top>";
try {
   xml.parse (test);
   str = xml.string ();
}
catch (Throwable e)
{
   str = "Exception thrown: " + e;
}
if (!str.equals(test)) { everything_ok=false; problem += "[b] " + str + " "; }
xml.close();

test = "<top><child attr1=\"blargh\">some text</child><child2 enc:attr2=\"more blargh\">more text</child2></top>";
try {
   xml.parse (test);
   str = xml.string ();
}
catch (Throwable e)
{
   str = "Exception thrown: " + e;
}
if (!str.equals(test)) { everything_ok=false; problem += "[c] " + str + " "; }
xml.close();

if (everything_ok) return ("ok");
return ("fail: " + problem);
   }
   public static String test_6() throws Exception {
xml     xml1 = new xml();
boolean everything_ok = true;
String  problem = "";
String  str = "";
String  test = "<top><child><inner-child/></child><child id=\"second\" child=\"child2\"/></top>";

try {
   xml1.parse (test);
   str = xml1.string ();
}
catch (Throwable e)
{
   str = "Exception thrown: " + e;
}

xml xml2 = xml1.newhandle();
xml2.to_loc (".child");
if (!xml2.string().equals("<child><inner-child/></child>")) { everything_ok=false; problem += str + " "; }

xml2.to_parent();
xml2.to_loc (".child[second]");
if (!xml2.attrval ("child").equals ("child2")) { everything_ok=false; problem += "[b] couldn't find second child (found " + xml2.string() + ") "; }

xml2.to_parent();
xml2.to_loc (".child(1)");
if (!xml2.attrval ("child").equals ("child2")) { everything_ok=false; problem += "[c] couldn't find second child (found " + xml2.string() + ") "; }

xml2.close ();
xml1.close();

if (everything_ok) return ("ok");
return ("fail: " + problem);
   }
   public static String test_7() throws Exception {
xml     xml1 = new xml();
xml     xml2 = new xml();
boolean everything_ok = true;
String  problem = "";
String  str = "";
String  test = "<top><child><inner-child/></child><child id=\"second\" child=\"child2\"/></top>";

try {
   xml1.parse (test);
   xml2.parse (test);
}
catch (Throwable e)
{
   str = "Exception thrown: " + e;
}

xml xml3 = xml1.newhandle();
xml3.to_loc (".child");

xml xml4 = xml2.newhandle();
xml4.to_loc (".child[second]");

xml3.replace (xml4);

xml xml5 = xml2.new_copy();

System.out.println (xml1.string());
System.out.println (xml5.string());


xml5.close();
xml4.close();
xml3.close();
xml2.close();
xml1.close();

if (everything_ok) return ("ok");
return ("fail: " + problem);
   }
   public static String test_simple_soap_1() throws Exception {
String problems = "";
boolean everything_ok = true;

// TODO: "full" mode gives an error in xmlapi-j (stringcontenthtml) -- fix it, as this is kinda important.
simple_soap ss = new simple_soap("http://localhost:8000", "get");
ss.add_parm ("list_id", "Archivalienakzession");
ss.add_parm ("key", "wf1");
ss.add_parm ("mode", "edit");
ss.call();
if (ss.return_type !=0) { everything_ok = false; problems += "[a] return_type not 0 but " + ss.return_type; }
System.out.println (ss.simple_value);
System.out.println (ss.XMLResult);

simple_soap ss2 = new simple_soap("http://localhost:8000", "get");
ss2.add_parm ("list_id", "Archivalienakzession");
ss2.add_parm ("key", "1");
ss2.call();
if (ss2.return_type !=2) { everything_ok = false; problems += "[b] return_type not 2 but " + ss2.return_type; }
System.out.println (ss2.XMLResult);

simple_soap ss3 = new simple_soap("http://localhost:8000", "list");
ss3.add_parm ("list_id", "_lists");
ss3.call();
if (ss3.return_type !=1) { everything_ok = false; problems += "[c] return_type not 1 but " + ss3.return_type; }
System.out.println (ss3.XMLResult);

if (everything_ok) return ("ok");
return ("failed: " + problems);
   }
   public static String test_repos_soap_1() throws Exception {
String problems = "";
boolean everything_ok = true;

Repository r = new RemoteSOAPRepository("http://localhost:8000");
Entry e = r.get ("Archivalienakzession", "1");
System.out.println (e.values());

List l = r.list ("_lists");
System.out.println (l.keys());
List l2 = r.lists ();
System.out.println (l2.keys() + ", which has " + l2.count() + " elements.");

Entry e2 = new Entry(r, "Archivalienakzession");
System.out.println ("New rec:\n" + e2.html_edit() + "\n\n");

e2.set ("TBNR", "wftest1");
e2.set ("LO", "ha!");
e2.set ("SS", "n");
e2.set ("BEISPIEL", "beispielstext hier");

e2.add ();

System.out.println ("added new obj '" + e2.key() + "'");
System.out.println ("fields: " + e2.value_count() + " and keys " + e2.values() + "!");

System.out.println ("Display of obj:\n" + e2.html_display() + "\n\n");
System.out.println ("Edit of obj:\n" + e2.html_edit() + "\n\n");

e2.set ("LO", "different");
e2.update ();

e2.set ("LO", "something totally else");
System.out.println ("Value of LO: " + e2.get("LO"));
e2.refresh ();
System.out.println ("Value of LO: " + e2.get("LO"));

l = r.tasks();
System.out.println ("By tasks():");
System.out.println (l.keys());

for (int i = 0; i < l.count(); i++) {
   System.out.println ("Task " + i + ": " + l.get_label(l.get_key(i)));
}

Entry e3 = r.get("_tasks", (String) l.keys().get(0));
System.out.println ("is_task(" + e3.key() + ")? " + e3.is_task());
System.out.println ("fields: " + e3.values());

System.out.println ("display: " + e3.html_display() + "\n\n");

System.out.println ("fields: " + e3.values());

//e3.complete();

Entry e4 = new Entry(r, "Archivalienabgabe");
e4.set ("BEISPIEL", "mehr Beispielstext");

e4.add ();

System.out.println ("Key of new record: " + e4.key());

l = e4.tasks();
System.out.println ("Tasks attached to new record:");
for (int i = 0; i < l.count(); i++) {
   System.out.println ("Task " + i + " (" + l.get_key(i) + "): " + l.get_label(l.get_key(i)));
}

Entry e5 = e4.get_task(l.get_key(0));
System.out.println ("fields: " + e5.values());

System.out.println ("key: " + e5.key() + " (list)" + e5.list_id);
e5.complete();

if (everything_ok) return ("ok");
return ("failed: " + problems);
   }
}
