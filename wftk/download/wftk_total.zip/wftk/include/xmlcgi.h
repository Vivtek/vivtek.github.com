XML * xmlcgi_init ();
XML * xmlcgi_readstdin (XML * cgi, XML * list);
