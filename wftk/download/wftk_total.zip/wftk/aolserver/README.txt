This directory houses the AOLserver integration module, such as it is.
This is effectively a Tcl extension, but as I've only used Tcl in the AOLserver
context, I don't know what would be required to make of this module a pure
Tcl extension.

