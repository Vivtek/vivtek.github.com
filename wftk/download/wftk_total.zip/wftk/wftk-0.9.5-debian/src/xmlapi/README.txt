Under Windows, the XMLAPI is compiled into two DLLs; one links to LIBC.LIB
for the C runtime, and the other links to MSVCRT.LIB.  This twofold build is
necessary because the XMLAPI uses file handles passed in from the caller, and
the two sets of file handles are incompatible.  (Hey, good design in Redmond
on *that* one, I can tell you.)

Under Unix, on the other hand, the build stops at xmlapi.o.  This is simply
because I don't understand dynamic linking yet.  At some point it should also
be a shared library.  Right?

