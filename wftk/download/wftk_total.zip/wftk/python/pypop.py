#######################################################################################################
#
# This is a Python GUI framework for the wftk.
#
# Copyright (c) 2003, Vivtek, and released under the GPL.
#
#######################################################################################################
import wftk
import wxpywf
import repmgr_cli
from wxPython.wx import *
class main_window(wxFrame):
    def __init__(self, parent, id, title):
        wxFrame.__init__(self, parent, -1, title, size = (500, 500),
                         style=wxDEFAULT_FRAME_STYLE|wxNO_FULL_REPAINT_ON_RESIZE)
        self.CreateStatusBar (1, wxST_SIZEGRIP) 

        m = wftk.xml("""
          <menubar>
            <menu label="&amp;Repository">
              <item cmd="open" label="&amp;Open" help="Open a repository"/>
              <item cmd="cmd" label="&amp;Cmd" help="View command window"/>
              <item cmd="list _lists" label="&amp;Show lists" help="Show lists in active repository"/>
              <item cmd="options" label="&amp;Options" help="View and set user options"/>
              <separator/>
              <separator/>
              <item cmd="exit" label="&amp;Exit" help="Quit the program"/>
            </menu>
            <menu label="&amp;Synch">
              <menu label="Test second level" help="Additional help">
                <item cmd="thing" label="&amp;Test thing" help="Wonder if this will show up?"/>
              </menu>
              <item cmd="something else" label="Test, test"/>
            </menu>
          </menubar>""")

        self.cmdcontext = wftk.xml('<context/>')

        self.menu = wxpywf.menu (m, self, self.cmdcontext, repmgr_cli.cli(None))

        self.control = wxTextCtrl(self, -1, style=wxTE_MULTILINE)
        self.Show(true)
class App(wxApp):
    def OnInit(self):
        frame = main_window(None, -1, "bing boing")
        self.SetTopWindow(frame)
        return true

app = App(0)
app.MainLoop()
