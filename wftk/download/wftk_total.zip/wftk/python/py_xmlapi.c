#include <python.h>
#include "../xmlapi/xmlapi.h"
#include "../xmlapi/xmlobj.h"
static PyObject *py_xml_write(PyObject *self, PyObject *args);
static PyObject *py_xml_writecontent(PyObject *self, PyObject *args);
static PyObject *py_xml_writehtml(PyObject *self, PyObject *args);
static PyObject *py_xml_writecontenthtml(PyObject *self, PyObject *args);
static PyObject *py_xml_string(PyObject *self, PyObject *args);
static PyObject *py_xml_stringcontent(PyObject *self, PyObject *args);
static PyObject *py_xml_stringhtml(PyObject *self, PyObject *args);
static PyObject *py_xml_stringcontenthtml(PyObject *self, PyObject *args);
static PyObject *py_xml_prepend(PyObject *self, PyObject *args);
static PyObject *py_xml_append(PyObject *self, PyObject *args);
static PyObject *py_xml_append_pretty(PyObject *self, PyObject *args);
static PyObject *py_xml_replace(PyObject *self, PyObject *args);
static PyObject *py_xml_replacecontent(PyObject *self, PyObject *args);
static PyObject *py_xml_loc(PyObject *self, PyObject *args);
static PyObject *py_xml_getloc(PyObject *self, PyObject *args);
static PyObject *py_xml_set(PyObject *self, PyObject *args);
static PyObject *py_xml_attrval(PyObject *self, PyObject *args);
static PyObject *py_xml_attrlist(PyObject *self, PyObject *args);
static PyObject *py_xml_attrs(PyObject *self, PyObject *args);
static PyObject *py_xml_create(PyObject *self, PyObject *args);
static PyObject *py_xml_createtext(PyObject *self, PyObject *args);
static PyObject *py_xml_delete(PyObject *self, PyObject *args);
static PyObject *py_xml_is(PyObject *self, PyObject *args);
static PyObject *py_xml_name(PyObject *self, PyObject *args);
static PyObject *py_xml_is_element(PyObject *self, PyObject *args);
static PyObject *py_xml_parent(PyObject *self, PyObject *args);
static PyObject *py_xml_elements(PyObject *self, PyObject *args);
static PyObject *py_xml_first(PyObject *self, PyObject *args);
static PyObject *py_xml_firstelem(PyObject *self, PyObject *args);
static PyObject *py_xml_last(PyObject *self, PyObject *args);
static PyObject *py_xml_lastelem(PyObject *self, PyObject *args);
static PyObject *py_xml_next(PyObject *self, PyObject *args);
static PyObject *py_xml_nextelem(PyObject *self, PyObject *args);
static PyObject *py_xml_prev(PyObject *self, PyObject *args);
static PyObject *py_xml_prevelem(PyObject *self, PyObject *args);
static PyObject *py_xml_copy(PyObject *self, PyObject *args);
static PyObject *py_xml_copyinto(PyObject *self, PyObject *args);
static PyObject *py_xml_read(PyObject *self, PyObject *args);
static PyObject *py_xml_parse(PyObject *self, PyObject *args);
static PyObject *py_xml_search(PyObject *self, PyObject *args);
static PyObject *py_xml_search_all(PyObject *self, PyObject *args);
static PyObject *py_xml_toutf8_attr(PyObject *self, PyObject *args);
static PyObject *py_xml_toutf8_text(PyObject *self, PyObject *args);
static PyObject *py_xml_toraw_str(PyObject *self, PyObject *args);

static PyObject *py_xmlobj_field(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_is_field(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_get(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_getkey(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_set(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_set_elem(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_getconf(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_setconf(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_format(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_diff(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_patch(PyObject *self, PyObject *args);
static PyObject *py_xmlobj_undiff(PyObject *self, PyObject *args);
static PyMethodDef XMLAPIMethods[] = {
    {"xml_write",             py_xml_write,             METH_VARARGS},
    {"xml_writecontent",      py_xml_writecontent,      METH_VARARGS},
    {"xml_writehtml",         py_xml_writehtml,         METH_VARARGS},
    {"xml_writecontenthtml",  py_xml_writecontenthtml,  METH_VARARGS},
    {"xml_string",            py_xml_string,            METH_VARARGS},
    {"xml_stringcontent",     py_xml_stringcontent,     METH_VARARGS},
    {"xml_stringhtml",        py_xml_stringhtml,        METH_VARARGS},
    {"xml_stringcontenthtml", py_xml_stringcontenthtml, METH_VARARGS},
    {"xml_prepend",           py_xml_prepend,           METH_VARARGS},
    {"xml_append",            py_xml_append,            METH_VARARGS},
    {"xml_append_pretty",     py_xml_append_pretty,     METH_VARARGS},
    {"xml_replace",           py_xml_replace,           METH_VARARGS},
    {"xml_replacecontent",    py_xml_replacecontent,    METH_VARARGS},
    {"xml_loc",               py_xml_loc,               METH_VARARGS},
    {"xml_getloc",            py_xml_getloc,            METH_VARARGS},
    {"xml_set",               py_xml_set,               METH_VARARGS},
    {"xml_attrval",           py_xml_attrval,           METH_VARARGS},
    {"xml_attrlist",          py_xml_attrlist,          METH_VARARGS},
    {"xml_attrs",             py_xml_attrs,             METH_VARARGS},
    {"xml_create",            py_xml_create,            METH_VARARGS},
    {"xml_createtext",        py_xml_createtext,        METH_VARARGS},
    {"xml_delete",            py_xml_delete,            METH_VARARGS},
    {"xml_is",                py_xml_is,                METH_VARARGS},
    {"xml_name",              py_xml_name,              METH_VARARGS},
    {"xml_is_element",        py_xml_is_element,        METH_VARARGS},
    {"xml_parent",            py_xml_parent,            METH_VARARGS},
    {"xml_elements",          py_xml_elements,          METH_VARARGS},
    {"xml_first",             py_xml_first,             METH_VARARGS},
    {"xml_firstelem",         py_xml_firstelem,         METH_VARARGS},
    {"xml_next",              py_xml_next,              METH_VARARGS},
    {"xml_nextelem",          py_xml_nextelem,          METH_VARARGS},
    {"xml_last",              py_xml_last,              METH_VARARGS},
    {"xml_lastelem",          py_xml_lastelem,          METH_VARARGS},
    {"xml_prev",              py_xml_prev,              METH_VARARGS},
    {"xml_prevelem",          py_xml_prevelem,          METH_VARARGS},
    {"xml_copy",              py_xml_copy,              METH_VARARGS},
    {"xml_copyinto",          py_xml_copyinto,          METH_VARARGS},
    {"xml_read",              py_xml_read,              METH_VARARGS},
    {"xml_parse",             py_xml_parse,             METH_VARARGS},
    {"xml_search",            py_xml_search,            METH_VARARGS},
    {"xml_search_all",        py_xml_search_all,        METH_VARARGS},
    {"xml_toutf8_attr",       py_xml_toutf8_attr,       METH_VARARGS},
    {"xml_toutf8_text",       py_xml_toutf8_text,       METH_VARARGS},
    {"xml_toraw_str",         py_xml_toraw_str,         METH_VARARGS},

    {"xmlobj_field",          py_xmlobj_field,          METH_VARARGS},
    {"xmlobj_is_field",       py_xmlobj_is_field,       METH_VARARGS},
    {"xmlobj_get",            py_xmlobj_get,            METH_VARARGS},
    {"xmlobj_getkey",         py_xmlobj_getkey,         METH_VARARGS},
    {"xmlobj_set",            py_xmlobj_set,            METH_VARARGS},
    {"xmlobj_set_elem",       py_xmlobj_set_elem,       METH_VARARGS},
    {"xmlobj_getconf",        py_xmlobj_getconf,        METH_VARARGS},
    {"xmlobj_setconf",        py_xmlobj_setconf,        METH_VARARGS},
    {"xmlobj_format",         py_xmlobj_format,         METH_VARARGS},
    {"xmlobj_diff",           py_xmlobj_diff,           METH_VARARGS},
    {"xmlobj_patch",          py_xmlobj_patch,          METH_VARARGS},
    {"xmlobj_undiff",         py_xmlobj_undiff,         METH_VARARGS},
    {NULL, NULL}
 };
void initxmlapi()
{
    (void) Py_InitModule("xmlapi", XMLAPIMethods);
}
static void py_xml_cleanup (void * xml, void *parent)
{
   if (parent) Py_DECREF ((PyObject *) parent);
   else (xml_free ((XML *) xml));
}
static PyObject *py_xml_parse(PyObject *self, PyObject *args)
{
   char * xml_in;
   XML * xml_out;

   if (!PyArg_ParseTuple(args, "s", &xml_in)) return NULL;
   xml_out = xml_parse (xml_in);
   if (xml_is (xml_out, "xml-error")) {
      PyErr_SetString(PyExc_IOError, xml_attrval (xml_out, "message"));
      xml_free (xml_out);
      return NULL;
   }
   return PyCObject_FromVoidPtrAndDesc (xml_out, (void *) Py_BuildValue(""), py_xml_cleanup);
}
static PyObject *py_xml_string(PyObject *self, PyObject *args)
{
   PyObject * arg;
   char * xml_out;

   if (!PyArg_ParseTuple(args, "O", &arg)) return NULL;
   if (!PyCObject_Check (arg)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   xml_out = xml_string ((XML *) (PyCObject_AsVoidPtr (arg)));
   arg = Py_BuildValue ("s", xml_out);
   free (xml_out);
   return arg;
}
static PyObject *py_xml_set(PyObject *self, PyObject *args)
{
   PyObject * xml_obj;
   char * attr;
   char * value;

   if (!PyArg_ParseTuple(args, "Oss", &xml_obj, &attr, &value)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   xml_set ((XML *) PyCObject_AsVoidPtr (xml_obj), attr, value);
   return Py_BuildValue("");
}
static PyObject *py_xml_loc(PyObject *self, PyObject *args)
{
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;
   char * loc;

   if (!PyArg_ParseTuple(args, "Os", &xml_obj, &loc)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_loc ((XML *) PyCObject_AsVoidPtr (xml_obj), loc);

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      PyErr_SetString (PyExc_IndexError, "location not found");
      return NULL;
   }
}
static PyObject *py_xml_append(PyObject *self, PyObject *args)
{
   PyObject * parent;
   PyObject * child;
   XML * chi;

   if (!PyArg_ParseTuple(args, "OO", &parent, &child)) return NULL;
   if (!PyCObject_Check (parent)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }

   if (PyCObject_Check (child)) {
      chi = xml_copy ((XML *) PyCObject_AsVoidPtr (child));
   } else if (PyString_Check (child)) {
      chi = xml_parse (PyString_AsString (child));
      if (xml_is (chi, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (chi, "message"));
         xml_free (chi);
         return NULL;
      }
   } else {
      PyErr_SetString (PyExc_TypeError, "appendee not XML object or string");
      return NULL;
   }

   xml_append ((XML *) PyCObject_AsVoidPtr (parent), chi);
   return Py_BuildValue("");
}
static PyObject *py_xml_prepend(PyObject *self, PyObject *args)
{
   PyObject * parent;
   PyObject * child;
   XML * chi;

   if (!PyArg_ParseTuple(args, "OO", &parent, &child)) return NULL;
   if (!PyCObject_Check (parent)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }

   if (PyCObject_Check (child)) {
      chi = xml_copy ((XML *) PyCObject_AsVoidPtr (child));
   } else if (PyString_Check (child)) {
      chi = xml_parse (PyString_AsString (child));
      if (xml_is (chi, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (chi, "message"));
         xml_free (chi);
         return NULL;
      }
   } else {
      PyErr_SetString (PyExc_TypeError, "prependee not XML object or string");
      return NULL;
   }

   xml_prepend ((XML *) PyCObject_AsVoidPtr (parent), chi);
   return Py_BuildValue("");
}

static PyObject *py_xml_replace(PyObject *self, PyObject *args)
{
   PyObject * parent;
   PyObject * child;
   XML * chi;

   if (!PyArg_ParseTuple(args, "OO", &parent, &child)) return NULL;
   if (!PyCObject_Check (parent)) {
      PyErr_SetString (PyExc_TypeError, "replacee not XML object");
      return NULL;
   }

   if (PyCObject_Check (child)) {
      chi = xml_copy ((XML *) PyCObject_AsVoidPtr (child));
   } else if (PyString_Check (child)) {
      chi = xml_parse (PyString_AsString (child));
      if (xml_is (chi, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (chi, "message"));
         xml_free (chi);
         return NULL;
      }
   } else {
      PyErr_SetString (PyExc_TypeError, "replacement not XML object or string");
      return NULL;
   }

   xml_replace ((XML *) PyCObject_AsVoidPtr (parent), chi);
   return Py_BuildValue("");
}

static PyObject *py_xml_replacecontent(PyObject *self, PyObject *args)
{
   PyObject * parent;
   PyObject * child;
   XML * chi;

   if (!PyArg_ParseTuple(args, "OO", &parent, &child)) return NULL;
   if (!PyCObject_Check (parent)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }

   if (PyCObject_Check (child)) {
      chi = xml_copy ((XML *) PyCObject_AsVoidPtr (child));
   } else if (PyString_Check (child)) {
      chi = xml_parse (PyString_AsString (child));
      if (xml_is (chi, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (chi, "message"));
         xml_free (chi);
         return NULL;
      }
   } else {
      PyErr_SetString (PyExc_TypeError, "replacement not XML object or string");
      return NULL;
   }

   xml_replacecontent ((XML *) PyCObject_AsVoidPtr (parent), chi);
   return Py_BuildValue("");
}
static PyObject *py_xml_copyinto(PyObject *self, PyObject *args) {
   PyObject * parent;
   PyObject * child;
   XML * chi;

   if (!PyArg_ParseTuple(args, "OO", &parent, &child)) return NULL;
   if (!PyCObject_Check (parent)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }

   if (PyCObject_Check (child)) {
      xml_copyinto ((XML *) PyCObject_AsVoidPtr(parent), (XML *) PyCObject_AsVoidPtr (child));
      return Py_BuildValue("");
   } else if (PyString_Check (child)) {
      chi = xml_parse (PyString_AsString (child));
      if (xml_is (chi, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (chi, "message"));
         xml_free (chi);
         return NULL;
      }
      xml_copyinto ((XML *) PyCObject_AsVoidPtr (parent), chi);
      xml_free (chi);
      return Py_BuildValue("");
   }

   PyErr_SetString (PyExc_TypeError, "replacement not XML object or string");
   return NULL;
}
static PyObject *py_xml_stringcontent(PyObject *self, PyObject *args) {
   PyObject * arg;
   char * xml_out;

   if (!PyArg_ParseTuple(args, "O", &arg)) return NULL;
   if (!PyCObject_Check (arg)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   xml_out = xml_stringcontent ((XML *) (PyCObject_AsVoidPtr (arg)));
   arg = Py_BuildValue ("s", xml_out);
   free (xml_out);
   return arg;
}
static PyObject *py_xml_stringhtml(PyObject *self, PyObject *args) {
   PyObject * arg;
   char * xml_out;

   if (!PyArg_ParseTuple(args, "O", &arg)) return NULL;
   if (!PyCObject_Check (arg)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   xml_out = xml_stringhtml ((XML *) (PyCObject_AsVoidPtr (arg)));
   arg = Py_BuildValue ("s", xml_out);
   free (xml_out);
   return arg;
}
static PyObject *py_xml_stringcontenthtml(PyObject *self, PyObject *args) {
   PyObject * arg;
   char * xml_out;

   if (!PyArg_ParseTuple(args, "O", &arg)) return NULL;
   if (!PyCObject_Check (arg)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   xml_out = xml_stringcontenthtml ((XML *) (PyCObject_AsVoidPtr (arg)));
   arg = Py_BuildValue ("s", xml_out);
   free (xml_out);
   return arg;
}
static PyObject *py_xml_getloc(PyObject *self, PyObject *args) {
   PyObject * arg;
   char * str_out;

   if (!PyArg_ParseTuple(args, "O", &arg)) return NULL;
   if (!PyCObject_Check (arg)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   str_out = xml_getlocbuf ((XML *) (PyCObject_AsVoidPtr (arg)));
   arg = Py_BuildValue ("s", str_out);
   free (str_out);
   return arg;
}
static PyObject *py_xml_attrval(PyObject *self, PyObject *args) {
   PyObject * arg;
   char * attr;
   const char * str_out;

   if (!PyArg_ParseTuple(args, "Os", &arg, &attr)) return NULL;
   if (!PyCObject_Check (arg)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   str_out = xml_attrval ((XML *) (PyCObject_AsVoidPtr (arg)), attr);
   arg = Py_BuildValue ("s", str_out);
   return arg;
}
static PyObject *py_xml_create(PyObject *self, PyObject *args) {
   char * str_in;
   XML * xml_out;

   if (!PyArg_ParseTuple(args, "s", &str_in)) return NULL;
   xml_out = xml_create (str_in);
   return PyCObject_FromVoidPtrAndDesc (xml_out, (void *) Py_BuildValue(""), py_xml_cleanup);
}
static PyObject *py_xml_createtext(PyObject *self, PyObject *args) {
   char * str_in;
   XML * xml_out;

   if (!PyArg_ParseTuple(args, "s", &str_in)) return NULL;
   xml_out = xml_createtext (str_in);
   return PyCObject_FromVoidPtrAndDesc (xml_out, (void *) Py_BuildValue(""), py_xml_cleanup);
}
static PyObject *py_xml_is(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   char * name;

   if (!PyArg_ParseTuple(args, "Os", &xml_obj, &name)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   if (xml_is ((XML *) PyCObject_AsVoidPtr (xml_obj), name))
      return Py_BuildValue ("i", 1);
   else
      return Py_BuildValue("");
}
static PyObject *py_xml_name(PyObject *self, PyObject *args) {
   PyObject * xml_obj;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   return PyString_FromString (xml_name ((XML *) PyCObject_AsVoidPtr (xml_obj)));
}
static PyObject *py_xml_is_element(PyObject *self, PyObject *args) {
   PyObject * xml_obj;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   if (xml_is_element ((XML *) PyCObject_AsVoidPtr (xml_obj)))
      return Py_BuildValue ("i", 1);
   else
      return Py_BuildValue("");
}
static PyObject *py_xml_parent(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * root;
   XML * parent;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   root = PyCObject_GetDesc (xml_obj);
   if (root == Py_None) return Py_BuildValue(""); /* If this *is* the root, then it has no parent.  Simple. */

   parent = xml_parent ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (PyCObject_AsVoidPtr (root) == parent) return (root);

   Py_INCREF (root);
   return PyCObject_FromVoidPtrAndDesc ((void *) parent, (void *) root, py_xml_cleanup);
}
static PyObject *py_xml_copy(PyObject *self, PyObject *args) {
   PyObject * src;
   XML * xml_out;

   if (!PyArg_ParseTuple(args, "O", &src)) return NULL;
   if (PyCObject_Check (src)) {
      xml_out = xml_copy ((XML *) PyCObject_AsVoidPtr (src));
   } else if (PyString_Check (src)) {
      xml_out = xml_parse (PyString_AsString (src));
      if (xml_is (xml_out, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (xml_out, "message"));
         xml_free (xml_out);
         return NULL;
      }
   } else {
      PyErr_SetString (PyExc_TypeError, "source not XML object or string");
      return NULL;
   }

   return PyCObject_FromVoidPtrAndDesc (xml_out, (void *) Py_BuildValue(""), py_xml_cleanup);
}
static PyObject *py_xml_delete(PyObject *self, PyObject *args) {
   PyObject * xml_obj;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_GetDesc (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "xml_delete can't be called on top-level XML structure");
      return NULL;
   }

   xml_delete ((XML *) PyCObject_AsVoidPtr (xml_obj));
   return Py_BuildValue("");
}
static PyObject *py_xml_write(PyObject *self, PyObject *args) {
   PyObject * file;
   FILE * f;
   PyObject * xml_obj;
   XML * xml;

   if (!PyArg_ParseTuple(args, "OO", &file, &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }
   xml = (XML *) PyCObject_AsVoidPtr (xml_obj);

   if (PyFile_Check(file)) {
      xml_write (PyFile_AsFile (file), xml);
      return Py_BuildValue("");
   }

   if (PyString_Check(file)) {
      f = fopen (PyString_AsString (file), "w");
      if (!f) {
         PyErr_SetString (PyExc_IOError, "can't open file for output");
         return NULL;
      }
      xml_write (f, xml);
      fclose (f);
      return Py_BuildValue("");
   }

   PyErr_SetString (PyExc_TypeError, "file neither file object nor path string");
   return NULL;
}
static PyObject *py_xml_writecontent(PyObject *self, PyObject *args) {
   PyObject * file;
   FILE * f;
   PyObject * xml_obj;
   XML * xml;

   if (!PyArg_ParseTuple(args, "OO", &file, &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }
   xml = (XML *) PyCObject_AsVoidPtr (xml_obj);

   if (PyFile_Check(file)) {
      xml_write (PyFile_AsFile (file), xml);
      return Py_BuildValue("");
   }

   if (PyString_Check(file)) {
      f = fopen (PyString_AsString (file), "w");
      if (!f) {
         PyErr_SetString (PyExc_IOError, "can't open file for output");
         return NULL;
      }
      xml_write (f, xml);
      fclose (f);
      return Py_BuildValue("");
   }

   PyErr_SetString (PyExc_TypeError, "file neither file object nor path string");
   return NULL;
}
static PyObject *py_xml_writehtml(PyObject *self, PyObject *args) {
   PyObject * file;
   FILE * f;
   PyObject * xml_obj;
   XML * xml;

   if (!PyArg_ParseTuple(args, "OO", &file, &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }
   xml = (XML *) PyCObject_AsVoidPtr (xml_obj);

   if (PyFile_Check(file)) {
      xml_write (PyFile_AsFile (file), xml);
      return Py_BuildValue("");
   }

   if (PyString_Check(file)) {
      f = fopen (PyString_AsString (file), "w");
      if (!f) {
         PyErr_SetString (PyExc_IOError, "can't open file for output");
         return NULL;
      }
      xml_write (f, xml);
      fclose (f);
      return Py_BuildValue("");
   }

   PyErr_SetString (PyExc_TypeError, "file neither file object nor path string");
   return NULL;
}
static PyObject *py_xml_writecontenthtml(PyObject *self, PyObject *args) {
   PyObject * file;
   FILE * f;
   PyObject * xml_obj;
   XML * xml;

   if (!PyArg_ParseTuple(args, "OO", &file, &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }
   xml = (XML *) PyCObject_AsVoidPtr (xml_obj);

   if (PyFile_Check(file)) {
      xml_write (PyFile_AsFile (file), xml);
      return Py_BuildValue("");
   }

   if (PyString_Check(file)) {
      f = fopen (PyString_AsString (file), "w");
      if (!f) {
         PyErr_SetString (PyExc_IOError, "can't open file for output");
         return NULL;
      }
      xml_write (f, xml);
      fclose (f);
      return Py_BuildValue("");
   }

   PyErr_SetString (PyExc_TypeError, "file neither file object nor path string");
   return NULL;
}
static PyObject *py_xml_read(PyObject *self, PyObject *args) {
   PyObject * file;
   FILE * f;
   XML * xml_out;

   if (!PyArg_ParseTuple(args, "O", &file)) return NULL;

   if (PyFile_Check(file)) {
      xml_out = xml_parse_general ((void *) PyFile_AsFile (file), (XMLAPI_DATARETRIEVE) fread);
   } else if (PyString_Check(file)) {
      f = fopen (PyString_AsString (file), "r");
      if (!f) {
         PyErr_SetString (PyExc_IOError, "can't open file for input");
         return NULL;
      }
      xml_out = xml_parse_general ((void *) f, (XMLAPI_DATARETRIEVE) fread);
      fclose (f);
   } else {
      PyErr_SetString (PyExc_TypeError, "file neither file object nor path string");
      return NULL;
   }

   if (xml_is (xml_out, "xml-error")) {
      PyErr_SetString(PyExc_IOError, xml_attrval (xml_out, "message"));
      xml_free (xml_out);
      return NULL;
   }
   return PyCObject_FromVoidPtrAndDesc (xml_out, (void *) Py_BuildValue(""), py_xml_cleanup);

}
static PyObject *py_xml_attrlist(PyObject *self, PyObject *args)
{
   PyObject * xml_obj;
   XML * xml;
   XML_ATTR * attr;
   PyObject * list;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   xml = (XML *) PyCObject_AsVoidPtr (xml_obj);

   list = PyList_New (0);

   attr = xml_attrfirst (xml);
   while (attr) {
      PyList_Append (list, PyString_FromString (xml_attrname (attr)));
      attr = xml_attrnext (attr);
   }

   return (list);
}
static PyObject *py_xml_attrs(PyObject *self, PyObject *args)
{
   PyObject * xml_obj;
   XML * xml;
   XML_ATTR * attr;
   PyObject * dict;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   xml = (XML *) PyCObject_AsVoidPtr (xml_obj);

   dict = PyDict_New ();

   attr = xml_attrfirst (xml);
   while (attr) {
      PyDict_SetItem (dict, PyString_FromString (xml_attrname (attr)), PyString_FromString (xml_attrvalue (attr)));
      attr = xml_attrnext (attr);
   }

   return (dict);
}
static PyObject *py_xml_first(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_first ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_firstelem(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_firstelem ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_last(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_last ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_lastelem(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_lastelem ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_next(PyObject *self, PyObject *args) {   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_next ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_nextelem(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_nextelem ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_prev(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_prev ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_prevelem(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_prevelem ((XML *) PyCObject_AsVoidPtr (xml_obj));

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_elements(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   PyObject * list;
   XML * found;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   list = PyList_New (0);

   found = xml_firstelem ((XML *) PyCObject_AsVoidPtr (xml_obj));

   while (found) {
      Py_INCREF (parent);
      PyList_Append (list, PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup));
      found = xml_nextelem (found);
   }

   return (list);
}
static PyObject *py_xml_toutf8_attr(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   char * attr;

   if (!PyArg_ParseTuple(args, "Os", &xml_obj, &attr)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   return Py_BuildValue ("i", xml_toutf8_attr ((XML *) PyCObject_AsVoidPtr (xml_obj), attr));
}
static PyObject *py_xml_toutf8_text(PyObject *self, PyObject *args) {
   PyObject * xml_obj;

   if (!PyArg_ParseTuple(args, "O", &xml_obj)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   return Py_BuildValue ("i", xml_toutf8_text ((XML *) PyCObject_AsVoidPtr (xml_obj)));
}
static PyObject *py_xml_toraw_str(PyObject *self, PyObject *args) {
   char * str;
   char * out;
   PyObject * outobj;

   if (!PyArg_ParseTuple(args, "s", &str)) return NULL;

   out = (char *) malloc (strlen (str));
   xml_toraw_str (out, str);
   outobj = Py_BuildValue ("s", out);
   free (out);
   return outobj;
}
static PyObject *py_xml_search(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   char * element = NULL;
   char * attr = NULL;
   char * value = NULL;
   XML * found;

   if (!PyArg_ParseTuple(args, "O|zzz", &xml_obj, &element, &attr, &value)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   found = xml_search ((XML *) PyCObject_AsVoidPtr (xml_obj), element, attr, value);

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xml_search_all(PyObject *self, PyObject *args) {
   PyObject * xml_obj;
   PyObject * parent;
   PyObject * list;
   char * element = NULL;
   char * attr = NULL;
   char * value = NULL;
   XML * found;

   if (!PyArg_ParseTuple(args, "O|zzz", &xml_obj, &element, &attr, &value)) return NULL;
   if (!PyCObject_Check (xml_obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (xml_obj);
   if (parent == Py_None) parent = xml_obj;

   list = PyList_New (0);

   found = xml_search ((XML *) PyCObject_AsVoidPtr (xml_obj), element, attr, value);
   while (found) {
      Py_INCREF (parent);
      PyList_Append (list, PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup));
      found = xml_search_next ((XML *) PyCObject_AsVoidPtr (xml_obj), found, element, attr, value);
   }

   return (list);
}
static PyObject *py_xml_append_pretty(PyObject *self, PyObject *args)
{
   PyObject * parent;
   PyObject * child;
   XML * chi;

   if (!PyArg_ParseTuple(args, "OO", &parent, &child)) return NULL;
   if (!PyCObject_Check (parent)) {
      PyErr_SetString (PyExc_TypeError, "parent not XML object");
      return NULL;
   }

   if (PyCObject_Check (child)) {
      chi = xml_copy ((XML *) PyCObject_AsVoidPtr (child));
   } else if (PyString_Check (child)) {
      chi = xml_parse (PyString_AsString (child));
      if (xml_is (chi, "xml-error")) {
         PyErr_SetString(PyExc_IOError, xml_attrval (chi, "message"));
         xml_free (chi);
         return NULL;
      }
   } else {
      PyErr_SetString (PyExc_TypeError, "appendee not XML object or string");
      return NULL;
   }

   xml_append_pretty ((XML *) PyCObject_AsVoidPtr (parent), chi);
   return Py_BuildValue("");
}
static PyObject *py_xmlobj_field(PyObject *self, PyObject *args) {
   PyObject * obj;
   PyObject * class;
   PyObject * parent;
   char * field = NULL;
   XML * found;

   if (!PyArg_ParseTuple(args, "OOs", &obj, &class, &field)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (obj);
   if (parent == Py_None) parent = obj;

   found = xmlobj_field ((XML *) PyCObject_AsVoidPtr (obj), (XML *) PyCObject_AsVoidPtr (class), field);

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xmlobj_is_field(PyObject *self, PyObject *args) {
   PyObject * obj;
   PyObject * class;
   PyObject * parent;
   char * field = NULL;
   XML * found;

   if (!PyArg_ParseTuple(args, "OOs", &obj, &class, &field)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   parent = PyCObject_GetDesc (obj);
   if (parent == Py_None) parent = obj;

   found = xmlobj_is_field ((XML *) PyCObject_AsVoidPtr (obj), (XML *) PyCObject_AsVoidPtr (class), field);

   if (found) {
      Py_INCREF (parent);
      return PyCObject_FromVoidPtrAndDesc ((void *) found, (void *) parent, py_xml_cleanup);
   } else {
      return Py_BuildValue("");
   }
}
static PyObject *py_xmlobj_get(PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   char * field;
   char * value;
   PyObject * ret;

   if (!PyArg_ParseTuple(args, "OOs", &obj, &class, &field)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   value = xmlobj_get ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), field);

   if (value) {
      ret = Py_BuildValue ("s", value);
      free ((void *) value);
   } else {
      ret = Py_BuildValue ("");
   }

   return ret;
}
static PyObject *py_xmlobj_getkey(PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   char * field;
   char * value;
   PyObject * ret;

   if (!PyArg_ParseTuple(args, "OOs", &obj, &class, &field)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   value = xmlobj_getkey ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class));

   if (value) {
      ret = Py_BuildValue ("s", value);
      free ((void *) value);
   } else {
      ret = Py_BuildValue ("");
   }

   return ret;
}
static PyObject *py_xmlobj_set(PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   char * field;
   char * value;

   if (!PyArg_ParseTuple(args, "OOss", &obj, &class, &field, &value)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   xmlobj_set ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), field, value);

   return Py_BuildValue("");
}
static PyObject *py_xmlobj_set_elem(PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   char * field;
   char * value;

   if (!PyArg_ParseTuple(args, "OOss", &obj, &class, &field, &value)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   xmlobj_set_elem ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), field, value);

   return Py_BuildValue("");
}
static PyObject *py_xmlobj_getconf(PyObject *self, PyObject *args)
{
   PyObject * obj;
   char * field;
   char * def = "";
   char * value;
   PyObject * ret;

   if (!PyArg_ParseTuple(args, "Os|s", &obj, &field, &def)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   value = xmlobj_getconf ((XML *) PyCObject_AsVoidPtr (obj), field, def);

   if (value) {
      ret = Py_BuildValue ("s", value);
      free ((void *) value);
   } else {
      ret = Py_BuildValue ("");
   }

   return ret;
}
static PyObject *py_xmlobj_setconf(PyObject *self, PyObject *args)
{
   PyObject * obj;
   char * field;
   char * value;

   if (!PyArg_ParseTuple(args, "Oss", &obj, &field, &value)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   xmlobj_setconf ((XML *) PyCObject_AsVoidPtr (obj), field, value);

   return Py_BuildValue("");
}
static PyObject *py_xmlobj_format(PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   char * format;
   char * value;
   PyObject * ret;

   if (!PyArg_ParseTuple(args, "OOs", &obj, &class, &format)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }

   value = xmlobj_format ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), format);

   if (value) {
      ret = Py_BuildValue ("s", value);
      free ((void *) value);
   } else {
      ret = Py_BuildValue ("");
   }

   return ret;
}
static PyObject *py_xmlobj_diff (PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   PyObject * changed;
   XML * diff;

   if (!PyArg_ParseTuple(args, "OOO", &obj, &class, &changed)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }
   if (!PyCObject_Check (changed)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   diff = xmlobj_diff ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), (XML *) PyCObject_AsVoidPtr (changed));

   return PyCObject_FromVoidPtrAndDesc (diff, (void *) Py_BuildValue(""), py_xml_cleanup);
}

static PyObject *py_xmlobj_patch (PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   PyObject * changed;
   XML * diff;

   if (!PyArg_ParseTuple(args, "OOO", &obj, &class, &changed)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }
   if (!PyCObject_Check (changed)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   diff = xmlobj_patch ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), (XML *) PyCObject_AsVoidPtr (changed));

   return PyCObject_FromVoidPtrAndDesc (diff, (void *) Py_BuildValue(""), py_xml_cleanup);
}

static PyObject *py_xmlobj_undiff (PyObject *self, PyObject *args)
{
   PyObject * obj;
   PyObject * class;
   PyObject * changed;
   XML * diff;

   if (!PyArg_ParseTuple(args, "OOO", &obj, &class, &changed)) return NULL;
   if (!PyCObject_Check (obj)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }
   if (!PyCObject_Check (class) && class != Py_None) {
      PyErr_SetString (PyExc_TypeError, "class not XML object");
      return NULL;
   }
   if (!PyCObject_Check (changed)) {
      PyErr_SetString (PyExc_TypeError, "arg not XML object");
      return NULL;
   }

   diff = xmlobj_undiff ((XML *) PyCObject_AsVoidPtr (obj), class == Py_None ? NULL : (XML *) PyCObject_AsVoidPtr (class), (XML *) PyCObject_AsVoidPtr (changed));

   return PyCObject_FromVoidPtrAndDesc (diff, (void *) Py_BuildValue(""), py_xml_cleanup);
}
