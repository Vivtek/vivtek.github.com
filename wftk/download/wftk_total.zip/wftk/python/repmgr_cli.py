################################################################################################
#
# Repmgr CLI: command handler for wftk repository manager
#
# Copyright (c) 2003 Vivtek, released under GPL
#
################################################################################################

import wftk
from string import *

class cli:
   def __init__ (self, repository):
      self.repository = repository
      self.mode = 0
      self.commands={}
      self.commands['publish']  = ['publish',  self.publish,  0, 2, '[list] [key]']
      self.commands['make']     = ['make',     self.make,     0, 1, '[page]']
      self.commands['add']      = ['add',      self.add,      2, 2, '[list] [what]']
      self.commands['del']      = ['del',      self.del_,      2, 2, '[list] [key]']
      self.commands['mod']      = ['mod',      self.mod,      2, 3, '[list] [file] [key]']
      self.commands['merge']    = ['merge',    self.merge,    3, 3, '[list] [file] [key]']
      self.commands['changed']  = ['changed',  self.changed,  2, 2, '[list] [key]']
      self.commands['diff']     = ['diff',     self.diff,     3, 3, '[list] [key] [file]']
      self.commands['test']     = ['test',     self.test,     1, 1, '[file]']
      self.commands['list']     = ['list',     self.list,     1, 1, '[list]']
      self.commands['changes']  = ['changes',  self.changes,  1, 2, '[date] [list]']
      self.commands['get']      = ['get',      self.get,      2, 2, '[list] [key]']
      self.commands['edit']     = ['edit',     self.edit,     2, 2, '[list] [key]']
      self.commands['display']  = ['display',  self.display,  2, 2, '[list] [key]']
      self.commands['form']     = ['form',     self.form,     1, 1, '[list]']
      self.commands['defn']     = ['defn',     self.defn,     1, 1, '[list]']
      self.commands['define']   = ['define',   self.define,   2, 2, '[list] [file]'] # Maybe...
      self.commands['push']     = ['push',     self.push,     1, 2, '[list] [remote]']
      self.commands['push_all'] = ['push_all', self.push_all, 1, 2, '[list] [remote]']
      self.commands['pull']     = ['pull',     self.pull,     1, 2, '[list] [remote]']
      self.commands['pull_all'] = ['pull_all', self.pull_all, 1, 2, '[list] [remote]']
      self.commands['synch']    = ['synch',    self.synch,    1, 2, '[list] [remote]']
      self.commands['submit']   = ['submit',   self.submit,   2, 2, '[list] [file]']
      self.commands['store']    = ['store',    self.store,    3, 3, '[list] [fname] [file]']
      self.commands['attach']   = ['attach',   self.attach,   4, 4, '[list] [key] [fld] [file]']
      self.commands['retrieve'] = ['retrieve', self.retrieve, 3, 4, '[list] [key] [fld] [file]']
      self.commands['checkout'] = ['checkout', self.checkout, 2, 3, '[list] [key] [fld]']
      self.commands['getver']   = ['getver',   self.getver,   2, 3, '[list] [key] [fld]']
      self.commands['time']     = ['time',     self.time,     0, 0, '']
   def mode(self, mode):
      self.mode = mode

   def do(self, context, cmdlist, obj=None):
      if type(cmdlist)==type(''):
         cmdlist = split(cmdlist)
      try:
         cmd = self.commands[cmdlist[0]]
      except:
         return None

      if len(cmdlist) - 1 < cmd[2] or len(cmdlist) - 1 > cmd[3]:
         return [1, 'Usage: %s %s' % (cmd[0], cmd[4])]

      return cmd[1](context, cmdlist[:1], obj)
   def publish(self, context, args, obj):
      return 0;
   def make(self, context, args, obj):
      return 0;
   def add(self, context, args, obj):
      return 0;
   def del_(self, context, args, obj):
      return 0;
   def mod(self, context, args, obj):
      return 0;
   def merge(self, context, args, obj):
      return 0;
   def changed(self, context, args, obj):
      return 0;
   def diff(self, context, args, obj):
      return 0;
   def test(self, context, args, obj):
      return 0;
   def list(self, context, args, obj):
      return 0;
   def changes(self, context, args, obj):
      return 0;
   def get(self, context, args, obj):
      return 0;
   def edit(self, context, args, obj):
      return 0;
   def display(self, context, args, obj):
      return 0;
   def form(self, context, args, obj):
      return 0;
   def defn(self, context, args, obj):
      return 0;
   def define(self, context, args, obj):
      return 0;
   def push(self, context, args, obj):
      return 0;
   def push_all(self, context, args, obj):
      return 0;
   def pull(self, context, args, obj):
      return 0;
   def pull_all(self, context, args, obj):
      return 0;
   def synch(self, context, args, obj):
      return 0;
   def submit(self, context, args, obj):
      return 0;
   def store(self, context, args, obj):
      return 0;
   def attach(self, context, args, obj):
      return 0;
   def retrieve(self, context, args, obj):
      return 0;
   def checkout(self, context, args, obj):
      return 0;
   def getver(self, context, args, obj):
      return 0;
   def time(self, context, args, obj):
      return 0;
