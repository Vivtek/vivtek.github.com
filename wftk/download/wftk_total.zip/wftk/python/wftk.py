#######################################################################################################
#
# This is a Python implementation of the wftk class schema.  It is the first such implementation.
#
# It's frustrating that my LPML tool can't do Python, due to its inability to preserve indentation.
# Maybe it's time to re-implement LPML....
#
# Copyright (c) 2002, Vivtek, and released under the GPL.
#
#######################################################################################################
import repmgr
import xmlapi
from types import *
ParseError = "Error parsing XML"
class xml:
   """Implements a convenient class on top of the XMLAPI library.
   """
   def __init__ (self, str=None):
      """Create XML object from optional string input"""
      self._xml = None
      self._iterparent = None
      if str:
         try:
            self.parse (str)
         except ParseError, message:
            raise ParseError, message

   # --------------------------------------------------------------
   # Formatting XML strings.
   # --------------------------------------------------------------
   def __str__ (self):
      if self._xml == None: return ""
      return xmlapi.xml_string (self._xml)
   def __repr__ (self):
      if self._xml == None: return ""
      return xmlapi.xml_string (self._xml)
   def string (self):
      if self._xml == None: return ""
      return xmlapi.xml_string (self._xml)
   def stringhtml (self):
      if self._xml == None: return ""
      return xmlapi.xml_stringhtml (self._xml)
   def stringcontent (self):
      if self._xml == None: return ""
      return xmlapi.xml_stringcontent (self._xml)
   def stringcontenthtml (self):
      if self._xml == None: return ""
      return xmlapi.xml_stringcontenthtml (self._xml)

   # --------------------------------------------------------------
   # File I/O: Writing to files.
   # --------------------------------------------------------------
   def write (self, file):
      if self._xml == None: return ""
      return xmlapi.xml_write (file, self._xml)
   def writehtml (self, file):
      if self._xml == None: return ""
      return xmlapi.xml_stringhtml (file, self._xml)
   def writecontent (self, file):
      if self._xml == None: return ""
      return xmlapi.xml_stringcontent (file, self._xml)
   def writecontenthtml (self, file):
      if self._xml == None: return ""
      return xmlapi.xml_stringcontenthtml (file, self._xml)
   # xml_output: probably not necessary in Python
   # xml_save: also not terribly necessary

   # --------------------------------------------------------------
   # Reading XML from strings and files.
   # --------------------------------------------------------------
   def parse (self, str):
      try:
         self._xml = xmlapi.xml_parse (str)
      except IOError, message:
         self._xml = None
         raise ParseError, message
   def read (self, file):
      try:
         self._xml = xmlapi.xml_read (file)
      except IOError, message:
         self._xml = None
         raise ParseError, message

   # --------------------------------------------------------------
   # Attribute access (including treating the attributes as a dictionary).
   # --------------------------------------------------------------
   def __getitem__ (self, key):
      if self._xml == None: return ""
      return xmlapi.xml_attrval (self._xml, key)
   def attrval (self, key):
      if self._xml == None: return ""
      return xmlapi.xml_attrval (self._xml, key)
   def __setitem__ (self, key, value):
      if self._xml == None: return
      xmlapi.xml_set (self._xml, key, `value`)
   def set (self, key, value):
      if self._xml == None: return
      xmlapi.xml_set (self._xml, key, `value`)
   def attrlist (self):
      if self._xml == None: return
      return xmlapi.xml_attrlist (self._xml)
   def attrs (self):
      if self._xml == None: return
      return xmlapi.xml_attrs (self._xml)

   # --------------------------------------------------------------
   # Subelement identification and iteration.
   # --------------------------------------------------------------
   def elements (self):   # Returns list of subelements.
      if self._xml == None: return []
      ret = []
      for e in xmlapi.xml_elements (self._xml):
         x = xml()
         x._xml = e
         ret.append (x)
      return ret
   def name (self):
      if self._xml == None: return None
      return xmlapi.xml_name (self._xml)
   def parent (self):
      if self._xml == None: return None
      ret = xmlapi.xml_parent (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def is_element (self):
      if self._xml == None: return None
      return xmlapi.xml_is_element (self._xml)
   def is_a (self, name):
      if self._xml == None: return None
      return xmlapi.xml_is (self._xml, name)
   def first (self):       # Regular C-style iteration functions.
      if self._xml == None: return None
      ret = xmlapi.xml_first (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def firstelem (self):
      if self._xml == None: return None
      ret = xmlapi.xml_firstelem (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def next (self):
      if self._xml == None: return None
      ret = xmlapi.xml_next (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def nextelem (self):
      if self._xml == None: return None
      ret = xmlapi.xml_nextelem (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def prev (self):
      if self._xml == None: return None
      ret = xmlapi.xml_prev (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def prevelem (self):
      if self._xml == None: return None
      ret = xmlapi.xml_prevelem (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def last (self):
      if self._xml == None: return None
      ret = xmlapi.xml_last (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None
   def lastelem (self):
      if self._xml == None: return None
      ret = xmlapi.xml_lastelem (self._xml)
      if ret:
         x = xml()
         x._xml = ret
         return x
      return None

   def iterate (self, parent, type='elem', dir='f'):  # A nice OO kind of iteration paradigm.
      self._iterparent = parent
      self._itertype = type
      self._iterdir = dir
      self._iteration = None
   def iterator (self, type='elem', dir='f'):
      i = xml()
      i.iterate (self, type, dir)
      return i
   def rewind (self):
      self._iteration = None
   def advance (self):
      if not self._iteration:
         self._iteration = 1
         if self._iterdir == 'f':
            if self._itertype == 'elem':
               self._xml = xmlapi.xml_firstelem (self._iterparent._xml)
            else:
               self._xml = xmlapi.xml_first (self._iterparent._xml)
         else:
            if self._itertype == 'elem':
               self._xml = xmlapi.xml_lastelem (self._iterparent._xml)
            else:
               self._xml = xmlapi.xml_last (self._iterparent._xml)
         if self._xml:
            return 1
         return None
      else:
         if not self._xml: return None
         if self._iterdir == 'f':
            if self._itertype == 'elem':
               self._xml = xmlapi.xml_nextelem (self._xml)
            else:
               self._xml = xmlapi.xml_next (self._xml)
         else:
            if self._itertype == 'elem':
               self._xml = xmlapi.xml_prevelem (self._xml)
            else:
               self._xml = xmlapi.xml_prev (self._xml)
         if self._xml:
            return 1
         return None

   # --------------------------------------------------------------
   # Element manipulation.
   # --------------------------------------------------------------
   def create (self, str):
      self._xml = xmlapi.xml_create (str)
   # createtext: TODO: implement
   # createtextf, len, _nodup: not necessary in Python
   # textcat: TODO: implement
   def delete (self):
      if self._xml:
         xmlapi.xml_delete (self._xml)
         self._xml = None
   # delete_pretty: TODO: implement
   # free: not applicable to Py env
   def new_copy (self):
      ret = xml()
      if not self._xml: return ret
      ret._xml = xmlapi.xml_copy (self._xml)
      return ret
   def copy (self, other):
      try:
         if not other._xml:
            self._xml = None
         else:
            self._xml = xmlapi.xml_copy (other._xml)
      except:
         raise TypeError, "object not XML object"
   def copyinto (self, other):
      try:
         if not other._xml:
            pass
         else:
            xmlapi.xml_copyinto (self._xml, other._xml)
      except:
         raise TypeError, "object not XML object"
   def replace (self, other):
      try:
         other._xml = self._xml
         self._xml = None
      except:
         raise TypeError, "object not XML object"
   def replacecontent (self, other):
      try:
         other._xml = self._xml
         self._xml = None
      except:
         raise TypeError, "object not XML object"

   # prepend, prepend_pretty : TODO: implement
   # append, append_pretty: TODO: implement
   # insertafter, insertbefore: TODO: implement

   # --------------------------------------------------------------
   # Finding pieces of XML.
   # --------------------------------------------------------------
   def loc (self, location):
      if not self._xml: return None
      l = xmlapi.xml_loc (self._xml, location)
      if not l: return None
      ret = xml()
      ret._xml = l
      return ret
   # locf: not necessary in Python
   def getloc (self):
      if not self._xml: return None
      return xmlapi.xml_getloc (self._xml)
   # getloc is actually getlocbuf, and getloc is unnecessary (and in fact impossible) in Python
   def search (self, elem, attr, val):
      if not self._xml: return None
      l = xmlapi.xml_search (self._xml, elem, attr, val)
      if not l: return None
      ret = xml()
      ret._xml = l
      return ret
   # search_next: TODO: implement?
   def search_all (self, elem, attr, val):
      if not self._xml: return []
      ret = []
      for result in xmlapi.xml_search_all (self._xml, elem, attr, val):
         r = xml()
         r._xml = result
         ret.append (r)
      return ret

   # -------------------------------------------
   # Binary pointer access
   # -------------------------------------------
   # setbin, getbin: TODO: implement

   # -------------------------------------------
   # UTF8 stuff
   # -------------------------------------------
   # toutf8_attr, toutf8_text, toraw_str: necessary in Py?

   # -------------------------------------------
   # Sorting
   # -------------------------------------------
   # sort: TODO: implement
class xmlobj(xml):
   """Implements a record object on top of the XML object.  Primarily this has to do with
      the organization of field values, which are normally <field]] attributes (but needn't be.)
   """
   def __init__ (self, defn=None, str=None):
      """Create XML object from optional string input"""
      self._list = defn
      self._xml = None

      if str:
         try:
            self.parse (str)
         except ParseError, message:
            raise ParseError, message

   # --------------------------------------------------------------
   # Getting and setting the value of the list definition.
   # --------------------------------------------------------------
   def define (self, list):
      self._list = list
   def defn (self):
      return self._list

   # --------------------------------------------------------------
   # Field reading.
   # --------------------------------------------------------------
   def __getitem__ (self, key):
      if self._xml == None: return ""
      return xmlapi.xmlobj_get (self._xml, self._list, key)
   def get (self, field):
      if self._xml == None: return ""
      return xmlapi.xmlobj_get (self._xml, self._list, key)
   def key (self):
      if self._xml == None: return ""
      return xmlapi.xmlobj_getkey (self._xml, self._list)

   # --------------------------------------------------------------
   # Field writing.  Note that we can choose element or field storage.
   # --------------------------------------------------------------
   def __setitem__ (self, key, value):
      if self._xml == None: self._xml = xmlapi.xml_create ("record")
      xmlapi.xmlobj_set (self._xml, self._list, key, value)
   def set (self, key, value):
      if self._xml == None: self._xml = xmlapi.xml_create ("record")
      xmlapi.xmlobj_set (self._xml, self._list, key, value)
   def set_elem (self, key, value):
      if self._xml == None: self._xml = xmlapi.xml_create ("record")
      xmlapi.xmlobj_set_elem (self._xml, self._list, key, value)
class repository:
   """Implements a wftk repository.  Define a repository using either a wftk.xml object or a
      string indicating a filename to read XML from."""
   def __init__ (self, defn='site.opm'):
      """Create and optionally open repository object."""
      self.repos = None
      if defn:
         if type(defn) == type(''): # string = filename
            self.repos = repmgr.open_file (defn)
         elif defn.__class__ == xml:
            self.repos = defn._xml
            repmgr.open (self.repos)
   # --------------------------------------------------------------
   # List manipulation.
   # --------------------------------------------------------------
   def list (self, list='_lists', query=None, order=None):
      if self.repos==None: return []
      return repmgr.list (self.repos, list)
   def keys (self, list='_lists', query=None, order=None):
      if self.repos==None: return []
      return repmgr.list (self.repos, list)
   def defn (self, list='_lists'):
      if self.repos==None: return None
      x = repmgr.defn (self.repos, list)
      if not x: return None
      ret = xml()
      ret._xml = x
      return ret

   #def create
   #def drop
   #def define
   # --------------------------------------------------------------
   # Entry manipulation.
   # --------------------------------------------------------------
   def get (self, list, key):
      ret = entry(self, list, key)
      ret.load ()
      if ret.is_element(): return ret
      return None
   #def add
   #def mod
   #def del
   #def merge
   #def getkey
   #def form
   #def edit
   #def display
   #def getvalue
   #def setvalue

   # --------------------------------------------------------------
   # Publishing
   # --------------------------------------------------------------
   #def publish_all
   #def publish_list
   #def publish_obj
   #def publish_pages
   #def publish_page
   #def get_layout

   # --------------------------------------------------------------
   # Change management.
   # --------------------------------------------------------------
   #def changes
   #def snapshot
   #def push
   #def push_all
   #def pull
   #def pull_all
   #def synch
   #def repos_attach
   #def repos_retrieve
class list(xml):
   """Implements a repository manager list.
   """

   #def query
   #def setquery
   #def rewind
   #def advance
   #def current
   #def prev
   #def next
class entry(xmlobj):
   """Implements an active object in a repository.
   """

   def __init__ (self, repository, list, key=None):
      self._repository = repository
      self._listid = list
      self._list = repository.defn (list)
      self._list = self._list._xml
      self._key = key
   def load (self):
      if not self._key: return None
      self._xml = repmgr.get (self._repository.repos, self._listid, self._key)
      if not self._xml: return None
      self._key = repmgr.getkey (self._repository.repos, self._listid, self._xml)
      return self._key
   def save (self):
      if not self._xml: return None
      self._key = repmgr.getkey (self._repository.repos, self._listid, self._xml)
      repmgr.mod (self._repository.repos, self._listid, self._xml, self._key)
      return self._key
   def getkey (self):
      if not self._xml: return None
      self._key = repmgr.getkey (self._repository.repos, self._listid, self._xml)
      return self._key
   def setxml (self, xml):
      self.copy (xml)
   #def attach
   #def retrieve
