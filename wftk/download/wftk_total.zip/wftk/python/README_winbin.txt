This ZIP file contains the binary distribution for the Win32 Python extensions for the wftk.  The wftk is an open-source
workflow toolkit which is released under the terms of the GPL; the legalese is as follows:

    wftk Python low-level wrappers
    Copyright (C) 2004  Vivtek

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

The full text of the GPL is in the COPYING.txt file.

Current information, source updates, and new distributions of the wftk are always available on the Vivtek website at
http://www.vivtek.com/wftk/ and you can get in touch with me at wftk@vivtek.com.

The salient contents of this ZIP file are as follows (source code is also included in lieu of better documentation):

- repmgr.pyd - Wrapper for low-level access to repmgr.dll C library.
- xmlapi.pyd - Wrapper for low-level direct access to XMLAPI in repmgr.dll C library.
- repmgr_rt.dll - The repository manager C library, linked to msvcrt.dll for I/O.
- expat.dll - The expat XML parser.

To access the repository manager from Python under Windows, you'll need repmgr.pyd, repmgr_rt.dll, xmlapi.pyd, xmlapi_rt.dll, and
expat.dll in your Python installation's Libs subdirectory.  You'll also have to read the code for repmgr.pyd in order to figure out
how to call the library, as documentation is not something I've spent a great deal of time on.  (You can always hire me to document
if you want documentation before I get around to it on my own time.)

TODO:
- Finish and include OO schema for easier use.
- Write API documentation for Python.
- Extract example code from existing projects.
- Finish and include wxPython widgets for GUI building (they're pretty cool.)