#######################################################################################################
#
# The wxPyWf is a set of classes to facilitate the building of quick wxPython GUI apps using wftk.
# More information at http://www.vivtek.com/wftk/doc/code/python
#
# Copyright (c) 2003, Vivtek, and released under the GPL.
#
#######################################################################################################
import wftk
from wxPython.wx import *
class menu(wftk.xml):
   def __init__ (self, defn, window, context, handler):
      self._window = window
      self._context = context
      if handler==None:
         self._handlers = []
      elif type(handler) == type([]):
         self._handlers = handler
      else:
         self._handlers = [handler]
      self.defn = defn.new_copy()


      self.refresh()

      self._window.SetMenuBar (self._menubar)



   def menu_handler (self, event):
      d = self.defn.search(None, "id", `event.GetId()`)
      cmd = d['cmd']
      print "Executing command %s" % cmd
      for h in self._handlers:
         rslt = h.do(self._context, cmd)
         if rslt: break
   def refresh (self):
      self._menubar = wxMenuBar()
      for e in self.defn.elements():
         self.init_menu (self._menubar, e)

   def init_menu (self, parent, d):
      if d.is_a('menu'):
        if d['id'] == '': d['id'] = wxNewId()
        d.menu=wxMenu()
        if d.parent().is_a ('menubar'):
           parent.Append (d.menu, d['label'])
        else:
           parent.AppendMenu (int(d['id']), d['label'], d.menu, d['help'])
           pass
        for e in d.elements():
           self.init_menu (d.menu, e)
        return
      if d.is_a('item'):
        if d['id'] == '': d['id'] = wxNewId()
        parent.Append (int(d['id']), d['label'], d['help'])
        EVT_MENU(self._window, int(d['id']), self.menu_handler)
        return
      if d.is_a('separator'):
        parent.AppendSeparator()
        return
      if d.is_a('break'):
        parent.Break()
