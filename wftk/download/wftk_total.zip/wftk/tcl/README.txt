This directory contains what I've done so far to embed wftk in Tcl;
so far, all I've done is to embed the XMLAPI.  This is based on the
Python wrapper for guidance.

Why wrap XMLAPI?  Simple: the wftk uses XMLAPI.  Rewriting wftk to use some other
DOM would be too much work.  As it is, I now have *one* library and
data structure which works equally well from either Tcl or C, which
means it's a great way for code on both sides to talk together.

This directory also contains the glue code for AOLserver compatibility.
If you're not using AOLserver, go look it up.