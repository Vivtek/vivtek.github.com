The popup UI framework started out as a separate project concept, but wftk subsumed it, as it ultimately
subsumes everything I think of nowadays.

The framework itself is based on wxWindows and is a simple UI from which to hang queries and event
listeners.  Effectively it is a general IM client, except that instead of handling a single kind of
unstructured message it is capable of handling structured messages which correspond to structured
interactions with arbitrary systems.

It is unusual in the wftk in that it is written in C++.  This allows it to interface with wxWindows,
which is a C++ library.  In addition, the window-UI style of programming is indeed a naturally
object-oriented paradigm, so (sigh) I guess I'll go with the flow on this one.  But notice that most
of the meat is in adaptors, and they remain ANSI C.