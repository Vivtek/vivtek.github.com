#ifndef _POPUP_H_
#define _POPUP_H_

#ifdef __GNUG__
    #pragma interface "life.h"
#endif

// for compilers that support precompilation, includes "wx/wx.h"
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

#ifdef __WXMSW__
#include <wx/msw/taskbar.h>
#endif

#ifdef __WXMSW__
class PopupSystemTrayIcon: public wxTaskBarIcon
{
public:
    PopupSystemTrayIcon() {};

    virtual void OnMouseMove(wxEvent&);
    virtual void OnLButtonDown(wxEvent&);
    virtual void OnLButtonUp(wxEvent&);
    virtual void OnRButtonDown(wxEvent&);
    virtual void OnRButtonUp(wxEvent&);
    virtual void OnLButtonDClick(wxEvent&);
    virtual void OnRButtonDClick(wxEvent&);

    void OnMenuRestore(wxCommandEvent&);
    void OnMenuExit(wxCommandEvent&);
    void OnMenuQuery(wxCommandEvent&);

    void ProcessAdaptor(wxCommandEvent&);

DECLARE_EVENT_TABLE()
};
#endif
class PopupApp: public wxApp
{
  public:
    bool OnInit();
    int OnExit();

  private:
#ifdef __WXMSW__
    PopupSystemTrayIcon   m_systemtrayicon;
#endif

};

DECLARE_APP(PopupApp)
#endif
class PopupFrame : public wxFrame
{
public:
    PopupFrame();
    ~PopupFrame();

    wxSizer *top_sizer;
    wxHtmlWindow *html;

    // This macro takes care of compile-time events.
    DECLARE_EVENT_TABLE()

    // event handlers
    void OnMenu      (wxCommandEvent& event);
    void OnFileSave  (wxCommandEvent& event);
    void OnFilePrefs (wxCommandEvent& event);
    void OnHide      (wxCommandEvent& event);
    void OnClose     (wxCommandEvent& event);
    void OnQueryList (wxCommandEvent& event);
    void OnHelpAbout (wxCommandEvent& event);

    void ProcessAdaptor (wxCommandEvent& event);

};
class AdaptorEventHandler : public wxEvtHandler
{
   public:
      virtual bool ProcessEvent(wxEvent& event);
};
