# 2003/07/07 - the idea of this script is to find HTML resulting from the build process and move it
#              to a documentation home.  We compare the current directory to the wftk home to find
#              out where to put the HTML in the doc home.  I was doing this with explicit mkdir -p and mv
#              commands, but (1) they don't translate well to Win32 and (2) it's a pain to change
#              them for new modules.  So this script just does the whole directory structure in one fell swoop.

sub scan_dir {
   my ($dir, $docdir) = @_;

   unless (-e $docdir) {
      print ("New directory $docdir\n");
      mkdir $docdir;
   }

   opendir D, $dir;
   my @files = readdir (D);
   closedir D;

   my $f;
   foreach $f (@files) {
      next if $f =~ /^\.*$/;
      next if $f eq 'examples'; # Don't move HTML out of the examples directory.
      next if $f eq 'CVS'; # Don't even try the CVS directories.

      if (-d "$dir/$f") {
         scan_dir ("$dir/$f", "$docdir/$f");
      } elsif ($f =~ /\.html$/ || $f =~ /\.css$/) {
         print "$dir/$f -> $docdir\n";
         if ($docdir =~ /\\/) {  # Probably not the sanest of OS detections, but ...
             $dir =~ s/\//\\/g;
             $docdir =~ s/\//\\/g;
             system "move $dir\\$f $docdir";
         } else {
             system "mv $dir/$f $docdir";
         }
      }
   }
}

scan_dir ('.', $ARGV[0]);