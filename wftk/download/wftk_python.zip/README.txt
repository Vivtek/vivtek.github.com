This directory contains all the Python-specific wftk building blocks, which are at varying
stages of completeness.  It also includes a couple of different distribution formats for
Windows (so far).  The major Python components are as follows:

- py_repmgr.xml -> repmgr.pyd - Wrapper for low-level access to repmgr.dll C library.
- py_xmlapi.xml -> xmlapi.pyd - Wrapper for low-level direct access to XMLAPI, now also in repmgr.dll C library.
- soap_server.xml -> soap_server.py and soap_server.zip - SOAP server for wftk based on repository manager and SOAPpy module.
- wftk.xml -> wftk.py - (unfinished) OO schema for Python
- wxwfpy.xml -> wxwfpy.py - (unfinished) wxPython widgets for wftk GUI building
- repmgr_cli.xml -> repmgr_cli.py - (unfinished) command-line component for wxwfpy.
- pypop.xml -> pypop.py - (unfinished) Generic wftk GUI app based on wxwfpy.
- repmgr_server.xml -> repmgr_server.py - (unfinished) command-line daemon, probably obsolete thanks to soap_server.

To access the repository manager from Python under Windows, you'll need repmgr.pyd, xmlapi.pyd, and repmgr_rt.dll.
You'll also have to read the code for repmgr.pyd in order to figure out how to call the library, as documentation is not something
I've spent a great deal of time on.  (You can always hire me to document if you want documentation before I get around to it on
my own time.)

Under Windows, this set of files is zipped up in wftk_python.zip for your viewing pleasure.  When the wftk.xml OO schema is closer
to completion, I will include it there.  Enjoy!