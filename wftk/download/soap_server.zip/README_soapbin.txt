This ZIP file contains the binary distribution for the Python SOAP server for the wftk.  The wftk is an open-source
workflow toolkit which is released under the terms of the GPL; the legalese is as follows:

    wftk Python-based SOAP server
    Copyright (C) 2004  Vivtek

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111 USA

The full text of the GPL is in the COPYING.txt file.

Current information, source updates, and new distributions of the wftk are always available on the Vivtek website at
http://www.vivtek.com/wftk/ and you can get in touch with me at wftk@vivtek.com.

The salient contents of this ZIP file are as follows (source code is also included in lieu of better documentation):

- repmgr.pyd - Wrapper for low-level access to repmgr.dll C library.
- xmlapi.pyd - Wrapper for low-level direct access to XMLAPI in repmgr.dll C library.
- repmgr_rt.dll - The repository manager C library (plus XMLAPI), linked to msvcrt.dll for I/O.
- expat.dll - The expat XML parser.

Configuration of the repository is something that's not yet documented.  I'm aware how much this situation sucks.
I take checks, PayPal, and small, unmarked bills, and my mortgage holders, daycare providers, health insurers, and the
Bursar's Office at Indiana University will all be gratified not to have to call me again.

TODO:
- Document repository configuration, which is getting
  complex enough I'm starting to forget how to do it, too.
- Get a sample installation running on my server so you can mess around with it.