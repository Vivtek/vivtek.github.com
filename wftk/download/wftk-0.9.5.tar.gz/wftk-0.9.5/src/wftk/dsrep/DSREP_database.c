#include <stdio.h>
#include <stdarg.h>
#include "xmlapi.h"
#include "../wftk_internals.h"
static char *names[] = 
{
   "init",
   "free",
   "info",
   "new",
   "load",
   "save",
   "delete",
   "archive"
};

XML * DSREP_database_init (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_free (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_info (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_new (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_load (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_save (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_delete (WFTK_ADAPTOR * ad, va_list args);
XML * DSREP_database_archive (WFTK_ADAPTOR * ad, va_list args);

static WFTK_API_FUNC vtab[] = 
{
   DSREP_database_init,
   DSREP_database_free,
   DSREP_database_info,
   DSREP_database_new,
   DSREP_database_load,
   DSREP_database_save,
   DSREP_database_delete,
   DSREP_database_archive
};

static struct adaptor_info _DSREP_database_info =
{
   8,
   names,
   vtab
};
struct adaptor_info * DSREP_database_get_info ()
{
   return & _DSREP_database_info;
}
XML * DSREP_database_init (WFTK_ADAPTOR * ad, va_list args) {
   const char * parms;
   WFTK_ADAPTOR * db_ad;

   parms = xml_attrval (ad->parms, "parm");
   if (!*parms) parms = config_get_value (ad->session, "dsrep.database.db");

   db_ad = wftk_get_adaptor (ad->session, TASKINDEX, parms);
   if (!db_ad) {
      xml_setf (ad->parms, "error", "Unable to initialize database %s", parms);
      return NULL;
   }
   ad->bindata = (void *) db_ad;
   xml_setf (ad->parms, "spec", "database:%s", parms);

   return (XML *) 0;
}
XML * DSREP_database_free (WFTK_ADAPTOR * ad, va_list args) {
   WFTK_ADAPTOR * db_ad = (WFTK_ADAPTOR *) ad->bindata;
   wftk_free_adaptor (ad->session, db_ad);
   return (XML *) 0;
}
XML * DSREP_database_info (WFTK_ADAPTOR * ad, va_list args) {
   XML * info;

   info = xml_create ("info");
   xml_set (info, "type", "dsrep");
   xml_set (info, "name", "database");
   xml_set (info, "ver", "1.0.0");
   xml_set (info, "compiled", __DATE__ " " __TIME__);
   xml_set (info, "author", "Michael Roberts");
   xml_set (info, "contact", "wftk@vivtek.com");
   xml_set (info, "extra_functions", "0");

   return (info);
}
XML * DSREP_database_new  (WFTK_ADAPTOR * ad, va_list args)
{
   WFTK_ADAPTOR *db_ad = (WFTK_ADAPTOR *) ad->bindata;
   char * id = (char *) 0;
   FILE * file;
   XML * ret = xml_create ("datasheet");

   if (args) id = va_arg (args, char *);
   if (id) xml_set (ret, "id", id);
   xml_set (ret, "noindex", "yes"); /* Tells wftk not to tell the taskindex about this proc directly. */

   wftk_call_adaptor (db_ad, "procnew", ret);
   if (*xml_attrval (db_ad->parms, "error")) {
      if (id) {
         xml_setf (ad->parms, "error", "Process '%s' already exists.", xml_attrval (ret, "id"));
         xml_set (ret, "id", "");
      } else {
         xml_setf (ad->parms, "error", xml_attrval (db_ad->parms, "error"));
      }
   } else {
      wftk_call_adaptor (db_ad, "xmlput", "process", "id", xml_attrval (ret, "id"), "datasheet", ret);
   }
   return ret;
}
XML * DSREP_database_load (WFTK_ADAPTOR * ad, va_list args) {
   WFTK_ADAPTOR *db_ad = (WFTK_ADAPTOR *) ad->bindata;
   XML * proc;
   XML * datasheet;
   XML * data;
   XML_ATTR * field;
   char *id = (char *) 0;

   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No ID given.");
      return (XML *) 0;
   }

   proc = wftk_call_adaptor (db_ad, "procget", id);

   if (!proc) {
      xml_setf (ad->parms, "error", "Process '%s' not found.", id);
      return (XML *) 0;
   }

   datasheet = wftk_call_adaptor (db_ad, "xmlget", "process", "id", xml_attrval (proc, "id"), "datasheet");

   if (!datasheet) {
      datasheet = xml_create ("datasheet");
      xml_set (datasheet, "id", xml_attrval (proc, "id"));
   }
   xml_set (datasheet, "noindex", "yes");

   field = xml_attrfirst (proc);
   while (field) {
      if (strcmp (xml_attrname (field), "id") &&
          strcmp (xml_attrname (field), "status") &&
          strcmp (xml_attrname (field), "title") &&
          strcmp (xml_attrname (field), "user")) {
         data = xml_create ("data");
         xml_set (data, "id", xml_attrname (field));
         xml_set (data, "value", xml_attrvalue (field));
         xml_setf (data, "storage", "currecord:%s", xml_attrval (db_ad->parms, "spec"));
         xml_append (datasheet, data);
      }
      field = xml_attrnext (field);
   }
   xml_free (proc);
   return datasheet;

}
XML * DSREP_database_save (WFTK_ADAPTOR * ad, va_list args) {
   WFTK_ADAPTOR *db_ad = (WFTK_ADAPTOR *) ad->bindata;
   XML  * ds = (XML *) 0;
   XML * fields;
   XML * field;

   if (args) ds = va_arg (args, XML *);
   if (!ds) {
      xml_set (ad->parms, "error", "No datasheet given.");
      return (XML *) 0;
   }

   fields = xml_create ("fields");
   wftk_call_adaptor (db_ad, "procput", ds);

   field = xml_firstelem (ds);
   while (field) {
      if (xml_is (field, "data") && !strncmp (xml_attrval (field, "storage"), "currecord:", 10)) {
         xml_append (fields, xml_copy (field));
         xml_delete (field);
         field = xml_firstelem (ds);
      }
      field = xml_nextelem (field);
   }

   wftk_call_adaptor (db_ad, "xmlput", "process", "id", xml_attrval (ds, "id"), "datasheet", ds);

   field = xml_firstelem (field);
   while (field) {
      xml_append (ds, xml_copy (field));
      field = xml_nextelem (field);
   }
   xml_free (fields);

   return ds;
}
XML * DSREP_database_delete (WFTK_ADAPTOR * ad, va_list args) {
   WFTK_ADAPTOR *db_ad = (WFTK_ADAPTOR *) ad->bindata;
   char * id = (char *) 0;

   if (args) id = va_arg (args, char *);
   if (!id) {
      xml_set (ad->parms, "error", "No ID given.");
      return (XML *) 0;
   }

   wftk_call_adaptor (db_ad, "procdel", id);
   return (XML *) 0;
}
XML * DSREP_database_archive (WFTK_ADAPTOR * ad, va_list args) { return (XML *) NULL; }
