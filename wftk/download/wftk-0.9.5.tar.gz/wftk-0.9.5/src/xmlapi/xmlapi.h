typedef struct _element XML;
typedef struct _attr ATTR;
typedef ATTR XML_ATTR;
typedef struct _list ELEMENTLIST;

struct _element {
   char * name;
   ATTR * attrs;
   XML * parent;
   ELEMENTLIST * children;
   void * extra;
};

struct _attr {
   char * name;
   char * value;
   int valsize; /* For dynamic allocation; we track the buffer. */
   ATTR * next;
};

struct _list {
   XML * element;
   ELEMENTLIST * next;
   ELEMENTLIST * prev;
};
#ifndef XMLAPI
#define XMLAPI
#endif
XMLAPI void xml_write (FILE * file, XML * xml);
XMLAPI void xml_writecontent (FILE * file, XML * xml);
XMLAPI void xml_writehtml (FILE * file, XML * xml);
XMLAPI void xml_writecontenthtml (FILE * file, XML * xml);
XMLAPI int  xml_output (char * file, XML * xml, int mode);
XMLAPI char * xml_string (XML * xml);
XMLAPI char * xml_stringcontent (XML * xml);
XMLAPI char * xml_stringhtml (XML * xml);
XMLAPI char * xml_stringcontenthtml (XML * xml);
XMLAPI void xml_prepend (XML * parent, XML * child);
XMLAPI void xml_append (XML * parent, XML * child);
XMLAPI void xml_replace (XML * xml, XML * newxml);
XMLAPI void xml_replacecontent (XML * parent, XML * child);
XMLAPI XML * xml_loc (XML * start, const char * loc);
XMLAPI XML * xml_locf (XML * start, const char * loc, ...);
XMLAPI void xml_getloc (XML * xml, char *loc, int len);
XMLAPI char * xml_getlocbuf (XML * xml);
XMLAPI void xml_set (XML * xml, const char * name, const char * value);
XMLAPI void xml_setf (XML * xml, const char * name, const char * format, ...);
XMLAPI void xml_setnum (XML * xml, const char *attr, int number);
XMLAPI void xml_attrcat (XML * xml, const char *name, const char *value);
XMLAPI void xml_attrncat (XML * xml, const char *name, const char *value, int len);
XMLAPI void xml_set_nodup (XML * xml, const char * name, char * value);
XMLAPI const char * xml_attrval (XML * element,const char * name);
XMLAPI int xml_attrvalnum (XML * element,const char * name);
XMLAPI XML_ATTR * xml_attrfirst (XML * element);
XMLAPI XML_ATTR * xml_attrnext  (XML_ATTR * attr);
XMLAPI const char * xml_attrname (XML_ATTR * attr);
XMLAPI const char * xml_attrvalue (XML_ATTR * attr);
XMLAPI XML * xml_create (const char * name);
XMLAPI XML * xml_createtext (const char * value);
XMLAPI XML * xml_createtextf (const char * format, ...);
XMLAPI XML * xml_createtextlen (const char * value, int len);
XMLAPI XML * xml_createtext_nodup (char * value);
XMLAPI void xml_textcat (XML * xml, const char * value);
XMLAPI void xml_textncat (XML * xml, const char * value, int len);
XMLAPI void xml_free (XML * xml);
XMLAPI void xml_delete(XML * piece);
XMLAPI int   xml_is (XML * xml, const char * name);
XMLAPI int   xml_is_element (XML * xml);
XMLAPI const char * xml_name (XML * xml);
XMLAPI XML * xml_parent (XML * xml);
XMLAPI XML * xml_first (XML * xml);
XMLAPI XML * xml_firstelem (XML * xml);
XMLAPI XML * xml_last (XML * xml);
XMLAPI XML * xml_lastelem (XML * xml);
XMLAPI XML * xml_next (XML * xml);
XMLAPI XML * xml_nextelem (XML * xml);
XMLAPI XML * xml_prev (XML * xml);
XMLAPI XML * xml_prevelem (XML * xml);
XMLAPI XML * xml_copy (XML * xml);
XMLAPI XML * xml_copyinto (XML * target, XML * source);
XMLAPI XML * xml_read (FILE * file);
XMLAPI XML * xml_read_error (FILE * file);
XMLAPI XML * xml_parse (const char * buf);
XMLAPI XML * xml_parse_general (void * data, size_t (*get_buf) (char * buf, size_t num, size_t chunk, void *data));
