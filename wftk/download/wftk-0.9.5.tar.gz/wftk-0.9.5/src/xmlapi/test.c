#include <stdio.h>
#include "xmlapi.h"

XML * xml;
XML * found;
char * loc;
FILE * file;

int main (int argc, char *argv[])
{
   xml = xml_parse ("<item stuff=\"here\" and=\"more\"/>");
   file = fopen ("test.out", "w");
   fprintf (file, "Still testing...\n");
   xml_write (file, xml);
   fclose (file);
   xml_free (xml);
   printf ("\n\n");
   xml=  xml_read(stdin);
   xml_prepend (xml, xml_create("boogida"));
   xml_write (stdout, xml);

   printf ("\n\n");
   found = xml_locf (xml, ".item(%d)", 1);
   xml_write (stdout, found);

   found = xml_nextelem (found);
   loc = xml_getlocbuf (found);

   printf ("\nInput is an item? %s", xml_is (xml, "item") ? "yes" : "no");
   printf ("\nInput is an xml? %s", xml_is (xml, "xml") ? "yes" : "no");

   printf ("\n\n%s\n\n", loc);
   free (loc);
}

