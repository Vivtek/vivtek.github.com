/* Unix-style compiled-in locations for important stuff. */
#define CONFIG_MODE 0
#define PROCDEF_DIRECTORY "c:\\wftk\\procdefs\\"
#define DATASHEET_DIRECTORY "c:\\wftk\\datasheets\\"
#define USER_DIRECTORY "c:\\wftk\\users\\"
#define GROUP_DIRECTORY "c:\\wftk\\groups\\"

#define CGI_EXTENSION ".exe"
#define AUTH_DOMAIN "wftk workflow"

#define ODBC_CONNECTION "DSN=wftk"

