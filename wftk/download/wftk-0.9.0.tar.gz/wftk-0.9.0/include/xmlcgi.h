XML * cgi_init ();

/* Now that wasn't hard, was it? */
