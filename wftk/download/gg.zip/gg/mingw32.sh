#
# If you're using a Bourne-like shell, use this file.
# replace c:/gcc-2.95.2 with whatever your installation root may be.
# GCC_EXEC_PREFIX is optional, and hardly ever needs to be set (read:
# leave it alone).
#
export PATH=//c/gcc-2.95.2/bin:$PATH
# export GCC_EXEC_PREFIX='c:\gcc-2.95.2\lib\gcc-lib\'
