#include <stdarg.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "xmlapi.h"
#include "wftk_internals.h"
#include "localdefs.h"
#ifdef WINDOWS
#include <windows.h>  /* For dynamic loading declarations. */
#endif
struct loaded_library {
   int adaptor_class;
   char adaptor[32]; /* Note the limit on adaptor name.  Since typical names are "localxml" or "oracle"
                        this limit should be quite sufficient. */
   char filename[256]; /* Here we'll build the path to the DLL. */
#ifdef WINDOWS
   HINSTANCE inst; /* This is how we'll do it under Win32.  Under Unix, I still have to learn how... */
#endif
   struct adaptor_info * ai;
   struct loaded_library * next;
};
struct loaded_library * loaded_libraries = NULL;
void config_cleanup ()
{
   struct loaded_library * ll;

   while (loaded_libraries) {
      ll = loaded_libraries;
      loaded_libraries = ll->next;
#ifdef WINDOWS
      FreeLibrary (ll->inst);
#endif
      free (ll);
   }
}
typedef struct adaptor_info * (ADAPTOR_INFO_FN) (void);
ADAPTOR_INFO_FN DSREP_localxml_get_info;
ADAPTOR_INFO_FN PDREP_localxml_get_info;
ADAPTOR_INFO_FN USER_localxml_get_info;
ADAPTOR_INFO_FN PERMS_localxml_get_info;
ADAPTOR_INFO_FN TASKINDEX_stdout_get_info;
ADAPTOR_INFO_FN ACTION_wftk_get_info;
ADAPTOR_INFO_FN ACTION_system_get_info;
ADAPTOR_INFO_FN DATASTORE_role_get_info;
ADAPTOR_INFO_FN DATASTORE_currecord_get_info;
ADAPTOR_INFO_FN DATATYPE_option_get_info;
WFTK_ADAPTOR * config_get_adaptor (void * session, int adaptor_class, char * adaptor_descriptor, int name_length)
{
   char namebuf[64];
   struct loaded_library * library;
   ADAPTOR_INFO_FN * func;
   struct adaptor_info * ai = (struct adaptor_info *) 0;
   char * dll_start = "";

   WFTK_ADAPTOR * ret;

   switch (adaptor_class) {
      case DSREP:
         dll_start = "DSREP_";
         if (!name_length || (name_length == 8 && !strncmp ("localxml", adaptor_descriptor, 8))) {
            ai = DSREP_localxml_get_info();
         }
         break;
      case DATASTORE:
         dll_start = "DATASTORE_";
         if (name_length == 4 && (!strncmp ("role", adaptor_descriptor, 4))) {
            ai = DATASTORE_role_get_info();
         }
         if (name_length == 9 && (!strncmp ("currecord", adaptor_descriptor, 9))) {
            ai = DATASTORE_currecord_get_info();
         }
         break;
      case DATATYPE:
         dll_start = "DATATYPE_";
         if (name_length == 6 && (!strncmp ("option", adaptor_descriptor, 6))) {
            ai = DATATYPE_option_get_info();
         }
         break;
      case PDREP:
         dll_start = "PDREP_";
         if (!name_length || (name_length == 8 && !strncmp ("localxml", adaptor_descriptor, 8))) {
            ai = PDREP_localxml_get_info();
         }
         break;
      case USER:
         dll_start = "USER_";
         if (!name_length || (name_length == 8 && !strncmp ("localxml", adaptor_descriptor, 8))) {
            ai = USER_localxml_get_info();
         }
         break;
      case PERMS:
         dll_start = "PERMS_";
         /* Perms are different -- the caller gets no choice.
            Otherwise I figure we're in trouble, security-wise.
            Probably are anyway. */
         ai = PERMS_localxml_get_info();
         break;
      case TASKINDEX:
         dll_start = "TASKINDEX_";
         if (name_length == 6 && !strncmp ("stdout", adaptor_descriptor, 6)) {
            ai = TASKINDEX_stdout_get_info();
            break;
         }
         if (!name_length) {  /* The default not being a static link, we have to check the config for an explicit name. */
            adaptor_descriptor = (char *) config_get_value (session, "taskindex.default");
            if (strchr (adaptor_descriptor, ':')) name_length = strchr (adaptor_descriptor, ':') - adaptor_descriptor;
            else                                  name_length = strlen (adaptor_descriptor);
         }
         break;
      case NOTIFY:
         dll_start = "NOTIFY_";
         if (!name_length) {
            adaptor_descriptor = (char *) config_get_value (session, "notify.default");
            if (strchr (adaptor_descriptor, ':')) name_length = strchr (adaptor_descriptor, ':') - adaptor_descriptor;
            else                                  name_length = strlen (adaptor_descriptor);
         }
         break;
      case ACTION:
         dll_start = "ACTION_";
         if (name_length == 6 && !strncmp ("system", adaptor_descriptor, 6)) {
            ai = ACTION_system_get_info();
            break;
         }
         if (!name_length || (name_length == 4 && !strncmp ("wftk", adaptor_descriptor, 4))) {
            ai = ACTION_wftk_get_info();
         }
         break;
      case DEBUG_MSG:
         dll_start = "DEBUG_MSG_";
         break;
      default:
         return (WFTK_ADAPTOR *) 0;
   }

   if (!ai && name_length) { /* The adaptor isn't statically linked, anyway.  Let's try finding it dynamically, if it's named. */
      /* Is this DLL already loaded?  Check the loaded list. */
      library = loaded_libraries;
      strncpy (namebuf, adaptor_descriptor, name_length);
      while (library) {
         if (adaptor_class == library->adaptor_class && !strcmp (namebuf, library->adaptor)) {
            ai = library->ai;
            break;
         }
         library = library->next;
      }

#ifdef WINDOWS
      if (!ai) {
         /* Look for a properly named DLL.  When I figure out dynaloading under Unix this will expand. */
         library = (struct loaded_library *) malloc (sizeof (struct loaded_library));
         library->adaptor_class = adaptor_class;
         strcpy (library->adaptor, namebuf);
         strcpy (namebuf, dll_start);
         strncat (namebuf, adaptor_descriptor, name_length);
         strcat (namebuf, ".dll");
         library->inst = LoadLibrary (namebuf);
         if (!library->inst) {
            config_debug_message ('A', "Failed to load library %s.\n", namebuf);
            free (library);
            return NULL;
         }
         strcpy (namebuf, dll_start);
         strncat (namebuf, adaptor_descriptor, name_length);
         strcat (namebuf, "_get_info");
         func = (ADAPTOR_INFO_FN *) GetProcAddress (library->inst, namebuf);
         if (!func) {
            config_debug_message ('A', "Adaptor doesn't export %s.\n", namebuf);
            free (library);
            return NULL;
         }
         ai = (*func) ();
      }
#endif
   }
   if (!ai) return (WFTK_ADAPTOR *) 0; /* No luck. */

   ret = (WFTK_ADAPTOR *) malloc (sizeof (struct wftk_adaptor) + ai->nfuncs * sizeof (void *));
   if (!ret) return (WFTK_ADAPTOR *) 0;

   ret->num     = adaptor_class;
   ret->parms   = (void *) 0;     /* This will be filled in by the caller. */
   ret->nfuncs  = ai->nfuncs;
   ret->names   = ai->names;
   ret->vtab    = ai->vtab;
   ret->session = session;
   return (ret);
}
WFTK_ADAPTORLIST * config_get_adaptorlist (void * session, int adaptor_class)
{
   const char * spec = "";
   int adaptors = 1;
   int i;
   const char * mark;
   char * mark2;
   char adaptorbuffer[256]; /* TODO: another dang static buffer.  Fix it. */
   WFTK_ADAPTORLIST * list;

   switch (adaptor_class) {
      case TASKINDEX:
         spec = config_get_value (session, "taskindex.always");
         break;
      case NOTIFY:
         spec = config_get_value (session, "notify.always");
         break;
      default:
         return (WFTK_ADAPTORLIST *) 0;
   }

   if (!*spec) return (WFTK_ADAPTORLIST *) 0;

   /* First pass: count semicolons, so we know how large a list structure to allocate. */
   mark = spec;
   do {
      mark = strchr (mark, ';');
      if (!mark) break;
      adaptors++; mark++;
   } while (mark);

   list = (WFTK_ADAPTORLIST *) malloc (sizeof (WFTK_ADAPTOR_LIST) + adaptors * sizeof (WFTK_ADAPTOR *));
   list->count = adaptors;

   for (i=0, mark = spec; i < adaptors; i++) {
      strcpy (adaptorbuffer, mark);
      mark = strchr(mark, ';');
      if (mark) { mark++; while (*mark == ' ') mark++; }
      mark2 = strchr (adaptorbuffer, ';');
      if (mark2) *mark2 = '\0';

      list->ads[i] = wftk_get_adaptor (session, adaptor_class, adaptorbuffer);
   }

   return (list);
}
XML * config_find_option (XML * xml, const char * name) {
   int len;
   XML * x;
   char * mark = strchr (name, '.');

   if (mark) len = mark - name;
   else      len = strlen (name);

   x = xml_firstelem (xml);
   while (x) {
      if (!strncmp (xml_attrval (x, "name"), name, len) ||
          !strncmp (xml_attrval (x, "id"), name, len)   ||
          !strncmp ("?", name, len)) {
         if (mark) {
            return (config_find_option (x, mark + 1));
         }
         return (x);
      }
      x = xml_nextelem (x);
   }
   return NULL;
}
XML * config_get_option (void * session, const char * valuename) {
   WFTK_SESSION * sess = session;
   if (sess) {
      if (sess->config) {
         return (config_find_option (sess->config, valuename));
      }
   }
   return NULL;
}
const char * config_get_value (void * session, const char * valuename) {
   XML * mark = config_get_option (session, valuename);
   if (mark) return (xml_attrval (mark, "value"));

   if (!strcmp (valuename, "pdrep.localxml.directory")) return PROCDEF_DIRECTORY;
   if (!strcmp (valuename, "dsrep.localxml.directory")) return DATASHEET_DIRECTORY;
   if (!strcmp (valuename, "user.localxml.directory")) return USER_DIRECTORY;
   if (!strcmp (valuename, "group.localxml.directory")) return GROUP_DIRECTORY;
   if (!strcmp (valuename, "taskindex.odbc.?.conn")) return ODBC_CONNECTION;
   return "";
}
void config_debug_message (char type, const char * message, ...)
{
   va_list arglist;

   va_start (arglist, message);
   printf ("DEBUG %c:", type);
   vprintf (message, arglist);
   printf ("\n");
   va_end (arglist);
}
