#include <stdio.h>

#ifdef PYTHON
#define XMLAPI_MALLOC_PYTHON
#undef XMLAPI_MALLOC_NATIVE
#endif

#ifndef XMLAPI_MALLOC_NATIVE
#define XMLAPI_MALLOC_NATIVE
#endif

#ifdef XMLAPI_MALLOC_NATIVE
#include <malloc.h>
#define MALLOC(x) malloc(x)
#define REALLOC(x,y) realloc((x),(y))
#define FREE(x) free(x)
#endif

#ifdef XMLAPI_MALLOC_PYTHON
#include <python.h>
#define MALLOC(x) PyMem_Malloc(x)
#define REALLOC(x,y) PyMem_Realloc((x),(y))
#define FREE(x,y) PyMem_Free(x)
#endif

#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#ifndef PYTHON
#include "expat.h"
#endif

#include "xmlapi.h"

char * _xml_string_tackon (char * buffer, int * cursize, int * curptr, const char * data)
{
   int len;

   if (!data) return (buffer);
   if (!*data) return (buffer);

   len = strlen (data);
   if (len + *curptr + 1 > *cursize) {
      *cursize += 256;
      buffer = (char *) REALLOC ((void *) buffer, *cursize);
   }
   *curptr += len;
   strcat (buffer, data);
   return (buffer);
}
char * _xml_string_tackonn (char * buffer, int * cursize, int * curptr, const char * data, int len)
{
   if (!len) return (buffer);
   if (len + *curptr + 1 > *cursize) {
      *cursize += 256;
      buffer = (char *) REALLOC ((void *) buffer, *cursize);
   }
   strncpy (buffer + *curptr, data, len);
   *curptr += len;
   buffer[*curptr] = '\0';
   return (buffer);
}

char * _xml_string_format (const char * format, va_list args)
{
   char * buffer = (char *) MALLOC (256);
   int cursize = 256;
   int curptr = 0;
   char * colon;
   char * strarg;
   int intarg;
   char numbuf[sizeof (int) * 3 + 1];

   while (colon = strchr (format, '%')) {
      buffer = _xml_string_tackonn (buffer, &cursize, &curptr, format, colon - format);
      format = colon;
      format ++;
      switch (*format) {
         case 's':
            strarg = va_arg (args, char *);
            buffer = _xml_string_tackon (buffer, &cursize, &curptr, strarg);
            break;
         case 'd':
            intarg = va_arg (args, int);
            sprintf (numbuf, "%d", intarg);
            buffer = _xml_string_tackon (buffer, &cursize, &curptr, numbuf);
            break;
         default:
            buffer = _xml_string_tackonn (buffer, &cursize, &curptr, format, 1);
            break;
      }
      format ++;
   }

   buffer = _xml_string_tackon (buffer, &cursize, &curptr, format);
   return (buffer);
}

char * _xml_string_append (char * buffer, int * cursize, int * curptr, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (xml->name == NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, xml->attrs->value);
      return (buffer);
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, "<");
   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name);
   attr = xml->attrs;
   while (attr != NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, " ");
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->name);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "=\"");
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->value);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "\"");
      attr = attr->next;
   }

   if (xml->children == NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "/>");
      return (buffer);
   } else buffer = _xml_string_tackon (buffer, cursize, curptr, ">");

   list = xml->children;
   while (list) {
      buffer = _xml_string_append (buffer, cursize, curptr, list->element);
      list = list->next;
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, "</");
   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name);
   buffer = _xml_string_tackon (buffer, cursize, curptr, ">");

   return (buffer);
}

XMLAPI char * xml_string (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   return (_xml_string_append (ret, &cursize, &curptr, xml));
}


XMLAPI char * xml_stringcontent (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;
   ELEMENTLIST * list;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   list = xml->children;
   while (list) {
      ret = _xml_string_append (ret, &cursize, &curptr, list->element);
      list = list->next;
   }

   return (ret);
}

char * _xml_string_appendhtml (char * buffer, int * cursize, int * curptr, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (xml->name == NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, xml->attrs->value);
      return (buffer);
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, "<");
   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name);
   attr = xml->attrs;
   while (attr != NULL) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, " ");
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->name);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "=\"");
      buffer = _xml_string_tackon (buffer, cursize, curptr, attr->value);
      buffer = _xml_string_tackon (buffer, cursize, curptr, "\"");
      attr = attr->next;
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, ">");
   if (xml->children == NULL) {
      if (!strcmp (xml->name, "p") ||
          !strcmp (xml->name, "a")) {
         buffer = _xml_string_tackon (buffer, cursize, curptr, "</");
         buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name);
         buffer = _xml_string_tackon (buffer, cursize, curptr, ">");
      }
      return (buffer);
   }

   list = xml->children;
   while (list) {
      buffer = _xml_string_appendhtml (buffer, cursize, curptr, list->element);
      list = list->next;
   }

   if (!strcmp (xml->name, "li") ||
       !strcmp (xml->name, "opt")) {
      /* Do nothing. */
   } else {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "</");
      buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name);
      buffer = _xml_string_tackon (buffer, cursize, curptr, ">");
   }

   return (buffer);
}

XMLAPI char * xml_stringhtml (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   return (_xml_string_appendhtml (ret, &cursize, &curptr, xml));
}


XMLAPI char * xml_stringcontenthtml (XML * xml)
{
   char * ret;
   int cursize;
   int curptr;
   ELEMENTLIST * list;

   ret = (char *) MALLOC (256);
   *ret = '\0';
   cursize = 256;
   curptr = 0;

   list = xml->children;
   while (list) {
      ret = _xml_string_appendhtml (ret, &cursize, &curptr, list->element);
      list = list->next;
   }

   return (ret);
}

XMLAPI XML * xml_create (const char * name)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   ret->name = strdup (name);
   ret->attrs = NULL;
   ret->children = NULL;
   ret->parent = NULL;

   return (ret);
}
XMLAPI void xml_set (XML * xml, const char * name, const char * value)
{
   ATTR * attr;

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (attr) {
      FREE ((void *) (attr->value));
      attr->value = strdup (value);
      attr->valsize = strlen (value) + 1;
      return;
   }

   if (xml->attrs == NULL) {
      attr = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs = attr;
   } else {
      attr = xml->attrs;
      while (attr->next) attr = attr->next;
      attr->next = (ATTR *) MALLOC (sizeof (struct _attr));
      attr = attr->next;
   }

   attr->next = NULL;
   attr->name = strdup (name);
   attr->value = strdup (value);
   attr->valsize = strlen (value + 1);
}
XMLAPI void xml_setf (XML * xml, const char *name, const char *format, ...)
{
   ATTR * attr;
   va_list args;
   char * value;

   va_start (args, format);
   value = _xml_string_format (format, args);
   va_end (args);

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (attr) {
      FREE ((void *) (attr->value));
      attr->value = value;
      attr->valsize = 0;
      return;
   }

   if (xml->attrs == NULL) {
      attr = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs = attr;
   } else {
      attr = xml->attrs;
      while (attr->next) attr = attr->next;
      attr->next = (ATTR *) MALLOC (sizeof (struct _attr));
      attr = attr->next;
   }

   attr->next = NULL;
   attr->name = strdup (name);
   attr->value = value;
   attr->valsize = 0;
}
XMLAPI void xml_setnum (XML * xml, const char *attr, int number)
{
   char buf[sizeof(number) * 3 + 1];
   sprintf (buf, "%d", number);
   xml_set (xml, attr, buf);
}
XMLAPI void xml_set_nodup (XML * xml, const char * name, char * value)
{
   ATTR * attr;

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (attr) {
      FREE ((void *) (attr->value));
      attr->value = value;
      attr->valsize = 0;
      return;
   }

   if (xml->attrs == NULL) {
      attr = (ATTR *) MALLOC (sizeof (struct _attr));
      xml->attrs = attr;
   } else {
      attr = xml->attrs;
      while (attr->next) attr = attr->next;
      attr->next = (ATTR *) MALLOC (sizeof (struct _attr));
      attr = attr->next;
   }

   attr->next = NULL;
   attr->name = strdup (name);
   attr->value = value;
   attr->valsize = 0;
}
XMLAPI void xml_attrcat (XML * xml, const char * name, const char * value)
{
   ATTR * attr;
   int len;

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (!attr) xml_set (xml, name, value);
   else {
      len = strlen (attr->value) + strlen (value) + 1;
      if (len > attr->valsize) {
         while (attr->valsize < len) attr->valsize += 256;
         attr->value = (char *) REALLOC (attr->value, attr->valsize);
      }
      strcat (attr->value, value);
   }
}
XMLAPI void xml_attrncat (XML * xml, const char * name, const char * value, int length)
{
   ATTR * attr;
   int len;

   attr = xml->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) break;
      attr = attr->next;
   }

   if (!attr) {
      xml_set (xml, name, "");
      attr = xml->attrs;
      while (attr) {
         if (!strcmp (attr->name, name)) break;
         attr = attr->next;
      }
   }
   if (!attr) return; /* This is probably a dumb way to handle low-mem situations, but... */

   len = strlen (attr->value) + length + 1;
   if (len > attr->valsize) {
      while (attr->valsize < len) attr->valsize += 256;
      attr->value = (char *) REALLOC (attr->value, attr->valsize);
   }
   strncat (attr->value, value, length);
}
XMLAPI const char * xml_attrval (XML * element,const char * name)
{
   ATTR * attr;

   attr = element->attrs;
   while (attr) {
      if (!strcmp (attr->name, name)) return (attr->value);
      attr = attr->next;
   }
   return ("");
}
XMLAPI int xml_attrvalnum (XML * element, const char * name)
{
   return (atoi (xml_attrval (element, name)));
}
XMLAPI void xml_prepend (XML * parent, XML * child)
{
   ELEMENTLIST * list;

   child->parent = parent;

   list = (ELEMENTLIST *) MALLOC (sizeof(struct _list));
   list->element = child;
   list->prev = NULL;
   list->next = parent->children;
   parent->children = list;
}
XMLAPI void xml_append (XML * parent, XML * child)
{
   ELEMENTLIST * list;
   ELEMENTLIST * ch;

   child->parent = parent;

   list = (ELEMENTLIST *) MALLOC (sizeof(struct _list));
   list->element = child;
   list->prev = NULL;
   list->next = NULL;

   if (parent->children == NULL) {
      parent->children = list;
      return;
   }

   ch = parent->children;
   while (ch->next != NULL) ch = ch->next;
   list->prev = ch;
   ch->next = list;
}
XMLAPI void xml_replace (XML * xml, XML * newxml)
{
   ELEMENTLIST * list;

   if (xml == NULL) return;
   if (xml->parent == NULL) return;
   if (newxml == NULL) xml_delete (xml);

   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return;

   newxml->parent = xml->parent;
   list->element = newxml;

   xml_free (xml);
}
XMLAPI void xml_replacecontent (XML * parent, XML * child)
{
   XML * first;

   if (parent == NULL) return;
   while (first = xml_first (parent)) {
      xml_delete (first);
   }
   if (child != NULL) xml_prepend (parent, child);
}
XMLAPI XML * xml_createtext (const char * value)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   ret->name = NULL;
   ret->children = NULL;
   ret->parent = NULL;
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   ret->attrs->value = strdup (value);
   ret->attrs->valsize = strlen (value) + 1;

   return (ret);
}
XMLAPI XML * xml_createtext_nodup (char * value)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   ret->name = NULL;
   ret->children = NULL;
   ret->parent = NULL;
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   ret->attrs->value = value;
   ret->attrs->valsize = strlen (value) + 1;

   return (ret);
}
XMLAPI XML * xml_createtextlen (const char * value, int len)
{
   XML * ret;

   ret = (XML *) MALLOC (sizeof (struct _element));
   ret->name = NULL;
   ret->children = NULL;
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   ret->attrs->value = (char *) MALLOC (len + 1);
   ret->attrs->valsize = len + 1;
   strncpy (ret->attrs->value, value, len);
   ret->attrs->value[len] = '\0';

   return (ret);
}
XMLAPI XML * xml_createtextf (const char * format, ...)
{
   XML * ret;
   char * value;
   va_list args;

   va_start (args, format);
   value = _xml_string_format (format, args);
   va_end (args);

   ret = (XML *) MALLOC (sizeof (struct _element));
   ret->name = NULL;
   ret->children = NULL;
   ret->parent = NULL;
   ret->attrs = (ATTR *) MALLOC (sizeof (struct _attr));
   ret->attrs->name = NULL;
   ret->attrs->next = NULL;
   ret->attrs->value = value;
   ret->attrs->valsize = strlen (value) + 1;

   return (ret);
}
XMLAPI void xml_textcat (XML * xml, const char * value)
{
   ATTR * attr;
   int len;

   if (xml_is_element (xml)) return; /* We refuse to work with non-elements. */

   attr = xml->attrs;
   if (!attr) return; /* This shouldn't happen, but... */

   len = strlen (attr->value) + strlen (value) + 1;
   if (len > attr->valsize) {
      while (attr->valsize < len) attr->valsize += 256;
      attr->value = (char *) REALLOC (attr->value, attr->valsize);
   }
   strcat (attr->value, value);
}
XMLAPI void xml_textncat (XML * xml, const char * value, int length)
{
   ATTR * attr;
   int len;

   if (xml_is_element (xml)) return; /* We refuse to work with non-elements. */

   attr = xml->attrs;
   if (!attr) return; /* This shouldn't happen, but... */

   len = strlen (attr->value) + length + 1;
   if (len > attr->valsize) {
      while (attr->valsize < len) attr->valsize += 256;
      attr->value = (char *) REALLOC (attr->value, attr->valsize);
   }
   strncat (attr->value, value, length);
}
XMLAPI void xml_write (FILE * file, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;
   if (xml->name == NULL) {
      fprintf (file, "%s", xml->attrs->value);
      return;
   }
   fprintf (file, "<%s", xml->name);
   attr = xml->attrs;
   while (attr != NULL) {
      fprintf (file, " %s=\"%s\"", attr->name, attr->value);
      attr = attr->next;
   }
   if (xml->children == NULL) {
      fprintf (file, "/>");
      return;
   } else  fprintf (file, ">");
   xml_writecontent (file, xml);
   fprintf (file, "</%s>", xml->name);
}
XMLAPI void xml_writecontent (FILE * file, XML * xml)
{
   ELEMENTLIST * list;

   list = xml->children;
   while (list) {
      xml_write (file, list->element);
      list = list->next;
   }
}
XMLAPI void xml_writehtml (FILE * file, XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (xml->name == NULL) {
      fprintf (file, "%s", xml->attrs->value);
      return;
   }

   fprintf (file, "<%s", xml->name);
   attr = xml->attrs;
   while (attr != NULL) {
      fprintf (file, " %s=\"%s\"", attr->name, attr->value);
      attr = attr->next;
   }
   fprintf (file, ">");
   if (xml->children == NULL) {
      if (!strcmp (xml->name, "p") ||
          !strcmp (xml->name, "a")) {
         fprintf (file, "</%s>", xml->name);
      }
      return;
   }

   xml_writecontenthtml (file, xml);
   if (!strcmp (xml->name, "li") ||
       !strcmp (xml->name, "opt")) {
   } else fprintf (file, "</%s>", xml->name);
}
XMLAPI void xml_writecontenthtml (FILE * file, XML * xml)
{
   ELEMENTLIST * list;

   list = xml->children;
   while (list) {
      xml_writehtml (file, list->element);
      list = list->next;
   }
}
XMLAPI int xml_output (char * f, XML * xml, int mode)
{
   FILE * file;

   file = fopen (f, "w");
   if (!file) return 0;

   switch (mode) {
      case 1: xml_writecontent (file, xml); break;
      case 2: xml_writehtml (file, xml); break;
      case 3: xml_writecontenthtml (file, xml); break;
      default: xml_write (file, xml); break;
   }

   fclose (file);
   return 1;
}
XMLAPI void xml_free (XML * xml)
{
   ATTR * attr;
   ELEMENTLIST * list;

   if (xml == NULL) return;

   if (xml->name != NULL) FREE ((void *) (xml->name));
   while (xml->attrs) {
      attr = xml->attrs;
      xml->attrs = xml->attrs->next;
      if (attr->name != NULL) FREE ((void *) (attr->name));
      if (attr->value != NULL) FREE ((void *) (attr->value));
      xml->attrs = attr->next;
      FREE ((void *) attr);
   }

   while (xml->children) {
      list = xml->children;
      xml->children = list->next;
      if (list->element != NULL) xml_free (list->element);
      FREE ((void *) list);
   }
   FREE ((void *) xml);
}
XMLAPI void xml_delete(XML * piece)
{
   ELEMENTLIST * list;
   if (!piece) return;
   if (piece->parent != NULL) {
      list = piece->parent->children;
      while (list != NULL && list->element != piece) list = list->next;
      if (list != NULL) {
         if (list->next != NULL) list->next->prev = list->prev;
         if (list->prev != NULL) list->prev->next = list->next;
      }
      if (list == piece->parent->children) piece->parent->children = list->next;
      if (list != NULL) FREE ((void *) list);
   }
   xml_free (piece);
}
XMLAPI XML * xml_first(XML * xml)
{
   if (xml == NULL) return NULL;
   if (xml->children == NULL) return NULL;
   return (xml->children->element);
}
XMLAPI XML * xml_firstelem(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return NULL;
   list = xml->children;
   while (list != NULL) {
      if (list->element->name != NULL) break;
      list = list->next;
   }
   if (list != NULL) return (list->element);
   return NULL;
}

XMLAPI XML * xml_last(XML *xml)
{
   ELEMENTLIST *list;
   list = xml->children;
   if (list == NULL) return NULL;
   while (list->next != NULL) list = list->next;
   return (list->element);
}
XMLAPI XML * xml_lastelem(XML *xml)
{
   ELEMENTLIST *list;
   list = xml->children;
   if (list == NULL) return NULL;
   while (list->next != NULL) list = list->next;
   while (list != NULL) {
      if (list->element->name != NULL) break;
      list = list->prev;
   }
   if (list != NULL) return (list->element);
   return NULL;
}
XMLAPI XML * xml_next(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   if (list->next == NULL) return (NULL);
   return (list->next->element);
}
XMLAPI XML * xml_nextelem(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   while (list->next != NULL) {
      if (list->next->element->name != NULL) break;
      list = list->next;
   }
   if (list->next == NULL) return (NULL);
   return (list->next->element);
}
XMLAPI XML * xml_prev(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   if (list->prev == NULL) return (NULL);
   return (list->prev->element);
}
XMLAPI XML * xml_prevelem(XML * xml)
{
   ELEMENTLIST *list;
   if (xml == NULL) return (NULL);
   if (xml->parent == NULL) return (NULL);
   list = xml->parent->children;
   while (list != NULL && list->element != xml) list = list->next;
   if (list == NULL) return (NULL);
   while (list->prev != NULL) {
      if (list->prev->element->name != NULL) break;
      list = list->prev;
   }
   if (list->prev == NULL) return (NULL);
   return (list->prev->element);
}
XMLAPI XML * xml_loc (XML * start, const char * loc)
{
   char * mark;
   const char * attrval;
   char piece[64];
   int i;
   int count;

   if (!loc) return (start);
   if (!*loc) return (start);

   if (*loc == '.') return (xml_loc (xml_first (start), loc + 1));

   while (start && start->name == NULL) start = xml_next (start);
   if (!start) return (NULL);

   while (*loc == ' ') loc++;
   i = 0;
   while (*loc && *loc != '.') piece[i++] = *loc++;
   piece[i] = '\0';
   if (*loc) loc++;
   while (*loc == ' ') loc++;

   mark = strchr (piece, ']');
   if (mark) *mark = '\0';
   mark = strchr (piece, '(');
   if (mark) {
      *mark++ = '\0';
      count = atoi (mark);
      mark = NULL;
   } else {
      count = 0;
      mark = strchr (piece, '[');
      if (mark) {
         *mark++ = '\0';
      }
   }

   while (start) {
      if (start->name == NULL) {
         start = xml_next (start);
         continue;
      }
      if (strcmp (start->name, piece)) {
         start = xml_next (start);
         continue;
      }
      if (count) {
         count --;
         start = xml_next (start);
         continue;
      }
      if (!mark) {
         if (*loc) return (xml_loc (xml_first (start), loc));
         return (start);
      }
      attrval = xml_attrval(start, "id");
      if (attrval) {
         if (strcmp (attrval, mark)) {
            start = xml_next (start);
            continue;
         }
         if (*loc) return (xml_loc (xml_first(start), loc));
         return (start);
      }
      attrval = xml_attrval(start, "name");
      if (attrval) {
         if (strcmp (attrval, mark)) {
            start = xml_next (start);
            continue;
         }
         if (*loc) return (xml_loc (xml_first(start), loc));
         return (start);
      }
   }
   return (NULL);
}

XMLAPI XML * xml_locf (XML *start, const char * loc, ...)
{
   va_list args;
   char * locator;
   XML * found;

   va_start (args, loc);
   locator = _xml_string_format (loc, args);
   va_end (args);

   found = xml_loc (start, locator);
   FREE (locator);
   return (found);
}
XMLAPI void xml_getloc (XML * xml, char *loc, int len)
{
   int s;
   int count;
   XML * sib;
   if (xml->parent != NULL) {
      xml_getloc (xml->parent, loc, len);
   } else {
      *loc = '\0';
   }
   s = strlen (loc);
   if (s > 0 && s < len-1) { strcat (loc, "."); s++; }
   len -= s;
   loc += s;
   if (strlen(xml->name) < len) {
      strcpy (loc, xml->name);
   } else {
      strncpy (loc, xml->name, len-1);
      loc[len-1] = '\0';
   }
   if (xml->parent == NULL) return;
   sib = xml_first(xml->parent);
   count = 0;
   while (sib != xml && sib != NULL) {
      if (sib->name != NULL) {
         if (!strcmp (sib->name, xml->name)) count ++;
      }
      sib = xml_next(sib);
   }
   if (count > 0 && s > 4) {
      strcat (loc, "(");
      sprintf (loc + strlen(loc), "%d", count);
      strcat (loc, ")");
   }
}
char * _xml_getlocbuf_buf (XML * xml, char *buffer, int *cursize, int *curptr)
{
   int s;
   int count;
   XML * sib;
   char countbuf[sizeof(int) * 3 + 1];

   if (xml->parent != NULL) {
      _xml_getlocbuf_buf (xml->parent, buffer, cursize, curptr);
      buffer = _xml_string_tackon (buffer, cursize, curptr, ".");
   }

   buffer = _xml_string_tackon (buffer, cursize, curptr, xml->name);

   if (xml->parent == NULL) return (buffer);

   sib = xml_first(xml->parent);
   count = 0;
   while (sib != xml && sib != NULL) {
      if (sib->name != NULL) {
         if (!strcmp (sib->name, xml->name)) count ++;
      }
      sib = xml_next(sib);
   }
   if (count > 0) {
      buffer = _xml_string_tackon (buffer, cursize, curptr, "(");
      sprintf (countbuf, "%d", count);
      buffer = _xml_string_tackon (buffer, cursize, curptr, countbuf);
      buffer = _xml_string_tackon (buffer, cursize, curptr, ")");
   }

   return (buffer);
}

XMLAPI char * xml_getlocbuf (XML * xml)
{
   char * buf = (char *) MALLOC (256);
   int  cursize = 256;
   int  curptr = 0;

   *buf = '\0';
   return (_xml_getlocbuf_buf (xml, buf, &cursize, &curptr));
}
#ifndef PYTHON
void startElement(void *userData, const char *name, const char **atts)
{
   XML ** parent;
   XML * element;

   element = xml_create (name);
   while (*atts) {
      xml_set(element, atts[0], atts[1]);
      atts += 2;
   }

   parent = (XML **) userData;
   if (*parent != NULL) xml_append (*parent, element);
   *parent = element;
}
void endElement(void *userData, const char *name)
{
   XML ** element;

   element = (XML **) userData;
   if ((*element)->parent != NULL) *element = (*element)->parent;
}
void charData (void *userData, const XML_Char *s, int len) {
   XML ** parent;

   parent = (XML **) userData;
   xml_append (*parent, xml_createtextlen ((char *) s, len));
}

XMLAPI XML * xml_read (FILE * file)
{
   XML_Parser parser;
   char buf[BUFSIZ];
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   do {
      len = fread(buf, 1, sizeof(buf), file);
      done = len < sizeof(buf);
      if (!XML_Parse(parser, buf, len, done)) {
         xml_free (ret);
         XML_ParserFree(parser);
         return NULL;
      }
   } while (!done);
   XML_ParserFree(parser);

   return (ret);
}
XMLAPI XML * xml_read_error (FILE * file)
{
   XML_Parser parser;
   char buf[BUFSIZ];
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   do {
      len = fread(buf, 1, sizeof(buf), file);
      done = len < sizeof(buf);
      if (!XML_Parse(parser, buf, len, done)) {
         xml_free (ret);
         ret = xml_create ("xml-error");
         xml_setnum (ret, "code", XML_GetErrorCode(parser));
         xml_set    (ret, "message", XML_ErrorString(XML_GetErrorCode(parser)));
         xml_setnum (ret, "line", XML_GetCurrentLineNumber(parser));
         done = 1;
      }
   } while (!done);
   XML_ParserFree(parser);

   return (ret);
}
XMLAPI XML * xml_parse (const char * buf)
{
   XML_Parser parser;
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   len = strlen (buf);
   if (!XML_Parse(parser, buf, len, done)) {
      xml_free (ret);
      ret = xml_create ("xml-error");
      xml_setnum (ret, "code", XML_GetErrorCode(parser));
      xml_set    (ret, "message", XML_ErrorString(XML_GetErrorCode(parser)));
      xml_setnum (ret, "line", XML_GetCurrentLineNumber(parser));
   }
   XML_ParserFree(parser);

   return (ret);
}
XMLAPI XML * xml_parse_general (void * data, size_t (*get_buf) (char * buf, size_t chunk, size_t num, void *data))
{
   XML_Parser parser;
   char buf[BUFSIZ];
   int done;
   XML * ret;
   size_t len;

   ret = NULL;
   parser = XML_ParserCreate(NULL);

   XML_SetUserData (parser, (void *) &ret);

   XML_SetElementHandler(parser, startElement, endElement);
   XML_SetCharacterDataHandler(parser, charData);

   done = 0;

   do {
      len = (*get_buf)(buf, 1, sizeof(buf), data);
      done = len < sizeof(buf)-1; /* Worst that can happen: we call get_buf for an empty buffer. */
      if (len > strlen (buf)) len = strlen (buf);
      if (len == 0) break;
      if (!XML_Parse(parser, buf, len, done)) {
         if (ret) xml_free (ret);
         ret = xml_create ("xml-error");
         xml_setnum (ret, "code", XML_GetErrorCode(parser));
         xml_set    (ret, "message", XML_ErrorString(XML_GetErrorCode(parser)));
         xml_setnum (ret, "line", XML_GetCurrentLineNumber(parser));
         done = 1;
      }
   } while (!done);
   XML_ParserFree(parser);

   if (!ret) {
      ret = xml_create ("xml-error");
      xml_setnum (ret, "code", 3);
      xml_set    (ret, "message", "no data received");
      xml_setnum (ret, "line", 0);
   }

   return (ret);
}
#endif
XMLAPI XML * xml_copy (XML * orig)
{
   XML * copy = NULL;
   char * text;
   XML * child;
   ATTR * attr;

   if (!orig) return copy;

   if (!orig->name) {
      text = xml_string (orig);
      copy = xml_createtext (text);
      FREE (text);
      return copy;
   }

   copy = xml_create (orig->name);
   attr = orig->attrs;
   while (attr) {
      xml_set (copy, attr->name, attr->value);
      attr = attr->next;
   }

   child = xml_first (orig);
   while (child) {
      xml_append (copy, xml_copy (child));
      child = xml_next (child);
   }

   return (copy);
}
XMLAPI XML * xml_copyinto (XML * target, XML * source)
{
   char * text;
   XML * child;
   ATTR * attr;

   if (!source) return target;
   if (!source->name) {
      text = xml_string (source);
      if (target) {
         xml_append (target, xml_createtext (text));
         FREE (text);
         return (target);
      }
      target = xml_createtext (text);
      return (target);
   }

   if (!target) target = xml_create (source->name);

   attr = source->attrs;
   while (attr) {
      xml_set (target, attr->name, attr->value);
      attr = attr->next;
   }

   child = xml_first (source);
   while (child) {
      xml_append (target, xml_copy (child));
      child = xml_next (child);
   }

   return (target);
}
XMLAPI XML_ATTR * xml_attrfirst (XML * element)
{
   if (!element) return NULL;
   return element->attrs;
}
XMLAPI XML_ATTR * xml_attrnext (XML_ATTR * attr)
{
   if (!attr) return NULL;
   return attr->next;
}
const char *xml_attrname  (XML_ATTR * attr) { return (attr->name);  }
const char *xml_attrvalue (XML_ATTR * attr) { return (attr->value); }
XMLAPI int xml_is (XML * xml, const char * name)
{
   if (!xml) return 0;
   if (!xml->name) return 0;
   if (!strcmp (xml->name, name)) return 1;
   return 0;
}
XMLAPI int xml_is_element (XML * xml)
{
   if (!xml) return 0;
   if (!xml->name) return 0;
   return 1;
}
XMLAPI const char * xml_name (XML * xml)
{
   if (!xml) return 0;
   return xml->name;
}
XMLAPI XML * xml_parent (XML * xml)
{
   if (!xml) return 0;
   return xml->parent;  /* Null if none, guaranteed. */
}
