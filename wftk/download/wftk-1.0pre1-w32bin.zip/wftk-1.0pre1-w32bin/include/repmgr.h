#ifndef REPMGR_H
#define REPMGR_H
#include <stdio.h>
#include <string.h>
#ifndef XMLAPI_H
#include "xmlobj.h"
#endif
#include "wftk_session.h"

#ifndef WFTK_EXPORT
#define WFTK_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

WFTK_EXPORT XML * repos_open (XML * repository, WFTK_MODULE_LOOKUP_FN * lookup_function);
WFTK_EXPORT XML * repos_open_file (const char * repfile, WFTK_MODULE_LOOKUP_FN * lookup_function);
WFTK_EXPORT void  repos_close     (XML * repository);

WFTK_EXPORT int   repos_publish_all   (XML * repository);
WFTK_EXPORT int   repos_publish_list  (XML * repository, const char * list);
WFTK_EXPORT int   repos_publish_obj   (XML * repository, const char * list, const char * key);
WFTK_EXPORT int   repos_publish_pages (XML * repository);
WFTK_EXPORT int   repos_publish_page  (XML * repository, const char * page);

WFTK_EXPORT int   repos_create  (XML * repository, const char * list);
WFTK_EXPORT int   repos_drop    (XML * repository, const char * list);
WFTK_EXPORT XML * repos_defn    (XML * repository, const char * list);
WFTK_EXPORT XML * repos_form    (XML * repository, const char * list);
WFTK_EXPORT int   repos_define  (XML * repository, const char * list, XML * defn);

WFTK_EXPORT int   repos_add (XML * repository, const char * list, XML * object);
WFTK_EXPORT int   repos_del (XML * repository, const char * list, const char * key);
WFTK_EXPORT int   repos_mod (XML * repository, const char * list, XML * object, const char * key);


WFTK_EXPORT XML * repos_list       (XML * repository, XML * list);
WFTK_EXPORT XML * repos_list_first (XML * repository, XML * list);
WFTK_EXPORT XML * repos_list_next  (XML * repository, XML * list);
WFTK_EXPORT XML * repos_changes    (XML * repository, XML * list, const char *date, const char * list_id);
WFTK_EXPORT XML * repos_snapshot   (XML * repository, const char * list_id);

WFTK_EXPORT const char * repos_getkey (XML * repository, const char * list, XML * object);

WFTK_EXPORT XML * repos_get     (XML * repository, const char * list, const char * key);
WFTK_EXPORT XML * repos_edit    (XML * repository, const char * list, const char * key);
WFTK_EXPORT XML * repos_display (XML * repository, const char * list, const char * key);

WFTK_EXPORT char * repos_getvalue (XML * repository, const char * list, const char * key, const char * field);
WFTK_EXPORT void   repos_setvalue (XML * repository, const char * list, const char * key, const char * field, const char * value);

WFTK_EXPORT XML * repos_get_layout (XML * repository, const char * layout_id);
WFTK_EXPORT void  repos_xml_free (XML * xml); /* Used to reduce DLL dependencies. */

WFTK_EXPORT int   repos_push     (XML * repository, const char *list_id, const char *remote_id);
WFTK_EXPORT int   repos_push_all (XML * repository, const char *list_id, const char *remote_id);
WFTK_EXPORT int   repos_pull     (XML * repository, const char *list_id, const char *remote_id, XML * changelist);
WFTK_EXPORT int   repos_pull_all (XML * repository, const char *list_id, const char *remote_id, XML * changelist);
WFTK_EXPORT int   repos_synch    (XML * repository, const char *list_id, const char *remote_id, XML * changelist);
WFTK_EXPORT int   repos_mark_time (XML * repository, const char *attr);

WFTK_EXPORT XML * repos_attach_open (XML * repository, const char *list_id, const char * key, const char * field, const char * filename);
WFTK_EXPORT int   repos_attach_write (void * buf, size_t size, size_t number, XML * handle);
WFTK_EXPORT int   repos_attach_cancel (XML * handle);
WFTK_EXPORT int   repos_attach_close (XML * repository, XML * handle);
WFTK_EXPORT int   repos_attach (XML * repository, const char * list_id, const char * key, const char * field, const char * filename, FILE * incoming);

WFTK_EXPORT XML * repos_retrieve_open (XML * repository, const char * list_id, const char * key, const char * field);
WFTK_EXPORT int   repos_retrieve_read (void * buf, size_t size, size_t number, XML * handle);
WFTK_EXPORT int   repos_retrieve_close (XML * handle);
WFTK_EXPORT int   repos_retrieve (XML * repository, const char * list_id, const char * key, const char * field, FILE * outgoing);

#ifdef __cplusplus
}
#endif
#endif
