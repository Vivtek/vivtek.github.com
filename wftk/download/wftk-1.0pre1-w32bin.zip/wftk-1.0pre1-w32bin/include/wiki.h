#ifndef WIKI_H
#define WIKI_H
#include <stdio.h>
#include <string.h>
#include "xmlapi.h"
#include "repmgr.h"

#ifndef WFTK_EXPORT
#define WFTK_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

WFTK_EXPORT XML * wiki_parse (const char * src);
WFTK_EXPORT XML * wiki_build (XML * context, XML * wiki, XML * todo);

#ifdef __cplusplus
}
#endif
#endif
