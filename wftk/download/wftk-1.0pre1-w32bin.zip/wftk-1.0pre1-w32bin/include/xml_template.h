XMLAPI XML * xml_template_apply (XML * context, XML * template, XML * record, char * valuecallback ());
XMLAPI XML * xml_template_apply_list (XML * context, XML * template, XML * list, XML * filter, char * valuecallback ());
