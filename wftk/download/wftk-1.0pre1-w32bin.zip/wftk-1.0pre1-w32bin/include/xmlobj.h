#include "xmlapi.h"

/* Basic functionality: */
XMLAPI char * xmlobj_get       (XML * obj, XML * class, const char * field);
XMLAPI int    xmlobj_set       (XML * obj, XML * class, const char * field, const char * value);
XMLAPI char * xmlobj_format    (XML * obj, XML * class, const char * format);
XMLAPI char * xmlobj_formatlong(XML * obj, XML * class, const char * format);
XMLAPI XML *  xmlobj_template  (XML * obj, XML * class, XML * template);
XMLAPI char * xmlobj_getkey    (XML * obj, XML * class);

XMLAPI XML *  xmlobj_values    (XML * obj, XML * class, const char * context, const char * userid);

/* Diff/patch functionality: */
XMLAPI XML *  xmlobj_diff      (XML * obj, XML * class, XML * changed);
XMLAPI XML *  xmlobj_undiff    (XML * obj, XML * class, XML * diff);
XMLAPI XML *  xmlobj_patch     (XML * obj, XML * class, XML * diff);

/* Versioning/list functionality (not yet implemented): */
XMLAPI char * xmlobj_getver    (XML * obj, XML * class, const char * field, const char * ver);
XMLAPI char * xmlobj_getcurver (XML * obj, XML * class, const char * field);
XMLAPI int    xmlobj_getvernum (XML * obj, XML * class, const char * field);
XMLAPI XML *  xmlobj_getlist   (XML * obj, XML * class, const char * field);
XMLAPI int    xmlobj_setver    (XML * obj, XML * class, const char * field, const char * value);
XMLAPI int    xmlobj_setcurver (XML * obj, XML * class, const char * field, const char * verid);
XMLAPI int    xmlobj_addval    (XML * obj, XML * class, const char * field, const char * value);
XMLAPI int    xmlobj_delval    (XML * obj, XML * class, const char * field, const char * value);
